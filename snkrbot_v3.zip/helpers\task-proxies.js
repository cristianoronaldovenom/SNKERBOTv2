// Role-aware proxy resolution.
//
// A task can have separate monitoring and checkout endpoints. The checkout
// endpoint remains sticky for the entire checkout run, while monitoring can use
// an independent endpoint. A provider gateway may be supplied via environment
// variables without storing its credentials in SQLite/Postgres.
import db from '../db/index.js';
import { canStartResidentialSession, remainingResidentialRatio } from './residential-budget.js';

const ROLE_ENV = {
  monitor: 'RESIDENTIAL_MONITOR_PROXY_URL',
  checkout: 'RESIDENTIAL_CHECKOUT_PROXY_URL',
};

const commonResidentialEnv = 'RESIDENTIAL_PROXY_URL';

const residentialRatioThreshold = (() => {
  const raw = Number(process.env.RESIDENTIAL_MIN_RATIO || 0.05);
  if (!Number.isFinite(raw)) return 0.05;
  return Math.max(0, Math.min(1, raw));
})();

const residentialHeadroomOk = (role) => {
  const ratio = remainingResidentialRatio(role);
  if (ratio === null) return true;
  return ratio >= residentialRatioThreshold;
};

const parseProxyUrl = (raw, source) => {
  if (!raw) return null;
  try {
    const url = new URL(String(raw));
    if (!['http:', 'https:'].includes(url.protocol)) return null;
    const port = Number(url.port || 80);
    if (!url.hostname || !Number.isInteger(port) || port < 1 || port > 65535) return null;
    return {
      id: null,
      host: url.hostname,
      port,
      username: decodeURIComponent(url.username || ''),
      password: decodeURIComponent(url.password || ''),
      proxy_type: 'residential',
      label: 'Residential gateway',
      source,
      ephemeral: true,
    };
  } catch (_) {
    return null;
  }
};

export const getResidentialProxy = (role) => {
  const roleEnv = ROLE_ENV[role] || ROLE_ENV.checkout;
  return parseProxyUrl(process.env[roleEnv], roleEnv)
    || parseProxyUrl(process.env[commonResidentialEnv], commonResidentialEnv);
};

export const isResidentialGatewayConfigured = (role = 'checkout') => Boolean(getResidentialProxy(role));

export const proxyModes = Object.freeze(['auto', 'assigned', 'residential_env', 'direct']);

const safeMode = (mode) => proxyModes.includes(String(mode || '').toLowerCase())
  ? String(mode).toLowerCase()
  : 'auto';

export const resolveTaskProxy = async (task, role) => {
  const prefix = role === 'monitor' ? 'monitor' : 'checkout';
  const mode = safeMode(task?.[`${prefix}_proxy_mode`]);
  const explicitId = task?.[`${prefix}_proxy_id`] ?? null;

  if (mode === 'direct') return { proxy: null, mode, source: 'direct' };

  if (mode === 'assigned') {
    if (!explicitId) return { proxy: null, mode, source: 'direct' };
    const proxy = await db('proxies').where({ id: explicitId, is_deleted: false }).first();
    if (proxy?.proxy_type === 'residential' && (!canStartResidentialSession(role) || !residentialHeadroomOk(role))) {
      return { proxy: null, mode, source: 'residential_budget_exhausted' };
    }
    return { proxy: proxy || null, mode, source: proxy ? 'assigned' : 'missing' };
  }

  if (mode === 'residential_env') {
    const proxy = getResidentialProxy(role);
    if (proxy && (!canStartResidentialSession(role) || !residentialHeadroomOk(role))) {
      return { proxy: null, mode, source: 'residential_budget_exhausted' };
    }
    return { proxy, mode, source: proxy ? 'residential_env' : 'missing' };
  }

  // Auto mode is intentionally direct-first for monitoring. A residential
  // assignment is retained only as a fallback for challenge recovery /
  // prewarm; it is NOT used for every polling request. Non-residential
  // assignments remain eligible for normal monitor routing.
  if (explicitId) {
    const proxy = await db('proxies').where({ id: explicitId, is_deleted: false }).first();
    if (proxy) {
      if (role === 'monitor' && proxy.proxy_type === 'residential') {
        if (!canStartResidentialSession(role) || !residentialHeadroomOk(role)) {
          return { proxy: null, fallbackProxy: null, mode: 'auto', source: 'direct_residential_budget_exhausted' };
        }
        return { proxy: null, fallbackProxy: proxy, mode: 'auto', source: 'direct_residential_fallback' };
      }
      if (proxy.proxy_type === 'residential' && (!canStartResidentialSession(role) || !residentialHeadroomOk(role))) {
        return { proxy: null, mode: 'auto', source: 'residential_budget_exhausted' };
      }
      return { proxy, mode: 'auto', source: 'assigned' };
    }
  }

  if (task?.proxy_id) {
    const legacy = await db('proxies').where({ id: task.proxy_id, is_deleted: false }).first();
    if (legacy) {
      if (role === 'monitor' && legacy.proxy_type === 'residential') {
        if (!canStartResidentialSession(role) || !residentialHeadroomOk(role)) {
          return { proxy: null, fallbackProxy: null, mode: 'auto', source: 'direct_residential_budget_exhausted' };
        }
        return { proxy: null, fallbackProxy: legacy, mode: 'auto', source: 'direct_residential_fallback' };
      }
      if (legacy.proxy_type === 'residential' && (!canStartResidentialSession(role) || !residentialHeadroomOk(role))) {
        return { proxy: null, mode: 'auto', source: 'residential_budget_exhausted' };
      }
      return { proxy: legacy, mode: 'auto', source: 'legacy' };
    }
  }

  // Monitoring remains direct in Auto mode. If no DB fallback exists, the
  // runtime can use the configured monitor residential gateway only when it
  // actually needs a challenge-recovery path. Checkout still resolves its
  // own residential endpoint normally.
  const residential = getResidentialProxy(role);
  if (residential && canStartResidentialSession(role) && residentialHeadroomOk(role)) {
    if (role === 'monitor') {
      return { proxy: null, fallbackProxy: residential, mode: 'auto', source: 'direct_residential_fallback' };
    }
    return { proxy: residential, mode: 'auto', source: 'residential_env' };
  }
  if (residential && role === 'monitor') {
    return { proxy: null, fallbackProxy: null, mode: 'auto', source: 'direct_residential_budget_exhausted' };
  }
  if (residential) return { proxy: null, mode: 'auto', source: 'residential_budget_exhausted' };

  return { proxy: null, fallbackProxy: null, mode: 'auto', source: 'direct' };
};

export const sanitizeProxyMeta = (proxy) => proxy ? ({
  id: proxy.id ?? null,
  host: proxy.host,
  port: proxy.port,
  proxy_type: proxy.proxy_type || 'unknown',
  label: proxy.label || '',
  source: proxy.source || 'database',
  ephemeral: Boolean(proxy.ephemeral),
}) : null;
