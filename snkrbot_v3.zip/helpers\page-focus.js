// Real focus and visibility for headful pages.
//
// Under headless, the stealth script forces hasFocus() to true and
// visibilityState to 'visible' because headless Chrome really does report
// otherwise. Under headful that patching is not just unnecessary — it is a
// contradiction, because a real window genuinely blurs when another window takes
// focus, and a page claiming to be visible and focused while the compositor says
// otherwise is measurable.
//
// Bringing the window to the front and driving the Page focus lifecycle lets the
// browser report the TRUTH, which is worth more than a consistent lie. The patch
// stays in place as a fallback: on the rare platform where bringToFront is a
// no-op the page is still coherent rather than newly broken.

import logger from './logger.js';

// Nudge the page to the foreground and confirm the runtime agrees before letting
// anything read it.
export const bringToFront = async (page) => {
  try {
    await page.bringToFront();
  } catch (err) {
    logger.debug(`[Focus] bringToFront unavailable: ${err.message}`);
    return { foreground: false, reason: 'bring_to_front_failed' };
  }

  // One animation frame is not enough on a compositor — the visibility state
  // flips on the next lifecycle tick. Poll briefly rather than sleeping blindly.
  for (let attempt = 0; attempt < 8; attempt++) {
    const state = await page.evaluate(() => ({
      visibility: typeof document.visibilityState === 'string' ? document.visibilityState : 'unknown',
      focused: typeof document.hasFocus === 'function' ? document.hasFocus() : null
    })).catch(() => null);

    if (state?.visibility === 'visible' && state.focused === true) {
      return { foreground: true, reason: 'confirmed' };
    }
    await new Promise((r) => setTimeout(r, 40));
  }

  const last = await page.evaluate(() => ({
    visibility: document.visibilityState,
    focused: document.hasFocus()
  })).catch(() => null);
  logger.debug(`[Focus] Page did not reach confirmed focus (visibility=${last?.visibility}, focused=${last?.focused})`);
  return { foreground: false, reason: 'unconfirmed' };
};

// Is the page currently foreground, without changing anything? Cheaper than
// bringToFront for a caller that only wants to re-check before a click.
export const isForeground = async (page) => {
  const state = await page.evaluate(() => ({
    visibility: document.visibilityState,
    focused: typeof document.hasFocus === 'function' ? document.hasFocus() : null
  })).catch(() => null);
  return Boolean(state && state.visibility === 'visible' && state.focused === true);
};
