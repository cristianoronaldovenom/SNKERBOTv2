// Per-browser RSS watchdog policy.
//
// `memory-guard.js` answers "may we launch ANOTHER browser?". It cannot answer
// "is the browser we already have quietly leaking?", and a parked prewarm
// browser is exactly the shape that leaks: it stays alive for 8 minutes holding
// a warmed page, and a single SPA that timers into a detached document tree can
// add tens of MB a minute. On a 1-2 GB host that is the difference between a
// warm checkout and the OOM killer.
//
// So this module is deliberately narrow and pure: given a browser's own RSS and
// page count it returns keep / recycle / evict. `cluster.js`-level policy is not
// duplicated here — no launch args, no admission math, no proxy concerns.
//
// Contract: pure, I/O-free, advisory. A `recycle` verdict is a hint to close and
// relaunch; `evict` means even relaunching is not worth it right now.

const MB = 1024 * 1024;

const num = (v, fallback) => {
  const n = Number(v);
  return Number.isFinite(n) && n >= 0 ? n : fallback;
};

// Budget per idle/parked browser, scaled to the host. A parked browser has
// nothing to do, so it gets a much tighter ceiling than one mid-checkout.
const PARKED_FLOOR_MB = Math.max(96, num(process.env.RSS_PARKED_FLOOR_MB, 180));
const ACTIVE_FLOOR_MB = Math.max(160, num(process.env.RSS_ACTIVE_FLOOR_MB, 420));
// Hard ceiling regardless of host: past this a single headless tab is almost
// certainly stuck, not merely heavy.
const ABSOLUTE_MAX_MB = Math.max(512, num(process.env.RSS_ABSOLUTE_MAX_MB, 1536));

export const VERDICT = Object.freeze({ KEEP: 'keep', RECYCLE: 'recycle', EVICT: 'evict' });

// Share of host memory one browser may take. Parked browsers get a small share
// because the whole point is to have room for the checkout that adopts them.
const parkedShare = () => Math.min(0.22, Math.max(0.05, num(process.env.RSS_PARKED_SHARE, 0.12)));
const activeShare = () => Math.min(0.55, Math.max(0.15, num(process.env.RSS_ACTIVE_SHARE, 0.3)));

export const rssBudgetMb = ({ hostLimitBytes = 0, parked = false } = {}) => {
  const hostMb = hostLimitBytes > 0 ? hostLimitBytes / MB : 0;
  const share = hostMb > 0 ? hostMb * (parked ? parkedShare() : activeShare()) : 0;
  const floor = parked ? PARKED_FLOOR_MB : ACTIVE_FLOOR_MB;
  return Math.round(Math.min(ABSOLUTE_MAX_MB, Math.max(floor, share)));
};

// Verdict for one browser. `growthMbPerMin` is optional but decisive: a browser
// well under its budget that is still climbing will blow it, so it recycles
// early rather than at the moment of adoption.
export const assessBrowser = ({
  rssBytes = 0,
  pageCount = 0,
  hostLimitBytes = 0,
  parked = false,
  growthMbPerMin = null,
  ageMs = null
} = {}) => {
  const rssMb = Math.round(num(rssBytes, 0) / MB);
  const budgetMb = rssBudgetMb({ hostLimitBytes, parked });
  const ratio = budgetMb > 0 ? rssMb / budgetMb : 0;
  const reasons = [];

  // An unreadable RSS is not a reason to kill anything.
  if (rssMb <= 0) return { verdict: VERDICT.KEEP, rssMb, budgetMb, ratio: 0, reasons: ['no_measurement'] };

  if (rssMb >= ABSOLUTE_MAX_MB) {
    reasons.push('absolute_max');
    return { verdict: VERDICT.EVICT, rssMb, budgetMb, ratio, reasons };
  }

  if (ratio >= 1) {
    reasons.push('over_budget');
    // A parked browser over budget is simply not worth keeping at all.
    return { verdict: parked ? VERDICT.EVICT : VERDICT.RECYCLE, rssMb, budgetMb, ratio, reasons };
  }

  const growth = Number(growthMbPerMin);
  if (Number.isFinite(growth) && growth > 0) {
    // Time until the budget is breached at the current rate. Acting at the
    // breach instant is too late — relaunching a happy checkout is disruptive, so
    // trigger once the breach is under ~2 minutes away.
    const headroomMb = budgetMb - rssMb;
    const minutesToBreach = headroomMb / growth;
    if (minutesToBreach <= 2) {
      reasons.push(`growth_${growth.toFixed(0)}mb_per_min`);
      return { verdict: parked ? VERDICT.EVICT : VERDICT.RECYCLE, rssMb, budgetMb, ratio, reasons };
    }
    if (growth > 25) reasons.push('leaking');
  }

  // A parked browser holding many tabs is not parked, it is accumulating.
  if (parked && pageCount > 2) reasons.push('too_many_pages');

  // Soft zone: recycle on the next opportunity, do not evict now.
  if (ratio >= 0.85) {
    reasons.push('near_budget');
    return { verdict: VERDICT.RECYCLE, rssMb, budgetMb, ratio, reasons };
  }

  // Very long-lived parked browser: recycle as hygiene once it is past TTL even
  // when small, so a slow leak cannot run forever.
  if (parked && Number.isFinite(Number(ageMs)) && Number(ageMs) > 20 * 60_000) {
    reasons.push('aged_out');
    return { verdict: VERDICT.RECYCLE, rssMb, budgetMb, ratio, reasons };
  }

  return { verdict: VERDICT.KEEP, rssMb, budgetMb, ratio, reasons };
};

export const rssWatchdogConfig = () => ({
  parkedFloorMb: PARKED_FLOOR_MB,
  activeFloorMb: ACTIVE_FLOOR_MB,
  absoluteMaxMb: ABSOLUTE_MAX_MB,
  parkedShare: parkedShare(),
  activeShare: activeShare()
});
