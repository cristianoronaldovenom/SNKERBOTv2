import { tryRequestFirstAddToCart } from '../../helpers/browser-request-atc.js';
import { tuneSitePage } from '../../helpers/site-checkout-fastpath.js';
import logger from '../../helpers/logger.js';
import { humanType, humanClick } from '../../helpers/human-type.js';
import { FillReport, verifyCartHasItem } from '../../helpers/autofill-utils.js';
import {
  guardedGoto, preOrderGuard, postClickGuard, takeFailureScreenshot
} from '../../helpers/checkout-guards.js';
import { captureOrderSuccess } from '../../helpers/order-capture.js';

import { waitForAnySelector } from '../../helpers/site-runtime.js';
import { assertActionButtonIntent } from '../../helpers/checkout-controls.js';

const TIMEOUT = 15000;

const SELECTORS = {
  addToCart: [
    'input#add-to-cart-button',
    'input[name="submit.add-to-cart"]',
    'span#submit\\.add-to-cart input',
    'button#add-to-cart-button'
  ],
  qtySelect: [
    'select#quantity',
    'select[name="quantity"]',
    'input[name="quantity"]'
  ],
  buyNow: [
    'input#buy-now-button',
    'input[name="submit.buy-now"]'
  ],
  proceedToCheckout: [
    'input[name="proceedToRetailCheckout"]',
    'a[href*="/gp/buy/spc"]',
    'input.a-button-input[aria-labelledby*="checkout"]',
    'span#sc-buy-box-ptc-button input'
  ],
  placeOrder: [
    'input[name="placeYourOrder1"]',
    'span#submitOrderButtonId input',
    'input.place-your-order-button',
    'input#bottomSubmitOrderButtonId'
  ],
  orderConfirmation: [
    '#thank-you-page',
    '.order-confirmation',
    'h1.a-spacing-none',
    '#widget-purchaseConfirmationStatus'
  ],
  signInEmail: ['input[name="email"]', 'input#ap_email'],
  signInPassword: ['input[name="password"]', 'input#ap_password'],
  signInSubmit: ['input#signInSubmit', 'input[type="submit"]'],
  cartWidget: ['a#nav-cart', 'a[href*="/cart"]']
};

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const findFirst = async (page, selectorList, timeout = TIMEOUT) => {
  const selector = await waitForAnySelector(page, selectorList, { timeout });
  if (!selector) return null;
  const el = await page.$(selector).catch(() => null);
  return el ? { el, selector } : null;
};

const clickFirst = async (page, selectorList, { stage = '' } = {}) => {
  const found = await findFirst(page, selectorList, TIMEOUT);
  if (!found) throw new Error(`Could not find clickable element at stage "${stage}" — tried [${selectorList.join(', ')}]`);
  await humanClick(page, found.selector);
  return found.selector;
};

const setQuantity = async (page, quantity) => {
  if (!quantity || quantity <= 1) return;
  const found = await findFirst(page, SELECTORS.qtySelect, 5000);
  if (!found) { logger.warn('[Amazon] Quantity selector not found'); return; }
  const tag = await found.el.evaluate((el) => el.tagName.toLowerCase());
  if (tag === 'select') {
    await page.select(found.selector, String(quantity)).catch(() => {});
  } else {
    await found.el.click({ clickCount: 3 }).catch(() => {});
    await humanType(page, found.selector, String(quantity));
  }
  await sleep(500);
  logger.info(`[Amazon] Quantity set to ${quantity}`);
};

// Amazon-specific challenge detection. Each throws a loud, pre-classified
// `human_required` failure so the runner stops, alerts, and marks the task
// `needs_human` instead of retrying (no automated solver exists for these).
const throwHuman = (message) => {
  const err = new Error(message);
  err.failureType = 'human_required';
  return err;
};

const detectRobotCheck = async (page) => {
  const robot = await page.evaluate(() =>
    /enter the characters you see below|type the characters you see in this image|robot check|we just need to make sure you're not a robot|api-services-support@amazon/i
      .test(document.body?.innerText || '')
  ).catch(() => false);
  if (robot) {
    throw throwHuman('captcha_required: Amazon image CAPTCHA / robot check detected — rotate proxy and retry manually');
  }
};

const detectOtp = async (page) => {
  const otp = await page.evaluate(() => {
    // The OTP input is the authoritative signal. Body text is only trusted on
    // Amazon's auth pages (/ap/*) so a security-product PDP that mentions
    // "two-step verification" in its description can't false-abort a checkout.
    if (document.querySelector('#auth-mfa-otpcode, input[name="otpCode"]')) return true;
    const onAuthPage = /\/ap\/|\/mfa/i.test(location.pathname + location.search);
    return onAuthPage && /two-step verification|enter the otp|one[- ]time password|verification code sent/i
      .test(document.body?.innerText || '');
  }).catch(() => false);
  if (otp) {
    throw throwHuman('mfa_required: Amazon two-step verification (OTP) prompt — cannot complete unattended');
  }
};

const detectPaymentVerification = async (page) => {
  // Anchored patterns only — bare "3ds" is dropped because it collides with
  // product titles (e.g. "Nintendo 3DS") on the order-review page.
  const v = await page.evaluate(() =>
    /3-?d secure|verify your card|additional authentication|otp sent to your bank/i
      .test(document.body?.innerText || '')
  ).catch(() => false);
  if (v) {
    throw throwHuman('payment_verification_required: card issuer verification (3-D Secure) prompt — cannot complete unattended');
  }
};

// Decline the optional warranty / protection-plan interstitial Amazon shows
// after add-to-cart. Silently no-ops when absent.
const declineCoverage = async (page) => {
  await page.evaluate(() => {
    const decline =
      document.querySelector('#attachSiNoCoverage input, #siNoCoverage, input[aria-labelledby*="noCoverage" i]') ||
      Array.from(document.querySelectorAll('button, a, input')).find((el) =>
        /no thanks/i.test(el.innerText || el.value || '')
      );
    if (decline) decline.click();
  }).catch(() => {});
};

// NOTE: Amazon requires a pre-authenticated browser session for checkout.
// Unlike guest-checkout sites (Walmart, Best Buy, etc.), Amazon does not
// expose shipping/payment forms to unauthenticated users. The adapter
// assumes the browser profile (`profiles/task-<id>`) already has valid
// Amazon session cookies from a prior manual login. The bot handles:
// product page → size selection → quantity → ATC → cart → checkout →
// place order. Shipping address and payment method must be pre-saved in
// the Amazon account — the adapter uses the default saved address/card.
const runAmazon = async ({ page, task }) => {
  const startedAt = Date.now();
  logger.info(`[Amazon] Starting checkout for task ${task.id}: ${task.url}`);
  await tuneSitePage(page, { navigationTimeoutMs: 30000 });
  logger.info('[Amazon] NOTE: requires pre-authenticated browser session with saved address + payment');
  page.setDefaultNavigationTimeout(30000);

  await guardedGoto(page, task.url, { taskId: task.id, stage: 'pdp_load' });
  await waitForAnySelector(page, SELECTORS.addToCart, { timeout: 10000 });
  await detectRobotCheck(page);

  // Detect if we're on a sign-in page (session expired / never logged in)
  const signInCheck = await findFirst(page, SELECTORS.signInEmail, 2000);
  if (signInCheck) {
    throw new Error('Amazon session not authenticated — log in manually via the browser profile first, then retry. Amazon does not support guest checkout.');
  }
  await detectOtp(page);

  if (task.size) {
    logger.info(`[Amazon] Selecting size "${task.size}"`);
    const sizeSelected = await page.evaluate((targetSize) => {
      const options = document.querySelectorAll('#variation_size_name li, #native_dropdown_selected_size_name option');
      for (const opt of options) {
        const text = (opt.textContent || opt.value || '').trim();
        if (text.toLowerCase().includes(targetSize.toLowerCase())) {
          if (opt.tagName === 'OPTION') {
            opt.closest('select').value = opt.value;
            opt.closest('select').dispatchEvent(new Event('change', { bubbles: true }));
          } else {
            const btn = opt.querySelector('button, a, span.a-button-text');
            if (btn) btn.click(); else opt.click();
          }
          return true;
        }
      }
      return false;
    }, task.size).catch(() => false);
    if (sizeSelected) await waitForAnySelector(page, [...SELECTORS.qtySelect, ...SELECTORS.addToCart], { timeout: 2500 });
    else logger.warn(`[Amazon] Size "${task.size}" not found — proceeding with default`);
  }

await setQuantity(page, task.quantity);
  const requestFirstAdded = await tryRequestFirstAddToCart(page, SELECTORS.addToCart);
  if (!requestFirstAdded) await clickFirst(page, SELECTORS.addToCart, { stage: 'add_to_cart' });
  logger.info('[Amazon] Added to cart');
  await waitForAnySelector(page, [...SELECTORS.proceedToCheckout, ...SELECTORS.cartWidget], { timeout: 10000 });
  await declineCoverage(page);
  await detectRobotCheck(page);

  const cartCheck = await verifyCartHasItem(page, { timeout: 5000 });
  if (cartCheck.empty) {
    const err = new Error('Cart is empty after add-to-cart — product may be out of stock');
    err.failureType = 'oos';
    throw err;
  }
  logger.info(`[Amazon] Cart verified (${cartCheck.count} item(s))`);

  const cartLink = await findFirst(page, SELECTORS.cartWidget, 5000);
  if (cartLink) { await humanClick(page, cartLink.selector); await waitForAnySelector(page, SELECTORS.proceedToCheckout, { timeout: 8000 }); }

  await clickFirst(page, SELECTORS.proceedToCheckout, { stage: 'proceed_to_checkout' });
  await page.waitForNavigation({ waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
  await postClickGuard(page, { taskId: task.id, stage: 'proceed_to_checkout' });

  // After proceeding, verify we landed on checkout (not redirected to sign-in)
  const postCheckoutSignIn = await findFirst(page, SELECTORS.signInEmail, 3000);
  if (postCheckoutSignIn) {
    throw new Error('Amazon redirected to sign-in during checkout — session expired. Re-authenticate the browser profile and retry.');
  }
  await detectRobotCheck(page);
  await detectOtp(page);

  // Amazon checkout uses saved address + saved payment by default.
  // If there's an address selection page, pick the first/default.
  const changeAddr = await page.$('input[name="shipToThisAddress"], a.ship-to-this-address').catch(() => null);
  if (changeAddr) {
    await changeAddr.click();
    await waitForAnySelector(page, ['input[name="continueButton"]', ...SELECTORS.placeOrder], { timeout: 5000 });
    await postClickGuard(page, { taskId: task.id, stage: 'confirm_address' });
    logger.info('[Amazon] Confirmed default shipping address');
  }

  const shippingContinue = await page.$('input[name="continueButton"], input.a-button-input[aria-labelledby*="shipping"]').catch(() => null);
  if (shippingContinue) {
    await shippingContinue.click();
    await waitForAnySelector(page, [...SELECTORS.placeOrder, SELECTORS.orderConfirmation[0]], { timeout: 6000 });
    await postClickGuard(page, { taskId: task.id, stage: 'confirm_shipping' });
    logger.info('[Amazon] Confirmed shipping method');
  }

  await preOrderGuard(page, { taskId: task.id });
  await detectPaymentVerification(page);
  await assertActionButtonIntent(page, SELECTORS.placeOrder, { stage: 'place order', allow: /place your order|place order|submit order/i });
  await clickFirst(page, SELECTORS.placeOrder, { stage: 'place_order' });

  const confirmed = await Promise.race([
    findFirst(page, SELECTORS.orderConfirmation, 60000),
    page.waitForFunction(() => /thank-you|order-confirmation|confirmation/.test(window.location.pathname), { timeout: 60000 }).then(() => ({ url: true })).catch(() => null)
  ]);
  if (!confirmed) {
    await takeFailureScreenshot(page, task.id, 'confirm_order_fail');
    throw new Error('Order confirmation not detected at stage "confirm_order"');
  }
  const orderNumber = await page.evaluate(() => {
    const el = document.querySelector('.order-id, [class*="orderNumber" i], .a-color-success .a-text-bold');
    return el ? el.textContent.trim() : null;
  }).catch(() => null);

  logger.info(`[Amazon] ✅ Order placed for task ${task.id}! Order: ${orderNumber || 'N/A'}`);
  await captureOrderSuccess({ page, taskId: task.id, orderNumber, productUrl: task.url, durationMs: Date.now() - startedAt }).catch(() => {});
};

export default runAmazon;
