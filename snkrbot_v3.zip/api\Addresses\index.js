import { Router } from 'express';
import { validate } from 'express-validation';
import * as controller from './controller.js';
import * as jigCtrl from './jig.js';
import { createAddressSchema, updateAddressSchema } from './validation.js';

const router = Router();

router.get('/', controller.findAll);
router.get('/:id', controller.findOne);
router.post('/', validate(createAddressSchema, {}, {}), controller.create);
router.patch('/:id', validate(updateAddressSchema, {}, {}), controller.update);
router.delete('/:id', controller.remove);
router.post('/:id/jig', jigCtrl.jig);

export default router;
