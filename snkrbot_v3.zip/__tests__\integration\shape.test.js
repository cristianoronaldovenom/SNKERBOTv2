// F5 Shape adapter tests.
//
// The regression this guards: Shape was classified and then dropped into the
// generic bot-block branch, which WIPED cookies. Wiping a TSPD session is the one
// thing guaranteed to make Shape worse, because TSPD is exactly what it wants to
// accumulate. So the ladder must start by keeping cookies, never by clearing them.
import { beforeEach, describe, expect, jest, test } from '@jest/globals';

const mockRequest = jest.fn();
jest.unstable_mockModule('../../helpers/tls-client.js', () => ({ tlsRequest: mockRequest }));

let s;
beforeEach(async () => {
  mockRequest.mockReset();
  s = await import('../../helpers/shape.js');
});

const pageUrl = 'https://shop.example.com/p/1';
const tspd = 'TSPD_101=abc123def456';

describe('detection', () => {
  test('a TSPD set-cookie is a challenge', () => {
    expect(s.isShapeChallenge({ status: 200, headers: { 'set-cookie': tspd } })).toBe(true);
  });

  test('TSPD or ct_257 in the body is a challenge', () => {
    expect(s.isShapeChallenge({ status: 403, body: 'var x = TSPD_101;' })).toBe(true);
    expect(s.isShapeChallenge({ status: 403, body: 'ct_257 bootstrap' })).toBe(true);
  });

  test('a 501 ASM page is a challenge', () => {
    expect(s.isShapeChallenge({ status: 501, body: 'TSabcdef12 error' })).toBe(true);
  });

  test('a plain 200 with nothing identifying is not', () => {
    expect(s.isShapeChallenge({ status: 200, body: '<html>hi</html>' })).toBe(false);
  });
});

describe('cookie extraction', () => {
  test('pulls the TSPD token out of a set-cookie blob', () => {
    expect(s.shapeCookies(`${tspd}; Path=/; HttpOnly`)).toBe('TSPD_101=abc123def456');
  });

  test('pulls legacy TS cookies too', () => {
    const out = s.shapeCookies('TS0123ab=vv1; TSabcdef=vv2');
    expect(out).toContain('TS0123ab=vv1');
    expect(out).toContain('TSabcdef=vv2');
  });

  test('joins for a Cookie header', () => {
    expect(s.shapeCookies(`${tspd}, TS0123ab=vv1`)).toBe('TSPD_101=abc123def456; TS0123ab=vv1');
  });

  test('an unrelated set-cookie yields empty', () => {
    expect(s.shapeCookies('sessionid=zzz')).toBe('');
  });

  test('hasShapeCookie is the presence check', () => {
    expect(s.hasShapeCookie(tspd)).toBe(true);
    expect(s.hasShapeCookie('sessionid=zzz')).toBe(false);
    expect(s.hasShapeCookie('')).toBe(false);
  });
});

describe('ladder', () => {
  test('freshly issued cookies are adopted for a retry', async () => {
    const out = await s.solveShape({ pageUrl, status: 403, headers: { 'set-cookie': tspd } });
    expect(out.action).toBe('rearm');
    expect(out.cookies).toBe('TSPD_101=abc123def456');
    expect(mockRequest).not.toHaveBeenCalled();
  });

  test('a token we already hold is KEPT, not cleared — the core fix', async () => {
    mockRequest.mockResolvedValue({ ok: true, status: 200, body: '' });
    const out = await s.solveShape({ pageUrl, status: 403, cookieHeader: tspd });
    expect(out.action).toBe('keep');
    expect(out.reason).toBe('tspd_present');
  });

  test('with no token, one re-request is attempted and its cookies adopted', async () => {
    mockRequest.mockResolvedValue({ ok: true, status: 403, headers: { 'set-cookie': tspd } });
    const out = await s.solveShape({ pageUrl, status: 403 });
    expect(out.action).toBe('rearm');
    expect(out.reason).toBe('rear_armed');
  });

  test('a 200 on the re-request means the token was not required', async () => {
    mockRequest.mockResolvedValue({ ok: true, status: 200, headers: {} });
    expect((await s.solveShape({ pageUrl, status: 403 })).action).toBe('keep');
  });

  test('earning nothing escalates to a browser solve', async () => {
    mockRequest.mockResolvedValue({ ok: true, status: 403, headers: {} });
    const out = await s.solveShape({ pageUrl, status: 403 });
    expect(out).toMatchObject({ action: 'browser', needBrowser: true });
  });

  test('a failed re-request still escalates rather than throwing', async () => {
    mockRequest.mockRejectedValue(new Error('ECONNRESET'));
    expect((await s.solveShape({ pageUrl, status: 403 })).needBrowser).toBe(true);
  });

  test('the re-request forwards our UA and exit', async () => {
    mockRequest.mockResolvedValue({ ok: true, status: 403, headers: {} });
    await s.solveShape({ pageUrl, status: 403, proxy: { host: 'g.net', port: 80 }, ua: 'UA/2' });
    const args = mockRequest.mock.calls[0][0];
    expect(args.proxy).toBe('g.net:80');
    expect(args.headers['User-Agent']).toBe('UA/2');
  });

  test('a missing URL waits rather than escalating', async () => {
    const out = await s.solveShape({ status: 403 });
    expect(out.action).toBe('wait');
    expect(out.needBrowser).toBe(false);
  });
});
