// Captcha harvester — solve captchas yourself in a browser tab, no API cost.
//
// Why pro bots ship this: paid solvers cost $1-3 per 1000 solves AND get
// rate-limited / DDoSed at major drops. Stellar/Hidden/Valor all ship a
// "harvester" UI: when the bot hits a captcha, it parks the challenge in a
// queue; the user opens a browser tab pointed at the harvester page; the
// real captcha widget renders with the actual sitekey + pageurl; the user
// clicks the checkbox / solves the challenge; the resulting token gets
// pushed back into the bot's running adapter — all in real time.
//
// We register harvester as a captcha provider in the cascade. The user
// chooses position via setting `harvester_position` ('first' = free solves
// preferred, 'last' = only when paid providers fail).
import logger from './logger.js';
import { randomUUID } from 'node:crypto';

// In-memory queue. Each entry: { id, type, siteKey, pageUrl, createdAt,
// resolve, reject, deadline }. Lives only in the running process; if the
// bot restarts, in-flight challenges are abandoned (which is correct
// behavior — you don't want stale tokens being submitted to drop adapters).
const pending = new Map();

const TYPE_LABEL = {
  recaptcha: 'reCAPTCHA v2',
  hcaptcha: 'hCaptcha',
  turnstile: 'Cloudflare Turnstile'
};

// Create a challenge and return a Promise that resolves when a human
// (or the harvester UI) submits a token via /v1/harvester/solve/:id.
// Auto-rejects when deadline is reached.
export const createHarvesterChallenge = ({ type, siteKey, pageUrl, deadline }) =>
  new Promise((resolve, reject) => {
    const id = randomUUID();
    const entry = { id, type, siteKey, pageUrl, createdAt: Date.now(), deadline, resolve, reject };
    pending.set(id, entry);
    logger.info(`[Harvester] Challenge ${id} queued — ${TYPE_LABEL[type] || type} for ${pageUrl}`);

    // Watchdog: reject if deadline passes without a solve
    const remaining = Math.max(1000, deadline - Date.now());
    const timer = setTimeout(() => {
      if (pending.has(id)) {
        pending.delete(id);
        logger.warn(`[Harvester] Challenge ${id} expired (no human solve within ${remaining}ms)`);
        reject(new Error('harvester: human did not solve in time'));
      }
    }, remaining);
    entry._timer = timer;
  });

// API: list pending challenges (UI polls this)
export const listPendingChallenges = () => {
  // Sweep stale entries (defensive — watchdog should already have)
  const now = Date.now();
  for (const [id, e] of pending) {
    if (e.deadline && now > e.deadline) {
      clearTimeout(e._timer);
      pending.delete(id);
      e.reject(new Error('harvester: expired during sweep'));
    }
  }
  return Array.from(pending.values()).map((e) => ({
    id: e.id,
    type: e.type,
    siteKey: e.siteKey,
    pageUrl: e.pageUrl,
    createdAt: e.createdAt,
    expiresInMs: Math.max(0, e.deadline - Date.now())
  }));
};

// API: human submits the solved token
export const submitHarvesterSolution = ({ id, token }) => {
  const entry = pending.get(id);
  if (!entry) return { ok: false, error: 'no such challenge (already solved or expired)' };
  if (!token || typeof token !== 'string' || token.length < 20) {
    return { ok: false, error: 'token missing or too short' };
  }
  clearTimeout(entry._timer);
  pending.delete(id);
  logger.info(`[Harvester] Challenge ${entry.id} solved by human in ${Date.now() - entry.createdAt}ms`);
  entry.resolve(token);
  return { ok: true };
};

// Stats for the UI footer
export const harvesterStats = () => ({
  pendingCount: pending.size,
  oldestAgeMs: pending.size === 0 ? 0 : Date.now() - Math.min(...Array.from(pending.values()).map((e) => e.createdAt))
});

// In-page solve — the CORRECT solve mode for domain-bound sitekeys.
//
// Why this exists: hCaptcha/Turnstile/reCAPTCHA enforce hostname binding on
// sitekeys. A token solved on localhost:3000 (the separate harvester tab)
// gets REJECTED by pokemoncenter.ca's verification call. Pro bots avoid
// this by having the human solve the captcha INSIDE the bot's already-open
// puppeteer browser, which is on the actual target domain — so the token
// is minted in a context the site accepts.
//
// Mechanism: when the bot detects a captcha, we just poll the response
// field on the page. When the human (in headful mode) clicks/solves the
// widget that's already rendered on the real page, the widget itself
// writes the token into the standard hidden input — we read it and return.
// No iframe injection, no cross-origin tricks needed.
const RESPONSE_SELECTORS = {
  recaptcha: 'textarea[name="g-recaptcha-response"]',
  hcaptcha: 'textarea[name="h-captcha-response"], [name="h-captcha-response"]',
  turnstile: 'input[name="cf-turnstile-response"]'
};

export const solveInPage = async ({ page, type, deadline }) => {
  const selector = RESPONSE_SELECTORS[type];
  if (!selector) throw new Error(`solveInPage: unsupported type ${type}`);
  if (!page || typeof page.evaluate !== 'function') throw new Error('solveInPage: no puppeteer page provided');

  logger.info(`[Harvester] In-page solve waiting for human to complete ${type} on ${page.url()} (deadline: ${Math.round((deadline - Date.now()) / 1000)}s)`);

  while (Date.now() < deadline) {
    const token = await page.evaluate((sel) => {
      const els = document.querySelectorAll(sel);
      for (const el of els) {
        const v = el.value || el.textContent || '';
        if (v && v.length > 20) return v;
      }
      return null;
    }, selector).catch(() => null);
    if (token) {
      logger.info(`[Harvester] In-page ${type} solved by human (token len: ${token.length})`);
      return token;
    }
    await new Promise((r) => setTimeout(r, 750));
  }
  throw new Error('harvester in-page: human did not solve in time');
};
