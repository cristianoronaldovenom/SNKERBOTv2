// The stealth script is a JS template literal, so a backtick inside a COMMENT
// is still a live delimiter — two backticks in one comment close and re-open the
// template and the parser lands on the next word. Strip them from comment text
// (single quotes read the same) but never touch ${...} interpolations.
//
// Scoped to the buildStealthScript() template body only: launch-code comments
// outside it are ordinary JS comments and may keep their backticks.
import fs from 'node:fs';

const FILE = 'helpers/cluster.js';
const src = fs.readFileSync(FILE, 'utf8');

const START = 'const buildStealthScript = (profile) => `';
const startIdx = src.indexOf(START);
if (startIdx === -1) throw new Error('stealth builder not found');

// The builder's closing delimiter is the first "\n`;" at column 1 after the
// factory function; locate it from the toString marker, exactly like
// scripts/stealth-check.mjs does.
const END_MARK = '\n`;';
const endIdx = src.indexOf(END_MARK, src.indexOf('function toString'));
if (endIdx === -1) throw new Error('stealth template terminator not found');

const head = src.slice(0, startIdx + START.length);
let body = src.slice(startIdx + START.length, endIdx);
const tail = src.slice(endIdx);

const before = body;
body = body.replace(/`/g, "'");

if (body === before) {
  console.log('nothing to strip');
} else {
  fs.writeFileSync(FILE, head + body + tail);
  console.log(`stripped ${(before.match(/`/g) || []).length} stray backtick(s) from the stealth template`);
}
