import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

// On Windows `node_modules/.bin/jest` is a batch shim (`jest.cmd`), and a .cmd
// cannot be executed by `process.execPath`. Spawning it produced
//   node ...\node_modules\.bin\jest.cmd:1
// and no tests ever ran. Point at the real JS entrypoint instead.
const jestCli = path.join(root, 'node_modules', 'jest', 'bin', 'jest.js');

const run = (args) => new Promise((resolve) => {
  const child = spawn(process.execPath, args, { cwd: root, stdio: 'inherit' });
  child.on('exit', (code, signal) => resolve(signal ? 1 : (code ?? 1)));
});

// The suite is jest plus two dependency-free audits (stealth fingerprint checks
// and the deploy-script logic guard). They used to be separate scripts nobody
// ran; `npm test` is the only command people reliably type, so it has to cover
// them or they rot.
const AUDITS = [
  ['scripts/stealth-check.mjs'],
  ['scripts/smoke-test.mjs'],
  ['scripts/go-tests.mjs'],
];

if (fs.existsSync(jestCli)) {
  // --forceExit is a jest flag, so it goes AFTER the CLI path (before it, node rejects it
  // as a bad option). Needed because the captcha pre-solve armer holds a reaper interval
  // and the refill timers are real, not faked, so jest can sit "not exiting" after a
  // green run. Every suite has finished by then, so a forced exit is safe.
  const jestCode = await run(['--experimental-vm-modules', jestCli, '--forceExit', ...process.argv.slice(2)]);
  if (jestCode !== 0) process.exit(jestCode);
} else {
  console.log('INFO: Jest dependencies are not installed; running dependency-free smoke/audit tests only.');
}

for (const args of AUDITS) {
  const code = await run(args);
  if (code !== 0) {
    console.error(`FAIL: node ${args.join(' ')} exited ${code}`);
    process.exit(code);
  }
}

process.exit(0);

