// Page teardown memory release.
//
// The regression this guards: closing a page relied on Chromium's own GC heuristics,
// which are tuned for a laptop with one foreground tab. A bot closes and relaunches
// constantly, so freed renderer memory stayed resident until pressure forced a sweep —
// and on a 2 GB box the OOM killer arrives first.
//
// The important property is that GC nudges must never break teardown: a detached CDP
// target rejects them routinely, and a checkout must still complete.
import { beforeEach, describe, expect, jest, test } from '@jest/globals';

jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));

const { storePageInTaskCache, removePageFromTaskCache, retrievePageFromTaskCache, clearTaskCache } =
  await import('../../helpers/task-cache.js');

beforeEach(async () => { await clearTaskCache(); });

const fakePage = ({ sendFails = false, detachFails = false, closeFails = false } = {}) => {
  const sent = [];
  return {
    sent,
    close: async () => { if (closeFails) throw new Error('already closed'); },
    target: () => ({
      createCDPSession: async () => ({
        send: async (cmd) => { if (sendFails) throw new Error('detached'); sent.push(cmd); },
        detach: async () => { if (detachFails) throw new Error('gone'); }
      })
    })
  };
};

describe('teardown', () => {
  test('asks for a collection before closing', async () => {
    const page = fakePage();
    storePageInTaskCache({ taskId: 1, page });
    await removePageFromTaskCache({ taskId: 1 });
    expect(page.sent).toContain('HeapProfiler.collectGarbage');
  });

  test('presses the renderer lifecycle so V8 shrinks its heap', async () => {
    const page = fakePage();
    storePageInTaskCache({ taskId: 2, page });
    await removePageFromTaskCache({ taskId: 2 });
    expect(page.sent.filter((c) => c === 'Page.setWebLifecycleState')).toHaveLength(2);
  });

  test('the entry is always removed, even if every CDP call fails', async () => {
    storePageInTaskCache({ taskId: 3, page: fakePage({ sendFails: true, detachFails: true }) });
    await expect(removePageFromTaskCache({ taskId: 3 })).resolves.toBeUndefined();
    expect(retrievePageFromTaskCache({ taskId: 3 })).toBeNull();
  });

  test('a page that throws on close still gets removed from the cache', async () => {
    storePageInTaskCache({ taskId: 4, page: fakePage({ closeFails: true }) });
    await expect(removePageFromTaskCache({ taskId: 4 })).resolves.toBeUndefined();
    expect(retrievePageFromTaskCache({ taskId: 4 })).toBeNull();
  });

  test('a page with no CDP target at all is tolerated', async () => {
    storePageInTaskCache({ taskId: 5, page: { close: async () => {} } });
    await expect(removePageFromTaskCache({ taskId: 5 })).resolves.toBeUndefined();
  });

  test('removing an unknown task is a no-op', async () => {
    await expect(removePageFromTaskCache({ taskId: 99 })).resolves.toBeUndefined();
  });
});
