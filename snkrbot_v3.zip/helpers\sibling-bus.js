// Cross-task signaling for sibling tasks targeting the same product.
//
// When the user fires 5 tasks at the same product URL (different profiles
// for "1 per customer" enforcement), the FIRST task to confirm an order
// wins. The other 4 are wasted runs that consume proxies, captcha credits,
// and possibly trip rate limits.
//
// Pro bots (Stellar, Hidden) emit a "product won" event and the sibling
// tasks abort cleanly mid-checkout. We replicate that here with an
// in-process EventEmitter (single-node deployment). For multi-node, swap
// for Redis pub/sub — the API stays the same.

import { EventEmitter } from 'node:events';
import logger from './logger.js';

const bus = new EventEmitter();
bus.setMaxListeners(100); // up to ~100 sibling tasks per drop

const recentWins = new Map(); // productKey → { taskId, orderNumber, at }
const WIN_TTL_MS = 5 * 60 * 1000; // 5 minutes

export const productKeyFromUrl = (url) => {
  try {
    const u = new URL(url);
    // Normalize: host + pathname (drop query string + fragment + trailing slash).
    // Two URLs hitting the same product page are siblings even if one has
    // ?utm_source=foo and the other doesn't.
    const path = u.pathname.replace(/\/+$/, '');
    return `${u.host}${path}`;
  } catch (_) { return String(url || ''); }
};

const cleanExpired = () => {
  const now = Date.now();
  for (const [k, v] of recentWins.entries()) {
    if (now - v.at > WIN_TTL_MS) recentWins.delete(k);
  }
};

// Called by start-task.js when an order is confirmed. Notifies any sibling
// tasks listening on the same productKey AND records the win for late
// joiners (tasks that start within the TTL window after the win).
export const notifyProductSuccess = ({ productUrl, taskId, orderNumber = null }) => {
  cleanExpired();
  const key = productKeyFromUrl(productUrl);
  recentWins.set(key, { taskId, orderNumber, at: Date.now() });
  const listenerCount = bus.listenerCount(key);
  if (listenerCount > 0) {
    logger.info(`[SiblingBus] Task ${taskId} won "${key}" — signaling ${listenerCount} sibling task(s) to abort`);
  }
  bus.emit(key, { winnerTaskId: taskId, orderNumber, productKey: key });
};

// Returns the prior win for this product if one happened within the TTL
// window. Tasks should check this on startup so a late-spawning sibling
// doesn't waste resources on an already-won drop.
export const getRecentWin = (productUrl) => {
  cleanExpired();
  const key = productKeyFromUrl(productUrl);
  return recentWins.get(key) || null;
};

// Subscribe to product-success events. The returned `unsubscribe` function
// MUST be called when the task ends (success OR failure) to prevent leaks.
export const subscribeToSiblings = (productUrl, callback) => {
  const key = productKeyFromUrl(productUrl);
  const handler = (info) => callback(info);
  bus.on(key, handler);
  return () => bus.off(key, handler);
};

// Helper for guards/adapters — throws a SiblingWonError if a sibling task
// already won this product. Cheap (just a Map lookup).
export class SiblingWonError extends Error {
  constructor(productKey, winner) {
    super(`Sibling task ${winner.taskId} already placed order on "${productKey}" (order: ${winner.orderNumber || 'unknown'}) — aborting to save resources`);
    this.name = 'SiblingWonError';
    this.siblingWon = true;
    this.winner = winner;
  }
}

export const throwIfSiblingWon = (productUrl) => {
  const win = getRecentWin(productUrl);
  if (win) throw new SiblingWonError(productKeyFromUrl(productUrl), win);
};

// Test/cleanup helper — clears all state. Used between test runs.
export const __resetForTests = () => {
  recentWins.clear();
  bus.removeAllListeners();
};
