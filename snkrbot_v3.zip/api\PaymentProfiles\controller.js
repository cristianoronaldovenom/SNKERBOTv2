import db from '../../db/index.js';

export const findAll = async (req, res, next) => {
  try {
    const profiles = await db('payment_profiles').where({ is_deleted: false }).select('*');
    if (profiles.length === 0) {
      return res.json({ success: true, message: 'Payment profiles not found', data: profiles });
    }
    return res.json({ success: true, message: 'Payment profiles successfully found', data: profiles });
  } catch (err) {
    next(err);
  }
};

export const findOne = async (req, res, next) => {
  try {
    const profile = await db('payment_profiles')
      .where({ id: req.params.id, is_deleted: false })
      .first('*');
    if (!profile) {
      return res.json({ success: true, message: 'Payment profile not found', data: undefined });
    }
    return res.json({ success: true, message: 'Payment profile successfully found', data: profile });
  } catch (err) {
    next(err);
  }
};

export const create = async (req, res, next) => {
  try {
    const [profile] = await db('payment_profiles').insert(req.body).returning('*');
    return res.json({ success: true, message: 'Payment profile successfully created', data: profile });
  } catch (err) {
    next(err);
  }
};

export const update = async (req, res, next) => {
  try {
    const [profile] = await db('payment_profiles')
      .where({ id: req.params.id })
      .update({ ...req.body, updated_at: new Date() })
      .returning('*');
    return res.json({ success: true, message: 'Payment profile successfully updated', data: profile });
  } catch (err) {
    next(err);
  }
};

export const remove = async (req, res, next) => {
  try {
    await db('payment_profiles').where({ id: req.params.id }).update({ is_deleted: true });
    return res.json({ success: true, message: 'Payment profile successfully deleted', data: {} });
  } catch (err) {
    next(err);
  }
};
