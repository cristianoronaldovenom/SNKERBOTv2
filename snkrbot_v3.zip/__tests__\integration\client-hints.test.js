// Client-hint generation must match what real Chrome emits for the same major
// version, because Imperva/DataDome/PX cross-check the JS `userAgentData.brands`
// against the `Sec-Ch-Ua` header. The expected values below are derived from
// Chromium M131's GetGreasedUserAgentBrandVersion() +
// GenerateBrandVersionList() (third_party/blink/common/user_agent/
// user_agent_metadata.cc): separator index = major % 11, GREASE version index =
// major % 3 of ['8','99','24'], and brand slot = major % 6 of the 6 possible
// permutations. Getting any of those wrong is a static tell, so they're pinned.
import { jest } from '@jest/globals';
import {
  greaseBrand, brandVersionList, secChUa, secChUaFullVersionList, __internals
} from '../../helpers/client-hints.js';

describe('chrome GREASE brand algorithm', () => {
  test('separator rotates with major version (major % 11)', () => {
    const chars = __internals.GREASE_CHARS;
    for (const major of [120, 124, 131, 132, 140]) {
      const { brand } = greaseBrand(major);
      const sep1 = chars[major % chars.length];
      const sep2 = chars[(major + 1) % chars.length];
      expect(brand).toBe(`Not${sep1}A${sep2}Brand`);
    }
  });

  test('GREASE version rotates through 8 / 99 / 24', () => {
    expect(greaseBrand(129).version).toBe('8');   // 129 % 3 === 0
    expect(greaseBrand(130).version).toBe('99');  // 130 % 3 === 1
    expect(greaseBrand(131).version).toBe('24');  // 131 % 3 === 2
  });

  test('Chrome 131 emits "Not_A Brand" v="24" (not the legacy Not-A.Brand v=99)', () => {
    expect(greaseBrand(131)).toEqual({ brand: 'Not_A Brand', version: '24' });
    const header = secChUa(131);
    expect(header).toContain('"Not_A Brand";v="24"');
    expect(header).not.toContain('Not-A.Brand');
    expect(header).not.toContain(';v="99"');
  });

  test('brand ordering follows major % 6 across all three slots', () => {
    // For each permutation slot the GREASE brand must land where Chrome puts it.
    const seen = new Set();
    for (let major = 131; major < 137; major++) {
      const list = brandVersionList(major).map((b) => b.brand);
      expect(list).toHaveLength(3);
      expect(new Set(list).size).toBe(3);               // no duplicate / no gap
      expect(list).toContain('Chromium');
      expect(list).toContain('Google Chrome');
      expect(list.filter((b) => b.startsWith('Not')).length).toBe(1);
      seen.add(list.indexOf(list.find((b) => b.startsWith('Not'))));
    }
    // All three positions get used across the six consecutive majors.
    expect([...seen].sort()).toEqual([0, 1, 2]);
  });

  test('full-version list carries fullVer on the real brands only', () => {
    const list = secChUaFullVersionList(131, '131.0.6778.204');
    expect(list).toContain('"Chromium";v="131.0.6778.204"');
    expect(list).toContain('"Google Chrome";v="131.0.6778.204"');
    // The GREASE entry keeps its own long form rather than borrowing fullVer.
    expect(list).toContain('v="24.0.0.0"');
  });

  test('degrades safely on a missing/garbage major version', () => {
    expect(() => secChUa(undefined)).not.toThrow();
    expect(secChUa('not-a-number')).toContain('Chromium'); // falls back to 131
    expect(brandVersionList(null)).toHaveLength(3);
  });
});
