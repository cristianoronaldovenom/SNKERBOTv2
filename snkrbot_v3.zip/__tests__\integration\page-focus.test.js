// Page focus driver tests.
//
// The regression this guards: under headful, hasFocus/visibilityState were still
// forced true by the stealth script. A real window genuinely blurs when another
// takes focus, so a page claiming visible+focus while the compositor disagrees is
// measurable. Driving real focus lets the browser report the truth.
import { describe, expect, test } from '@jest/globals';
import { bringToFront, isForeground } from '../../helpers/page-focus.js';

// Minimal puppeteer-shaped fake. `states` is consumed in order by evaluate.
const fakePage = (states, { bringFails = false } = {}) => {
  let i = 0;
  return {
    bringToFront: async () => { if (bringFails) throw new Error('no window'); },
    evaluate: async () => {
      const s = states[Math.min(i, states.length - 1)];
      i += 1;
      return s;
    },
    get calls() { return i; }
  };
};

describe('bringToFront', () => {
  test('confirms once the runtime reports visible and focused', async () => {
    const page = fakePage([{ visibility: 'visible', focused: true }]);
    expect(await bringToFront(page)).toEqual({ foreground: true, reason: 'confirmed' });
  });

  test('polls until the compositor catches up', async () => {
    const page = fakePage([
      { visibility: 'hidden', focused: false },
      { visibility: 'hidden', focused: false },
      { visibility: 'visible', focused: true }
    ]);
    expect((await bringToFront(page)).foreground).toBe(true);
    expect(page.calls).toBe(3);
  });

  test('a failed bringToFront is survivable', async () => {
    const out = await bringToFront(fakePage([{ visibility: 'visible', focused: true }], { bringFails: true }));
    expect(out).toEqual({ foreground: false, reason: 'bring_to_front_failed' });
  });

  test('never confirming gives up rather than hanging', async () => {
    const page = fakePage([{ visibility: 'hidden', focused: false }]);
    const out = await bringToFront(page);
    expect(out.foreground).toBe(false);
    expect(out.reason).toBe('unconfirmed');
  });

  test('an evaluate that throws does not escape', async () => {
    const page = { bringToFront: async () => {}, evaluate: async () => { throw new Error('detached'); } };
    expect((await bringToFront(page)).foreground).toBe(false);
  });
});

describe('isForeground', () => {
  test('true only when visible and focused', async () => {
    expect(await isForeground(fakePage([{ visibility: 'visible', focused: true }]))).toBe(true);
  });

  test('false when blurred even if visible', async () => {
    expect(await isForeground(fakePage([{ visibility: 'visible', focused: false }]))).toBe(false);
  });

  test('false on a hidden page', async () => {
    expect(await isForeground(fakePage([{ visibility: 'hidden', focused: true }]))).toBe(false);
  });

  test('false rather than throwing on a broken page', async () => {
    expect(await isForeground({ evaluate: async () => { throw new Error('gone'); } })).toBe(false);
  });
});
