// Session cookie security flag.
//
// The regression this guards: the cookie had httpOnly and sameSite but no `secure`,
// so the session id could cross the wire in cleartext (CWE-614). It also cannot be
// set unconditionally — that breaks plain-HTTP LAN access. So it is derived, with an
// explicit override for TLS-terminating proxies.
import { describe, expect, test } from '@jest/globals';
import { cookieSecure } from '../../helpers/auth.js';

describe('cookieSecure', () => {
  test('an https public URL turns it on', () => {
    expect(cookieSecure({ env: { APP_URL: 'https://bot.example.com' } })).toBe(true);
    expect(cookieSecure({ env: { PUBLIC_URL: 'https://bot.example.com' } })).toBe(true);
  });

  test('plain http stays off so LAN access keeps working', () => {
    expect(cookieSecure({ env: { APP_URL: 'http://192.168.1.10:3000' } })).toBe(false);
    expect(cookieSecure({ env: {} })).toBe(false);
  });

  test('an explicit true wins over an http URL (TLS-terminating proxy)', () => {
    expect(cookieSecure({ env: { SESSION_COOKIE_SECURE: 'true', APP_URL: 'http://internal:3000' } })).toBe(true);
    expect(cookieSecure({ env: { SESSION_COOKIE_SECURE: '1' } })).toBe(true);
  });

  test('an explicit false wins over an https URL', () => {
    expect(cookieSecure({ env: { SESSION_COOKIE_SECURE: 'false', APP_URL: 'https://bot.example.com' } })).toBe(false);
    expect(cookieSecure({ env: { SESSION_COOKIE_SECURE: '0' } })).toBe(false);
  });

  test('URL casing and whitespace do not matter', () => {
    expect(cookieSecure({ env: { APP_URL: '  HTTPS://Bot.Example.com  ' } })).toBe(true);
  });

  test('a garbage override falls through to URL detection', () => {
    expect(cookieSecure({ env: { SESSION_COOKIE_SECURE: 'yes-please', APP_URL: 'https://x.dev' } })).toBe(true);
  });
});
