// Token cache correctness. Both helpers sit on the checkout hot path: a bogus
// hit means a blank token is injected and the site rejects the submit, while a
// blindly-accepting deposit can poison the pool with an unusable token.
import { jest } from '@jest/globals';

jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));

const { getCachedToken, cacheToken, clearExpired, __resetCaptchaCacheForTests } = await import('../../helpers/captcha-cache.js');
const { consumeToken, depositToken, stockpileDepth, startStockpiling, __resetForTests } =
  await import('../../helpers/token-stockpile.js');

const GOOD = 'x'.repeat(40);
const PAGE = 'https://shop.example.com/checkout';

beforeEach(() => {
  jest.useFakeTimers();
  jest.setSystemTime(new Date('2026-01-01T00:00:00Z'));
  __resetCaptchaCacheForTests();
  __resetForTests();
});

afterEach(() => { jest.useRealTimers(); });

describe('captcha cache', () => {
  test('round-trips a valid token', () => {
    expect(cacheToken('recaptcha', 'SK', PAGE, GOOD)).toBe(true);
    expect(getCachedToken('recaptcha', 'SK', PAGE)).toBe(GOOD);
  });

  test('refuses to store an empty or stub token', () => {
    expect(cacheToken('recaptcha', 'SK', PAGE, '')).toBe(false);
    expect(cacheToken('recaptcha', 'SK', PAGE, undefined)).toBe(false);
    expect(getCachedToken('recaptcha', 'SK', PAGE)).toBeNull();
  });

  test('treats a previously stored blank token as a miss', () => {
    expect(cacheToken('hcaptcha', 'SK', PAGE, 'too-short')).toBe(false);
    expect(getCachedToken('hcaptcha', 'SK', PAGE)).toBeNull();
  });

  test('a token expires after the TTL', () => {
    cacheToken('recaptcha', 'SK', PAGE, GOOD);
    jest.setSystemTime(new Date('2026-01-01T00:02:00Z'));
    clearExpired();
    expect(getCachedToken('recaptcha', 'SK', PAGE)).toBeNull();
  });

  test('keys are scoped by type, key and host', () => {
    cacheToken('recaptcha', 'SK', PAGE, GOOD);
    expect(getCachedToken('hcaptcha', 'SK', PAGE)).toBeNull();
    expect(getCachedToken('recaptcha', 'OTHER', PAGE)).toBeNull();
    expect(getCachedToken('recaptcha', 'SK', 'https://other.test/checkout')).toBeNull();
  });
});

describe('token stockpile', () => {
  test('pops the freshest token and reports remaining depth', () => {
    depositToken('turnstile', 'SK', 'older'.padEnd(40, 'x'));
    jest.setSystemTime(new Date('2026-01-01T00:00:10Z'));
    depositToken('turnstile', 'SK', 'newer'.padEnd(40, 'y'));
    expect(stockpileDepth('turnstile', 'SK')).toBe(2);
    expect(consumeToken('turnstile', 'SK')).toBe('newer'.padEnd(40, 'y'));
    expect(stockpileDepth('turnstile', 'SK')).toBe(1);
  });

  test('rejects deposits too short to be a token', () => {
    expect(depositToken('turnstile', 'SK', '')).toBe(false);
    expect(depositToken('turnstile', 'SK', 'short')).toBe(false);
    expect(stockpileDepth('turnstile', 'SK')).toBe(0);
  });

  test('sweeps expired tokens instead of serving them', () => {
    depositToken('hcaptcha', 'SK', GOOD);
    jest.setSystemTime(new Date('2026-01-01T00:05:00Z')); // past 96s TTL
    expect(consumeToken('hcaptcha', 'SK')).toBeNull();
    expect(stockpileDepth('hcaptcha', 'SK')).toBe(0);
  });

  test('an empty pool returns null', () => {
    expect(consumeToken('hcaptcha', 'nothing')).toBeNull();
  });

  test('targetDepth 0 still refills instead of going dormant', async () => {
    const solveOnce = jest.fn(async () => GOOD);
    const stop = startStockpiling({ type: 'turnstile', siteKey: 'Z', pageUrl: PAGE, solveOnce, targetDepth: 0 });
    await jest.advanceTimersByTimeAsync(10);
    expect(solveOnce).toHaveBeenCalled();
    expect(stockpileDepth('turnstile', 'Z')).toBeGreaterThan(0);
    stop();
  });
});
