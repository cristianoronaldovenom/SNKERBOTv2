import Joi from 'joi';

const proxyType = Joi.string().valid('unknown', 'datacenter', 'residential', 'mobile').optional();

export const createProxySchema = {
  body: Joi.object({
    host: Joi.string().hostname().max(255).required(),
    port: Joi.number().integer().min(1).max(65535).required(),
    username: Joi.string().max(255).allow('').optional(),
    password: Joi.string().max(255).allow('').optional(),
    proxy_type: proxyType,
    label: Joi.string().max(120).allow('').optional()
  })
};

export const updateProxySchema = {
  body: Joi.object({
    host: Joi.string().hostname().max(255).optional(),
    port: Joi.number().integer().min(1).max(65535).optional(),
    username: Joi.string().max(255).allow('').optional(),
    password: Joi.string().max(255).allow('').optional(),
    proxy_type: proxyType,
    label: Joi.string().max(120).allow('').optional()
  })
};
