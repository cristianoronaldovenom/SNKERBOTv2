export const up = (knex) =>
  knex.schema.alterTable('tasks', (table) => {
    table.integer('max_failures').nullable();
    table.integer('consecutive_failures').notNullable().defaultTo(0);
    table.timestamp('disabled_at').nullable();
    table.string('disabled_reason').nullable();
  });

export const down = (knex) =>
  knex.schema.alterTable('tasks', (table) => {
    table.dropColumn('max_failures');
    table.dropColumn('consecutive_failures');
    table.dropColumn('disabled_at');
    table.dropColumn('disabled_reason');
  });
