const API = '/v1';

const SITES = {
  1: 'Footsites', 2: 'Shopify', 3: 'Demandware',
  4: 'Nike', 5: 'Supreme NY', 6: 'Pokemon Center CA',
  7: 'Topps'
};

const taskStatuses = {};
const activeStreams = {};

// ── API helpers ──────────────────────────────────────────────────────────────
const get  = (path) => fetch(API + path).then(r => r.json());
const post = (path, body) => fetch(API + path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) }).then(r => r.json());
const patch = (path, body) => fetch(API + path, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }).then(r => r.json());
const del  = (path) => fetch(API + path, { method: 'DELETE' }).then(r => r.json());
const put  = (path, body) => fetch(API + path, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }).then(r => r.json());

// ── Toast ────────────────────────────────────────────────────────────────────
function toast(msg, type = '') {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className = `toast show ${type}`;
  clearTimeout(el._t);
  el._t = setTimeout(() => el.className = 'toast', 3000);
}

// ── Tabs ─────────────────────────────────────────────────────────────────────
document.querySelectorAll('.nav-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('tab-' + btn.dataset.tab).classList.add('active');
    if (btn.dataset.tab === 'tasks')     loadTasks();
    if (btn.dataset.tab === 'activity')  loadActivity();
    if (btn.dataset.tab === 'addresses') loadAddresses();
    if (btn.dataset.tab === 'payments')  loadPaymentProfiles();
    if (btn.dataset.tab === 'proxies')   loadProxies();
    if (btn.dataset.tab === 'runs')      loadRuns();
    if (btn.dataset.tab === 'feed')       refreshLiveFeed();
    if (btn.dataset.tab === 'settings')  loadSettings();
  });
});

// ── Modals ───────────────────────────────────────────────────────────────────
function openModal(id)  { document.getElementById(id).style.display = ''; }
function closeModal(id) { document.getElementById(id).style.display = 'none'; }

document.querySelectorAll('.modal-overlay').forEach(overlay => {
  overlay.addEventListener('click', e => { if (e.target === overlay) overlay.style.display = 'none'; });
});

// ── TASKS ────────────────────────────────────────────────────────────────────
// Role-aware proxy selectors. Values are encoded as mode:id so the same UI
// control can represent an assigned DB proxy, the environment residential
// gateway, auto resolution, or a direct connection.
let proxyCatalog = [];
let residentialGatewayMeta = { monitorConfigured: false, checkoutConfigured: false };

function proxyOptionValue(proxyId) { return `assigned:${proxyId}`; }
function proxySelectionFromTask(task, role) {
  const prefix = role === 'monitor' ? 'monitor' : 'checkout';
  const mode = task?.[`${prefix}_proxy_mode`] || 'auto';
  const id = task?.[`${prefix}_proxy_id`];
  if (mode === 'assigned' && id) return proxyOptionValue(id);
  if (mode === 'residential_env') return 'residential_env';
  if (mode === 'direct') return 'direct';
  return 'auto';
}

function buildProxyOptions(role, selectedValue = 'auto') {
  const configured = role === 'monitor'
    ? residentialGatewayMeta.monitorConfigured
    : residentialGatewayMeta.checkoutConfigured;
  const options = [
    '<option value="auto">Auto (assigned → residential → direct)</option>',
    '<option value="direct">Direct connection</option>'
  ];
  if (configured) options.push('<option value="residential_env">🏠 Residential Gateway</option>');
  for (const p of proxyCatalog) {
    const type = (p.proxy_type || 'unknown').toLowerCase();
    const badge = type === 'residential' ? '🏠 ' : type === 'mobile' ? '📱 ' : '';
    const label = p.label ? ` — ${escapeHtml(p.label)}` : '';
    options.push(`<option value="${proxyOptionValue(p.id)}">${badge}${escapeHtml(p.host)}:${p.port}${label}</option>`);
  }
  return options.join('').replace(`value="${selectedValue}"`, `value="${selectedValue}" selected`);
}

function populateTaskProxySelectors(task = null) {
  const monitor = document.getElementById('task-monitor-proxy');
  const checkout = document.getElementById('task-checkout-proxy');
  if (monitor) {
    const selected = proxySelectionFromTask(task || {}, 'monitor');
    monitor.innerHTML = buildProxyOptions('monitor', selected);
  }
  if (checkout) {
    const selected = proxySelectionFromTask(task || {}, 'checkout');
    checkout.innerHTML = buildProxyOptions('checkout', selected);
  }
}

function selectionToProxyFields(value) {
  const raw = value || 'auto';
  if (raw === 'direct') return { mode: 'direct', id: null };
  if (raw === 'residential_env') return { mode: 'residential_env', id: null };
  if (raw.startsWith('assigned:')) return { mode: 'assigned', id: parseInt(raw.slice(9), 10) };
  return { mode: 'auto', id: null };
}

async function loadTasks() {
  const container = document.getElementById('tasks-list');
  const [res, addrRes, payRes, proxyRes, proxyMetaRes] = await Promise.all([
    get('/tasks'),
    get('/addresses'),
    get('/payment-profiles'),
    get('/proxies'),
    get('/proxies/meta')
  ]);
  populateSelect('task-shipping', addrRes.data || [], a => `${a.first_name} ${a.last_name} — ${a.address1}`);
  populateSelect('task-billing',  addrRes.data || [], a => `${a.first_name} ${a.last_name} — ${a.address1}`);
  populateSelect('task-payment',  payRes.data  || [], p => `${p.label} ****${String(p.card_number).slice(-4)}`);
  proxyCatalog = Array.isArray(proxyRes.data) ? proxyRes.data : [];
  residentialGatewayMeta = proxyMetaRes?.data?.residentialGateway || residentialGatewayMeta;
  populateTaskProxySelectors(null);

  if (!res.data || res.data.length === 0) {
    container.innerHTML = `<div class="empty-state"><p>No tasks yet — create one to get started.</p></div>`;
    return;
  }

  container.innerHTML = res.data.map(task => buildTaskCard(task)).join('');

  // Hydrate the UI from the server's authoritative monitor state so a page reload
  // never makes an active monitor look stopped. The hydration helper also opens
  // the per-task SSE stream, so there is no second reattach pass here.
  await hydrateMonitorStates();
}

function buildTaskCard(task) {
  const site = SITES[task.site_id] || `Site ${task.site_id}`;
  const taskJson = JSON.stringify(task).replace(/"/g, '&quot;');
  const dropBadge = task.start_at
    ? `<span class="badge badge-yellow" id="drop-${task.id}" data-start="${task.start_at}">⏱ DROP ${new Date(task.start_at).toLocaleString()}</span>`
    : '';
  const lastBadge = task.last_status === 'success'
    ? `<span class="badge badge-green">✓ ${task.last_order_number || 'OK'}</span>`
    : task.last_status === 'failed'
    ? `<span class="badge badge-red">✗ failed</span>`
    : task.last_status === 'preflight_fail'
    ? `<span class="badge badge-red">✗ preflight</span>`
    : task.last_status === 'outside_hours'
    ? `<span class="badge badge-yellow">🕕 outside 8am–6pm ET</span>`
    : task.last_status === 'needs_human'
    ? `<span class="badge badge-yellow">👤 needs human (3DS)</span>`
    : task.last_status === 'household_cap'
    ? `<span class="badge badge-red">🏠 household cap</span>`
    : task.last_status === 'payment_locked' || task.pay_disabled_at
    ? `<span class="badge badge-red" title="${escapeHtml(task.pay_disabled_reason || 'Payment locked')}">💳 payment locked ${task.pay_fail_count || 5}/5</span>`
    : '';
  // Pokemon Center (site_id 6) only runs 8am–6pm ET — show the schedule on the card
  const scheduleBadge = task.site_id === 6
    ? `<span class="badge badge-yellow" title="Monitoring auto-starts at 8am ET and auto-stops at 6pm ET daily">🕕 8am–6pm ET</span>`
    : '';
  const retryBadge = (task.retry_count > 0)
    ? `<span class="badge badge-yellow">↻ ${task.retry_count}</span>`
    : '';
  const quickBadge = task.quick_mode === false
    ? '' : `<span class="badge badge-green">⚡ Quick</span>`;
  return `
  <div class="card" id="task-card-${task.id}">
    <div class="card-title">
      <span class="status-dot idle" id="dot-${task.id}"></span>
      <span class="url-truncate" title="${task.url}">${task.url}</span>
    </div>
    <div class="card-meta">
      <span class="badge badge-blue">${site}</span>
      ${scheduleBadge}
      ${task.monitor_24_7 ? '<span class="badge badge-green">📡 24/7</span>' : ''}
      ${task.monitor_proxy_id ? `<span class="badge badge-blue">📡 M:${escapeHtml(task.monitor_proxy_label || task.monitor_proxy_host || ('#'+task.monitor_proxy_id))}</span>` : (task.monitor_proxy_mode === 'residential_env' ? '<span class="badge badge-green">📡 M:Residential</span>' : '')}
      ${task.checkout_proxy_id ? `<span class="badge badge-blue">🛒 C:${escapeHtml(task.checkout_proxy_label || task.checkout_proxy_host || ('#'+task.checkout_proxy_id))}</span>` : (task.checkout_proxy_mode === 'residential_env' ? '<span class="badge badge-green">🛒 C:Residential</span>' : '')}
      ${task.keywords ? `<span class="badge badge-yellow">🔑 ${task.keywords}</span>` : ''}
      ${task.size     ? `<span class="badge badge-blue">Size: ${task.size}</span>`   : ''}
      ${task.auto_solve_captchas ? `<span class="captcha-badge">⚡ Captcha</span>`   : ''}
      ${quickBadge}
      ${dropBadge}
      ${retryBadge}
      ${lastBadge}
      <span class="badge badge-blue" id="preflight-${task.id}" style="cursor:pointer" onclick="checkPreflight(${task.id})">⌨ Preflight</span>
    </div>
    ${task.coupon_code ? `<div class="card-meta"><span style="color:var(--neon, #00ff9c)">🏷 ${task.coupon_code}</span></div>` : ''}
    <div class="card-meta" id="stage-meta-${task.id}" style="display:none"></div>

    <div class="monitor-panel">
      <div class="stock-status" id="stock-status-${task.id}">
        <span class="stock-dot idle" id="stock-dot-${task.id}"></span>
        <span class="stock-label" id="stock-label-${task.id}" style="color:var(--text-muted)">Not monitoring</span>
      </div>
      <div id="product-preview-${task.id}"></div>
      <div class="monitor-actions">
        <button class="btn-monitor" id="btn-monitor-${task.id}" onclick="startMonitor(${task.id})">📡 Monitor Stock</button>
        <button class="btn-monitor-stop" id="btn-monitor-stop-${task.id}" onclick="stopMonitor(${task.id})" style="display:none">⏹ Stop Monitor</button>
      </div>
    </div>

    <div class="card-actions">
      ${(task.pay_disabled_at || task.last_status === 'payment_locked')
        ? `<button class="btn-start" onclick="enablePayment(${task.id})" title="${escapeHtml(task.pay_disabled_reason || '')}">🔓 Re-enable payment</button>`
        : ''}
      <button class="btn-start" onclick="startTask(${task.id})">▶ Start Now</button>
      <button class="btn-stop"  onclick="stopTask(${task.id})">■ Stop</button>
      <button class="btn-icon"  onclick="editTask(${taskJson})">Edit</button>
      <button class="btn-icon"  onclick="cloneTask(${task.id})" title="Clone this task N times">⧉ Clone</button>
      <button class="btn-danger" onclick="deleteTask(${task.id})">Delete</button>
    </div>
  </div>`;
}

async function loadRuns() {
  const status = document.getElementById('runs-filter-status')?.value || '';
  const qs = status ? `?status=${encodeURIComponent(status)}` : '';
  const [runsRes, statsRes] = await Promise.all([
    fetch(`/v1/runs${qs}`).then(r => r.json()).catch(() => null),
    fetch(`/v1/runs/stats`).then(r => r.json()).catch(() => null)
  ]);
  const list = document.getElementById('runs-list');
  const statsEl = document.getElementById('runs-stats');
  if (statsEl && statsRes?.success) {
    const SITES = { 1:'Footsites',2:'Shopify',3:'Demandware',4:'Nike',5:'Supreme',6:'PokemonCenter',7:'Topps' };
    statsEl.innerHTML = (statsRes.data || []).map(s => `
      <div class="stat-card">
        <div class="stat-label">${SITES[s.site_id] || 'Site '+s.site_id}</div>
        <div class="stat-value">${s.successRate}%</div>
        <div class="stat-meta">${s.wins}/${s.total} wins · avg ${Math.round(s.avgMs/1000)}s</div>
      </div>`).join('') || '<div class="empty-state"><p>No runs yet.</p></div>';
  }
  if (!list) return;
  if (!runsRes?.success || !runsRes.data?.rows?.length) {
    list.innerHTML = `<div class="empty-state"><p>No runs match your filter.</p></div>`;
    return;
  }
  list.innerHTML = runsRes.data.rows.map(r => {
    const ok = r.status === 'success';
    const color = ok ? 'var(--success, #00ff9c)' : 'var(--danger, #ff3b5c)';
    const dur = r.duration_ms ? `${(r.duration_ms/1000).toFixed(1)}s` : '—';
    return `
      <div class="card">
        <div class="card-title" style="color:${color}">
          ${ok ? '✓' : '✗'} Task ${r.task_id} · attempt ${r.attempt} · ${r.status}
        </div>
        <div class="card-meta">${new Date(r.started_at).toLocaleString()} · ${dur}${r.profile_label ? ' · '+escapeHtml(r.profile_label) : ''}${r.proxy_host ? ' · '+escapeHtml(r.proxy_host) : ''}</div>
        ${r.order_number ? `<div class="card-meta">Order: <strong>${escapeHtml(r.order_number)}</strong></div>` : ''}
        ${r.stage_failed ? `<div class="card-meta">Failed at stage: <strong>${escapeHtml(r.stage_failed)}</strong></div>` : ''}
        ${r.error_message ? `<div class="card-meta" style="color:var(--text-muted);font-family:monospace;font-size:11px">${escapeHtml(r.error_message).slice(0,300)}</div>` : ''}
        ${r.screenshot_url ? `<div class="card-meta"><a href="${escapeHtml(r.screenshot_url)}" target="_blank">📷 Screenshot</a></div>` : ''}
      </div>`;
  }).join('');
}
window.loadRuns = loadRuns;

window.cloneTask = async (taskId) => {
  const count = parseInt(prompt('How many clones of this task? (1-50)', '5'), 10);
  if (!count || count < 1) return;
  try {
    const res = await fetch(`/v1/tasks/${taskId}/clone`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ count })
    }).then(r => r.json());
    alert(res.message || 'Cloned');
    if (res.success) loadTasks();
  } catch (e) { alert('Clone failed: ' + e.message); }
};

window.jigAddress = async (addressId) => {
  const count = parseInt(prompt('How many jigged variants? (1-20)\n\nEach variant uses email +tags, name initials, and street/apt micro-changes so the same household can place multiple orders without tripping per-address limits.', '5'), 10);
  if (!count || count < 1) return;
  try {
    const res = await fetch(`/v1/addresses/${addressId}/jig?count=${count}`, { method: 'POST' }).then(r => r.json());
    alert(res.message || 'Done');
    if (res.success) loadAddresses();
  } catch (e) { alert('Jig failed: ' + e.message); }
};

window.testProxy = async (proxyId) => {
  try {
    const res = await fetch(`/v1/proxies/${proxyId}/health`, { method: 'POST' }).then(r => r.json());
    if (!res.success) return alert('Test failed: ' + res.message);
    const d = res.data;
    const lines = d.results.map(r => `  ${r.target}\n    → ${r.ok ? '✓' : '✗'} HTTP ${r.status} · ${r.latencyMs}ms${r.blocked ? ' · BLOCKED' : ''}${r.error ? ' · ' + r.error : ''}`).join('\n');
    alert(`Proxy ${d.host}:${d.port} → ${d.summary.toUpperCase()}\nAvg latency: ${d.avgLatency}ms\n\n${lines}`);
  } catch (e) { alert('Test failed: ' + e.message); }
};

async function checkPreflight(taskId) {
  const badge = document.getElementById(`preflight-${taskId}`);
  if (badge) { badge.textContent = '… checking'; badge.className = 'badge badge-blue'; }
  const res = await fetch(`${API}/tasks/${taskId}/preflight`).then(r => r.json()).catch(() => null);
  if (!res || !res.success || !res.data || typeof res.data.ok === 'undefined') {
    if (badge) { badge.className = 'badge badge-red'; badge.textContent = '✗ check failed'; }
    toast(res?.message || 'Preflight check failed', 'error');
    return;
  }
  const ok = !!res.data.ok;
  const issues = Array.isArray(res.data.issues) ? res.data.issues : [];
  const warnings = Array.isArray(res.data.warnings) ? res.data.warnings : [];
  const summary = res.data.summary || (ok ? 'OK' : 'Issues');
  if (badge) {
    badge.className = ok ? 'badge badge-green' : 'badge badge-red';
    badge.textContent = ok ? `✓ ${summary}` : `✗ ${summary}`;
  }
  const lines = [];
  issues.forEach(i => lines.push(`✗ ${i}`));
  warnings.forEach(w => lines.push(`⚠ ${w}`));
  if (lines.length === 0) lines.push('All checks passed');
  toast(lines.join('\n'), ok ? 'success' : 'error');
}
window.checkPreflight = checkPreflight;

// Live drop-time countdown updater
setInterval(() => {
  document.querySelectorAll('[id^="drop-"][data-start]').forEach((el) => {
    const t = new Date(el.getAttribute('data-start')).getTime();
    const ms = t - Date.now();
    if (isNaN(t)) return;
    if (ms <= 0) { el.textContent = '⏱ DROPPED'; el.className = 'badge badge-green'; return; }
    const s = Math.floor(ms / 1000);
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    el.textContent = `⏱ T-${h > 0 ? `${h}h ` : ''}${m}m ${String(sec).padStart(2,'0')}s`;
    el.className = ms < 60_000 ? 'badge badge-red' : 'badge badge-yellow';
  });
}, 1000);

// ── MONITORING ───────────────────────────────────────────────────────────────
// Server-authoritative monitor hydration. Keeps task cards correct after
// dashboard reloads/reconnects and reattaches per-task SSE streams.
async function hydrateMonitorStates() {
  try {
    const res = await get('/tasks/monitors/all');
    if (!res?.success || !res.data) return;
    for (const [taskId, m] of Object.entries(res.data)) {
      const id = Number(taskId);
      const btn = document.getElementById(`btn-monitor-${id}`);
      const btnStop = document.getElementById(`btn-monitor-stop-${id}`);
      const dot = document.getElementById(`stock-dot-${id}`);
      const label = document.getElementById(`stock-label-${id}`);
      const stageMeta = document.getElementById(`stage-meta-${id}`);
      if (!btn || !btnStop || !dot || !label) continue;
      if (m.active === false) continue;
      btn.style.display = 'none';
      btnStop.style.display = '';
      dot.className = /checkout|instock/i.test(m.status || '') ? 'stock-dot checkout' : 'stock-dot checking';
      label.textContent = m.message || `Monitoring — ${m.status || 'checking'}`;
      label.className = 'stock-label checking';
      if (stageMeta && m.stage) {
        stageMeta.style.display = '';
        stageMeta.innerHTML = `Stage: <strong>${escapeHtml(m.stage)}</strong>`;
      }
      openStream(id);
    }
  } catch (_) {}
}

async function startMonitor(taskId) {
  const btn      = document.getElementById(`btn-monitor-${taskId}`);
  const btnStop  = document.getElementById(`btn-monitor-stop-${taskId}`);
  const dot      = document.getElementById(`stock-dot-${taskId}`);
  const label    = document.getElementById(`stock-label-${taskId}`);

  btn.disabled = true;
  dot.className = 'stock-dot checking';
  label.textContent = 'Starting monitor…';
  label.className = 'stock-label checking';

  const res = await post(`/tasks/${taskId}/monitor/start`);
  if (!res.success) {
    toast(res.message || 'Failed to start monitor', 'error');
    btn.disabled = false;
    // Reset the status row (e.g. Pokemon Center outside 8am–6pm ET returns 409)
    dot.className = 'stock-dot idle';
    if (res.data?.outsideBusinessHours) {
      label.textContent = 'Outside 8am–6pm ET — auto-starts at 8am';
      label.className = 'stock-label';
      label.style.color = 'var(--text-muted)';
    } else {
      label.textContent = 'Not monitoring';
      label.className = 'stock-label';
    }
    return;
  }

  btn.style.display = 'none';
  btnStop.style.display = '';
  dot.className = 'stock-dot checking';
  label.textContent = 'Checking every 2 seconds…';

  openStream(taskId);
}

function openStream(taskId) {
  if (activeStreams[taskId]) {
    activeStreams[taskId].close();
  }

  const es = new EventSource(`${API}/tasks/${taskId}/monitor/stream`);
  activeStreams[taskId] = es;

  es.onmessage = (e) => {
    try {
      const data = JSON.parse(e.data);
      handleMonitorUpdate(taskId, data);
    } catch (_) {}
  };

  es.onerror = () => {
    const label = document.getElementById(`stock-label-${taskId}`);
    if (label) label.textContent = 'Connection lost — retrying…';
  };
}

function reattachStream(taskId) {
  openStream(taskId);
}

function handleMonitorUpdate(taskId, data) {
  const dot     = document.getElementById(`stock-dot-${taskId}`);
  const label   = document.getElementById(`stock-label-${taskId}`);
  const preview = document.getElementById(`product-preview-${taskId}`);
  const card    = document.getElementById(`task-card-${taskId}`);
  const btn     = document.getElementById(`btn-monitor-${taskId}`);
  const btnStop = document.getElementById(`btn-monitor-stop-${taskId}`);

  if (!dot) return;

  const now = new Date().toLocaleTimeString();

  if (data.status === 'idle' || data.status === 'stopped') {
    dot.className = 'stock-dot idle';
    label.textContent = 'Not monitoring';
    label.className = 'stock-label';
    card.classList.remove('instock-flash');
    btn.style.display = '';
    btnStop.style.display = 'none';
    btn.disabled = false;
    if (preview) preview.innerHTML = '';
    if (activeStreams[taskId]) { activeStreams[taskId].close(); delete activeStreams[taskId]; }
    return;
  }

  if (data.status === 'outofstock') {
    dot.className = 'stock-dot outofstock';
    label.textContent = `Out of stock — last checked ${now}`;
    label.className = 'stock-label outofstock';
    card.classList.remove('instock-flash');
  }

  if (data.status === 'blocked') {
    dot.className = 'stock-dot checking';
    label.textContent = `⚠️ Bot protection hit — rotating agent… (${now})`;
    label.className = 'stock-label checking';
  }

  if (data.status === 'instock') {
    dot.className = 'stock-dot instock';
    label.textContent = `🟢 IN STOCK — ${now}`;
    label.className = 'stock-label instock';
    card.classList.add('instock-flash');
    toast(`IN STOCK detected for task ${taskId}! Starting checkout…`, 'success');
  }

  const stageMeta = document.getElementById(`stage-meta-${taskId}`);
  if (stageMeta && data.stage) {
    stageMeta.style.display = '';
    stageMeta.innerHTML = `Stage: <strong>${escapeHtml(data.stage)}</strong>`;
  }

  if (data.status === 'checkout_started') {
    dot.className = 'stock-dot checkout';
    label.textContent = '🛒 Checkout in progress…';
    label.className = 'stock-label checkout_started';
  }

  if (data.status === 'checkout_failed') {
    dot.className = 'stock-dot outofstock';
    label.textContent = `❌ Checkout failed: ${data.error}`;
    label.className = 'stock-label outofstock';
    card.classList.remove('instock-flash');
  }

  if (preview && (data.productName || data.imageUrl)) {
    preview.innerHTML = `
      <div class="product-preview">
        ${data.imageUrl ? `<img src="${data.imageUrl}" alt="product" onerror="this.style.display='none'" />` : ''}
        <div class="product-preview-info">
          ${data.productName ? `<div class="product-preview-name">${data.productName}</div>` : ''}
          ${data.price       ? `<div class="product-preview-price">${data.price}</div>`       : ''}
          <div class="last-checked">Checked at ${now}</div>
        </div>
      </div>`;
  } else if (preview) {
    const lastChecked = preview.querySelector('.last-checked');
    if (lastChecked) lastChecked.textContent = `Checked at ${now}`;
  }
}

async function stopMonitor(taskId) {
  if (activeStreams[taskId]) {
    activeStreams[taskId].close();
    delete activeStreams[taskId];
  }
  let res;
  try {
    res = await post(`/tasks/${taskId}/monitor/stop`);
  } catch (err) {
    toast(`Monitor stop failed: ${err.message}`, 'error');
    return false;
  }
  if (!res?.success) {
    toast(res?.message || 'Failed to stop monitor', 'error');
    return false;
  }
  const dot     = document.getElementById(`stock-dot-${taskId}`);
  const label   = document.getElementById(`stock-label-${taskId}`);
  const card    = document.getElementById(`task-card-${taskId}`);
  const btn     = document.getElementById(`btn-monitor-${taskId}`);
  const btnStop = document.getElementById(`btn-monitor-stop-${taskId}`);
  if (dot)    dot.className = 'stock-dot idle';
  if (label)  { label.textContent = 'Not monitoring'; label.className = 'stock-label'; }
  if (card)   card.classList.remove('instock-flash');
  if (btn)    { btn.style.display = ''; btn.disabled = false; }
  if (btnStop) btnStop.style.display = 'none';
  toast('Monitor stopped');
  return true;
}

// ── TASK START / STOP ────────────────────────────────────────────────────────
async function startTask(id) {
  taskStatuses[id] = 'running';
  document.querySelector(`#dot-${id}`).className = 'status-dot running';
  const res = await post(`/tasks/${id}/start`);
  if (res.success) toast('Task started!', 'success');
  else {
    taskStatuses[id] = 'failed';
    document.querySelector(`#dot-${id}`).className = 'status-dot failed';
    toast(res.message || 'Failed to start task', 'error');
  }
}

async function stopTask(id) {
  let res;
  try {
    res = await post(`/tasks/${id}/stop`);
  } catch (err) {
    toast(`Task stop failed: ${err.message}`, 'error');
    return;
  }
  if (!res?.success) {
    toast(res?.message || 'Failed to stop task', 'error');
    return;
  }

  taskStatuses[id] = 'idle';
  const dot = document.querySelector(`#dot-${id}`);
  if (dot) dot.className = 'status-dot idle';

  // The task stop endpoint now tears down both the checkout page and any stock
  // monitor. Close only the browser-side SSE stream here; don't issue a second
  // monitor-stop request that could race the backend cleanup.
  if (activeStreams[id]) {
    activeStreams[id].close();
    delete activeStreams[id];
  }
  const stockDot = document.getElementById(`stock-dot-${id}`);
  const stockLabel = document.getElementById(`stock-label-${id}`);
  const monitorBtn = document.getElementById(`btn-monitor-${id}`);
  const monitorStopBtn = document.getElementById(`btn-monitor-stop-${id}`);
  if (stockDot) stockDot.className = 'stock-dot idle';
  if (stockLabel) { stockLabel.textContent = 'Not monitoring'; stockLabel.className = 'stock-label'; }
  if (monitorBtn) { monitorBtn.style.display = ''; monitorBtn.disabled = false; }
  if (monitorStopBtn) monitorStopBtn.style.display = 'none';
  toast('Task stopped');
}

// Clear a payment lock and re-render. Deliberately explicit: after 5 declines
// the card is presumed dead, so nothing runs again until a human says so.
async function enablePayment(id) {
  let res;
  try {
    res = await post(`/tasks/${id}/enable-payment`);
  } catch (err) {
    toast(`Could not re-enable payment: ${err.message}`, 'error');
    return;
  }
  if (!res?.success) {
    toast(res?.message || 'Could not re-enable payment', 'error');
    return;
  }
  toast('Payment re-enabled — task can run again', 'success');
  await loadTasks();
}

async function deleteTask(id) {
  if (!confirm('Delete this task?')) return;
  let res;
  try {
    // The backend delete endpoint tears down both monitor and browser state.
    res = await del(`/tasks/${id}`);
  } catch (err) {
    toast(`Task delete failed: ${err.message}`, 'error');
    return;
  }
  if (!res?.success) {
    toast(res?.message || 'Failed to delete task', 'error');
    return;
  }
  if (activeStreams[id]) {
    activeStreams[id].close();
    delete activeStreams[id];
  }
  toast('Task deleted', 'success');
  loadTasks();
}

function editTask(task) {
  document.getElementById('task-id').value = task.id;
  document.getElementById('task-url').value = task.url;
  document.getElementById('task-site').value = task.site_id;
  document.getElementById('task-keywords').value = task.keywords || '';
  document.getElementById('task-size').value = task.size || '';
  document.getElementById('task-coupon').value = task.coupon_code || '';
  document.getElementById('task-email').value = task.notification_email_address || '';
  document.getElementById('task-captcha').checked = !!task.auto_solve_captchas;
  document.getElementById('task-monitor-247').checked = !!task.monitor_24_7;
  // Always clear relationship selects first. Otherwise editing a task with no
  // saved address/payment can inherit the previous task's selection from the
  // same modal, producing an unintended configuration on save.
  document.getElementById('task-shipping').value = '';
  document.getElementById('task-billing').value = '';
  document.getElementById('task-payment').value = '';
  if (task.shipping_address_id != null) document.getElementById('task-shipping').value = String(task.shipping_address_id);
  if (task.billing_address_id != null)  document.getElementById('task-billing').value  = String(task.billing_address_id);
  if (task.payment_profile_id != null)  document.getElementById('task-payment').value  = String(task.payment_profile_id);
  populateTaskProxySelectors(task);
  document.getElementById('task-modal-title').textContent = 'Edit Task';
  openModal('task-modal');
}

document.getElementById('task-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = document.getElementById('task-id').value;
  const body = {
    url:                        document.getElementById('task-url').value,
    site_id:                    parseInt(document.getElementById('task-site').value),
    keywords:                   document.getElementById('task-keywords').value || '',
    size:                       document.getElementById('task-size').value || '',
    coupon_code:                document.getElementById('task-coupon').value || '',
    notification_email_address: document.getElementById('task-email').value || '',
    auto_solve_captchas:        document.getElementById('task-captcha').checked,
    monitor_24_7:                document.getElementById('task-monitor-247').checked,
    proxy_id:                     null,
    monitor_proxy_id:             selectionToProxyFields(document.getElementById('task-monitor-proxy').value).id,
    checkout_proxy_id:            selectionToProxyFields(document.getElementById('task-checkout-proxy').value).id,
    monitor_proxy_mode:           selectionToProxyFields(document.getElementById('task-monitor-proxy').value).mode,
    checkout_proxy_mode:          selectionToProxyFields(document.getElementById('task-checkout-proxy').value).mode,
    shipping_address_id:        parseInt(document.getElementById('task-shipping').value) || null,
    billing_address_id:         parseInt(document.getElementById('task-billing').value)  || null,
    payment_profile_id:         parseInt(document.getElementById('task-payment').value)  || null,
  };
  const res = id ? await patch(`/tasks/${id}`, body) : await post('/tasks', body);
  if (res.success) {
    toast(id ? 'Task updated!' : 'Task created!', 'success');
    closeModal('task-modal');
    document.getElementById('task-modal-title').textContent = 'New Task';
    document.getElementById('task-id').value = '';
    e.target.reset();
    loadTasks();
  } else {
    toast(res.message || 'Error saving task', 'error');
  }
});

// ── ADDRESSES ────────────────────────────────────────────────────────────────
async function loadAddresses() {
  const res = await get('/addresses');
  const container = document.getElementById('addresses-list');
  if (!res.data || res.data.length === 0) {
    container.innerHTML = `<div class="empty-state"><p>No addresses yet.</p></div>`;
    return;
  }
  container.innerHTML = res.data.map(a => `
    <div class="card">
      <div class="card-title">${a.first_name} ${a.last_name}</div>
      <div class="card-meta">${a.address1}${a.address2 ? ', ' + a.address2 : ''}</div>
      <div class="card-meta">${a.city}, ${a.state} ${a.zip} — ${a.country}</div>
      <div class="card-meta">${a.phone} · ${a.email}</div>
      <div class="card-actions">
        <button class="btn-icon" onclick="editAddress(${JSON.stringify(a).replace(/"/g, '&quot;')})">Edit</button>
        <button class="btn-icon" onclick="jigAddress(${a.id})" title="Generate N jigged variants to bypass per-address purchase limits">⚡ Jig</button>
        <button class="btn-danger" onclick="deleteAddress(${a.id})">Delete</button>
      </div>
    </div>`).join('');
}

function editAddress(a) {
  document.getElementById('address-id').value = a.id;
  document.getElementById('addr-first').value = a.first_name;
  document.getElementById('addr-last').value = a.last_name;
  document.getElementById('addr-addr1').value = a.address1;
  document.getElementById('addr-addr2').value = a.address2 || '';
  document.getElementById('addr-city').value = a.city;
  document.getElementById('addr-state').value = a.state;
  document.getElementById('addr-zip').value = a.zip;
  document.getElementById('addr-country').value = a.country;
  document.getElementById('addr-phone').value = a.phone;
  document.getElementById('addr-email').value = a.email;
  document.getElementById('address-modal-title').textContent = 'Edit Address';
  openModal('address-modal');
}

async function deleteAddress(id) {
  if (!confirm('Delete this address?')) return;
  let res;
  try { res = await del(`/addresses/${id}`); }
  catch (err) { toast(`Address delete failed: ${err.message}`, 'error'); return; }
  if (!res?.success) { toast(res?.message || 'Failed to delete address', 'error'); return; }
  toast('Address deleted', 'success');
  loadAddresses();
}

document.getElementById('address-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = document.getElementById('address-id').value;
  const body = {
    first_name: document.getElementById('addr-first').value,
    last_name:  document.getElementById('addr-last').value,
    address1:   document.getElementById('addr-addr1').value,
    address2:   document.getElementById('addr-addr2').value || '',
    city:       document.getElementById('addr-city').value,
    state:      document.getElementById('addr-state').value,
    zip:        document.getElementById('addr-zip').value,
    country:    document.getElementById('addr-country').value,
    phone:      document.getElementById('addr-phone').value,
    email:      document.getElementById('addr-email').value
  };
  const res = id ? await patch(`/addresses/${id}`, body) : await post('/addresses', body);
  if (res.success) {
    toast(id ? 'Address updated!' : 'Address created!', 'success');
    closeModal('address-modal');
    document.getElementById('address-modal-title').textContent = 'New Address';
    document.getElementById('address-id').value = '';
    e.target.reset();
    document.getElementById('addr-country').value = 'CA';
    loadAddresses();
  } else {
    toast(res.message || 'Error saving address', 'error');
  }
});

// ── PAYMENT PROFILES ─────────────────────────────────────────────────────────
async function loadPaymentProfiles() {
  const res = await get('/payment-profiles');
  const container = document.getElementById('payments-list');
  if (!res.data || res.data.length === 0) {
    container.innerHTML = `<div class="empty-state"><p>No payment profiles yet.</p></div>`;
    return;
  }
  container.innerHTML = res.data.map(p => {
    const last4 = String(p.card_number).slice(-4);
    return `
    <div class="card">
      <div class="card-title">${p.label}</div>
      <div class="card-meta"><span class="badge badge-blue">${detectCardType(p.card_number)}</span> **** **** **** ${last4}</div>
      <div class="card-meta">${p.card_holder_name} · Exp ${p.expiration_month}/${p.expiration_year}</div>
      <div class="card-actions">
        <button class="btn-icon" onclick="editPaymentProfile(${JSON.stringify(p).replace(/"/g, '&quot;')})">Edit</button>
        <button class="btn-danger" onclick="deletePaymentProfile(${p.id})">Delete</button>
      </div>
    </div>`;
  }).join('');
}

function editPaymentProfile(p) {
  document.getElementById('payment-id').value = p.id;
  document.getElementById('pay-label').value = p.label;
  document.getElementById('pay-holder').value = p.card_holder_name;
  document.getElementById('pay-number').value = p.card_number;
  document.getElementById('pay-month').value = p.expiration_month;
  document.getElementById('pay-year').value = p.expiration_year;
  document.getElementById('pay-cvv').value = p.cvv;
  document.getElementById('payment-modal-title').textContent = 'Edit Payment Profile';
  openModal('payment-modal');
}

async function deletePaymentProfile(id) {
  if (!confirm('Delete this payment profile?')) return;
  let res;
  try { res = await del(`/payment-profiles/${id}`); }
  catch (err) { toast(`Payment profile delete failed: ${err.message}`, 'error'); return; }
  if (!res?.success) { toast(res?.message || 'Failed to delete payment profile', 'error'); return; }
  toast('Payment profile deleted', 'success');
  loadPaymentProfiles();
}

document.getElementById('payment-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = document.getElementById('payment-id').value;
  const body = {
    label:             document.getElementById('pay-label').value,
    card_holder_name:  document.getElementById('pay-holder').value,
    card_number:       document.getElementById('pay-number').value.replace(/\s/g, ''),
    expiration_month:  document.getElementById('pay-month').value.padStart(2, '0'),
    expiration_year:   document.getElementById('pay-year').value,
    cvv:               document.getElementById('pay-cvv').value
  };
  const res = id ? await patch(`/payment-profiles/${id}`, body) : await post('/payment-profiles', body);
  if (res.success) {
    toast(id ? 'Profile updated!' : 'Profile created!', 'success');
    closeModal('payment-modal');
    document.getElementById('payment-modal-title').textContent = 'New Payment Profile';
    document.getElementById('payment-id').value = '';
    e.target.reset();
    loadPaymentProfiles();
  } else {
    toast(res.message || 'Error saving profile', 'error');
  }
});

// ── PROXIES ──────────────────────────────────────────────────────────────────
async function loadProxies() {
  const [res, meta] = await Promise.all([get('/proxies'), get('/proxies/meta')]);
  const container = document.getElementById('proxies-list');
  const budget = meta?.data?.residentialBudget;
  const budgetBox = document.getElementById('proxy-budget-status');
  if (budgetBox && budget) {
    const pct = Math.min(100, Math.max(0, Number(budget.percentUsed || 0)));
    const mon = budget.monitor || {};
    const co = budget.checkout || {};
    budgetBox.innerHTML = `
      <div class="card">
        <div class="card-title">🏠 Residential bandwidth budget</div>
        <div class="card-meta">Monitoring: ${escapeHtml(String(mon.usedMb ?? 0))} / ${escapeHtml(String(mon.monthlyBudgetMb ?? 1024))} MB</div>
        <div class="card-meta">Checkout: ${escapeHtml(String(co.usedMb ?? 0))} / ${escapeHtml(String(co.monthlyBudgetMb ?? 1024))} MB</div>
        <div class="card-meta">Direct monitoring can promote to the configured residential gateway when Pokémon Center access is denied. Checkout uses its dedicated residential gateway when configured.</div>
      </div>`;
  }
  if (!res.data || res.data.length === 0) {
    container.innerHTML = `<div class="empty-state"><p>No proxies yet.</p></div>`;
    return;
  }
  container.innerHTML = res.data.map(p => `
    <div class="card">
      <div class="card-title">${p.proxy_type === 'residential' ? '🏠 ' : p.proxy_type === 'mobile' ? '📱 ' : ''}${escapeHtml(p.label || `${p.host}:${p.port}`)}</div>
      <div class="card-meta">${escapeHtml(p.host)}:${p.port} · ${escapeHtml(p.proxy_type || 'unknown')}</div>
      ${p.username ? `<div class="card-meta">Auth: ${escapeHtml(p.username)}</div>` : '<div class="card-meta" style="color:var(--text-muted)">No auth</div>'}
      <div class="card-actions">
        <button class="btn-icon" onclick="editProxy(${JSON.stringify(p).replace(/"/g, '&quot;')})">Edit</button>
        <button class="btn-icon" onclick="testProxy(${p.id})" title="Test latency and reachability against PokemonCenter + Topps">🔌 Test</button>
        <button class="btn-danger" onclick="deleteProxy(${p.id})">Delete</button>
      </div>
    </div>`).join('');
}
function editProxy(p) {
  document.getElementById('proxy-id').value = p.id;
  document.getElementById('proxy-host').value = p.host;
  document.getElementById('proxy-port').value = p.port;
  document.getElementById('proxy-user').value = p.username || '';
  document.getElementById('proxy-pass').value = p.password || '';
  document.getElementById('proxy-type').value = p.proxy_type || 'unknown';
  document.getElementById('proxy-label').value = p.label || '';
  document.getElementById('proxy-modal-title').textContent = 'Edit Proxy';
  openModal('proxy-modal');
}

async function deleteProxy(id) {
  if (!confirm('Delete this proxy?')) return;
  let res;
  try { res = await del(`/proxies/${id}`); }
  catch (err) { toast(`Proxy delete failed: ${err.message}`, 'error'); return; }
  if (!res?.success) { toast(res?.message || 'Failed to delete proxy', 'error'); return; }
  toast('Proxy deleted', 'success');
  loadProxies();
}

document.getElementById('proxy-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = document.getElementById('proxy-id').value;
  const body = {
    host:     document.getElementById('proxy-host').value,
    port:     parseInt(document.getElementById('proxy-port').value),
    username: document.getElementById('proxy-user').value || '',
    password: document.getElementById('proxy-pass').value || '',
    proxy_type: document.getElementById('proxy-type').value || 'unknown',
    label: document.getElementById('proxy-label').value || ''
  };
  const res = id ? await patch(`/proxies/${id}`, body) : await post('/proxies', body);
  if (res.success) {
    toast(id ? 'Proxy updated!' : 'Proxy created!', 'success');
    closeModal('proxy-modal');
    document.getElementById('proxy-modal-title').textContent = 'New Proxy';
    document.getElementById('proxy-id').value = '';
    document.getElementById('proxy-type').value = 'unknown';
    document.getElementById('proxy-label').value = '';
    e.target.reset();
    document.getElementById('proxy-type').value = 'unknown';
    loadProxies();
  } else {
    toast(res.message || 'Error saving proxy', 'error');
  }
});

// ── SETTINGS ─────────────────────────────────────────────────────────────────
async function loadSettings() {
  const res = await get('/settings');
  const settings = {};
  (res.data || []).forEach(s => settings[s.key] = s.value);
  if (settings.captcha_api_key)     document.getElementById('captcha-key-input').value   = settings.captcha_api_key;
  if (settings.capmonster_api_key)  document.getElementById('capmonster-key-input').value = settings.capmonster_api_key;
  if (settings.capsolver_api_key)   document.getElementById('capsolver-key-input').value  = settings.capsolver_api_key;
  if (settings.anticaptcha_api_key) document.getElementById('anticaptcha-key-input').value = settings.anticaptcha_api_key;
  if (settings.discord_webhook_url) document.getElementById('discord-webhook-input').value = settings.discord_webhook_url;
  if (settings.webhook_url)         document.getElementById('webhook-input').value        = settings.webhook_url;
  const pollInput = document.getElementById('monitor-poll-input');
  if (pollInput) pollInput.value = settings.monitor_poll_ms || '1000';
  const residentialState = document.getElementById('residential-gateway-state');
  if (residentialState) {
    try {
      const meta = await get('/proxies/meta');
      const rg = meta?.data?.residentialGateway || {};
      residentialState.textContent = rg.monitorConfigured || rg.checkoutConfigured
        ? `Configured — monitoring: ${rg.monitorConfigured ? 'yes' : 'no'} · checkout: ${rg.checkoutConfigured ? 'yes' : 'no'}`
        : 'Not configured — set RESIDENTIAL_PROXY_URL in your .env';
      residentialState.style.color = (rg.monitorConfigured || rg.checkoutConfigured) ? 'var(--success, #00ff9c)' : 'var(--text-muted)';
    } catch (_) {}
  }

  // Pokemon Center business hours — default ON when the setting is absent;
  // OFF only when explicitly set to a falsey value (mirrors the backend).
  const pcHours = document.getElementById('pc-hours-input');
  if (pcHours) {
    const raw = settings.pc_business_hours_enabled;
    const enabled = raw == null ? true : !['false', '0', 'off', 'no', ''].includes(String(raw).trim().toLowerCase());
    pcHours.checked = enabled;
    const state = document.getElementById('pc-hours-state');
    if (state) state.textContent = enabled ? 'Enabled — PC runs 8am–6pm ET only' : 'Disabled — PC runs anytime';
  }
}

async function saveMonitorPollSetting() {
  const input = document.getElementById('monitor-poll-input');
  const value = Math.max(300, Math.min(10000, parseInt(input?.value || '1000', 10) || 1000));
  if (input) input.value = value;
  return saveSetting('monitor_poll_ms', String(value));
}

async function saveSetting(key, value) {
  const res = await put(`/settings/${key}`, { value });
  if (res.success) toast('Setting saved!', 'success');
  else toast('Error saving setting', 'error');
}

async function testNotif(channel) {
  toast(`Sending test ${channel} notification…`);
  const res = await post(`/settings/test/${channel}`);
  if (res.success) toast(res.message, 'success');
  else toast(res.message || 'Test failed', 'error');
}

// ── ACTIVITY ─────────────────────────────────────────────────────────────────
let _activityTimer = null;
let _activityInflight = false;
const ACTIVITY_INTERVAL_MS = 8000;

const escapeHtml = (s) => String(s ?? '').replace(/[<>&"']/g, (c) => ({
  '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&#39;'
}[c]));
const safeAttr = escapeHtml;
const safeClass = (s) => String(s ?? '').toLowerCase().replace(/[^a-z0-9_-]/g, '');
const safeUrl = (u) => {
  const s = String(u ?? '');
  if (/^\/v1\/screenshots\/[A-Za-z0-9._%-]+$/.test(s)) return s;
  return '';
};

function loadActivity() {
  if (_activityTimer) { clearInterval(_activityTimer); _activityTimer = null; }
  _activityTimer = setInterval(refreshActivity, ACTIVITY_INTERVAL_MS);
  refreshActivity();
}

async function refreshActivity() {
  const isVisible = document.getElementById('tab-activity')?.classList.contains('active');
  if (!isVisible) {
    if (_activityTimer) { clearInterval(_activityTimer); _activityTimer = null; }
    return;
  }
  if (_activityInflight) return;
  _activityInflight = true;
  try {
    const [statsRes, logsRes, shotsRes] = await Promise.all([
      get('/stats').catch(() => ({ data: null })),
      get('/logs').catch(() => ({ data: [] })),
      get('/screenshots').catch(() => ({ data: [] }))
    ]);
    renderStats(statsRes.data);
    renderLogs((logsRes.data || []).slice(0, 50));
    renderShots(shotsRes.data || []);
  } finally {
    _activityInflight = false;
  }
}

function renderStats(s) {
  const el = document.getElementById('stats-grid');
  if (!el) return;
  if (!s) { el.innerHTML = ''; return; }
  const cards = [
    { label: 'Active Tasks',         value: s.activeTasks,          accent: 'blue' },
    { label: 'Successful Checkouts', value: s.successfulCheckouts,  accent: 'green' },
    { label: 'Success Rate',         value: s.successRate + '%',    accent: 'green' },
    { label: 'Active Monitors',      value: s.activeMonitors,       accent: s.activeMonitors > 0 ? 'green' : 'gray' },
    { label: 'Errors Logged',        value: s.recentLogsErr,        accent: s.recentLogsErr > 0 ? 'red' : 'gray' },
    { label: 'Addresses / Cards / Proxies', value: `${s.addresses} · ${s.payments} · ${s.proxies}`, accent: 'gray' }
  ];
  el.innerHTML = cards.map(c => `
    <div class="stat-card stat-${safeClass(c.accent)}">
      <div class="stat-value">${escapeHtml(c.value)}</div>
      <div class="stat-label">${escapeHtml(c.label)}</div>
    </div>`).join('');
}

function renderLogs(logs) {
  const el = document.getElementById('logs-list');
  if (!el) return;
  if (!logs.length) { el.innerHTML = `<div class="empty-state"><p>No logs yet.</p></div>`; return; }
  el.innerHTML = logs.map(l => {
    const lvlRaw = (l.level || 'info').toLowerCase();
    const lvl = ['info','warn','error','debug'].includes(lvlRaw) ? lvlRaw : 'info';
    const ts = l.created_at ? new Date(l.created_at).toLocaleTimeString() : '';
    return `<div class="log-row log-${lvl}">
      <span class="log-time">${escapeHtml(ts)}</span>
      <span class="log-level lvl-${lvl}">${escapeHtml(lvl)}</span>
      <span class="log-msg">${escapeHtml(l.message)}</span>
    </div>`;
  }).join('');
}

function renderShots(shots) {
  const el = document.getElementById('shots-list');
  if (!el) return;
  if (!shots.length) { el.innerHTML = `<div class="empty-state"><p>No failure screenshots — clean run!</p></div>`; return; }
  el.innerHTML = shots.map(s => {
    const url = safeUrl(s.url);
    if (!url) return '';
    return `<a class="shot-card" href="${safeAttr(url)}" target="_blank" rel="noreferrer">
      <img src="${safeAttr(url)}" loading="lazy" alt="${safeAttr(s.filename)}" />
      <div class="shot-meta">
        <strong>Task ${escapeHtml(s.taskId ?? '?')}</strong> · ${escapeHtml(s.stage ?? '—')}<br/>
        <span class="text-muted">${escapeHtml(new Date(s.createdAt).toLocaleString())} · ${escapeHtml(s.sizeKb)}KB</span>
      </div>
    </a>`;
  }).join('');
}

// ── HELPERS ──────────────────────────────────────────────────────────────────
function populateSelect(id, items, labelFn) {
  const sel = document.getElementById(id);
  const current = sel.value;
  sel.innerHTML = '<option value="">— None —</option>' +
    items.map(item => `<option value="${item.id}">${labelFn(item)}</option>`).join('');
  if (current) sel.value = current;
}

function detectCardType(number) {
  const n = String(number).replace(/\s/g, '');
  if (/^4/.test(n))     return 'Visa';
  if (/^5[1-5]/.test(n)) return 'Mastercard';
  if (/^3[47]/.test(n)) return 'Amex';
  if (/^6/.test(n))     return 'Discover';
  return 'Card';
}

// ── INIT ─────────────────────────────────────────────────────────────────────
loadTasks();


// ═════════ STELLAR-STYLE COMMAND + LIVE WORKSPACE ═════════
let _feedTimer = null;
let _feedSse = null;
let _runStatsCache = null;

function switchTab(name) {
  const btn = document.querySelector(`.nav-btn[data-tab="${name}"]`);
  if (btn) btn.click();
}

function openCommandPalette() {
  const overlay = document.getElementById('command-palette');
  if (!overlay) return;
  overlay.style.display = 'flex';
  overlay.setAttribute('aria-hidden', 'false');
  const input = document.getElementById('command-input');
  input.value = '';
  renderCommandResults('');
  setTimeout(() => input.focus(), 0);
}

function closeCommandPalette() {
  const overlay = document.getElementById('command-palette');
  if (!overlay) return;
  overlay.style.display = 'none';
  overlay.setAttribute('aria-hidden', 'true');
}

function commandItems(query='') {
  const q = query.trim().toLowerCase();
  const items = [
    { title:'Create new task', sub:'Open the task builder', key:'N', run:() => openModal('task-modal') },
    { title:'Open Tasks', sub:'Task dashboard', run:() => switchTab('tasks') },
    { title:'Open Live Feed', sub:'Real-time monitor status', run:() => switchTab('feed') },
    { title:'Open Analytics', sub:'Performance and run history', run:() => switchTab('activity') },
    { title:'Refresh monitors', sub:'Reload current monitor state', key:'R', run:() => refreshLiveFeed() },
    { title:'Preflight active tasks', sub:'Validate profiles and task configuration', run:() => { closeCommandPalette(); document.querySelectorAll('[id^="preflight-"]').forEach(() => {}); refreshTasks(); } },
    { title:'Toggle high contrast', sub:'Accessibility mode', run:() => toggleHighContrast() }
  ];
  return q ? items.filter(x => `${x.title} ${x.sub}`.toLowerCase().includes(q)) : items;
}

function renderCommandResults(query='') {
  const el = document.getElementById('command-results');
  if (!el) return;
  const items = commandItems(query);
  el.innerHTML = items.map((x, i) => `
    <div class="command-item${i===0?' active':''}" data-command-index="${i}">
      <div><div class="command-item-title">${escapeHtml(x.title)}</div><div class="command-item-sub">${escapeHtml(x.sub)}</div></div>
      ${x.key ? `<div class="command-key">${escapeHtml(x.key)}</div>` : ''}
    </div>`).join('');
  el.querySelectorAll('.command-item').forEach((node, i) => node.addEventListener('click', () => { const item=items[i]; closeCommandPalette(); item?.run?.(); }));
}

function toggleHighContrast(force) {
  const on = typeof force === 'boolean' ? force : !document.body.classList.contains('high-contrast');
  document.body.classList.toggle('high-contrast', on);
  const input = document.getElementById('high-contrast-input');
  if (input) input.checked = on;
  localStorage.setItem('sb_high_contrast', on ? '1' : '0');
}

async function refreshSystemStatus() {
  const health = await fetch('/healthz', { cache: 'no-store' }).then(r => r.json()).catch(() => null);
  const badge = document.getElementById('system-health-badge');
  const mem = document.getElementById('system-memory-badge');
  if (!health?.ok) {
    if (badge) { badge.textContent = '● Server offline'; badge.className = 'badge badge-red'; }
    if (mem) mem.textContent = 'RAM —';
    return;
  }
  if (badge) {
    badge.textContent = `● Online · ${health.activeMonitors ?? 0} monitors`;
    badge.className = 'badge badge-green';
  }
  if (mem && health.memory) {
    const rssMb = Number(health.memory.rssMb || 0);
    mem.textContent = `RAM ${rssMb.toFixed(0)} MB`;
  }
}

async function refreshLiveFeed() {
  const list = document.getElementById('live-feed-list');
  if (!list) return;
  const [feedRes, runRes] = await Promise.all([
    get('/tasks/feed').catch(() => ({ data:{} })),
    get('/runs/stats').catch(() => ({ data:[] })),
    refreshSystemStatus()
  ]);
  const monitors = Array.isArray(feedRes.data?.monitors) ? feedRes.data.monitors : [];
  if (!monitors.length) {
    list.innerHTML = '<div class="empty-state"><p>No active monitors.</p></div>';
  } else {
    list.innerHTML = monitors.map(m => {
      const status = String(m.status || 'checking').toLowerCase();
      const cls = /checkout/.test(status) ? 'checkout' : /error|failed|blocked/.test(status) ? 'error' : 'live';
      return `<div class="live-feed-item">
        <span class="live-feed-dot ${cls}"></span>
        <div class="live-feed-main"><div class="live-feed-title">Task ${escapeHtml(m.taskId ?? '—')} · ${escapeHtml(m.siteId ?? 'site')} · ${escapeHtml(status)}${m.stage ? ' · ' + escapeHtml(m.stage) : ''}</div><div class="live-feed-meta">${escapeHtml(m.message || m.lastMessage || 'Monitor active')} ${m.lastCheckedAt ? '· ' + escapeHtml(new Date(m.lastCheckedAt).toLocaleTimeString()) : ''}</div></div>
        <div class="live-feed-actions"><button class="btn-icon" onclick="stopMonitor(${Number(m.taskId)})">Stop</button></div>
      </div>`;
    }).join('');
  }
  _runStatsCache = Array.isArray(runRes.data) ? runRes.data : [];
  const wins = _runStatsCache.reduce((a,r)=>a+Number(r.wins||0),0);
  const total = _runStatsCache.reduce((a,r)=>a+Number(r.total||0),0);
  const avg = _runStatsCache.filter(r=>r.avgMs).reduce((a,r)=>a+Number(r.avgMs),0) / Math.max(1,_runStatsCache.filter(r=>r.avgMs).length);
  const perf = document.getElementById('feed-performance');
  if (perf) perf.innerHTML = [
    ['Win rate', `${total ? Math.round(wins/total*100) : 0}%`],
    ['Runs', total],
    ['Avg duration', avg ? `${(avg/1000).toFixed(1)}s` : '—'],
    ['Sites', _runStatsCache.length]
  ].map(([label,value]) => `<div class="feed-metric"><div class="feed-metric-value">${escapeHtml(value)}</div><div class="feed-metric-label">${escapeHtml(label)}</div></div>`).join('');
}

function startLiveFeedPolling() {
  if (_feedTimer) clearInterval(_feedTimer);
  if (_feedSse) { try { _feedSse.close(); } catch (_) {} _feedSse = null; }

  // Real-time monitor feed: push changes over one SSE connection instead of
  // polling the dashboard every 2.5s. Keep a low-frequency fallback so the UI
  // still works behind proxies that do not support long-lived event streams.
  try {
    _feedSse = new EventSource(`${API}/tasks/feed/stream`);
    _feedSse.onmessage = () => {
      if (document.getElementById('tab-feed')?.classList.contains('active')) refreshLiveFeed();
    };
    _feedSse.onerror = () => {
      try { _feedSse?.close(); } catch (_) {}
      _feedSse = null;
      if (!_feedTimer) {
        _feedTimer = setInterval(() => {
          if (document.getElementById('tab-feed')?.classList.contains('active')) refreshLiveFeed();
        }, 10000);
      }
    };
  } catch (_) {}

  refreshLiveFeed();
}

const _oldOpenModal = window.openModal;
window.openModal = function(id) { if (_oldOpenModal) _oldOpenModal(id); };

document.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); openCommandPalette(); return; }
  if (e.key === 'Escape') { closeCommandPalette(); return; }
  if (e.key.toLowerCase() === 'n' && !['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName)) { e.preventDefault(); openModal('task-modal'); }
  if (e.key.toLowerCase() === 'r' && !['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName)) { refreshLiveFeed(); }
});

document.getElementById('command-input')?.addEventListener('input', (e) => renderCommandResults(e.target.value));
document.getElementById('command-input')?.addEventListener('keydown', (e) => {
  const nodes = [...document.querySelectorAll('.command-item')];
  if (!nodes.length) return;
  const active = nodes.findIndex(n => n.classList.contains('active'));
  if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
    e.preventDefault();
    const next = e.key === 'ArrowDown' ? (active + 1) % nodes.length : (active - 1 + nodes.length) % nodes.length;
    nodes.forEach(n => n.classList.remove('active')); nodes[next].classList.add('active'); nodes[next].scrollIntoView({block:'nearest'});
  } else if (e.key === 'Enter') {
    e.preventDefault(); nodes[Math.max(0, active)]?.click();
  }
});
document.getElementById('command-palette')?.addEventListener('click', (e) => { if (e.target.id === 'command-palette') closeCommandPalette(); });
document.getElementById('high-contrast-input')?.addEventListener('change', (e) => toggleHighContrast(e.target.checked));

try { toggleHighContrast(localStorage.getItem('sb_high_contrast') === '1'); } catch (_) {}
startLiveFeedPolling();
