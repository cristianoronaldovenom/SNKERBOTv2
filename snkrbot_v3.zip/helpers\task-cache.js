import logger from './logger.js';

const taskCache = new Map();

// Ask Blink to collect a torn-down page's renderer memory now instead of whenever
// the next allocation happens to trigger it.
//
// Chromium's own heuristics are tuned for a laptop with one foreground tab; a bot
// closes pages constantly and keeps launching new ones, so without this the freed
// renderer memory sits resident until pressure forces a sweep — which on a 2 GB box
// means the OOM killer arrives first. Both calls are best-effort and must never
// break teardown: a detached target rejects them routinely.
const nudgeGc = async (page) => {
  try {
    const cdp = await page.target().createCDPSession();
    await cdp.send('HeapProfiler.collectGarbage').catch(() => {});
    await cdp.detach?.().catch?.(() => {});
  } catch (_) { /* detached target: routine */ }
};

// Tell the renderer it is under memory pressure so V8 shrinks its heap rather than
// holding a peak. Uses Page.setWebLifecycleState, which is cheap and idempotent.
const notifyPressure = async (page) => {
  try {
    const cdp = await page.target().createCDPSession();
    await cdp.send('Page.setWebLifecycleState', { state: 'frozen' }).catch(() => {});
    await cdp.send('Page.setWebLifecycleState', { state: 'active' }).catch(() => {});
  } catch (_) { /* best effort */ }
};

export const storePageInTaskCache = ({ taskId, page }) => {
  if (taskId == null || !page) return;
  taskCache.set(Number(taskId), page);
};

export const retrievePageFromTaskCache = ({ taskId }) => taskCache.get(Number(taskId)) || null;

export const removePageFromTaskCache = async ({ taskId }) => {
  const key = Number(taskId);
  const page = taskCache.get(key);
  const startedAt = Date.now();
  try {
    if (page) {
      // Both before close(): the CDP target disappears with the page.
      await notifyPressure(page);
      await nudgeGc(page);
      await page.close();
    }
  } catch (_) {
    // page/browser already torn down
  } finally {
    taskCache.delete(key);
    if (page) logger.debug(`[TaskCache] Task ${key} page released in ${Date.now() - startedAt}ms`);
  }
};

export const clearTaskCache = async () => {
  const ids = Array.from(taskCache.keys());
  await Promise.all(ids.map((taskId) => removePageFromTaskCache({ taskId })));
};

export const taskCacheSize = () => taskCache.size;
