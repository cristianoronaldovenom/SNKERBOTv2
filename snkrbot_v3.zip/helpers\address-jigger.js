// Address jigging — generate N visually-different but mail-deliverable variants
// of one address so a single household can place N orders without tripping
// per-address purchase limits used by Pokemon Center, Topps, Shopify, etc.
//
// Tactics used (all USPS/Canada Post tolerant):
//   1. Street suffix expansion: "St" ⇄ "Street", "Ave" ⇄ "Avenue", "Rd" ⇄ "Road", etc.
//   2. Apartment line jigging: empty / "Apt 1" / "Unit 1" / "#1" / etc.
//   3. Email +tag aliasing: user@gmail.com → user+drop1@gmail.com (works on Gmail/Outlook/iCloud).
//   4. Name micro-variants: "John" / "John A" / "J A" (matches card name prefix tolerance at most processors).

const SUFFIX_EXPANSIONS = {
  'st': 'Street', 'street': 'St',
  'ave': 'Avenue', 'avenue': 'Ave',
  'rd': 'Road', 'road': 'Rd',
  'blvd': 'Boulevard', 'boulevard': 'Blvd',
  'dr': 'Drive', 'drive': 'Dr',
  'ln': 'Lane', 'lane': 'Ln',
  'ct': 'Court', 'court': 'Ct',
  'pl': 'Place', 'place': 'Pl',
  'pkwy': 'Parkway', 'parkway': 'Pkwy',
  'cir': 'Circle', 'circle': 'Cir',
  'hwy': 'Highway', 'highway': 'Hwy',
  'ter': 'Terrace', 'terrace': 'Ter'
};

const APT_VARIANTS = ['', 'Apt 1', 'Unit 1', '#1', 'Suite 1', 'Apt A'];

const swapStreetSuffix = (address1) => {
  const parts = String(address1 || '').trim().split(/\s+/);
  if (parts.length < 2) return address1;
  const last = parts[parts.length - 1].replace(/\.$/, '');
  const swap = SUFFIX_EXPANSIONS[last.toLowerCase()];
  if (!swap) return address1;
  parts[parts.length - 1] = swap;
  return parts.join(' ');
};

const aliasEmail = (email, n) => {
  if (!email || !email.includes('@')) return email;
  const [user, domain] = email.split('@');
  // Gmail / Outlook / iCloud all support +tag aliasing.
  if (user.includes('+')) {
    return `${user.split('+')[0]}+drop${n}@${domain}`;
  }
  return `${user}+drop${n}@${domain}`;
};

const variantName = (firstName, n) => {
  if (!firstName || n === 0) return firstName;
  // Append a middle initial that rotates A..Z. Most checkout flows accept
  // anything in the first-name field, and the card processor will match on
  // the first name + last name + ZIP combo.
  const initials = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  return `${firstName} ${initials[(n - 1) % 26]}`;
};

export const jigAddress = (base, count = 5) => {
  const n = Math.max(1, Math.min(50, parseInt(count, 10) || 5));
  const out = [];
  // Always include the original as variant 0 reference (not inserted).
  for (let i = 1; i <= n; i++) {
    const swapStreet = i % 2 === 1;          // alternate suffix swapping
    const apt = APT_VARIANTS[i % APT_VARIANTS.length];
    const v = {
      ...base,
      first_name: variantName(base.first_name, i),
      address1: swapStreet ? swapStreetSuffix(base.address1) : base.address1,
      address2: apt,
      email: aliasEmail(base.email, i)
    };
    delete v.id;
    delete v.created_at;
    delete v.updated_at;
    out.push(v);
  }
  return out;
};
