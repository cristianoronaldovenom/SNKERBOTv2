// Geolocation / locale / Accept-Language consistency.
//
// Real users have one consistent geographic identity: their browser timezone,
// HTML5 geolocation API, Accept-Language header, and proxy IP all agree.
// Bots that randomize each independently leak the inconsistency to anti-fraud
// scoring (Riskified, Forter, Stripe Radar, Imperva). Pro bots build a
// "geo profile" once and apply it everywhere.
//
// Map fingerprint timezone → {lat, lng, locale, accept-language}. The
// coordinates are city center with a small random jitter (~5km radius) so two
// tasks with the same timezone don't claim identical GPS positions.
//
// NEW: when the exit IP's timezone is known it wins over the pinned profile
// timezone. A pinned America/Toronto session egressing through a Los Angeles
// residential proxy while still reporting a Toronto clock is a hard mismatch
// that IP-intelligence-backed vendors score immediately.
import logger from './logger.js';

const GEO_BY_TZ = {
  'America/Toronto':   { lat: 43.6532, lng: -79.3832, locale: 'en-CA', acceptLang: 'en-CA,en-US;q=0.9,en;q=0.8' },
  'America/Montreal':  { lat: 45.5017, lng: -73.5673, locale: 'en-CA', acceptLang: 'en-CA,fr-CA;q=0.9,en-US;q=0.8,en;q=0.7' },
  'America/Vancouver': { lat: 49.2827, lng: -123.1207, locale: 'en-CA', acceptLang: 'en-CA,en-US;q=0.9,en;q=0.8' },
  'America/New_York':  { lat: 40.7128, lng: -74.0060, locale: 'en-US', acceptLang: 'en-US,en;q=0.9' },
  'America/Los_Angeles': { lat: 34.0522, lng: -118.2437, locale: 'en-US', acceptLang: 'en-US,en;q=0.9' },
  'America/Chicago':   { lat: 41.8781, lng: -87.6298, locale: 'en-US', acceptLang: 'en-US,en;q=0.9' },
  'America/Denver':    { lat: 39.7392, lng: -104.9903, locale: 'en-US', acceptLang: 'en-US,en;q=0.9' },
  'America/Phoenix':   { lat: 33.4484, lng: -112.0740, locale: 'en-US', acceptLang: 'en-US,en;q=0.9' },
  'America/Edmonton':  { lat: 53.5461, lng: -113.4938, locale: 'en-CA', acceptLang: 'en-CA,en-US;q=0.9,en;q=0.8' },
  'America/Winnipeg':  { lat: 49.8951, lng: -97.1384, locale: 'en-CA', acceptLang: 'en-CA,en-US;q=0.9,en;q=0.8' },
  'Europe/London':     { lat: 51.5074, lng: -0.1278, locale: 'en-GB', acceptLang: 'en-GB,en-US;q=0.9,en;q=0.8' },
  'Europe/Berlin':     { lat: 52.5200, lng: 13.4050, locale: 'de-DE', acceptLang: 'de-DE,de;q=0.9,en;q=0.8' },
  'Europe/Paris':      { lat: 48.8566, lng: 2.3522, locale: 'fr-FR', acceptLang: 'fr-FR,fr;q=0.9,en;q=0.8' }
};

const DEFAULT = GEO_BY_TZ['America/Toronto'];

export const supportedTimezones = () => Object.keys(GEO_BY_TZ);

// ~111 km per degree of latitude; longitude compresses by cos(lat) so a fixed
// km offset needs a bigger degree delta the further from the equator. The old
// code applied the latitude scale to BOTH axes, which threw longitude ~1.3–1.6×
// too far at North American / European latitudes — a "5 km" jitter was really
// 7–8 km east-west.
const KM_PER_DEG_LAT = 111;

const jitter = (deg, kmRadius = 5, isLatitude = true) => {
  const offset = (Math.random() - 0.5) * 2 * (kmRadius / KM_PER_DEG_LAT);
  return deg + offset;
};

const jitterLng = (deg, lat, kmRadius = 5) => {
  const cos = Math.max(0.15, Math.cos((lat * Math.PI) / 180));
  const offset = (Math.random() - 0.5) * 2 * (kmRadius / (KM_PER_DEG_LAT * cos));
  return deg + offset;
};

export const getGeoForTimezone = (tz) => {
  const base = GEO_BY_TZ[tz] || DEFAULT;
  return {
    ...base,
    tz: GEO_BY_TZ[tz] ? tz : 'America/Toronto',
    matched: Boolean(GEO_BY_TZ[tz]),
    lat: jitter(base.lat),
    lng: jitterLng(base.lng, base.lat)
  };
};

// Whether two timezones sit in the same country, for the exit-vs-market check.
// Compared by prefix region (America/Europe/...) AND country name, because
// America/Toronto and America/Chicago are different countries on the same prefix.
const COUNTRY_OF_TZ = Object.freeze({
  'America/Toronto': 'ca', 'America/Montreal': 'ca', 'America/Vancouver': 'ca', 'America/Edmonton': 'ca', 'America/Winnipeg': 'ca',
  'America/New_York': 'us', 'America/Los_Angeles': 'us', 'America/Chicago': 'us', 'America/Denver': 'us',
  'America/Phoenix': 'us', 'America/Anchorage': 'us', 'Pacific/Honolulu': 'us',
  'Europe/London': 'gb', 'Europe/Berlin': 'de', 'Europe/Paris': 'fr', 'Europe/Madrid': 'es', 'Europe/Rome': 'it'
});

export const countryOfTimezone = (tz) => COUNTRY_OF_TZ[String(tz || '')] || null;

// Resolve the timezone that should actually be applied.
//
// Order of preference:
//   1. profile.proxy_exit_tz — the timezone of the IP carrying the session.
//   2. profile.tz            — the pinned device timezone.
//
// The exit normally wins (a mismatched TZ is more detectable than a stale pinned
// one) — BUT only when it does not cross a country border against a site's
// required market. Decodo hands out any city in the target country, and letting a
// New York profile drift to Los Angeles still keeps TZ, locale and IP mutually
// coherent. Letting it drift to Brazil does not.
//
// `requiredCountry` comes from the site policy. Returns
// { tz, source, mismatch, blocked }.
export const resolveTimezoneForExit = (profile = {}, { requiredCountry = null } = {}) => {
  const pinned = profile.tz || null;
  const proxyTz = profile.proxy_exit_tz || null;

  if (proxyTz && GEO_BY_TZ[proxyTz]) {
    // Enforce the retailer's market: the exit's country must MATCH the required
    // one. Comparing against the pinned timezone instead would let a Canadian
    // profile on a correctly-US exit get pulled back to a Canadian clock.
    const exitCountry = countryOfTimezone(proxyTz);
    const crossesBorder = requiredCountry && exitCountry && exitCountry !== String(requiredCountry).toLowerCase();
    if (crossesBorder) {
      return { tz: pinned || proxyTz, source: 'profile-market', mismatch: proxyTz, blocked: true };
    }
    if (pinned && pinned !== proxyTz) return { tz: proxyTz, source: 'proxy-exit', mismatch: pinned, blocked: false };
    return { tz: proxyTz, source: 'proxy-exit', mismatch: null, blocked: false };
  }
  // Pinned timezone outside the table is still better than the blanket default.
  if (pinned) return { tz: pinned, source: GEO_BY_TZ[pinned] ? 'profile' : 'profile-unmapped', mismatch: null, blocked: false };
  return { tz: 'America/Toronto', source: 'default', mismatch: null, blocked: false };
};

// Effective profile for a launch: the pinned fingerprint with its timezone
// aligned to the exit IP, or held inside the retailer's market when the exit
// would cross a border.
export const alignProfileToExit = (profile = {}, { requiredCountry = null } = {}) => {
  const { tz, source, mismatch, blocked } = resolveTimezoneForExit(profile, { requiredCountry });
  if (blocked) {
    logger.info(`[Geo] Exit timezone ${mismatch} leaves the required market — keeping ${tz} (${source})`);
  } else if (mismatch) {
    logger.info(`[Geo] Exit timezone ${tz} (${source}) overrides pinned ${mismatch} — aligning TZ/locale/geolocation`);
  }
  return { ...profile, tz };
};


export const applyGeoConsistency = async ({ cdp, page, profile }) => {
  const geo = getGeoForTimezone(profile.tz);
  // CDP geolocation override — beats fingerprint scripts that probe
  // navigator.geolocation.getCurrentPosition()
  await cdp.send('Emulation.setGeolocationOverride', {
    latitude: geo.lat,
    longitude: geo.lng,
    accuracy: 25 + Math.random() * 50
  }).catch(() => {});
  await cdp.send('Browser.grantPermissions', {
    permissions: ['geolocation']
  }).catch(() => {});
  await cdp.send('Emulation.setLocaleOverride', { locale: geo.locale }).catch(() => {});
  return geo;
};
