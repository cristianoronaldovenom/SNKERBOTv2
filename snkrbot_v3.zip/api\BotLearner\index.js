import { Router } from 'express';
import { getBotLearnerStats, getBotLearnerRecommendation, resetBotLearner } from '../../helpers/bot-learner.js';

const router = Router();

// GET /v1/bot-learner/stats
// Full diagnostic view of what the bandit has learned per site.
// Shows each arm's win rate, number of pulls, UCB1 score, and overall
// confidence level. High confidence = the system has enough data to
// reliably recommend a profile. Low = early learning. Exploring = <3 pulls.
router.get('/stats', async (req, res, next) => {
  try {
    const stats = await getBotLearnerStats();
    return res.json({ success: true, data: stats });
  } catch (err) { next(err); }
});

// GET /v1/bot-learner/recommendation/:siteId
// What the bandit would recommend right now for a given site.
// Useful for debugging or pre-flight checks.
router.get('/recommendation/:siteId', async (req, res, next) => {
  try {
    const siteId = parseInt(req.params.siteId, 10);
    if (!siteId || isNaN(siteId)) return res.status(400).json({ success: false, error: 'Invalid siteId' });
    const rec = await getBotLearnerRecommendation(siteId);
    return res.json({ success: true, data: rec });
  } catch (err) { next(err); }
});

// DELETE /v1/bot-learner/reset
// Wipe all learned state and reseed from scratch.
// Use when you've switched proxies/VPS so old data is no longer relevant.
router.delete('/reset', async (req, res, next) => {
  try {
    await resetBotLearner();
    return res.json({ success: true, message: 'Bot learner state reset. Will reseed from task_runs on next recommendation request.' });
  } catch (err) { next(err); }
});

export default router;
