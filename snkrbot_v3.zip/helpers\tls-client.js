// Node bridge to the Go TLS sidecar (tls-sidecar/main.go).
//
// All "stealth" HTTP calls — drop probes, captcha solver API calls (later),
// session warmers, account auth — should route through this so the TLS
// ClientHello matches Chrome instead of Node/OpenSSL. Anti-bot vendors
// hash the ClientHello (JA3/JA4) and a Node-shaped one is an instant tell.
//
// Graceful fallback: if the sidecar isn't running (Go not installed, build
// failed, etc.), every call returns { ok:false, fallback:true } so the
// caller can fall back to got-scraping or axios. The bot never breaks just
// because the sidecar is unavailable.
import axios from 'axios';
import fs from 'node:fs';
import http from 'node:http';
import logger from './logger.js';

const SIDECAR_URL = process.env.TLS_SIDECAR_URL || 'http://127.0.0.1:8099';
const HEALTH_TIMEOUT_MS = 1500;
const TOKEN_FILE = '/tmp/tls-sidecar.token';
const sidecarAgent = new http.Agent({ keepAlive: true, maxSockets: 64, maxFreeSockets: 16, timeout: 30_000 });

// Read shared-secret token written by the sidecar at startup. Cached, but
// re-read on auth failures (in case sidecar restarted with a fresh token).
//
// An EMPTY result is deliberately not cached. The bot usually boots before the
// sidecar has written its token file; caching '' made every later call send
// `Bearer ` until the 30s health recheck happened to fail — so the first 30s of
// stealth HTTP silently ran on Node TLS.
let cachedToken = null;
const readToken = () => {
  if (cachedToken) return cachedToken;
  try {
    cachedToken = fs.readFileSync(TOKEN_FILE, 'utf-8').trim() || null;
  } catch (_) {
    cachedToken = null;
  }
  if (!cachedToken) {
    const fromEnv = process.env.TLS_SIDECAR_TOKEN || '';
    if (fromEnv) cachedToken = fromEnv;
  }
  return cachedToken || '';
};
const refreshToken = () => { cachedToken = null; return readToken(); };

let sidecarStatus = 'unknown'; // 'up' | 'down' | 'unknown'

// Read-only view for health reporting. Exported as a getter function (not the
// binding) so callers always see the current state.
export const sidecarState = () => sidecarStatus;
let lastHealthCheck = 0;
const HEALTH_RECHECK_MS = 30_000;

const checkHealth = async () => {
  const now = Date.now();
  if (sidecarStatus !== 'unknown' && now - lastHealthCheck < HEALTH_RECHECK_MS) {
    return sidecarStatus === 'up';
  }
  lastHealthCheck = now;
  try {
    const { data } = await axios.get(`${SIDECAR_URL}/health`, { timeout: HEALTH_TIMEOUT_MS, httpAgent: sidecarAgent });
    if (data?.ok) {
      if (sidecarStatus !== 'up') logger.info(`[TLS] sidecar UP at ${SIDECAR_URL} (${data.library}, profile=${data.profile})`);
      sidecarStatus = 'up';
      return true;
    }
  } catch (err) {
    if (sidecarStatus !== 'down') {
      logger.warn(`[TLS] sidecar DOWN at ${SIDECAR_URL} — falling back to Node TLS for stealth HTTP calls. Start with: cd tls-sidecar && go run .`);
    }
    sidecarStatus = 'down';
    return false;
  }
  sidecarStatus = 'down';
  return false;
};

export const isTlsSidecarAvailable = () => checkHealth();

// JA3/JA4 fingerprint diversity: every request that omits `profile` gets one
// of these picked randomly, weighted toward Chrome 131 (matches the actual
// Chromium binary). Without this, every call shares the same JA3 hash and
// Akamai/Cloudflare can mass-flag based on a single fingerprint.
//
// The pool is env-overridable so a deployment that ships a newer Chromium can
// widen or replace it (TLS_SIDECAR_PROFILES=chrome131_psk,chrome131,...) without
// a code edit. Unset keeps the conservative defaults.
const DEFAULT_PROFILE_POOL = [
  'chrome131', 'chrome131', 'chrome131', 'chrome131', // 4/7 ≈ 57%
  'chrome124', 'chrome124',                            // 2/7 ≈ 29%
  'chrome120'                                          // 1/7 ≈ 14%
];

const PROFILE_POOL = (() => {
  const raw = String(process.env.TLS_SIDECAR_PROFILES || '').trim();
  if (!raw) return DEFAULT_PROFILE_POOL;
  const parsed = raw.split(',').map((p) => p.trim().toLowerCase()).filter(Boolean);
  return parsed.length ? parsed : DEFAULT_PROFILE_POOL;
})();

export const pickTlsProfile = () => PROFILE_POOL[Math.floor(Math.random() * PROFILE_POOL.length)];

// ── Sticky profiles ─────────────────────────────────────────────────────────
// A real browser does NOT change its TLS ClientHello between two polls ten
// seconds apart. Picking a random profile per request made the JA3 hash hop
// around on one identity — a coherence tell worse than any single profile.
// So: one profile per (host, proxy), rotated on a long timer, still drawn from
// the same diverse pool so different sessions don't all look identical.
const STICKY_TTL_MS = 15 * 60_000;

const stickyProfiles = new Map(); // `${host}|${proxy}` → { profile, expiresAt }

// Ceiling on tracked identities. Task churn can otherwise grow this map for
// the life of the process; a bot running hundreds of per-session proxies would
// accumulate a stale entry each time one is replaced.
const STICKY_MAX = 512;

const stickyProfile = (host, proxy) => {
  const key = `${host}|${proxy || ''}`;
  const now = Date.now();
  const hit = stickyProfiles.get(key);
  if (hit && hit.expiresAt > now) return hit.profile;
  // Sweep expired entries before inserting, then hard-cap: keeps the map
  // bounded even under heavy task rotation.
  for (const [k, v] of stickyProfiles) {
    if (v.expiresAt <= now) stickyProfiles.delete(k);
  }
  if (stickyProfiles.size >= STICKY_MAX) {
    const first = stickyProfiles.keys().next().value;
    stickyProfiles.delete(first);
  }
  const profile = pickTlsProfile();
  stickyProfiles.set(key, { profile, expiresAt: now + STICKY_TTL_MS });
  return profile;
};

// ── Coalescing ───────────────────────────────────────────────────────────────
// At drop time N tasks poll the SAME url through the SAME proxy every 350ms.
// Without coalescing that's N parallel handshakes for identical responses —
// more proxies burned AND more fingerprint surface. Share one in-flight call.
const inflightGets = new Map(); // key → Promise<result>

const coalesceKey = (method, url, proxy, session) =>
  `${method} ${url} @${proxy || ''} #${session || ''}`;

// Make an HTTP request through the sidecar with Chrome's exact TLS fingerprint.
// Returns { ok, status, headers, body, finalUrl, fallback?, error? }.
// On sidecar unavailable: { ok:false, fallback:true } so caller can try got-scraping.
export const tlsRequest = async ({
  method = 'GET',
  url,
  headers = {},
  body = null,
  profile = null,         // null → sticky profile for this host+proxy (JA3 coherence)
  proxy = null,
  session = null,         // optional: enables sidecar-side cookie persistence
  timeoutMs = 15_000,
  noRedirect = false,
  coalesce = null         // explicit opt-in for GET coalescing; default: GETs coalesce
} = {}) => {
  if (!url) return { ok: false, error: 'url required' };
  if (!(await checkHealth())) return { ok: false, fallback: true, error: 'sidecar down' };

  let host = '';
  try { host = new URL(url).hostname; } catch (_) { /* non-fatal */ }
  if (!profile) profile = stickyProfile(host, proxy);

  const isGet = method.toUpperCase() === 'GET';
  const key = coalesceKey(method, url, proxy, session);
  if (isGet && coalesce !== false) {
    const existing = inflightGets.get(key);
    if (existing) return existing;
  }

  const run = async () => {
  const payload = {
    method,
    url,
    headers,
    profile,
    timeout_ms: timeoutMs,
    no_redirect: noRedirect
  };
  if (session) payload.session = session;
  if (proxy) payload.proxy = proxy;
  if (body != null) {
    if (Buffer.isBuffer(body)) payload.body_b64 = body.toString('base64');
    else if (typeof body === 'string') payload.body = body;
    else payload.body = JSON.stringify(body);
  }

  const doPost = (token) => axios.post(`${SIDECAR_URL}/request`, payload, {
    timeout: timeoutMs + 5_000,
    httpAgent: sidecarAgent,
    headers: { Authorization: `Bearer ${token}` }
  });

  try {
    let resp;
    try {
      resp = await doPost(readToken());
    } catch (err) {
      if (err.response?.status === 401) {
        // Sidecar may have restarted with a new token — re-read once.
        resp = await doPost(refreshToken());
      } else throw err;
    }
    const data = resp.data;
    if (data.error) return { ok: false, error: data.error };
    const decoded = data.body_b64 ? Buffer.from(data.body_b64, 'base64').toString('utf-8') : '';
    return {
      ok: true,
      status: data.status,
      headers: data.headers,
      // The sidecar decompresses gzip/deflate/br before returning, so this
      // body is always the plain text the caller's regexes expect.
      body: decoded,
      finalUrl: data.final_url
    };
  } catch (err) {
    // Mark sidecar down on connection errors so subsequent calls skip the
    // health check and immediately fall back.
    if (err.code === 'ECONNREFUSED' || err.code === 'ECONNRESET') {
      sidecarStatus = 'down';
    }
    return { ok: false, error: err.message, fallback: err.code === 'ECONNREFUSED' };
  }
  };

  if (isGet && coalesce !== false) {
    const promise = run().finally(() => { inflightGets.delete(key); });
    inflightGets.set(key, promise);
    return promise;
  }
  return run();
};

// ── Pre-warm ─────────────────────────────────────────────────────────────────
// Opens (and keeps) the pooled TLS/H2 connection for this url+proxy BEFORE the
// hot window starts, so the first real poll skips the handshake entirely.
// Best effort: never throws; returns true if the sidecar accepted it.
export const tlsPreconnect = async ({ url, profile = null, proxy = null, timeoutMs = 5000 } = {}) => {
  try {
    if (!(await checkHealth())) return false;
    let host = '';
    try { host = new URL(url).hostname; } catch (_) { return false; }
    const payload = {
      url,
      profile: profile || stickyProfile(host, proxy),
      timeout_ms: timeoutMs
    };
    if (proxy) payload.proxy = proxy;
    const { data } = await axios.post(`${SIDECAR_URL}/preconnect`, payload, {
      timeout: timeoutMs + 2000,
      httpAgent: sidecarAgent,
      headers: { Authorization: `Bearer ${readToken()}` }
    });
    return Boolean(data?.ok);
  } catch (_) {
    return false;
  }
};
