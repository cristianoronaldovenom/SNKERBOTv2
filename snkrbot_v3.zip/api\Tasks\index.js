import { Router } from 'express';
import { validate } from 'express-validation';
import * as controller from './controller.js';
import * as monitor from './monitor.js';
import * as preflight from './preflight.js';
import * as cloneCtrl from './clone.js';
import { startGroup } from './start-group.js';
import feedRoutes from './feed.js';
import { createTaskSchema, updateTaskSchema } from './validation.js';

const router = Router();

router.get('/', controller.findAll);
router.get('/:id', controller.findOne);
router.post('/', validate(createTaskSchema, {}, {}), controller.create);
router.patch('/:id', validate(updateTaskSchema, {}, {}), controller.update);
router.delete('/:id', controller.remove);
router.post('/start-group', startGroup);
router.get('/feed', feedRoutes);
router.get('/feed/stream', monitor.streamAllMonitors);
router.post('/:id/start', controller.startTask);
router.post('/:id/stop', controller.stopTask);
router.post('/:id/enable-payment', controller.enablePayment);
router.get('/:id/preflight', preflight.runPreflight);
router.post('/:id/clone', cloneCtrl.clone);

router.post('/:id/monitor/start', monitor.startMonitor);
router.post('/:id/monitor/stop', monitor.stopMonitor);
router.get('/:id/monitor/stream', monitor.streamMonitor);
router.get('/:id/monitor/status', monitor.getMonitorStatus);
router.get('/monitors/all', monitor.getAllMonitorStatuses);
router.get('/monitors/reliability', monitor.getReliability);

export default router;
