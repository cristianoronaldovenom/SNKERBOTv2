// Residential exit-IP affinity tests.
//
// Regression this guards: nothing stopped a monitor spending a NEW residential
// exit on every poll. That burns provider rotations and resets the WAF's per-IP
// history each tick, which is both expensive and bot-like. The contract here is
// that one task+role+host keeps ONE exit, rotation is earned rather than timed,
// and the caller's proxy object is never mutated.
//
// The template is read at call time, but the sticky map is module state, so each
// block still needs a fresh module instance to prove cold-start behaviour.
import { afterEach, describe, expect, jest, test } from '@jest/globals';

const load = async (template) => {
  process.env.RESIDENTIAL_SESSION_TEMPLATE = template;
  jest.resetModules();
  return import('../../helpers/residential-affinity.js');
};

const proxy = (username = 'user1') => ({
  host: 'gate.provider.net', port: 8000, username, password: 'p', proxy_type: 'residential'
});

afterEach(() => {
  delete process.env.RESIDENTIAL_SESSION_TEMPLATE;
  delete process.env.RESIDENTIAL_AFFINITY_TTL_MS;
});

describe('disabled without a template', () => {
  test('an empty template passes the proxy through untouched', async () => {
    const m = await load('');
    expect(m.affinityEnabled()).toBe(false);
    const p = proxy();
    const out = m.withAffinity(p, { taskId: 1, host: 'a.com' });
    expect(out.proxy).toBe(p);
    expect(out.session).toBeNull();
    expect(out.reason).toBe('disabled');
  });

  test('a template without the placeholder is also treated as off', async () => {
    const m = await load('static-user');
    expect(m.affinityEnabled()).toBe(false);
  });
});

describe('sticky exits', () => {
  const TEMPLATE = '{user}-session-{session}';

  test('the first call pins an exit and the second reuses it', async () => {
    const m = await load(TEMPLATE);
    const first = m.withAffinity(proxy(), { taskId: 7, host: 'shop.com' });
    expect(first.reused).toBe(false);
    expect(first.session).toBeTruthy();
    expect(first.proxy.username).toBe(`user1-session-${first.session}`);

    const second = m.withAffinity(proxy(), { taskId: 7, host: 'shop.com' });
    expect(second.reused).toBe(true);
    expect(second.session).toBe(first.session);
  });

  test('different tasks, roles and hosts get different exits', async () => {
    const m = await load(TEMPLATE);
    const a = m.withAffinity(proxy(), { taskId: 1, host: 'shop.com' });
    const b = m.withAffinity(proxy(), { taskId: 2, host: 'shop.com' });
    const c = m.withAffinity(proxy(), { taskId: 1, role: 'monitor', host: 'shop.com' });
    const d = m.withAffinity(proxy(), { taskId: 1, host: 'other.com' });
    expect(new Set([a.session, b.session, c.session, d.session]).size).toBe(4);
  });

  test('the caller proxy object is copied, never mutated', async () => {
    const m = await load(TEMPLATE);
    const p = proxy();
    const out = m.withAffinity(p, { taskId: 3, host: 'shop.com' });
    expect(p.username).toBe('user1');
    expect(out.proxy).not.toBe(p);
    expect(out.proxy.password).toBe('p');
    expect(out.proxy.host).toBe('gate.provider.net');
  });

  test('an already-affine username is not double-suffixed', async () => {
    const m = await load(TEMPLATE);
    const first = m.withAffinity(proxy(), { taskId: 4, host: 'shop.com' });
    const again = m.withAffinity(first.proxy, { taskId: 4, host: 'shop.com' });
    expect(again.proxy.username).toBe(first.proxy.username);
    expect(again.proxy.username.match(/-session-/g)).toHaveLength(1);
  });
});

describe('rotation', () => {
  const TEMPLATE = '{user}-session-{session}';

  test('rotateAffinity forces a genuinely new exit', async () => {
    const m = await load(TEMPLATE);
    const first = m.withAffinity(proxy(), { taskId: 5, host: 'shop.com' });
    expect(m.rotateAffinity({ taskId: 5, host: 'shop.com' })).toBe(true);
    const second = m.withAffinity(proxy(), { taskId: 5, host: 'shop.com' });
    expect(second.session).not.toBe(first.session);
    expect(second.reused).toBe(false);
    // Rotating an unknown key is a no-op.
    expect(m.rotateAffinity({ taskId: 99, host: 'shop.com' })).toBe(false);
  });

  test('tokens never repeat across many rotations', async () => {
    const m = await load(TEMPLATE);
    const seen = new Set();
    for (let i = 0; i < 8; i++) {
      seen.add(m.withAffinity(proxy(), { taskId: 6, host: 'shop.com' }).session);
      m.rotateAffinity({ taskId: 6, host: 'shop.com' });
    }
    expect(seen.size).toBe(8);
  });

  test('release drops the session without advancing the rotation counter', async () => {
    const m = await load(TEMPLATE);
    const first = m.withAffinity(proxy(), { taskId: 8, host: 'shop.com' });
    m.releaseAffinity({ taskId: 8, host: 'shop.com' });
    expect(m.affinitySessionFor({ taskId: 8, host: 'shop.com' })).toBeNull();
    // Re-acquiring after release reuses the same token: no rotation was earned.
    expect(m.withAffinity(proxy(), { taskId: 8, host: 'shop.com' }).session).toBe(first.session);
  });
});

describe('gating', () => {
  test('non-residential proxies and missing usernames are skipped', async () => {
    const m = await load('{user}-session-{session}');
    const dc = { ...proxy(), proxy_type: 'datacenter' };
    expect(m.withAffinity(dc, { taskId: 1 }).reason).toBe('not_residential');
    expect(m.withAffinity({ ...proxy(), username: '' }, { taskId: 1 }).reason).toBe('no_username');
    expect(m.withAffinity(null, { taskId: 1 }).proxy).toBeNull();
  });
});
