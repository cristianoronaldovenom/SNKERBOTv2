// Order success capture — preserves a permanent receipt for every successful
// checkout. Pro bots ship this because (1) you need proof for accounting /
// reselling, (2) the screenshot doubles as a debug artifact if the
// downstream payment is later voided/contested, (3) the JSON receipt feeds
// analytics on which sites/profiles win most often.
import path from 'node:path';
import fs from 'node:fs/promises';
import logger from './logger.js';
import { notifyProductSuccess } from './sibling-bus.js';

const orderDir = (taskId) => path.resolve(process.cwd(), 'orders', `task-${taskId}`);

export const captureOrderSuccess = async ({ page, taskId, orderNumber, productUrl, durationMs, profile }) => {
  // Announce the win first. If this task is one of many armed on the same product,
  // every sibling is holding a browser, a residential exit and a queue slot that
  // are now all wasted — the bus lets them abort. Doing it before the screenshot
  // means a slow disk write does not delay the signal.
  if (productUrl) {
    try {
      notifyProductSuccess({ productUrl, taskId, orderNumber: orderNumber || null });
    } catch (err) {
      logger.warn(`[OrderCapture] Sibling signal failed: ${err.message}`);
    }
  }
  try {
    const dir = orderDir(taskId);
    await fs.mkdir(dir, { recursive: true });
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const safeOrder = String(orderNumber || 'unknown').replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 60);
    const base = `${safeOrder}-${stamp}`;

    const shotPath = path.join(dir, `${base}.png`);
    const receiptPath = path.join(dir, `${base}.json`);

    // Full-page screenshot of the confirmation page
    await page.screenshot({ path: shotPath, fullPage: true }).catch((err) => {
      logger.warn(`[OrderCapture] Screenshot failed for task ${taskId}: ${err.message}`);
    });

    // JSON receipt with everything we know
    const receipt = {
      taskId,
      orderNumber: orderNumber || null,
      productUrl: productUrl || null,
      capturedAt: new Date().toISOString(),
      durationMs: durationMs || null,
      pageUrl: page.url(),
      profile: profile ? {
        ua: profile.ua,
        platform: profile.platform,
        chromeVer: profile.chromeVer,
        tz: profile.tz,
        viewport: profile.viewport
      } : null
    };
    await fs.writeFile(receiptPath, JSON.stringify(receipt, null, 2), 'utf8');

    logger.info(`[OrderCapture] Task ${taskId} order ${orderNumber} captured → ${path.relative(process.cwd(), shotPath)}`);
    return { screenshot: shotPath, receipt: receiptPath };
  } catch (err) {
    logger.warn(`[OrderCapture] Capture failed for task ${taskId}: ${err.message}`);
    return null;
  }
};
