// Payment lockout — a hard circuit breaker on the task itself.
//
// A repeatedly-declined card is not just "another retry": retrying it burns
// proxy bandwidth, captcha credits and the drop's remaining cart window. After
// PAYMENT_LOCKOUT_THRESHOLD declines the task parks itself and stays parked
// until a human fixes the card and clears the lock from the dashboard.
//
// The lock is deliberately SEPARATE from the stop-loss columns
// (disabled_at / disabled_reason): stop-loss trips on any failure and a single
// good run clears it, whereas a payment lock survives restarts and only clears
// on an explicit operator action. Sharing one column would have let the
// monitor reconciler quietly re-arm a task with a known-dead card.
export const up = (knex) =>
  knex.schema.alterTable('tasks', (table) => {
    table.integer('pay_fail_count').notNullable().defaultTo(0);
    table.timestamp('pay_disabled_at').nullable();
    table.string('pay_disabled_reason').nullable();
  });

export const down = (knex) =>
  knex.schema.alterTable('tasks', (table) => {
    table.dropColumn('pay_fail_count');
    table.dropColumn('pay_disabled_at');
    table.dropColumn('pay_disabled_reason');
  });
