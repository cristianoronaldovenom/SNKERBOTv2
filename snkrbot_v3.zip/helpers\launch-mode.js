import { spawn } from 'node:child_process';
import logger from './logger.js';

// How the browser is launched: headless or on a real display.
//
// Every one of the ~31 patch blocks in cluster.js is fighting the same fact:
// the browser underneath is headless. A headless Chrome has no window manager,
// no compositor, no real GPU — so `outerWidth` equals the viewport, `screenX` is
// always 0, `:hover` needs synthesising, and the viewport meta truly is the only
// size. DataDome and PerimeterX score that, and no amount of property patching
// convincingly fakes a window manager.
//
// The catch is RAM: a headful browser needs an X server, which is +40-90MB and
// on a 2 GB box is real. So this is a policy, not a switch:
//
//   * `BROWSER_HEADLESS=0` forces headful wherever a display can be had.
//   * `BROWSER_HEADLESS=1` forces headless (the old behaviour, always available).
//   * unset (`auto`) goes headful only when a display exists AND the host has the
//     headroom, otherwise headless.
//
// On Windows/macOS a desktop is already present, so auto is straightforward. On
// Linux it needs `DISPLAY` or Xvfb — and if neither exists we simply stay
// headless rather than launching a browser nothing can draw into.
//
// Pure and I/O-free: callers pass the environment and host facts, so the matrix
// is asserted directly and nothing has to actually launch a browser to be tested.

export const MODE = Object.freeze({ HEADFUL: 'headful', HEADLESS: 'headless' });

// A headful session is worth its RAM; below this the host would rather have a
// second tab than a real window (checkout concurrency beats stealth on a
// starved box, because a live checkout you cannot render is useless).
const MIN_HEADFUL_BYTES = 900 * 1024 * 1024;

const truthy = (v, fallback = null) => {
  const s = String(v ?? '').trim().toLowerCase();
  if (!s) return fallback;
  // Both spellings are accepted because operators get this wrong constantly:
  // `BROWSER_HEADLESS=headless` and `BROWSER_HEADLESS=true` mean the same thing,
  // and `headful`/`false` mean the other. Getting one backwards here silently
  // inverts the operator's intent, which is worse than accepting both.
  if (['1', 'true', 'yes', 'on', 'headless'].includes(s)) return true;
  if (['0', 'false', 'no', 'off', 'headful'].includes(s)) return false;
  return fallback;
};

// Is there anywhere to draw? Windows/macOS always have one; Linux needs a
// DISPLAY (a real X server or the Xvfb we start ourselves).
export const hasDisplay = ({ platform = process.platform, env = process.env } = {}) => {
  if (platform === 'win32' || platform === 'darwin') return true;
  // Wayland sessions still export a socket the XWayland bridge answers on, but
  // Chromium only uses it via DISPLAY, so that is the only thing we check.
  return Boolean(String(env.DISPLAY || '').trim());
};

export const headfulReason = ({ platform = process.platform, env = process.env, totalMemoryBytes = 0 } = {}) => {
  const override = truthy(env.BROWSER_HEADLESS);
  if (override === true) return { mode: MODE.HEADLESS, reason: 'forced_headless' };
  if (override === false) {
    const display = hasDisplay({ platform, env });
    return display
      ? { mode: MODE.HEADFUL, reason: 'forced_headful' }
      // Forced headful with no display is not an error worth failing a launch
      // over — a headless browser still buys the checkout.
      : { mode: MODE.HEADLESS, reason: 'forced_headful_but_no_display' };
  }

  if (!hasDisplay({ platform, env })) return { mode: MODE.HEADLESS, reason: 'no_display' };
  if (totalMemoryBytes > 0 && totalMemoryBytes < MIN_HEADFUL_BYTES) {
    return { mode: MODE.HEADLESS, reason: 'low_memory' };
  }
  return { mode: MODE.HEADFUL, reason: 'display_available' };
};

export const resolveHeadless = (opts = {}) => {
  const { mode } = headfulReason(opts);
  return mode === MODE.HEADLESS;
};

// Should the caller start a display BEFORE asking resolveHeadless?
//
// Linux is a chicken-and-egg: hasDisplay() reads DISPLAY, but on a fresh box
// nothing has started an X server yet, so auto would always conclude "no display"
// and never even try. This says whether bootstrapping is worth attempting:
// Linux, not forced headless, no DISPLAY yet, and enough RAM to carry it.
export const shouldBootstrapDisplay = ({ platform = process.platform, env = process.env, totalMemoryBytes = 0 } = {}) => {
  if (platform !== 'linux') return false;
  if (truthy(env.BROWSER_HEADLESS) === true) return false;
  if (hasDisplay({ platform, env })) return false;
  if (totalMemoryBytes > 0 && totalMemoryBytes < MIN_HEADFUL_BYTES) return false;
  return true;
};

// Launch args that only make sense on a real display, and their inverse.
//
// `--disable-gpu` is the big one: it is right for headless (no GPU exists) but on
// a display it also disables the compositor, which reintroduces most of the
// headless tells we just paid RAM to remove.
export const displayArgs = (headless) => (headless
  ? ['--disable-gpu']
  : ['--use-gl=angle', '--use-angle=swiftshader', '--enable-features=CalculateNativeWinOcclusion']);

export const headfulConfig = ({ platform = process.platform, env = process.env } = {}) => ({
  minHeadfulBytes: MIN_HEADFUL_BYTES,
  hasDisplay: hasDisplay({ platform, env }),
  override: truthy(env.BROWSER_HEADLESS) === null ? 'auto' : String(env.BROWSER_HEADLESS)
});

// ── Display bootstrapping (Linux) ─────────────────────────────────────────────
//
// A headful browser on Linux needs an X server. Xvfb is the standard answer and
// costs ~40-90MB, which is exactly why headful is gated on memory above.
//
// Two rules, both learned from how this class of bug behaves:
//   * start it ONCE per process, not per browser. Ten Xvfbs is ten displays all
//     colliding on :99. A shared promise also collapses a concurrent launch burst
//     into one start.
//   * never fail a launch over it. If Xvfb is missing, headless still buys the
//     checkout — the stealth gain is worth less than the sale.

let displayPromise = null;
let xvfbProc = null;
let exitHooked = false;
// :99 by default; high enough to dodge a real :0 desktop and any existing Xvfb.
const XVFB_DISPLAY = String(process.env.XVFB_DISPLAY || ':99');

// A spawned child outlives its parent on Linux, so without this every run leaks
// one Xvfb holding an X socket — and the NEXT run's start on :99 then fails.
const registerExitHook = () => {
  if (exitHooked) return;
  exitHooked = true;
  // `exit` handlers must be synchronous; kill() only signals, which is enough.
  process.once('exit', () => { stopDisplay(); });
  for (const sig of ['SIGINT', 'SIGTERM']) {
    process.once(sig, () => { stopDisplay(); });
  }
};

const which = (bin) => new Promise((resolve) => {
  const p = spawn(process.platform === 'win32' ? 'where' : 'which', [bin], { stdio: ['ignore', 'pipe', 'ignore'] });
  let out = '';
  p.stdout?.on('data', (d) => { out += d; });
  p.on('error', () => resolve(null));
  p.on('exit', (code) => resolve(code === 0 && out.trim() ? out.trim().split(/\r?\n/)[0] : null));
});

export const ensureDisplay = async () => {
  if (process.platform !== 'linux') return { ok: true, reason: 'not_linux' };
  if (process.env.DISPLAY) return { ok: true, reason: 'display_present' };
  if (displayPromise) return displayPromise;

  displayPromise = (async () => {
    const bin = await which('Xvfb');
    if (!bin) {
      logger.warn('[Display] Xvfb not found — staying headless. Install xvfb for headful stealth.');
      return { ok: false, reason: 'xvfb_missing' };
    }
    try {
      xvfbProc = spawn(bin, [
        XVFB_DISPLAY,
        '-screen', '0', '1920x1080x24',
        // Depth 24 matches a real panel. -nolisten tcp is fine; Chromium uses the socket.
        '-nolisten', 'tcp'
      ], { stdio: 'ignore' });
      // A crashed Xvfb must not take the bot down, and must be restartable.
      xvfbProc.on('error', (err) => { logger.warn(`[Display] Xvfb error: ${err.message}`); xvfbProc = null; displayPromise = null; });
      xvfbProc.on('exit', (code) => { if (code) logger.warn(`[Display] Xvfb exited ${code}`); xvfbProc = null; displayPromise = null; });
      process.env.DISPLAY = XVFB_DISPLAY;
      // Xvfb needs a moment before accepting connections; launching Chromium in
      // the same tick loses the race and reads as "no display".
      await new Promise((r) => setTimeout(r, 350));
      registerExitHook();
      logger.info(`[Display] Xvfb started on ${XVFB_DISPLAY} (1920x1080x24)`);
      return { ok: true, reason: 'xvfb_started' };
    } catch (err) {
      logger.warn(`[Display] Xvfb failed to start: ${err.message} — staying headless`);
      return { ok: false, reason: 'xvfb_failed' };
    }
  })();

  return displayPromise;
};

export const stopDisplay = () => {
  if (xvfbProc) {
    try { xvfbProc.kill(); } catch (_) { /* already gone */ }
    xvfbProc = null;
  }
  displayPromise = null;
};

export const __displayState = () => ({ running: Boolean(xvfbProc), display: process.env.DISPLAY || null });
