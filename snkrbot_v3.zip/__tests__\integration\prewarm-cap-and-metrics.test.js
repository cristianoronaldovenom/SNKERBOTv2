// Prewarm cap + monitor-metrics bounds.
//
// recommendedPrewarmCap is documented as "only ever lowers the operator
// setting". The refactor hoists that contract into a single `ceiling` so no
// future branch can forget the operator's cap; this sweep pins the contract
// across every configuration instead of one hand-picked case.
import { jest } from '@jest/globals';

jest.unstable_mockModule('../../helpers/cpu-performance.js', () => ({
  cpuPerformanceMode: () => 'max'
}));
jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));

const { recommendedPrewarmCap, armParkingStorm, __resetMemoryCache } = await import('../../helpers/memory-guard.js');
const metrics = await import('../../helpers/monitor-metrics.js');

beforeEach(() => { __resetMemoryCache(); });

describe('recommendedPrewarmCap', () => {
  test('never exceeds the configured cap for any setting', async () => {
    for (let configured = 1; configured <= 10; configured += 1) {
      __resetMemoryCache();
      const cap = await recommendedPrewarmCap(configured);
      expect(cap).toBeLessThanOrEqual(configured);
      expect(cap).toBeGreaterThanOrEqual(0);
    }
  });

  test('configured 0 means parking off', async () => {
    expect(await recommendedPrewarmCap(0)).toBe(0);
  });

  test('allowParking:false short-circuits to 0 regardless of headroom', async () => {
    expect(await recommendedPrewarmCap(3, { allowParking: false })).toBe(0);
  });

  test('junk input is clamped, not NaN', async () => {
    for (const junk of [null, undefined, 'abc', -5, 999]) {
      const cap = await recommendedPrewarmCap(junk);
      expect(Number.isInteger(cap)).toBe(true);
      expect(cap).toBeGreaterThanOrEqual(0);
    }
  });

  test('arms a parking storm without throwing', () => {
    expect(() => armParkingStorm()).not.toThrow();
  });
});

describe('monitor metrics bounds', () => {
  test('evicts the least recently checked host past the cap', () => {
    metrics.reset();
    for (let i = 0; i < 260; i += 1) {
      metrics.record(`h${i}.test`, { outcome: 'instock' });
    }
    const all = metrics.getAllMetrics();
    expect(Object.keys(all).length).toBeLessThanOrEqual(256);
    // The most recent host must survive eviction.
    expect(all['h259.test']).toBeTruthy();
  });

  test('percentiles are computed over retained latency samples', () => {
    metrics.reset();
    for (let i = 1; i <= 10; i += 1) metrics.record('p.test', { outcome: 'instock', latencyMs: i * 10 });
    const m = metrics.getMetrics('p.test');
    expect(m.latency.max).toBe(100);
    expect(m.latency.p50).toBeGreaterThan(0);
  });
});
