export const up = async (knex) => {
  await knex.schema.alterTable('tasks', (t) => {
    t.integer('monitor_proxy_id').nullable().references('id').inTable('proxies').onDelete('SET NULL');
    t.integer('checkout_proxy_id').nullable().references('id').inTable('proxies').onDelete('SET NULL');
    t.string('monitor_proxy_mode', 32).notNullable().defaultTo('auto');
    t.string('checkout_proxy_mode', 32).notNullable().defaultTo('auto');
  });

  // Preserve existing behavior: tasks that already had proxy_id use it for both roles.
  await knex.raw(`
    UPDATE tasks
       SET monitor_proxy_id = proxy_id,
           checkout_proxy_id = proxy_id,
           monitor_proxy_mode = CASE WHEN proxy_id IS NULL THEN 'auto' ELSE 'assigned' END,
           checkout_proxy_mode = CASE WHEN proxy_id IS NULL THEN 'auto' ELSE 'assigned' END
     WHERE monitor_proxy_id IS NULL AND checkout_proxy_id IS NULL
  `);
};

export const down = async (knex) => {
  await knex.schema.alterTable('tasks', (t) => {
    t.dropColumn('monitor_proxy_id');
    t.dropColumn('checkout_proxy_id');
    t.dropColumn('monitor_proxy_mode');
    t.dropColumn('checkout_proxy_mode');
  });
};
