// Proxy + User-Agent wiring for captcha solvers.
//
// Why this matters (the bug): every provider was called with a *Proxyless task
// type and no UA. The solver therefore minted the token from its own datacenter
// IP with its own headless-ish UA. Two things break:
//
//   1. IP binding. reCAPTCHA/hCaptcha/Turnstile scores are IP-sensitive, and
//      DataDome/Akamai bind the token to the requesting IP. A token minted on
//      the solver's IP then submitted from our residential exit is a mismatch —
//      it often "works" but scores worse, and on strict tiers is rejected.
//   2. Fingerprint binding. Some challenges bind to UA. The solver's UA
//      disagreeing with ours is a silent tell at validation time.
//
// The fix is to send OUR exit + OUR UA so the token is born on the same identity
// that will submit it. That requires per-provider param names, which is the whole
// reason this is a module: the four vendors descend from the anti-captcha spec but
// disagree on every key name, and getting one wrong silently yields a proxyless
// solve (the API ignores unknown fields rather than erroring).
//
// Pure, so the naming matrix is asserted directly.

// Proxy types the solvers accept. Our pool is HTTP, but residential gateways are
// sometimes reached over SOCKS and a stray value is rejected outright.
const ALLOWED_TYPES = new Set(['http', 'https', 'socks4', 'socks5']);

export const solverProxy = (proxy) => {
  if (!proxy?.host || !proxy?.port) return null;
  const type = String(proxy.proxy_type || proxy.type || 'http').toLowerCase();
  return {
    host: String(proxy.host),
    port: Number(proxy.port),
    username: proxy.username ? String(proxy.username) : '',
    password: proxy.password ? String(proxy.password) : '',
    type: ALLOWED_TYPES.has(type) ? type : 'http'
  };
};

// 2Captcha in.php uses lowercase, comma-free, query-string keys.
export const twocaptchaProxyParams = (proxy) => {
  const p = solverProxy(proxy);
  if (!p) return {};
  const params = { proxy: `${p.host}:${p.port}`, proxytype: p.type };
  if (p.username) params.proxyuser = p.username;
  if (p.password) params.proxypass = p.password;
  return params;
};

// CapMonster / AntiCaptcha / CapSolver all use the anti-captcha v2 TASK shape,
// with split address/port/login/password keys. CapSolver additionally accepts a
// URL form, but the split keys work everywhere, so one shape covers all three.
export const taskProxyParams = (proxy) => {
  const p = solverProxy(proxy);
  if (!p) return {};
  return {
    proxyType: p.type,
    proxyAddress: p.host,
    proxyPort: p.port,
    ...(p.username ? { proxyLogin: p.username } : {}),
    ...(p.password ? { proxyPassword: p.password } : {})
  };
};

// CapSolver diverges from its siblings: it takes one `proxy` URL rather than
// split address/port/login fields, plus a separate `proxyType`.
export const capsolverProxyParams = (proxy) => {
  const p = solverProxy(proxy);
  if (!p) return {};
  const auth = p.username ? `${encodeURIComponent(p.username)}:${encodeURIComponent(p.password)}@` : '';
  return { proxy: `${p.type}://${auth}${p.host}:${p.port}`, proxyType: p.type };
};

// Proxied vs proxyless task-type names, per provider. Derived by suffix so the
// four vendors stay in one table instead of four near-identical maps drifting.
const SUFFIX = 'ProxyLess';
export const taskTypeFor = (base, { proxied }) => (proxied ? base : `${base}${SUFFIX}`);

// Only attach a UA when we actually have one: an empty `userAgent` field makes
// some providers fall back to a default that then disagrees with the browser.
export const uaParam = (userAgent) => (userAgent ? { userAgent: String(userAgent) } : {});

export const proxyConfig = () => ({ allowedTypes: Array.from(ALLOWED_TYPES) });
