// Same-session request-first Add-to-Cart bridge.
// It only submits a retailer's own, currently rendered Add-to-Cart form. It
// never invents an endpoint and never handles payment/order submission.
// If the page does not expose a safe POST form matching the adapter's button
// selectors, callers fall back to their existing site-specific click path.

const ACTION_RE = /(?:add(?:-?to)?[-_/ ]?cart|cart(?:[/_-]?add)?|add(?:-?to)?[-_/ ]?(?:bag|basket)|basket|bag)/i;
const BUY_CONTROL_RE = /add\s*(?:to|into)\s*(?:cart|bag|basket)|add\s*to\s*cart/i;

const normalizeUrl = (value, base) => {
  try { return new URL(value, base).href; } catch (_) { return null; }
};

export const tryRequestFirstAddToCart = async (page, buttonSelectors = [], { timeoutMs = 1400 } = {}) => {
  try {
    const result = await page.evaluate(async ({ buttonSelectors, timeoutMs, actionRe, buyRe }) => {
      const buttons = [];
      for (const selector of buttonSelectors || []) {
        try { document.querySelectorAll(selector).forEach((el) => buttons.push(el)); } catch (_) {}
      }

      const candidate = buttons.find((el) => {
        const text = `${el.innerText || ''} ${el.value || ''} ${el.getAttribute('aria-label') || ''}`.trim();
        return !el.disabled && (el.form || new RegExp(buyRe, 'i').test(text));
      }) || buttons.find((el) => !el.disabled);

      if (!candidate) return { ok: false, reason: 'no-button' };

      const form = candidate.form || candidate.closest?.('form');
      if (!form || !form.action) return { ok: false, reason: 'no-form' };

      const method = String(form.method || 'get').toLowerCase();
      if (method !== 'post') return { ok: false, reason: 'non-post-form' };

      const action = new URL(form.action, location.href);
      if (action.origin !== location.origin) return { ok: false, reason: 'cross-origin-form' };
      const actionPattern = new RegExp(actionRe, 'i');
      if (!actionPattern.test(action.pathname) && !actionPattern.test(action.search)) {
        return { ok: false, reason: 'unsafe-action' };
      }

      const payload = new URLSearchParams();
      const fd = new FormData(form);
      for (const [key, value] of fd.entries()) {
        if (typeof value === 'string') payload.append(key, value);
      }

      // Preserve the clicked submitter's name/value when the retailer relies on it.
      const name = candidate.getAttribute('name');
      if (name && !payload.has(name)) {
        payload.append(name, candidate.getAttribute('value') || candidate.innerText?.trim() || '');
      }

      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), timeoutMs);
      try {
        const response = await fetch(action.href, {
          method: 'POST',
          credentials: 'same-origin',
          redirect: 'manual',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' },
          body: payload.toString(),
          signal: controller.signal,
        });
        clearTimeout(timer);

        const status = Number(response.status || 0);
        // A normal HTML/redirect response means the cart mutation reached the
        // retailer. Error statuses are deliberately left to the browser path.
        if (status >= 200 && status < 400) {
          return { ok: true, status, action: action.href };
        }
        return { ok: false, reason: `status-${status}`, status };
      } catch (err) {
        clearTimeout(timer);
        return { ok: false, reason: err?.name === 'AbortError' ? 'timeout' : 'fetch-error' };
      }
    }, {
      buttonSelectors,
      timeoutMs,
      actionRe: ACTION_RE.source,
      buyRe: BUY_CONTROL_RE.source,
    });

    return Boolean(result?.ok);
  } catch (_) {
    return false;
  }
};
