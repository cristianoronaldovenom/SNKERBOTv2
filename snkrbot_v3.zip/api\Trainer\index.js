import { Router } from 'express';
import { getTrainerStatus, startTrainer, stopTrainer } from '../../helpers/trainer.js';

const router = Router();

// GET /v1/trainer/status
// Full training loop status: running/stopped, probe counts, pass/block rates,
// and the last 50 probe results so you can see what's happening in real time.
router.get('/status', (req, res) => {
  res.json({ success: true, data: getTrainerStatus() });
});

// POST /v1/trainer/start
// Start the 24/7 training loop. Safe to call if already running.
router.post('/start', (req, res) => {
  startTrainer();
  res.json({ success: true, message: 'Trainer started — probing Akamai/DataDome/Imperva sites 24/7' });
});

// POST /v1/trainer/stop
// Gracefully stop the loop (finishes the current probe then exits).
router.post('/stop', (req, res) => {
  stopTrainer();
  res.json({ success: true, message: 'Trainer stop requested — will exit after current probe' });
});

export default router;
