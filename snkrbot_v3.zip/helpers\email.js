import nodemailer from 'nodemailer';
import logger from './logger.js';

const createTransporter = () => nodemailer.createTransport({
  host:   process.env.SMTP_HOST || 'smtp.gmail.com',
  port:   parseInt(process.env.SMTP_PORT || '587'),
  secure: false,
  auth:   { user: process.env.SMTP_USER || '', pass: process.env.SMTP_PASS || '' }
});

const FROM = () => process.env.SMTP_FROM || process.env.SMTP_USER;

export const sendSuccessEmail = async ({ to, taskId, productUrl, size }) => {
  if (!to) return;
  try {
    await createTransporter().sendMail({
      from: FROM(), to,
      subject: 'SneakerBot — Checkout Successful!',
      html: `
        <h2>Checkout Successful!</h2>
        <p><strong>Task ID:</strong> ${taskId}</p>
        <p><strong>Product:</strong> <a href="${productUrl}">${productUrl}</a></p>
        ${size ? `<p><strong>Size:</strong> ${size}</p>` : ''}
        <p>Your order has been placed successfully.</p>
      `
    });
    logger.info(`Success email sent to ${to} for task ${taskId}`);
  } catch (err) {
    logger.error(`Failed to send success email to ${to}: ${err.message}`);
  }
};

export const sendApprovalRequestEmail = async ({ ownerEmail, newUsername, newEmail, approveUrl, declineUrl }) => {
  if (!ownerEmail) return;
  await createTransporter().sendMail({
    from: FROM(), to: ownerEmail,
    subject: `SneakerBot — Account request from ${newUsername}`,
    html: `
      <div style="font-family:sans-serif;max-width:520px;margin:0 auto">
        <h2 style="color:#00ff9c">⚡ SneakerBot — New Account Request</h2>
        <p>Someone wants access to your SneakerBot dashboard:</p>
        <table style="border-collapse:collapse;margin:16px 0;width:100%">
          <tr><td style="padding:8px 12px;color:#888;width:110px">Username</td><td style="padding:8px 12px;font-weight:600">${newUsername}</td></tr>
          <tr style="background:#f9f9f9"><td style="padding:8px 12px;color:#888">Email</td><td style="padding:8px 12px;font-weight:600">${newEmail}</td></tr>
        </table>
        <p>Click one of the buttons below to approve or decline:</p>
        <div style="margin:24px 0;display:flex;gap:12px">
          <a href="${approveUrl}" style="background:#00ff9c;color:#000;font-weight:700;padding:12px 28px;border-radius:8px;text-decoration:none;display:inline-block">✅ Approve</a>
          &nbsp;&nbsp;
          <a href="${declineUrl}" style="background:#ff3b5c;color:#fff;font-weight:700;padding:12px 28px;border-radius:8px;text-decoration:none;display:inline-block">❌ Decline</a>
        </div>
        <p style="color:#888;font-size:0.85rem">These links are single-use and will expire once clicked.</p>
      </div>
    `
  });
  logger.info(`[Auth] Approval request email sent to ${ownerEmail} for ${newUsername}`);
};

export const sendApprovalResultEmail = async ({ to, username, approved }) => {
  if (!to) return;
  await createTransporter().sendMail({
    from: FROM(), to,
    subject: `SneakerBot — Your account has been ${approved ? 'approved' : 'declined'}`,
    html: approved
      ? `<div style="font-family:sans-serif;max-width:480px;margin:0 auto">
           <h2 style="color:#00ff9c">✅ Access Approved!</h2>
           <p>Hi <strong>${username}</strong>, the owner has approved your SneakerBot account.</p>
           <p>You can now log in using the email and password you chose when signing up.</p>
         </div>`
      : `<div style="font-family:sans-serif;max-width:480px;margin:0 auto">
           <h2 style="color:#ff3b5c">❌ Access Declined</h2>
           <p>Hi <strong>${username}</strong>, the owner has declined your SneakerBot account request.</p>
           <p>If you think this was a mistake, contact the owner directly.</p>
         </div>`
  });
  logger.info(`[Auth] Result email (${approved ? 'approved' : 'declined'}) sent to ${to}`);
};
