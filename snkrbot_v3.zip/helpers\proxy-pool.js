// Reliable proxy failover for infrastructure failures.
//
// This module deliberately treats proxy rotation as a transport/reliability
// concern: dead, refusing, timing-out, or unreachable proxies are quarantined
// temporarily and healthy candidates are preferred. It does not rotate merely
// because a retailer/WAF rejected a request.

import db from '../db/index.js';
import logger from './logger.js';
import { selectBestProxy } from './proxy-intelligence.js';
import { rankProxies } from './proxy-quality.js';
import {
  recordLatency as recordLivenessSuccess,
  recordFailure as recordLivenessFailure,
  shouldAbandon,
  verdictFor
} from './proxy-liveness.js';

const POOL_CACHE_TTL_MS = 5000;
const TRANSPORT_COOLDOWN_BASE_MS = 30_000;
const TRANSPORT_COOLDOWN_MAX_MS = 10 * 60_000;
const poolCache = { value: null, expiresAt: 0, promise: null };
const transportFailures = new Map(); // proxyId -> { count, until, lastReason }

export const loadActiveProxies = async ({ force = false } = {}) => {
  const now = Date.now();
  if (!force && poolCache.value && poolCache.expiresAt > now) return poolCache.value;
  if (!force && poolCache.promise) return poolCache.promise;

  poolCache.promise = db('proxies')
    .where({ is_deleted: false })
    .select('*')
    .then((rows) => {
      poolCache.value = rows;
      poolCache.expiresAt = Date.now() + POOL_CACHE_TTL_MS;
      return rows;
    })
    .catch((err) => {
      logger.warn(`[ProxyPool] Failed to load proxy pool: ${err.message}`);
      return poolCache.value || [];
    })
    .finally(() => { poolCache.promise = null; });

  return poolCache.promise;
};

const isUsable = (proxy) => {
  const port = Number.parseInt(proxy?.port, 10);
  return Boolean(proxy?.id && proxy?.host && Number.isInteger(port) && port >= 1 && port <= 65535);
};

const cooldownEntry = (proxyId) => {
  const e = transportFailures.get(proxyId);
  if (!e) return null;
  if (e.until <= Date.now()) {
    transportFailures.delete(proxyId);
    return null;
  }
  return e;
};

export const markProxyTransportFailure = (proxyId, reason = 'transport failure') => {
  if (!proxyId) return;
  recordLivenessFailure(proxyId);
  const prev = cooldownEntry(proxyId);
  const count = (prev?.count || 0) + 1;
  const delay = Math.min(TRANSPORT_COOLDOWN_MAX_MS, TRANSPORT_COOLDOWN_BASE_MS * (2 ** Math.max(0, count - 1)));
  transportFailures.set(proxyId, { count, until: Date.now() + delay, lastReason: String(reason).slice(0, 180) });
  logger.warn(`[ProxyPool] Proxy ${proxyId} quarantined for ${Math.round(delay / 1000)}s after transport failure: ${String(reason).slice(0, 180)}`);
};

export const markProxyTransportSuccess = (proxyId, latencyMs = null) => {
  if (!proxyId) return;
  recordLivenessSuccess(proxyId, latencyMs);
  transportFailures.delete(proxyId);
};

export const proxyCooldownMs = (proxyId) => Math.max(0, (cooldownEntry(proxyId)?.until || 0) - Date.now());

// Expose the abandon decision so callers can rotate mid-stage on a dead exit
// instead of waiting out a timeout.
export const shouldAbandonProxy = (proxyId, opts) => shouldAbandon(proxyId, opts);

// Rotate only for transport-level failures. HTTP 403/429, challenge pages,
// captcha, or other retailer-side decisions stay on the task's normal retry path.
export const isProxyTransportFailure = (lastResult) => {
  if (!lastResult || lastResult.ok) return false;
  const type = String(lastResult.failureType || '').toLowerCase();
  const stage = String(lastResult.stage || '').toLowerCase();
  const msg = String(lastResult.error || '').toLowerCase();

  if (['network', 'timeout', 'proxy_error', 'connection_error', 'socket_error', 'dns_error'].includes(type)) return true;
  if (/^(connect|proxy|network|dns|socket|navigation)(?:_|$)/.test(stage)) return true;
  return /(econnreset|econnrefused|enotfound|enetunreach|ehostunreach|etimedout|eai_again|socket hang up|proxy.*timeout|tunnel.*failed|fetch failed|network timeout)/i.test(msg);
};

// A WAF/IP-level rejection ("Access denied", Imperva/Akamai/Cloudflare/Datadome
// interstitial). Unlike a merchant-side OOS or a card decline, the *next* fix is
// a different exit IP — retrying the same banned proxy just burns the task.
//
// Kept separate from isProxyTransportFailure(): that one is about the transport
// itself dying, this one is about the retailer refusing this identity.
const BAN_STAGE_RE = /^(connect|proxy|network|dns|socket|navigation|imperva|incapsula|akamai|cloudflare|cf|datadome|perimeterx|kasada|queue)(?:_|$)/;
const BAN_MESSAGE_RE = /(access denied|cloudflare\s*(?:error\s*)?10\d\d|error\s*1015|imperva|incapsula|akamai|datadome|perimeterx|kasada|bot detection|bot[- ]blocked|blocked|challenge|captcha|waiting room|rate[- ]?limit)/i;

export const isProxyBanFailure = (lastResult) => {
  if (!lastResult || lastResult.ok) return false;
  const type = String(lastResult.failureType || '').toLowerCase();
  const stage = String(lastResult.stage || '').toLowerCase();
  const msg = String(lastResult.error || lastResult.message || '');

  if (['blocked', 'banned', 'bot_blocked', 'challenge', 'captcha', 'rate_limited'].includes(type)) return true;
  if (BAN_STAGE_RE.test(stage)) return true;
  return BAN_MESSAGE_RE.test(msg);
};

export const shouldRotateProxyAfterFailure = ({ task, lastResult }) => {
  if (task?.rotate_on_retry === false) return false;
  if (isProxyTransportFailure(lastResult)) return true;
  return isProxyBanFailure(lastResult);
};

// Region + monthly-IP-quota fields are optional on the proxy row; absent data
// simply contributes nothing. Read defensively so an older row still ranks.
const softCountry = (p) => p?.country_code || p?.countryCode || p?.exit_country || p?.exitCountry || null;
const softCap = (p) => p?.monthly_ip_cap || p?.monthlyIpCap || 0;
const softUsed = (p) => p?.ips_used_this_month || p?.ipsUsedThisMonth || 0;

// Translate a liveness verdict into the counters proxy-quality already scores.
// Done here so quality stays a pure function of numbers and needs no knowledge of
// the liveness series.
const livenessAsEntry = (proxyId) => {
  const v = verdictFor(proxyId);
  return {
    meanLatencyMs: v.lastMs || 0,
    blocks: v.verdict === 'dead' ? 3 : (v.verdict === 'degraded' ? 1 : 0),
    transportFailures: 0,
    successes: v.verdict === 'healthy' ? 1 : 0
  };
};

export const pickBackupProxy = async ({ host, excludeIds = new Set(), forceRefresh = false, proxyType = null, profileCountry = null } = {}) => {
  const all = await loadActiveProxies({ force: forceRefresh });
  const typed = proxyType && proxyType !== 'unknown'
    ? all.filter((p) => String(p.proxy_type || 'unknown') === String(proxyType))
    : all;
  const candidates = typed.filter((p) => isUsable(p) && !excludeIds.has(p.id) && !cooldownEntry(p.id));
  if (candidates.length === 0) {
    // Don't fail forever when every proxy is cooling down. Pick the proxy whose
    // cooldown expires first only as a last-resort availability fallback.
    const fallback = typed
      .filter((p) => isUsable(p) && !excludeIds.has(p.id))
      .sort((a, b) => proxyCooldownMs(a.id) - proxyCooldownMs(b.id))[0] || null;
    if (fallback) logger.warn(`[ProxyPool] All healthy candidates are cooling down for ${host || 'unknown-host'}; using earliest recovery candidate ${fallback.id}`);
    return fallback;
  }

  // Grade on region fit and monthly IP quota, then let the host-affinity scorer
  // choose WITHIN the best quality band. Ordering matters: picking purely on host
  // affinity re-tries a spent or geo-wrong exit, and picking purely on quality
  // throws away per-host history.
  const ranked = rankProxies({
    profileCountry,
    candidates: candidates.map((p) => ({
      id: p.id,
      proxy: p,
      countryCode: softCountry(p),
      monthlyIpCap: softCap(p),
      ipsUsedThisMonth: softUsed(p),
      // Feed liveness in as the "entry" counters so a dead exit sinks without
      // needing a separate pass, and a slow one ranks below a clean peer.
      entry: livenessAsEntry(p.id)
    }))
  });

  const usable = ranked.filter((c) => !c.quota.exhausted);
  if (usable.length === 0) {
    logger.warn(`[ProxyPool] Every candidate for ${host || 'unknown-host'} has spent its monthly IP quota; using the least-recently-used`);
    const lru = ranked[ranked.length - 1];
    return lru ? lru.proxy : (candidates[0] || null);
  }

  // A quality band of 5 is wide enough to keep host affinity meaningful without
  // letting it drag in a clearly worse exit.
  const band = usable.slice(0, 5);
  const ids = band.map((c) => c.id);
  const bestId = host ? selectBestProxy(host, ids) : ids[0];
  const chosen = band.find((c) => c.id === bestId) || band[0];
  if (chosen.reasons.length) {
    logger.debug(`[ProxyPool] Picked proxy ${chosen.id} for ${host || 'unknown-host'} (${chosen.reasons.join('+')})`);
  }
  return chosen.proxy || candidates.find((p) => p.id === chosen.id) || candidates[0];
};

export const getProxyPoolSnapshot = () => Array.from(transportFailures.entries()).map(([proxyId, e]) => ({
  proxyId,
  cooldownMs: Math.max(0, e.until - Date.now()),
  count: e.count,
  lastReason: e.lastReason,
}));

export const __resetForTests = () => {
  transportFailures.clear();
  poolCache.value = null;
  poolCache.expiresAt = 0;
};
