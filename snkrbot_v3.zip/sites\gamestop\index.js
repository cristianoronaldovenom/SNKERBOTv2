import { tryRequestFirstAddToCart } from '../../helpers/browser-request-atc.js';
import { navigateCartUnlessReady } from '../../helpers/site-checkout-fastpath.js';
import logger from '../../helpers/logger.js';
import { humanType, humanTypeInFrames, humanClick, humanSelect } from '../../helpers/human-type.js';
import {
  formatPostal, stripPhone, dismissAutocomplete,
  requireCardIframe, verifyCartHasItem, FillReport, assertCriticalFields
} from '../../helpers/autofill-utils.js';
import {
  guardedGoto, preOrderGuard, postClickGuard, takeFailureScreenshot
} from '../../helpers/checkout-guards.js';
import { captureOrderSuccess } from '../../helpers/order-capture.js';
import { assertActionButtonIntent } from '../../helpers/checkout-controls.js';

const BASE_URL = 'https://www.gamestop.ca';
import { waitForAnySelector } from '../../helpers/site-runtime.js';

const TIMEOUT = 15000;

const SELECTORS = {
  addToCart: [
    'button.add-to-cart',
    'button[data-buttontext="Add to Cart"]',
    'button[data-testid="add-to-cart"]',
    'button.pdp-add-btn',
    'input[data-buttontext="Add to Cart"]',
    'button[name="addToCart"]'
  ],
  qtySelect: [
    'select.quantity-select',
    'select[name="quantity"]',
    'input[name="quantity"]',
    'select.qty'
  ],
  cartCheckout: [
    'a.checkout-btn',
    'button.checkout-btn',
    'a[href*="/checkout"]',
    'button[name="dwfrm_cart_checkoutCart"]'
  ],
  guestCheckout: [
    'button.guest-continue',
    'button[name="dwfrm_login_unregistered"]',
    'a.guest-checkout'
  ],
  email:      ['input[name="dwfrm_billing_billingAddress_email_emailAddress"]', 'input[name="email"]', 'input#email', 'input[type="email"]'],
  firstName:  ['input[name="dwfrm_shipping_shippingAddress_addressFields_firstName"]', 'input[name="firstName"]', 'input#shippingFirstName'],
  lastName:   ['input[name="dwfrm_shipping_shippingAddress_addressFields_lastName"]', 'input[name="lastName"]', 'input#shippingLastName'],
  address1:   ['input[name="dwfrm_shipping_shippingAddress_addressFields_address1"]', 'input[name="address1"]'],
  address2:   ['input[name="dwfrm_shipping_shippingAddress_addressFields_address2"]', 'input[name="address2"]'],
  city:       ['input[name="dwfrm_shipping_shippingAddress_addressFields_city"]', 'input[name="city"]'],
  state:      ['select[name="dwfrm_shipping_shippingAddress_addressFields_states_stateCode"]', 'select[name="state"]'],
  postalCode: ['input[name="dwfrm_shipping_shippingAddress_addressFields_postalCode"]', 'input[name="postalCode"]'],
  phone:      ['input[name="dwfrm_shipping_shippingAddress_addressFields_phone"]', 'input[name="phone"]', 'input[type="tel"]'],
  shippingSubmit: ['button.submit-shipping', 'button[name="submit-shipping"]'],
  cardNumber: ['input[name="dwfrm_billing_creditCardFields_cardNumber"]', 'input#cardNumber', 'input[autocomplete="cc-number"]'],
  cardOwner:  ['input[name="dwfrm_billing_creditCardFields_cardOwner"]', 'input#cardOwner', 'input[autocomplete="cc-name"]'],
  expMonth:   ['select[name="dwfrm_billing_creditCardFields_expirationMonth"]', 'select#expirationMonth'],
  expYear:    ['select[name="dwfrm_billing_creditCardFields_expirationYear"]', 'select#expirationYear'],
  cvv:        ['input[name="dwfrm_billing_creditCardFields_securityCode"]', 'input#securityCode', 'input[autocomplete="cc-csc"]'],
  paymentSubmit: ['button.submit-payment', 'button[name="submit-payment"]'],
  placeOrder: ['button.place-order', 'button[name="submit-order"]', 'button[data-action="place-order"]'],
  orderConfirmation: ['.order-confirmation-number', '.order-thank-you', 'h1.order-thank-you-msg']
};

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const findFirst = async (page, selectorList, timeout = TIMEOUT) => {
  const selector = await waitForAnySelector(page, selectorList, { timeout });
  if (!selector) return null;
  const el = await page.$(selector).catch(() => null);
  return el ? { el, selector } : null;
};

const clickFirst = async (page, selectorList, { stage = '' } = {}) => {
  const found = await findFirst(page, selectorList, TIMEOUT);
  if (!found) throw new Error(`Could not find clickable element at stage "${stage}" — tried [${selectorList.join(', ')}]`);
  await humanClick(page, found.selector);
  return found.selector;
};

const fillField = async (page, selectorList, value, { label = '', report = null } = {}) => {
  const name = label || 'unnamed';
  if (!value) { if (report) report.record(name, true, 'skipped (empty)'); return false; }
  const found = await findFirst(page, selectorList, 8000);
  if (!found) { if (report) report.record(name, false, 'selector not found'); return false; }
  await found.el.click({ clickCount: 3 }).catch(() => {});
  await page.keyboard.press('Backspace').catch(() => {});
  await humanType(page, found.selector, String(value));
  await dismissAutocomplete(page, found.selector);
  await page.keyboard.press('Tab').catch(() => {});
  if (report) report.record(name, true);
  return true;
};

const setQuantity = async (page, quantity) => {
  if (!quantity || quantity <= 1) return;
  const found = await findFirst(page, SELECTORS.qtySelect, 5000);
  if (!found) { logger.warn('[GameStop] Quantity selector not found'); return; }
  const tag = await found.el.evaluate((el) => el.tagName.toLowerCase());
  if (tag === 'select') {
    await page.select(found.selector, String(quantity)).catch(() => {});
  } else {
    await found.el.click({ clickCount: 3 }).catch(() => {});
    await humanType(page, found.selector, String(quantity));
  }
  await sleep(500);
  logger.info(`[GameStop] Quantity set to ${quantity}`);
};

const runGameStop = async ({ page, task }) => {
  const startedAt = Date.now();
  logger.info(`[GameStop] Starting checkout for task ${task.id}: ${task.url}`);
  page.setDefaultNavigationTimeout(30000);

  await guardedGoto(page, task.url, { taskId: task.id, stage: 'pdp_load' });
  await waitForAnySelector(page, SELECTORS.addToCart, { timeout: 8000 });

  if (task.keywords) {
    const kws = task.keywords.toLowerCase().split(',').map((s) => s.trim()).filter(Boolean);
    if (kws.length > 0) {
      logger.info(`[GameStop] Trying to match variant for keywords [${kws.join(', ')}]`);
      const matched = await page.evaluate((kws) => {
        const tiles = Array.from(document.querySelectorAll('.product-variations button, .variant-tile, .swatch-value'));
        const hit = tiles.find((t) => {
          const text = (t.textContent || t.getAttribute('aria-label') || '').toLowerCase();
          return kws.every((k) => text.includes(k));
        });
        if (hit) { hit.click(); return true; }
        return false;
      }, kws).catch(() => false);
      if (matched) await sleep(800);
    }
  }

  await setQuantity(page, task.quantity);
if (!(await tryRequestFirstAddToCart(page, SELECTORS.addToCart))) await clickFirst(page, SELECTORS.addToCart, { stage: 'add_to_cart' });
  logger.info('[GameStop] Added to cart');

  await navigateCartUnlessReady({ page, cartUrl: `${BASE_URL}/cart`, navigate: guardedGoto, taskId: task.id, stage: 'cart_load' });

  const cartCheck = await verifyCartHasItem(page, { timeout: 6000 });
  if (cartCheck.empty) {
    const err = new Error('Cart is empty after add-to-cart — product may be out of stock');
    err.failureType = 'oos';
    throw err;
  }
  logger.info(`[GameStop] Cart verified (${cartCheck.count} item(s))`);

  await clickFirst(page, SELECTORS.cartCheckout, { stage: 'cart_to_checkout' });
  await page.waitForNavigation({ waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
  await postClickGuard(page, { taskId: task.id, stage: 'cart_to_checkout' });

  const guest = await findFirst(page, SELECTORS.guestCheckout, 4000);
  if (guest) { await humanClick(page, guest.selector); await waitForAnySelector(page, SELECTORS.email, { timeout: 8000 }); await postClickGuard(page, { taskId: task.id, stage: 'guest_checkout' }); }

  const ship = task.shippingAddress;
  if (!ship) throw new Error('Shipping address missing at stage "fill_shipping"');
  const shipReport = new FillReport(task.id, 'GameStop Shipping');
  await fillField(page, SELECTORS.email, task.notification_email_address || ship.email, { label: 'email', report: shipReport });
  await fillField(page, SELECTORS.firstName, ship.first_name, { label: 'firstName', report: shipReport });
  await fillField(page, SELECTORS.lastName, ship.last_name, { label: 'lastName', report: shipReport });
  await fillField(page, SELECTORS.address1, ship.address1, { label: 'address1', report: shipReport });
  await fillField(page, SELECTORS.address2, ship.address2, { label: 'address2', report: shipReport });
  await fillField(page, SELECTORS.city, ship.city, { label: 'city', report: shipReport });
  await fillField(page, SELECTORS.postalCode, formatPostal(ship.zip), { label: 'postalCode', report: shipReport });
  await fillField(page, SELECTORS.phone, stripPhone(ship.phone), { label: 'phone', report: shipReport });
  const stateSel = await findFirst(page, SELECTORS.state, 3000);
  if (stateSel) await humanSelect(page, stateSel.selector, ship.state).catch(() => {});
  shipReport.log();
  assertCriticalFields(shipReport, ['email', 'firstName', 'lastName', 'address1', 'city', 'postalCode', 'phone']);

  await clickFirst(page, SELECTORS.shippingSubmit, { stage: 'submit_shipping' });
  await waitForAnySelector(page, [...SELECTORS.cardNumber, ...SELECTORS.paymentSubmit], { timeout: 12000 });
  await postClickGuard(page, { taskId: task.id, stage: 'submit_shipping' });

  const pay = task.paymentProfile;
  if (!pay) throw new Error('Payment profile missing at stage "fill_payment"');

  await requireCardIframe(page, { timeout: 15000 });

  const payReport = new FillReport(task.id, 'GameStop Payment');

  const ownerOk = await humanTypeInFrames(page, SELECTORS.cardOwner.join(', '), pay.card_holder_name, { tabAfter: true });
  payReport.record('cardOwner', ownerOk, ownerOk ? '' : 'not found in main or iframes');

  const numOk = await humanTypeInFrames(page, SELECTORS.cardNumber.join(', '), pay.card_number.replace(/\s/g, ''), { tabAfter: true });
  payReport.record('cardNumber', numOk, numOk ? '' : 'not found in main or iframes');

  const cvvOk = await humanTypeInFrames(page, SELECTORS.cvv.join(', '), pay.cvv, { tabAfter: true });
  payReport.record('cvv', cvvOk, cvvOk ? '' : 'not found in main or iframes');

  const rawMo = String(pay.expiration_month);
  const intMo = String(parseInt(rawMo, 10));
  const expMo = await findFirst(page, SELECTORS.expMonth, 2000);
  if (expMo) {
    for (const v of [rawMo, intMo, intMo.padStart(2, '0')]) {
      if (await humanSelect(page, expMo.selector, v).catch(() => false)) break;
    }
  }
  const rawYr = String(pay.expiration_year);
  const expYr = await findFirst(page, SELECTORS.expYear, 2000);
  if (expYr) {
    if (!await humanSelect(page, expYr.selector, rawYr).catch(() => false)) {
      await humanSelect(page, expYr.selector, rawYr.slice(-2)).catch(() => {});
    }
  }
  payReport.log();
  assertCriticalFields(payReport, ['cardOwner', 'cardNumber', 'cvv']);

  await clickFirst(page, SELECTORS.paymentSubmit, { stage: 'submit_payment' });
  await waitForAnySelector(page, SELECTORS.placeOrder, { timeout: 12000 });
  await postClickGuard(page, { taskId: task.id, stage: 'submit_payment' });

  await preOrderGuard(page, { taskId: task.id });
  await assertActionButtonIntent(page, SELECTORS.placeOrder, { stage: 'place order', allow: /place order|submit order|complete order/i });
  await clickFirst(page, SELECTORS.placeOrder, { stage: 'place_order' });

  const confirmed = await Promise.race([
    findFirst(page, SELECTORS.orderConfirmation, 60000),
    page.waitForFunction(() => /thank-you|order-confirmation|confirmation/.test(window.location.pathname), { timeout: 60000 }).then(() => ({ url: true })).catch(() => null)
  ]);
  if (!confirmed) {
    await takeFailureScreenshot(page, task.id, 'confirm_order_fail');
    throw new Error('Order confirmation not detected at stage "confirm_order"');
  }

  const orderNumber = await page.evaluate(() => {
    const el = document.querySelector('.order-confirmation-number, [class*="orderNumber" i], .order-number');
    return el ? el.textContent.trim() : null;
  }).catch(() => null);

  logger.info(`[GameStop] ✅ Order placed for task ${task.id}! Order: ${orderNumber || 'N/A'}`);
  await captureOrderSuccess({ page, taskId: task.id, orderNumber, productUrl: task.url, durationMs: Date.now() - startedAt }).catch(() => {});
};

export default runGameStop;
