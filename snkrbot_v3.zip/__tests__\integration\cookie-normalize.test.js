// Cookie injection normalization. Both the warm-cookie pool and the CF-clearance
// restore hand objects to page.setCookie(); a single entry without a domain/path
// makes CDP throw and discards the WHOLE set.
import { jest } from '@jest/globals';

jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));

const { normalizeCookiesForPage, storeCookies, injectCookies } =
  await import('../../helpers/cookie-pool.js');

const URL_UNDER_TEST = 'https://shop.example.com/checkout/step-2';

test('fills in domain and path from the page URL', () => {
  const out = normalizeCookiesForPage(URL_UNDER_TEST, [{ name: 'a', value: '1' }]);
  expect(out).toEqual([{ name: 'a', value: '1', domain: 'shop.example.com', path: '/checkout/step-2' }]);
});

test('keeps an explicit domain and path untouched', () => {
  const out = normalizeCookiesForPage(URL_UNDER_TEST, [
    { name: 'c', value: 'v', domain: '.example.com', path: '/' }
  ]);
  expect(out[0].domain).toBe('.example.com');
  expect(out[0].path).toBe('/');
});

test('drops nameless entries instead of poisoning the set', () => {
  const out = normalizeCookiesForPage(URL_UNDER_TEST, [
    { value: 'orphan' },
    { name: 'good', value: 'x' }
  ]);
  expect(out).toHaveLength(1);
  expect(out[0].name).toBe('good');
});

test('coerces values and only passes a finite expiry through', () => {
  const out = normalizeCookiesForPage(URL_UNDER_TEST, [
    { name: 'n', value: null, expires: 1893456000 },
    { name: 'bad', value: 'v', expires: 'not-a-date' }
  ]);
  expect(out[0].value).toBe('');
  expect(out[0].expires).toBe(1893456000);
  expect(out[1].expires).toBeUndefined();
});

test('an unparseable URL yields an empty set', () => {
  expect(normalizeCookiesForPage('not a url', [{ name: 'a', value: 'b' }])).toEqual([]);
});

test('injectCookies sends normalized cookies to the page', async () => {
  storeCookies(URL_UNDER_TEST, [{ name: 'warm', value: 'yes' }]);
  const setCookie = jest.fn(async () => {});
  const ok = await injectCookies({ setCookie }, URL_UNDER_TEST);
  expect(ok).toBe(true);
  expect(setCookie).toHaveBeenCalledTimes(1);
  const [sent] = setCookie.mock.calls[0];
  expect(sent.domain).toBe('shop.example.com');
  expect(sent.name).toBe('warm');
});

test('a rejecting setCookie is reported, not thrown', async () => {
  storeCookies(URL_UNDER_TEST, [{ name: 'warm', value: 'yes' }]);
  const setCookie = jest.fn(async () => { throw new Error('CDP says no'); });
  await expect(injectCookies({ setCookie }, URL_UNDER_TEST)).resolves.toBe(false);
});
