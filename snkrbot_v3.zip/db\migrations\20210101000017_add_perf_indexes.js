// Performance indexes for hot/queried paths. All additive + reversible; no
// behavior change. Targets three real queries (verified against the code):
//
//   1. Household-cap enforcement runs on EVERY checkout attempt:
//        SELECT id FROM tasks WHERE shipping_address_id = ? FOR UPDATE
//        + JOIN task_runs ON task_id WHERE task_runs.status = 'success'
//      tasks.shipping_address_id is a FK but Postgres does NOT auto-index FK
//      columns, so this lock did a seq scan. task_runs(task_id, status) serves
//      the join+filter directly.
//
//   2. GET /v1/runs (default + export.csv): ORDER BY started_at DESC over the
//      whole table. The existing (task_id, started_at) index can't serve a pure
//      started_at sort (wrong leading column), so a standalone started_at index
//      keeps history/exports fast as the table grows.
export const up = async (knex) => {
  await knex.schema.alterTable('task_runs', (t) => {
    t.index(['task_id', 'status']);
    t.index(['started_at']);
  });
  await knex.schema.alterTable('tasks', (t) => {
    t.index(['shipping_address_id']);
  });
};

export const down = async (knex) => {
  await knex.schema.alterTable('tasks', (t) => {
    t.dropIndex(['shipping_address_id']);
  });
  await knex.schema.alterTable('task_runs', (t) => {
    t.dropIndex(['started_at']);
    t.dropIndex(['task_id', 'status']);
  });
};
