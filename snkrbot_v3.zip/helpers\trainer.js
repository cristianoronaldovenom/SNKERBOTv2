// Continuous background trainer — probes anti-bot-protected sites with every
// TLS/behavioral arm so the Bayesian bandit accumulates high-confidence data
// without waiting for real checkout attempts.
//
// Problem: the bandit starts cold. Without training data it has to explore all
// 6 arms during real checkout runs — each "exploration" probe risks burning a
// proxy/captcha budget and missing a limited-stock drop. By probing 24/7 with
// cheap HTTP GETs, we build signal on which Chrome TLS profile gets through
// each WAF before any task fires.
//
// How it works:
//   1. Every ~4 minutes, cycle through 4 training targets (Nike/Akamai,
//      Topps/DataDome, Pokemon Center/Imperva, Foot Locker/Imperva).
//   2. For each target, pick the arm with fewest real observations so every
//      arm gets probed evenly. Once all arms have ≥20 pulls, switch to the
//      bandit's recommended arm (exploit mode).
//   3. Make an HTTP GET via the TLS sidecar with that arm's Chrome profile
//      and matching Sec-CH-UA headers.
//   4. Classify the response as pass/block using the same 30+ WAF signatures
//      from stock-monitor.js.
//   5. Record the outcome to the bandit so future task.start() recommendations
//      carry real confidence.
//   6. On a successful probe, if the response set Imperva/Akamai cookies,
//      forward them to the session store so checkout tasks skip the warm-up.
//
// The trainer never actually adds to cart or checks out — it only GETs public
// product-list pages. Impact: ~4 req/min spread across 4 domains = well below
// any rate limit.

import { tlsRequest } from './tls-client.js';
import { getBotLearnerRecommendation, recordBotLearnerOutcome } from './bot-learner.js';
import { markSessionWarmed } from './stock-monitor.js';
import logger from './logger.js';
import { secChUa, secChUaFullVersionList } from './client-hints.js';

// ── Training targets ──────────────────────────────────────────────────────────
// One entry per site we want to train against. URL must be a public page that
// each vendor's WAF actively guards (category/listing page, not checkout).

const TARGETS = [
  { siteId: 4, vendor: 'akamai',   label: 'Nike',          url: 'https://www.nike.com/w/mens-shoes-nik1zy7ok' },
  { siteId: 7, vendor: 'datadome', label: 'Topps',         url: 'https://www.topps.com/' },
  { siteId: 6, vendor: 'imperva',  label: 'PokémonCenter', url: 'https://www.pokemoncenter.com/en-ca/' },
  { siteId: 1, vendor: 'imperva',  label: 'FootLocker',    url: 'https://www.footlocker.com/category/shoes.html' },
];

// All 6 arms the bandit knows about
const ARMS = [
  'chrome131-quick', 'chrome131-normal',
  'chrome124-quick', 'chrome124-normal',
  'chrome120-quick', 'chrome120-normal',
];

// Chrome version → matching User-Agent and Sec-CH-UA version string
const PROFILE_META = {
  chrome131: { ver: '131', fullVer: '131.0.6778.204', ua: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36' },
  chrome124: { ver: '124', fullVer: '124.0.6367.207', ua: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36' },
  chrome120: { ver: '120', fullVer: '120.0.6099.234', ua: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36' },
};

// WAF block signatures — same set as stock-monitor.js BOT_BLOCK_PATTERNS
const BLOCK_PATTERNS = [
  /pardon our interruption/i, /access denied/i, /captcha/i,
  /verify you are human/i, /just a moment/i, /challenge-platform/i,
  /ray id/i, /_Incapsula_Resource/i, /reese84/i, /px-captcha/i,
  /perimeterx/i, /kasada/i, /datadome/i, /dd_cookie_test/i,
  /kpsdk/i, /cf-mitigated/i, /turnstile/i, /request blocked/i,
  /security check/i, /bot[\s\-]?detection/i, /unusual traffic/i,
  /sucuri_cloudproxy/i, /attention required/i, /one more step/i,
];

// Minimum body length for a "real" HTML page (blocks are often tiny stubs)
const MIN_REAL_BODY = 5_000;

// ── Probe interval ────────────────────────────────────────────────────────────
// Full cycle = one probe per target = 4 probes total.
// Cycle interval ~4 min → each site probed ~15×/hour → ~360×/day.
// One arm per target per cycle → each arm gets ~60 probes/day per site.
// After ~20 days all 6 arms have ≥20 pulls → exploit mode kicks in.
// (In practice the bandit is useful much sooner — confidence builds fast.)

const CYCLE_INTERVAL_MS   = 4 * 60 * 1000;  // 4 min between cycles
const INTER_TARGET_GAP_MS = 10_000;          // 10s gap between targets (rate-limit safety)
const EXPLOIT_THRESHOLD   = 20;              // pulls per arm to switch to exploit mode

// ── State ─────────────────────────────────────────────────────────────────────

const MAX_HISTORY = 300;
const probeHistory = [];   // most-recent first
let running       = false;
let startedAt     = null;
let probeCount    = 0;
let passCount     = 0;
let blockCount    = 0;
let skipCount     = 0;

const rand = (lo, hi) => lo + Math.floor(Math.random() * (hi - lo + 1));
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const pushHistory = (e) => { probeHistory.unshift({ ...e, ts: new Date().toISOString() }); if (probeHistory.length > MAX_HISTORY) probeHistory.pop(); };

// ── Arm selector — least-tested first ────────────────────────────────────────
// Training goal: build even signal across all 6 arms as quickly as possible.
// Strategy: always probe the arm with the fewest real observations for this
// site. If several arms are tied, pick one at random.
// Once every arm has ≥EXPLOIT_THRESHOLD pulls, trust the bandit and let it
// exploit its best arm (with its built-in 5% epsilon exploration).

const pickArm = async (siteId) => {
  try {
    const rec = await getBotLearnerRecommendation(siteId);
    const minPulls = Math.min(...rec.ranked.map(a => a.pulls));
    const allWellTested = rec.ranked.every(a => a.pulls >= EXPLOIT_THRESHOLD);
    if (allWellTested) return rec.arm; // exploit mode
    // Pick one of the least-tested arms at random
    const candidates = rec.ranked.filter(a => a.pulls === minPulls);
    return candidates[Math.floor(Math.random() * candidates.length)].arm;
  } catch (_) {
    return ARMS[probeCount % ARMS.length];
  }
};

// ── Single HTTP probe ─────────────────────────────────────────────────────────

const probeTarget = async (target, arm) => {
  const [profileKey] = arm.split('-');
  const meta = PROFILE_META[profileKey] || PROFILE_META.chrome131;
  const t0 = Date.now();

  let resp;
  try {
    resp = await tlsRequest({
      url: target.url,
      profile: profileKey,
      timeoutMs: 14_000,
      headers: {
        'User-Agent':                 meta.ua,
        'Accept':                     'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language':            'en-US,en;q=0.9',
        'Accept-Encoding':            'gzip, deflate, br',
        'Sec-Ch-Ua':                  secChUa(meta.ver),
        'Sec-Ch-Ua-Full-Version-List': secChUaFullVersionList(meta.ver, meta.fullVer),
        'Sec-Ch-Ua-Mobile':           '?0',
        'Sec-Ch-Ua-Platform':         '"Windows"',
        'Sec-Ch-Ua-Platform-Version': '"15.0.0"',
        'Sec-Fetch-Dest':             'document',
        'Sec-Fetch-Mode':             'navigate',
        'Sec-Fetch-Site':             'none',
        'Sec-Fetch-User':             '?1',
        'Cache-Control':              'no-cache',
        'Pragma':                     'no-cache',
        'Upgrade-Insecure-Requests':  '1',
      }
    });
  } catch (err) {
    return { skipped: true, reason: 'request_error', error: err.message, latencyMs: Date.now() - t0 };
  }

  const latencyMs = Date.now() - t0;

  if (!resp.ok || resp.fallback) {
    return { skipped: true, reason: 'sidecar_down', latencyMs };
  }

  const body   = resp.body || '';
  const status = resp.status || 0;
  const hdr    = resp.headers || {};
  const setCookie = Array.isArray(hdr['set-cookie']) ? hdr['set-cookie'].join('; ') : (hdr['set-cookie'] || '');

  const hardBlock   = [403, 429, 503, 403].includes(status);
  const htmlBlock   = BLOCK_PATTERNS.some(p => p.test(body));
  const tinyBody    = status === 200 && body.length < MIN_REAL_BODY;
  const blocked     = hardBlock || htmlBlock || tinyBody;

  // If we got real session cookies from Imperva/Akamai, store them
  if (!blocked && status === 200 && /visid_incap|reese84|_abck|ak_bmsc/i.test(setCookie)) {
    const host = new URL(target.url).hostname;
    markSessionWarmed(host);
    logger.debug(`[Trainer] Harvested warm session cookies for ${host}`);
  }

  return { skipped: false, blocked, status, bodyLen: body.length, latencyMs };
};

// ── Main loop ─────────────────────────────────────────────────────────────────

const runLoop = async () => {
  startedAt = new Date().toISOString();
  logger.info(`[Trainer] 24/7 training loop started — ${TARGETS.length} targets (Akamai, DataDome, Imperva)`);

  while (running) {
    for (const target of TARGETS) {
      if (!running) break;

      const arm = await pickArm(target.siteId);
      const [profile, mode] = arm.split('-');

      logger.debug(`[Trainer] → ${target.label} (${target.vendor}) arm="${arm}"`);

      const result = await probeTarget(target, arm);
      probeCount++;

      if (result.skipped) {
        skipCount++;
        pushHistory({ site: target.label, siteId: target.siteId, vendor: target.vendor, arm, skipped: true, reason: result.reason });
        // Don't record to bandit — no information gained
        await sleep(rand(2_000, 4_000));
        continue;
      }

      if (result.blocked) {
        blockCount++;
      } else {
        passCount++;
      }

      // Map vendor to the stage string the bandit's BOT_STAGE_PATTERNS will match
      const blockedStage = { akamai: 'akamai', datadome: 'datadome', imperva: 'imperva' }[target.vendor] || 'bot_block';
      const outcome = result.blocked
        ? { ok: false, stage: blockedStage, failureType: 'bot_block' }
        : { ok: true,  stage: 'probe_pass', failureType: null };

      await recordBotLearnerOutcome(target.siteId, arm, outcome).catch(() => {});

      const icon = result.blocked ? '✗' : '✓';
      logger.info(
        `[Trainer] ${icon} ${target.label} ${arm} — ` +
        `${result.blocked ? 'BLOCKED' : 'PASSED'} ` +
        `(HTTP ${result.status}, ${result.bodyLen}b, ${result.latencyMs}ms)`
      );

      pushHistory({
        site:     target.label,
        siteId:   target.siteId,
        vendor:   target.vendor,
        arm,
        passed:   !result.blocked,
        blocked:  result.blocked,
        status:   result.status,
        bodyLen:  result.bodyLen,
        latencyMs: result.latencyMs,
      });

      if (!running) break;
      await sleep(rand(INTER_TARGET_GAP_MS - 3_000, INTER_TARGET_GAP_MS + 5_000));
    }

    if (!running) break;

    // Jittered wait before next cycle — avoids clock-aligned patterns
    const wait = rand(CYCLE_INTERVAL_MS - 45_000, CYCLE_INTERVAL_MS + 60_000);
    logger.debug(`[Trainer] Cycle done (${passCount}P/${blockCount}B/${skipCount}S). Next in ${Math.round(wait / 1000)}s`);
    await sleep(wait);
  }

  logger.info('[Trainer] Loop stopped');
};

// ── Public API ────────────────────────────────────────────────────────────────

export const startTrainer = () => {
  if (running) { logger.debug('[Trainer] Already running'); return; }
  running = true;
  runLoop().catch(err => {
    logger.error(`[Trainer] Loop crashed: ${err.message} — will not auto-restart`);
    running = false;
  });
};

export const stopTrainer = () => {
  if (!running) return;
  running = false;
  logger.info('[Trainer] Stop requested — loop will exit after current probe');
};

export const getTrainerStatus = () => ({
  running,
  startedAt,
  probeCount,
  passCount,
  blockCount,
  skipCount,
  passRate:  probeCount > 0 ? parseFloat(((passCount / probeCount) * 100).toFixed(1)) : null,
  targets:   TARGETS.map(t => ({ siteId: t.siteId, label: t.label, vendor: t.vendor, url: t.url })),
  recentProbes: probeHistory.slice(0, 50),
});
