// Preflight card-expiry handling. `2-digit year` used to resolve to 1926, which
// made every such card read as expired, and a card is valid THROUGH the last day
// of its expiry month — not up to the first.
import { jest } from '@jest/globals';

const db = jest.fn(() => ({ where: () => ({ first: async () => null }) }));
jest.unstable_mockModule('../../db/index.js', () => ({ default: db }));
jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));
jest.unstable_mockModule('../../helpers/task-proxies.js', () => ({
  resolveTaskProxy: async () => ({ proxy: { id: 1 }, source: 'task' })
}));

const { preflightTask } = await import('../../helpers/preflight.js');

const base = {
  url: 'https://shop.example.com/p/1',
  site_id: 2,
  shipping_address_id: 1,
  payment_profile_id: 1,
  start_at: null,
};

// The address/payment rows come from db(); stub them per call.
const withRows = (address, pay) => {
  db.mockImplementation(() => ({ where: () => ({ first: async () => pay }) }));
  return address;
};

const CURRENT_YEAR = new Date().getFullYear();

const runWith = async (pay) => {
  const address = {
    first_name: 'A', last_name: 'B', address1: '1 St', city: 'C',
    state: 'ON', zip: 'M5V 1A1', phone: '5551234567', email: 'a@b.com'
  };
  let call = 0;
  db.mockImplementation(() => ({
    where: () => ({ first: async () => (call++ === 0 ? address : pay) })
  }));
  return preflightTask(base);
};

const payBase = { card_number: '4242424242424242', card_holder_name: 'A B', cvv: '123' };

beforeEach(() => { jest.useFakeTimers(); jest.setSystemTime(new Date(`${CURRENT_YEAR}-06-15T12:00:00Z`)); });
afterEach(() => { jest.useRealTimers(); });

test('a valid 4-digit future expiry is not flagged', async () => {
  const r = await runWith({ ...payBase, expiration_month: '12', expiration_year: String(CURRENT_YEAR + 1) });
  expect(r.issues.some((i) => i.startsWith('Card expired'))).toBe(false);
});

test('a 2-digit year in the future is not treated as 1926', async () => {
  const r = await runWith({ ...payBase, expiration_month: '12', expiration_year: String((CURRENT_YEAR + 1) % 100) });
  expect(r.issues.some((i) => i.startsWith('Card expired'))).toBe(false);
});

test('a card is still valid during its own expiry month', async () => {
  const r = await runWith({ ...payBase, expiration_month: '06', expiration_year: String(CURRENT_YEAR) });
  expect(r.issues.some((i) => i.startsWith('Card expired'))).toBe(false);
});

test('a genuinely past expiry is flagged', async () => {
  const r = await runWith({ ...payBase, expiration_month: '05', expiration_year: String(CURRENT_YEAR) });
  expect(r.issues.some((i) => i.startsWith('Card expired'))).toBe(true);
});

test('an impossible month is flagged rather than silently accepted', async () => {
  const r = await runWith({ ...payBase, expiration_month: '13', expiration_year: String(CURRENT_YEAR + 1) });
  expect(r.issues.some((i) => i.startsWith('Card expired'))).toBe(true);
});
