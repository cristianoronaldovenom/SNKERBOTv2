// Pure-logic tests for the runtime bootstrap layer.
//
// Nothing here touches the network: the value of this module is the decision
// logic (version comparison, PATH resolution, environment wiring), and that is
// what breaks silently. The download path was exercised by hand end-to-end —
// Go was fetched, checked against go.dev's release index, extracted, run, and
// only then reported installed.
import { describe, expect, test } from '@jest/globals';
import path from 'node:path';
import {
  parseVersion, versionAtLeast, findOnPath, resolveChromiumPath,
  ensureRuntime, managedEnv, SPECS, REQUIRED_BY_DEFAULT
} from '../../helpers/bootstrap-env.js';

describe('version comparison', () => {
  test('parses each vendor\'s version format', () => {
    // `go version` output is the awkward one: the number is embedded mid-string.
    expect(parseVersion('v22.14.0')).toEqual([22, 14, 0]);
    expect(parseVersion('go version go1.25.3 windows/amd64')).toEqual([1, 25, 3]);
    expect(parseVersion('Python 3.12.7')).toEqual([3, 12, 7]);
    expect(parseVersion('nonsense')).toBeNull();
  });

  test('compares numerically, not lexically', () => {
    // "1.9.0" < "1.10.0" is false as a string comparison; every Go minor past 9
    // would otherwise look outdated.
    expect(versionAtLeast('1.10.0', '1.9.0')).toBe(true);
    expect(versionAtLeast('1.9.0', '1.10.0')).toBe(false);
  });

  test('equal and greater versions pass, lower versions fail', () => {
    expect(versionAtLeast('20.0.0', '20.0.0')).toBe(true);
    expect(versionAtLeast('20.1.0', '20.0.0')).toBe(true);
    expect(versionAtLeast('19.9.9', '20.0.0')).toBe(false);
  });

  test('an unparseable version never satisfies a minimum', () => {
    expect(versionAtLeast(null, '1.0.0')).toBe(false);
    expect(versionAtLeast('garbage', '1.0.0')).toBe(false);
  });
});

describe('path resolution', () => {
  test('a PATH entry that exists is returned, a missing one is not', () => {
    const sysDir = process.platform === 'win32'
      ? path.join(process.env.SystemRoot || 'C:\\Windows', 'System32')
      : '/usr/bin';
    const env = { PATH: ['C:\\nope', sysDir].join(path.delimiter) };
    expect(findOnPath('not-a-real-binary-xyz', { env })).toBeNull();
    // cmd.exe / sh live in exactly that directory, so this proves the hit path.
    expect(findOnPath(process.platform === 'win32' ? 'cmd' : 'sh', { env })).toBeTruthy();
  });

  test('an empty PATH is tolerated', () => {
    expect(findOnPath('node', { env: { PATH: '' } })).toBeNull();
  });

  test('an env override pointing at a missing file is not accepted', () => {
    const previous = process.env.PUPPETEER_EXECUTABLE_PATH;
    process.env.PUPPETEER_EXECUTABLE_PATH = 'C:\\definitely\\not\\here.exe';
    try {
      const found = resolveChromiumPath();
      // Falls through to a real browser or to `missing` — never the bad path.
      expect(found.path).not.toBe('C:\\definitely\\not\\here.exe');
      expect(['managed', 'path', 'well-known', 'missing']).toContain(found.source);
    } finally {
      if (previous === undefined) delete process.env.PUPPETEER_EXECUTABLE_PATH;
      else process.env.PUPPETEER_EXECUTABLE_PATH = previous;
    }
  });
});

describe('advisory contract', () => {
  test('an unknown runtime reports `unknown` instead of throwing', async () => {
    const result = await ensureRuntime('cobol', { download: false });
    expect(result.status).toBe('unknown');
    expect(result.detail).toContain('cobol');
  });

  test('an offline check of a missing runtime never downloads', async () => {
    const result = await ensureRuntime('python', { download: false });
    // On a host without python this is `missing`; with python it is `ok`.
    expect(['ok', 'missing', 'broken', 'outdated']).toContain(result.status);
    expect(result.name).toBe('python');
  });

  test('node and go are the load-bearing runtimes, python is not', () => {
    expect(REQUIRED_BY_DEFAULT).toEqual(['node', 'go']);
    expect(SPECS.python).toBeTruthy();
  });

  test('managedEnv is empty for a runtime with no managed install', () => {
    expect(managedEnv('python')).toEqual({});
  });

  test('a stamped browser path is resolved even without the env', async () => {
    // macOS/Windows installs are a directory tree, not a lone binary, so the path
    // is recorded at install time. Without reading that stamp the install would be
    // invisible on the next launch and the user would be re-prompted forever.
    const fs = await import('node:fs');
    const os = await import('node:os');
    const root = fs.mkdtempSync(path.join(os.tmpdir(), 'bootstrap-'));
    const chrome = path.join(root, 'chrome');
    fs.writeFileSync(chrome, '');
    try {
      process.env.BOOTSTRAP_DIR = root;
      // The module reads BOOTSTRAP_DIR at import time, so reload it.
      const mod = await import(`../../helpers/bootstrap-env.js?stamp=${Date.now()}`);
      fs.mkdirSync(path.join(root, 'bin'), { recursive: true });
      fs.writeFileSync(path.join(root, 'bin', '.chrome-path'), chrome);

      const found = mod.resolveChromiumPath({ env: {} });
      expect(found.path).toBe(chrome);
      expect(found.source).toBe('managed');
    } finally {
      delete process.env.BOOTSTRAP_DIR;
      fs.rmSync(root, { recursive: true, force: true });
    }
  });
});
