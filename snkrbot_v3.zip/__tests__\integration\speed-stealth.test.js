// Tests for the "beat other bots without getting detected" upgrades.
// Covers: per-host concurrency cap, JA3 profile rotation, and the
// cross-task sibling-bus that aborts duplicate runs.

import { jest } from '@jest/globals';

// Pin the CPU mode for the whole file. The queue's global cap is
// min(configured, cpuCap, …), so an ambient CPU_PERFORMANCE_MODE=balanced (cap 8,
// and cpuCap can be lower still on a small runner) silently undercut the 25 slots
// these tests assume and made them hang rather than fail. Forcing `max` and a
// generous explicit cap makes the available slot count deterministic.
process.env.CPU_PERFORMANCE_MODE = 'max';
process.env.CHECKOUT_CONCURRENCY_CAP = '64';

// We mock db before importing run-queue so the settings lookups don't actually
// hit Postgres during unit tests.
// Mock db so refreshLimit() returns a high global cap (so tests focus on
// per-host behavior, not the default 3-slot global cap).
jest.unstable_mockModule('../../db/index.js', () => {
  const fakeDb = (table) => ({
    where: (q) => ({
      first: async () => {
        if (table === 'settings' && q?.key === 'max_concurrent_runs') return { value: '25' };
        if (table === 'settings' && q?.key === 'max_concurrent_per_host') return { value: '5' };
        return null;
      }
    })
  });
  return { default: fakeDb };
});

const { acquireSlot, queueStatus } = await import('../../helpers/run-queue.js');
const { pickTlsProfile } = await import('../../helpers/tls-client.js');
const {
  notifyProductSuccess,
  getRecentWin,
  subscribeToSiblings,
  throwIfSiblingWon,
  productKeyFromUrl,
  SiblingWonError,
  __resetForTests
} = await import('../../helpers/sibling-bus.js');

describe('Per-host concurrency cap (run-queue.js)', () => {
  test('allows up to default cap on the same host without queueing', async () => {
    const releases = [];
    for (let i = 0; i < 5; i++) {
      releases.push(await acquireSlot(`host-test-a-${i}`, { host: 'a.example.com' }));
    }
    const status = queueStatus();
    expect(status.perHost['a.example.com']).toBe(5);
    releases.forEach((r) => r());
  });

  test('throttles the 6th task on the same host until a slot frees', async () => {
    const releases = [];
    for (let i = 0; i < 5; i++) {
      releases.push(await acquireSlot(`host-test-b-${i}`, { host: 'b.example.com' }));
    }
    let sixthAcquired = false;
    const sixthPromise = acquireSlot('host-test-b-5', { host: 'b.example.com' }).then((r) => {
      sixthAcquired = true;
      return r;
    });
    await new Promise((r) => setTimeout(r, 50));
    expect(sixthAcquired).toBe(false);                  // still waiting
    expect(queueStatus().perHost['b.example.com']).toBe(5); // cap holds

    releases[0]();                                       // free a slot
    const sixthRelease = await sixthPromise;
    expect(sixthAcquired).toBe(true);

    sixthRelease();
    releases.slice(1).forEach((r) => r());
  });

  test('different hosts do not contend with each other', async () => {
    const aReleases = [];
    for (let i = 0; i < 5; i++) {
      aReleases.push(await acquireSlot(`mix-a-${i}`, { host: 'mix-a.example.com' }));
    }
    // Should not block — different host
    const bRelease = await acquireSlot('mix-b-0', { host: 'mix-b.example.com' });
    expect(queueStatus().perHost['mix-b.example.com']).toBe(1);
    bRelease();
    aReleases.forEach((r) => r());
  });

  test('release without host is safe (legacy callers)', async () => {
    const r = await acquireSlot('legacy-task', {});
    expect(typeof r).toBe('function');
    r();
  });
});

describe('TLS profile rotation (tls-client.js)', () => {
  test('pickTlsProfile returns a known utls profile name', () => {
    const valid = new Set(['chrome131', 'chrome124', 'chrome120']);
    for (let i = 0; i < 50; i++) {
      expect(valid.has(pickTlsProfile())).toBe(true);
    }
  });

  test('over many picks, all 3 profiles appear (JA3 diversity)', () => {
    const seen = new Set();
    for (let i = 0; i < 500; i++) seen.add(pickTlsProfile());
    expect(seen.size).toBeGreaterThanOrEqual(2); // at least 2 distinct, almost always 3
  });

  test('chrome131 is the most common (matches actual Chromium binary)', () => {
    const counts = { chrome131: 0, chrome124: 0, chrome120: 0 };
    for (let i = 0; i < 5000; i++) counts[pickTlsProfile()]++;
    expect(counts.chrome131).toBeGreaterThan(counts.chrome124);
    expect(counts.chrome131).toBeGreaterThan(counts.chrome120);
  });
});

describe('Sibling-bus (helpers/sibling-bus.js)', () => {
  beforeEach(() => __resetForTests());

  test('productKeyFromUrl normalizes host+path, ignores query/fragment/trailing slash', () => {
    expect(productKeyFromUrl('https://shop.example.com/products/jordan-1?variant=42'))
      .toBe('shop.example.com/products/jordan-1');
    expect(productKeyFromUrl('https://shop.example.com/products/jordan-1/'))
      .toBe('shop.example.com/products/jordan-1');
    expect(productKeyFromUrl('https://shop.example.com/products/jordan-1#sizes'))
      .toBe('shop.example.com/products/jordan-1');
  });

  test('notifyProductSuccess records win retrievable via getRecentWin', () => {
    const url = 'https://shop.example.com/products/dunk-low';
    expect(getRecentWin(url)).toBeNull();
    notifyProductSuccess({ productUrl: url, taskId: 42, orderNumber: 'ORD-9' });
    const win = getRecentWin(url);
    expect(win).toMatchObject({ taskId: 42, orderNumber: 'ORD-9' });
  });

  test('throwIfSiblingWon throws SiblingWonError when a recent win exists', () => {
    const url = 'https://shop.example.com/products/yeezy-350';
    expect(() => throwIfSiblingWon(url)).not.toThrow();
    notifyProductSuccess({ productUrl: url, taskId: 7, orderNumber: 'ORD-7' });
    expect(() => throwIfSiblingWon(url)).toThrow(SiblingWonError);
  });

  test('subscribeToSiblings invokes callback when a sibling wins', async () => {
    const url = 'https://shop.example.com/products/sb-low';
    const events = [];
    const unsub = subscribeToSiblings(url, (info) => events.push(info));
    notifyProductSuccess({ productUrl: url, taskId: 100, orderNumber: 'X1' });
    expect(events.length).toBe(1);
    expect(events[0]).toMatchObject({ winnerTaskId: 100, orderNumber: 'X1' });
    unsub();
    notifyProductSuccess({ productUrl: url, taskId: 200, orderNumber: 'X2' });
    expect(events.length).toBe(1); // unsub'd — no new events delivered
  });

  test('subscribers on different products do not cross-fire', () => {
    const a = 'https://shop.example.com/products/a';
    const b = 'https://shop.example.com/products/b';
    const aEvents = [];
    const bEvents = [];
    const ua = subscribeToSiblings(a, (i) => aEvents.push(i));
    const ub = subscribeToSiblings(b, (i) => bEvents.push(i));
    notifyProductSuccess({ productUrl: a, taskId: 1 });
    expect(aEvents.length).toBe(1);
    expect(bEvents.length).toBe(0);
    ua(); ub();
  });

  test('different query strings on the same product are siblings', () => {
    const url1 = 'https://shop.example.com/products/dunk?variant=10';
    const url2 = 'https://shop.example.com/products/dunk?variant=11';
    const events = [];
    const unsub = subscribeToSiblings(url1, (i) => events.push(i));
    notifyProductSuccess({ productUrl: url2, taskId: 3 });
    expect(events.length).toBe(1); // url1 listener got notified by url2 success
    unsub();
  });
});
