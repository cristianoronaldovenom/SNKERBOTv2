// Poll economy policy tests.
//
// The regression this guards: backoff was purely reactive (`getAdaptiveDelay`
// only runs after a block), so an unchanged PDP on a quiet monitor still cost a
// residential exit plus a full body on every tick. What must hold is the shape
// of the tradeoff — HOT stays fast, COLD gets long, jitter is deterministic per
// key, and an exhausted budget never lets idle polling outrun a checkout.
import { describe, expect, test } from '@jest/globals';
import {
  TIER, classify, jitterFor, nextPollDelay, pollEconomyConfig
} from '../../helpers/poll-economy.js';

const cfg = pollEconomyConfig();

describe('tier classification', () => {
  test('in stock or an open drop window is HOT regardless of quiet time', () => {
    expect(classify({ inStock: true, msSinceChange: 99 * 60_000 })).toBe(TIER.HOT);
    expect(classify({ dropWindowOpen: true, blockStreak: 3 })).toBe(TIER.HOT);
  });

  test('a block streak outranks quiet time', () => {
    expect(classify({ blockStreak: 1, msSinceChange: 99 * 60_000 })).toBe(TIER.BLOCKED);
  });

  test('quiet time steps through WARM then COLD', () => {
    expect(classify({ msSinceChange: cfg.warmAfterMs - 1 })).toBe(TIER.HOT);
    expect(classify({ msSinceChange: cfg.warmAfterMs })).toBe(TIER.WARM);
    expect(classify({ msSinceChange: cfg.coldAfterMs })).toBe(TIER.COLD);
  });

  test('an unknown quiet time stays HOT rather than guessing', () => {
    expect(classify({})).toBe(TIER.HOT);
  });
});

describe('delay selection', () => {
  test('HOT polls at the hot interval and COLD at the cold interval', () => {
    const hot = nextPollDelay({ key: 'a', inStock: true });
    const cold = nextPollDelay({ key: 'a', msSinceChange: cfg.coldAfterMs });
    expect(hot.tier).toBe(TIER.HOT);
    expect(cold.tier).toBe(TIER.COLD);
    // Jitter is +/-15%, so a factor of 5 apart is unambiguous.
    expect(cold.delayMs).toBeGreaterThan(hot.delayMs * 4);
  });

  test('a block streak raises the floor above the warm tier', () => {
    const one = nextPollDelay({ key: 'b', blockStreak: 1 });
    const four = nextPollDelay({ key: 'b', blockStreak: 4 });
    expect(one.tier).toBe(TIER.BLOCKED);
    expect(four.delayMs).toBeGreaterThan(one.delayMs * 2);
    // Capped so a long streak cannot silence a monitor for a minute.
    expect(nextPollDelay({ key: 'b', blockStreak: 30 }).delayMs).toBeLessThanOrEqual(60_000 * 1.15);
  });

  test('jitter is deterministic per key and bounded by the configured ratio', () => {
    const a1 = jitterFor('task-1');
    const a2 = jitterFor('task-1');
    const b = jitterFor('task-2');
    expect(a1).toBe(a2);
    expect(a1).not.toBe(b);
    expect(Math.abs(a1)).toBeLessThanOrEqual(cfg.maxJitterRatio);
    // Two keys must not tick in lockstep.
    expect(nextPollDelay({ key: 'task-1', msSinceChange: cfg.coldAfterMs }).delayMs)
      .not.toBe(nextPollDelay({ key: 'task-2', msSinceChange: cfg.coldAfterMs }).delayMs);
  });

  test('minMs and maxMs clamp the result', () => {
    expect(nextPollDelay({ key: 'c', inStock: true, minMs: 4000 }).delayMs).toBe(4000);
    expect(nextPollDelay({ key: 'c', msSinceChange: cfg.coldAfterMs, maxMs: 2000 }).delayMs).toBe(2000);
  });
});

describe('budget squeeze', () => {
  test('a healthy budget does not stretch the hot tier', () => {
    const plain = nextPollDelay({ key: 'd', inStock: true });
    const rich = nextPollDelay({ key: 'd', inStock: true, budgetRemainingRatio: 0.9 });
    expect(rich.delayMs).toBe(plain.delayMs);
  });

  test('running low on residential bytes stretches every tier', () => {
    const rich = nextPollDelay({ key: 'e', inStock: true, budgetRemainingRatio: 0.8 });
    const poor = nextPollDelay({ key: 'e', inStock: true, budgetRemainingRatio: 0.02 });
    expect(poor.delayMs).toBeGreaterThan(rich.delayMs * 2);
    expect(poor.reason).toContain('budget_squeeze');
  });

  test('an exhausted budget pins to the cold interval so checkouts win', () => {
    const out = nextPollDelay({ key: 'f', inStock: true, budgetRemainingRatio: 0 });
    expect(out.delayMs).toBeGreaterThanOrEqual(cfg.coldMs);
    expect(out.reason).toContain('budget_exhausted');
  });

  test('a non-numeric ratio is ignored instead of squeezing to zero', () => {
    expect(nextPollDelay({ key: 'g', inStock: true, budgetRemainingRatio: null }).delayMs)
      .toBe(nextPollDelay({ key: 'g', inStock: true }).delayMs);
  });
});

describe('config surface', () => {
  test('intervals are ordered hot < warm < cold', () => {
    expect(cfg.hotMs).toBeLessThanOrEqual(cfg.warmMs);
    expect(cfg.warmMs).toBeLessThanOrEqual(cfg.coldMs);
  });

  test('the cold threshold is never shorter than a minute of quiet', () => {
    expect(cfg.coldAfterMs).toBeGreaterThanOrEqual(60_000);
  });
});
