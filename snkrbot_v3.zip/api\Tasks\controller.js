import db from '../../db/index.js';
import { removePageFromTaskCache } from '../../helpers/task-cache.js';
import { endMonitorForTask } from './monitor.js';

export const findAll = async (req, res, next) => {
  try {
    const tasks = await db('tasks')
      .leftJoin('proxies as legacy_proxy', 'tasks.proxy_id', 'legacy_proxy.id')
      .leftJoin('proxies as monitor_proxy', 'tasks.monitor_proxy_id', 'monitor_proxy.id')
      .leftJoin('proxies as checkout_proxy', 'tasks.checkout_proxy_id', 'checkout_proxy.id')
      .where({ 'tasks.is_deleted': false })
      .select(
        'tasks.*',
        'legacy_proxy.host as proxy_host',
        'legacy_proxy.port as proxy_port',
        'monitor_proxy.host as monitor_proxy_host',
        'monitor_proxy.port as monitor_proxy_port',
        'monitor_proxy.proxy_type as monitor_proxy_type',
        'monitor_proxy.label as monitor_proxy_label',
        'checkout_proxy.host as checkout_proxy_host',
        'checkout_proxy.port as checkout_proxy_port',
        'checkout_proxy.proxy_type as checkout_proxy_type',
        'checkout_proxy.label as checkout_proxy_label'
      );
    return res.json({ success: true, message: tasks.length ? 'Tasks successfully found' : 'Tasks not found', data: tasks });
  } catch (err) {
    next(err);
  }
};

export const findOne = async (req, res, next) => {
  try {
    const task = await db('tasks')
      .where({ 'tasks.id': req.params.id, 'tasks.is_deleted': false })
      .select('tasks.*')
      .first();
    if (!task) {
      return res.json({ success: true, message: 'Task not found', data: undefined });
    }
    return res.json({ success: true, message: 'Task successfully found', data: task });
  } catch (err) {
    next(err);
  }
};

export const create = async (req, res, next) => {
  try {
    const [task] = await db('tasks').insert(req.body).returning('*');
    return res.json({ success: true, message: 'Task successfully created', data: task });
  } catch (err) {
    next(err);
  }
};

export const update = async (req, res, next) => {
  try {
    const [task] = await db('tasks')
      .where({ id: req.params.id })
      .update({ ...req.body, updated_at: new Date() })
      .returning('*');
    return res.json({ success: true, message: 'Task successfully updated', data: task });
  } catch (err) {
    next(err);
  }
};

export const remove = async (req, res, next) => {
  try {
    await endMonitorForTask(req.params.id).catch(() => {});
    await removePageFromTaskCache({ taskId: req.params.id });
    await db('tasks').where({ id: req.params.id }).update({ is_deleted: true });
    return res.json({ success: true, message: 'Task successfully deleted', data: {} });
  } catch (err) {
    next(err);
  }
};

export const startTask = async (req, res, next) => {
  try {
    const task = await db('tasks').where({ id: req.params.id, is_deleted: false }).first();
    if (!task) {
      return res.status(404).json({ success: false, message: 'Task not found', data: {} });
    }
    const { default: startTask } = await import('../../scripts/start-task.js');
    const logger = (await import('../../helpers/logger.js')).default;
    startTask(task).catch((err) => {
      logger.error(`[Tasks] Background task ${task.id} failed: ${err.message}`);
    });
    return res.json({ success: true, message: 'Task started', data: task });
  } catch (err) {
    next(err);
  }
};

export const stopTask = async (req, res, next) => {
  try {
    await endMonitorForTask(req.params.id).catch(() => {});
    await removePageFromTaskCache({ taskId: req.params.id });
    return res.json({ success: true, message: 'Task stopped', data: {} });
  } catch (err) {
    next(err);
  }
};

// Operator-only: clear a payment lock so an armed task can run again. Kept as a
// separate endpoint from PATCH so the dashboard can't accidentally clear the
// lock while editing an unrelated field, and so the "5 strikes → you must act"
// contract stays explicit.
export const enablePayment = async (req, res, next) => {
  try {
    const task = await db('tasks').where({ id: req.params.id, is_deleted: false }).first();
    if (!task) {
      return res.status(404).json({ success: false, message: 'Task not found', data: {} });
    }
    const { clearPaymentLock } = await import('../../helpers/payment-lockout.js');
    await clearPaymentLock(db, req.params.id);
    // Clearing the lock also clears the stale status so the dashboard badge and
    // the monitor reconcilers don't keep treating the task as parked.
    await db('tasks').where({ id: req.params.id }).update({ last_status: '' });
    const updated = await db('tasks').where({ id: req.params.id }).first();
    return res.json({ success: true, message: 'Payment lock cleared — task can run again', data: updated });
  } catch (err) {
    next(err);
  }
};
