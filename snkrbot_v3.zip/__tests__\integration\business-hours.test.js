import { getEtHour, isWithinBusinessHours, BUSINESS_START_HOUR, BUSINESS_END_HOUR, PC_SITE_ID } from '../../helpers/business-hours.js';

describe('business-hours (Pokemon Center window)', () => {
  test('constants', () => {
    expect(BUSINESS_START_HOUR).toBe(8);
    expect(BUSINESS_END_HOUR).toBe(18);
    expect(PC_SITE_ID).toBe(6);
  });

  describe('EST (winter, UTC-5)', () => {
    // 2026-01-15 is standard time in New York.
    test('13:00 UTC == 8am ET → open (start boundary, inclusive)', () => {
      const d = new Date('2026-01-15T13:00:00Z');
      expect(getEtHour(d)).toBe(8);
      expect(isWithinBusinessHours(d)).toBe(true);
    });
    test('22:59 UTC == 5:59pm ET → open', () => {
      const d = new Date('2026-01-15T22:59:00Z');
      expect(getEtHour(d)).toBe(17);
      expect(isWithinBusinessHours(d)).toBe(true);
    });
    test('23:00 UTC == 6pm ET → closed (end boundary, exclusive)', () => {
      const d = new Date('2026-01-15T23:00:00Z');
      expect(getEtHour(d)).toBe(18);
      expect(isWithinBusinessHours(d)).toBe(false);
    });
    test('12:00 UTC == 7am ET → closed (before open)', () => {
      const d = new Date('2026-01-15T12:00:00Z');
      expect(getEtHour(d)).toBe(7);
      expect(isWithinBusinessHours(d)).toBe(false);
    });
  });

  describe('EDT (summer, UTC-4)', () => {
    // 2026-07-15 is daylight saving time in New York.
    test('12:00 UTC == 8am ET → open (start boundary, inclusive)', () => {
      const d = new Date('2026-07-15T12:00:00Z');
      expect(getEtHour(d)).toBe(8);
      expect(isWithinBusinessHours(d)).toBe(true);
    });
    test('21:59 UTC == 5:59pm ET → open', () => {
      const d = new Date('2026-07-15T21:59:00Z');
      expect(getEtHour(d)).toBe(17);
      expect(isWithinBusinessHours(d)).toBe(true);
    });
    test('22:00 UTC == 6pm ET → closed (end boundary, exclusive)', () => {
      const d = new Date('2026-07-15T22:00:00Z');
      expect(getEtHour(d)).toBe(18);
      expect(isWithinBusinessHours(d)).toBe(false);
    });
    test('11:00 UTC == 7am ET → closed (before open)', () => {
      const d = new Date('2026-07-15T11:00:00Z');
      expect(getEtHour(d)).toBe(7);
      expect(isWithinBusinessHours(d)).toBe(false);
    });
  });
});
