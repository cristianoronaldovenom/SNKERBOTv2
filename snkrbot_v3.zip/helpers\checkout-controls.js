import logger from './logger.js';

const visible = (el) => {
  if (!el) return false;
  const r = el.getBoundingClientRect();
  const s = window.getComputedStyle(el);
  return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none';
};

export const assertActionButtonIntent = async (page, selectorList, {
  stage = 'action',
  allow = /./i,
  deny = /cancel|close|remove|delete|edit|back/i,
} = {}) => {
  const selectors = Array.isArray(selectorList) ? selectorList : [selectorList];
  const found = await page.evaluate(({ selectors, allow: allowSrc, deny: denySrc }) => {
    const allowRe = new RegExp(allowSrc, 'i');
    const denyRe = new RegExp(denySrc, 'i');
    for (const selector of selectors) {
      const nodes = Array.from(document.querySelectorAll(selector));
      for (const el of nodes) {
        if (!visible(el)) continue;
        if ('disabled' in el && el.disabled) continue;
        const text = String(el.innerText || el.value || el.getAttribute('aria-label') || el.getAttribute('data-test') || '').replace(/\s+/g, ' ').trim();
        if (!allowRe.test(text) || denyRe.test(text)) continue;
        return { selector, text };
      }
    }
    return null;
  }, {
    selectors,
    allow: allow.source,
    deny: deny.source,
  }).catch(() => null);

  if (!found) {
    const err = new Error(`No safe ${stage} control found — checkout stopped before an ambiguous click`);
    err.failureType = 'checkout_control_not_found';
    throw err;
  }
  logger.debug(`[CheckoutControl] ${stage}: ${found.text}`);
  return found;
};

export const verifyCheckoutFields = async (page, checks = []) => {
  const results = [];
  for (const check of checks) {
    const selectors = Array.isArray(check.selectors) ? check.selectors : [check.selectors];
    const result = await page.evaluate(({ selectors, expected, kind }) => {
      for (const selector of selectors) {
        const el = document.querySelector(selector);
        if (!el) continue;
        if (kind === 'presence') return { ok: true, actual: '' };
        const actual = String(el.value ?? el.textContent ?? '').replace(/\s+/g, ' ').trim();
        if (!expected) return { ok: actual.length > 0, actual };
        const norm = (v) => String(v).replace(/\s+/g, ' ').trim().toLowerCase();
        if (norm(actual) === norm(expected) || norm(actual).includes(norm(expected)) || norm(expected).includes(norm(actual))) {
          return { ok: true, actual };
        }
      }
      return { ok: false, actual: null };
    }, { selectors, expected: check.expected ?? '', kind: check.kind || 'value' }).catch(() => ({ ok: false, actual: null }));
    results.push({ name: check.name, ...result });
  }
  return results;
};
