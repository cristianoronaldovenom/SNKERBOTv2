import { Router } from 'express';
import * as controller from './controller.js';

const router = Router();

router.post('/test/:channel', controller.testNotification);
router.get('/', controller.findAll);
router.get('/:key', controller.findOne);
router.put('/:key', controller.upsert);

export default router;
