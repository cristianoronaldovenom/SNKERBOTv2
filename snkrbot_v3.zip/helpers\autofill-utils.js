import logger from './logger.js';

const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const randInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

export const formatPostal = (raw, country) => {
  if (!raw) return raw;
  const c = String(country || 'CA').toUpperCase();
  const cleaned = String(raw).replace(/\s+/g, '').toUpperCase();
  if (c === 'CA' && /^[A-Z]\d[A-Z]\d[A-Z]\d$/.test(cleaned)) {
    return cleaned.slice(0, 3) + ' ' + cleaned.slice(3);
  }
  if (c === 'US' && /^\d{9}$/.test(cleaned)) {
    return cleaned.slice(0, 5) + '-' + cleaned.slice(5);
  }
  return raw;
};

export const stripPhone = (raw) => {
  if (!raw) return raw;
  return String(raw).replace(/[^\d+]/g, '');
};

export const dismissAutocomplete = async (page) => {
  try {
    await page.keyboard.press('Escape');
    await sleep(randInt(60, 140));
  } catch (_) {}
};

const PHONE_LIKE = /^[\d\s().+\-]+$/;
const POSTAL_LIKE_RE = /postal|postcode|^zip$/i;

const normalizeForCompare = (raw, hint = '') => {
  const s = String(raw || '');
  if (hint === 'phone' || (PHONE_LIKE.test(s) && /\d{6,}/.test(s.replace(/\D/g, '')))) {
    return s.replace(/\D/g, '');
  }
  if (hint === 'postal' || POSTAL_LIKE_RE.test(hint)) {
    return s.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
  }
  return s.replace(/\s+/g, ' ').trim();
};

export const verifyFieldValue = async (page, selector, expected, fieldHint = '') => {
  try {
    const actual = await page.$eval(selector, (el) => el.value || '');
    const exp = String(expected || '').trim();
    const got = String(actual || '').trim();
    if (!exp) return { ok: true, actual: got };
    if (got === exp) return { ok: true, actual: got };
    if (normalizeForCompare(got, fieldHint) === normalizeForCompare(exp, fieldHint)) {
      return { ok: true, actual: got };
    }
    return { ok: false, actual: got, expected: exp };
  } catch (_) {
    return { ok: false, actual: null, expected: String(expected || '') };
  }
};

const CARD_INPUT_SELECTORS = [
  'input[name="cardNumber"]',
  'input[id*="cardNumber" i]',
  'input[data-cse="encryptedCardNumber"]',
  'input[name="dwfrm_billing_creditCardFields_cardNumber"]',
  'input[autocomplete="cc-number"]',
  'input[name="encryptedCardNumber"]'
].join(', ');

const findCardInputFrame = async (page) => {
  for (const frame of page.frames()) {
    try {
      const handle = await frame.$(CARD_INPUT_SELECTORS);
      if (handle) {
        const visible = await frame.evaluate((el) => {
          if (!el) return false;
          const r = el.getBoundingClientRect();
          const cs = getComputedStyle(el);
          return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none';
        }, handle).catch(() => true);
        await handle.dispose().catch(() => {});
        if (visible) return frame;
      }
    } catch (_) {}
  }
  return null;
};

export const waitForCardIframeReady = async (page, { timeout = 15000, throwOnTimeout = false } = {}) => {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    const frame = await findCardInputFrame(page);
    if (frame) {
      const isMain = frame === page.mainFrame();
      logger.info(`[Autofill] Card input ready in ${isMain ? 'main page' : `iframe ${frame.url().slice(0, 80)}`}`);
      await sleep(randInt(250, 500));
      return frame;
    }
    await sleep(250);
  }
  if (throwOnTimeout) {
    throw new Error(`Card input iframe did not load within ${timeout}ms — payment fields not ready`);
  }
  logger.warn(`[Autofill] No card input field detected after ${timeout}ms — proceeding anyway`);
  return null;
};

export const requireCardIframe = (page, opts = {}) =>
  waitForCardIframeReady(page, { ...opts, throwOnTimeout: true });

export const verifyCartHasItem = async (page, { timeout = 8000 } = {}) => {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    const result = await page.evaluate(() => {
      const text = (document.body?.innerText || '').slice(0, 8000);
      const empty = /your (?:cart|bag|basket) is empty|no items in (?:your )?(?:cart|bag|basket)|cart is currently empty/i.test(text);
      if (empty) return { empty: true, count: 0 };

      const countEl = document.querySelector(
        '[data-cart-count], [data-cart-item-count], .cart-count, .cart-counter, ' +
        '.bag-count, .CartCount, [class*="cart-count" i], [class*="bag-count" i], ' +
        '[data-test*="cart" i][data-test*="count" i], [aria-label*="cart" i][aria-label*="item" i]'
      );
      let count = 0;
      if (countEl) {
        const m = (countEl.textContent || countEl.getAttribute('aria-label') || '').match(/\d+/);
        if (m) count = parseInt(m[0], 10);
      }

      if (count === 0) {
        const itemSel = '.cart-item, .CartItem, .line-item, [data-cart-item], ' +
                        '[data-test*="cart-item"], tr.cart_item, .order-summary__section .product, ' +
                        '.cart__row, .basket-item, .bag-item';
        const items = document.querySelectorAll(itemSel);
        count = items.length;
      }

      return { empty: count === 0, count };
    }).catch(() => ({ empty: false, count: -1 }));

    if (!result.empty || result.count > 0) return result;
    await sleep(400);
  }
  return { empty: true, count: 0 };
};

export class FillReport {
  constructor(taskId, stage) {
    this.taskId = taskId;
    this.stage = stage;
    this.fields = [];
  }
  record(name, ok, detail = '') {
    this.fields.push({ name, ok, detail });
  }
  summary() {
    const okCount = this.fields.filter(f => f.ok).length;
    const failed = this.fields.filter(f => !f.ok);
    return { okCount, total: this.fields.length, failed };
  }
  log() {
    const s = this.summary();
    if (s.failed.length === 0) {
      logger.info(`[FillReport] task ${this.taskId} ${this.stage}: ${s.okCount}/${s.total} fields OK ✓`);
    } else {
      const failedNames = s.failed.map(f => `${f.name}${f.detail ? `(${f.detail})` : ''}`).join(', ');
      logger.warn(`[FillReport] task ${this.taskId} ${this.stage}: ${s.okCount}/${s.total} fields OK — FAILED: ${failedNames}`);
    }
  }
}

// Abort the checkout if any CRITICAL field failed to fill. Without this, an
// adapter would happily click "Place Order" on a form missing the card number or
// address — burning the session/proxy and risking a broken/partial order on a
// real drop. Throws a classified error so the retry loop handles it cleanly
// instead of treating it as a generic crash.
export const assertCriticalFields = (report, criticalNames = []) => {
  const failed = (report.summary().failed || []).map(f => f.name);
  const missing = criticalNames.filter(n => failed.includes(n));
  if (missing.length > 0) {
    const err = new Error(`Critical checkout field(s) failed to fill: ${missing.join(', ')} — aborting before Place Order`);
    err.failureType = 'checkout_fill_failed';
    throw err;
  }
};

// Pure decision for the address-verification modal that Walmart/Pokémon Center
// (and most retailers) pop after you submit a shipping address. We only ever want
// to keep the address the USER entered — never silently accept the site's
// "suggested" rewrite (wrong unit/postal = failed delivery) and never click
// edit/cancel/change (which would stall the bot). Returns the index of the safe
// button to click, or -1 if there's no modal / no safe button.
const MODAL_PRESENT_RE = /(verify your address|address verification|verify address|suggested address|we could ?n.?t verify|did you mean|confirm your address|use the address you entered|edit your address)/i;
// Only EXPLICIT "keep the address I typed" labels are safe. Ambiguous buttons
// like "Use this address", "Confirm", or "Continue" can select the retailer's
// SUGGESTED rewrite (wrong unit/postal → failed delivery), so they are NOT here.
// If none of these match we return -1 (no click) and let the flow fail loud
// downstream rather than silently shipping to a rewritten address.
const KEEP_PRIORITIES = [
  /use (the )?original( address)?/i,
  /use (the )?address (i|you) entered/i,
  /keep (my|the) (current )?address/i,
  /\bas (i |you )?entered\b/i,
];
const KEEP_NEVER_RE = /\b(edit|cancel|change|go back|close)\b/i;

// Card network from BIN. Returns null on an unrecognized prefix so callers can
// SKIP a card-type <select> rather than mislabeling the card (a wrong type trips
// a card-type-mismatch decline). Covers Mastercard's 2-series (2221–2720) range.
export const detectCardType = (number) => {
  const n = String(number || '').replace(/\D/g, '');
  if (/^4/.test(n)) return 'Visa';
  if (/^(5[1-5]|2(2[2-9]|[3-6]\d|7[01]|720))/.test(n)) return 'MasterCard';
  if (/^3[47]/.test(n)) return 'Amex';
  if (/^6(?:011|5)/.test(n)) return 'Discover';
  return null;
};

export const chooseAddressKeepButton = (bodyText = '', buttonTexts = []) => {
  if (!MODAL_PRESENT_RE.test(String(bodyText || ''))) return -1;
  const texts = buttonTexts.map(t => String(t || '').trim());
  for (const pri of KEEP_PRIORITIES) {
    const idx = texts.findIndex(t => t && pri.test(t) && !KEEP_NEVER_RE.test(t));
    if (idx !== -1) return idx;
  }
  return -1;
};

// Detect-and-dismiss an address-verification modal, keeping the entered address.
// No-op (returns null) when no modal is present. Never throws.
export const dismissAddressSuggestion = async (page, { settleMs = 800 } = {}) => {
  try {
    const scraped = await page.evaluate(() => {
      const visible = (el) => {
        const r = el.getBoundingClientRect();
        const s = window.getComputedStyle(el);
        return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none';
      };
      const btns = Array.from(document.querySelectorAll('button, a[role="button"], [role="button"], input[type="button"], input[type="submit"]'))
        .filter(visible);
      return {
        bodyText: document.body ? document.body.innerText.slice(0, 5000) : '',
        buttons: btns.map(b => (b.innerText || b.value || b.getAttribute('aria-label') || '').trim()),
      };
    }).catch(() => null);
    if (!scraped) return null;

    const idx = chooseAddressKeepButton(scraped.bodyText, scraped.buttons);
    if (idx === -1) return null;
    const expectedText = scraped.buttons[idx];

    // Re-verify the button text at that index STILL matches before clicking — the
    // DOM can reorder between the two evaluates, and clicking a stale index could
    // hit the "edit"/suggested-address button we deliberately avoided. If it no
    // longer matches, click nothing (safe no-op).
    const clickedText = await page.evaluate(({ i, expected }) => {
      const visible = (el) => {
        const r = el.getBoundingClientRect();
        const s = window.getComputedStyle(el);
        return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none';
      };
      const btns = Array.from(document.querySelectorAll('button, a[role="button"], [role="button"], input[type="button"], input[type="submit"]'))
        .filter(visible);
      const target = btns[i];
      if (!target) return null;
      const txt = (target.innerText || target.value || target.getAttribute('aria-label') || '').trim();
      if (txt !== expected) return null;
      target.click();
      return txt;
    }, { i: idx, expected: expectedText }).catch(() => null);

    if (clickedText) {
      logger.info(`[AddressModal] Dismissed address-verification modal by clicking "${clickedText}" (kept entered address)`);
      await new Promise(r => setTimeout(r, settleMs));
    }
    return clickedText;
  } catch (_) {
    return null;
  }
};
