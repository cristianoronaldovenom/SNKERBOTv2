import { gotScraping } from 'got-scraping';
import logger from './logger.js';
import { detectAndSolveDataDome } from './datadome.js';
import { detectAndSolveAkamai } from './akamai.js';
import { isKasadaChallenge, solveKasada, kasadaHeaders } from './kasada.js';
import { isShapeChallenge, solveShape } from './shape.js';
import { targetingFor, applyTargeting } from './residential-provider.js';

// Verify upstream TLS certificates?
//
// Was hardcoded false at three call sites. The trade: residential gateways and
// CDNs occasionally present chains Node will not build, and a verification failure
// mid-drop costs a checkout, whereas accepting any cert costs only a theoretical
// MITM. So the default stays permissive but is now explicit and switchable, and the
// health snapshot reports which mode is live.
const tlsStrict = () => ['1', 'true'].includes(String(process.env.TLS_VERIFY_STRICT || '').toLowerCase());
const tlsVerifyOption = () => ({ rejectUnauthorized: tlsStrict() });
export const tlsVerifyMode = () => (tlsStrict() ? 'strict' : 'permissive');
import { warmSession, startAutoRefresh, stopAutoRefresh, isImpervaChallenged } from './session-warmer.js';
import { loadCookieJar, saveCookieJar } from './cookie-store.js';
import { tlsRequest } from './tls-client.js';
import { SITE_CHECKERS, autoDetectChecker, validateStockResult } from './site-stock-apis.js';
import * as breaker from './circuit-breaker.js';
import * as metrics from './monitor-metrics.js';
import { recordResidentialBytes, remainingResidentialBytes } from './residential-budget.js';
import { directGotAgents } from './network-performance.js';
import { isParked } from './prewarm-engine.js';
import { secChUa } from './client-hints.js';
import { withAffinity, rotateAffinity } from './residential-affinity.js';
import { nextPollDelay } from './poll-economy.js';

const USER_AGENTS = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_5_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Safari/605.1.15',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0',
  'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'
];

let uaIndex = 0;
const nextUA = () => USER_AGENTS[uaIndex++ % USER_AGENTS.length];

// Keep a stable client identity for Pokemon Center monitoring. Rotating the
// User-Agent on every poll can create an unnecessarily inconsistent session
// even when the connection itself is healthy. This is a reliability measure,
// not a stealth/bypass mechanism.
const stableUAByHost = new Map();
const getStableUA = (host) => {
  if (!stableUAByHost.has(host)) stableUAByHost.set(host, USER_AGENTS[0]);
  return stableUAByHost.get(host);
};

const sessionCookies = new Map();
const sessionCookieMeta = new Map();
const blockStreaks = new Map();
const lastBlockAt = new Map();      // host → timestamp of most recent block event

// Cross-task request coalescing + validator cache. These are intentionally tiny:
// the goal is to remove duplicate monitor traffic when several tasks watch the
// same URL, not to serve stale stock data. Unique requests still hit the origin.
const REQUEST_COALESCE_MS = 300;
const API_RESPONSE_COALESCE_MS = Math.max(250, Number.parseInt(process.env.MONITOR_API_COALESCE_MS || '700', 10));
const HTML_RESPONSE_COALESCE_MS = Math.max(250, Number.parseInt(process.env.MONITOR_HTML_COALESCE_MS || '500', 10));
const MAX_MONITOR_CACHE_ENTRIES = 500;
const MAX_TRANSPORT_CACHE_ENTRIES = 128;
const MAX_CACHED_HTML_BYTES = 2 * 1024 * 1024;
// Fixed per-request cost: request line, headers, TLS record overhead. Added to
// every billed poll so accounting is not purely body-sized.
const REQUEST_OVERHEAD_BYTES = 4096;
// A 304 is headers only. Roughly the real cost of an H2 conditional response.
const NOT_MODIFIED_COST_BYTES = 1024;
const inFlightChecks = new Map();
const recentCheckResults = new Map();
const httpValidators = new Map();
const apiTransportInFlight = new Map();
const apiTransportRecent = new Map();
const htmlTransportInFlight = new Map();
const htmlTransportRecent = new Map();

const proxyCacheKey = (proxy) => proxy
  ? `${proxy.id ?? 'ephemeral'}:${proxy.host}:${proxy.port}:${proxy.username || ''}`
  : 'direct';

const monitorCacheKey = ({ productUrl, proxy, siteId, size, style }) =>
  [String(productUrl), String(proxy?.proxy_type || 'direct'), proxyCacheKey(proxy), siteId || '', size || '', style || ''].join('|');

const trimMap = (map) => {
  if (map.size <= MAX_MONITOR_CACHE_ENTRIES) return;
  const cutoff = Date.now() - REQUEST_COALESCE_MS;
  for (const [key, entry] of map) {
    if ((entry?.expiresAt || 0) <= cutoff) map.delete(key);
  }
  while (map.size > MAX_MONITOR_CACHE_ENTRIES) {
    const first = map.keys().next().value;
    if (first === undefined) break;
    map.delete(first);
  }
};

const getCachedValidatorHeaders = (key) => {
  const entry = httpValidators.get(key);
  if (!entry) return {};
  const headers = {};
  if (entry.etag) headers['If-None-Match'] = entry.etag;
  if (entry.lastModified) headers['If-Modified-Since'] = entry.lastModified;
  return headers;
};

const updateValidator = (key, headers, parsedResult, source) => {
  const etag = headers?.etag || headers?.ETag || null;
  const lastModified = headers?.['last-modified'] || headers?.['Last-Modified'] || null;
  if (!etag && !lastModified && !parsedResult) return;
  httpValidators.set(key, {
    etag,
    lastModified,
    result: parsedResult || httpValidators.get(key)?.result || null,
    source,
    updatedAt: Date.now(),
  });
  trimMap(httpValidators);
};

const getCached304Result = (key) => httpValidators.get(key)?.result || null;
const PAUSE_WARM_AFTER_CLEAN_MS = 10 * 60 * 1000; // stop proactive warm after 10 min of clean polls
const COOKIE_TTL_MS = 9 * 60 * 1000;

// â”€â”€â”€ Proxy escalation (datacenter-first) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
// HTTP stock polling uses the datacenter IP by default (zero proxy bandwidth).
// When a poll comes back blocked, we immediately retry with the task's residential
// proxy and flip into "escalated" mode for that task.  After CLEAN_THRESHOLD
// consecutive non-blocked responses on the proxy we drop back to datacenter.
//
// Browser-based operations (session warming, prewarm, checkout) ALWAYS use the
// task proxy — escalation only controls the plain HTTP path.
//
// taskId → { useProxy: boolean, cleanStreak: number }
const proxyEscalation = new Map(); // escalationKey -> { useProxy, cleanStreak, updatedAt }
const taskEscalationKeys = new Map();
const escalationKeyFor = (host, proxy) => `${host}|${proxyCacheKey(proxy)}`;
// Residential-efficiency controls: once a proxy has produced clean results,
// return to direct polling sooner so we do not spend residential bytes while
// the direct path is healthy again.
const ESCALATION_CLEAN_THRESHOLD = Math.max(1, Number.parseInt(process.env.RESIDENTIAL_MONITOR_CLEAN_POLLS || '1', 10));
const RESIDENTIAL_RESULT_CACHE_MS = Math.max(300, Number.parseInt(process.env.RESIDENTIAL_MONITOR_RESULT_CACHE_MS || '1500', 10));

export const clearEscalation = (taskId) => { if (taskId != null) taskEscalationKeys.delete(taskId); };

const getEscalation = (host, proxy, taskId = null) => {
  const key = escalationKeyFor(host, proxy);
  if (taskId != null) taskEscalationKeys.set(taskId, key);
  return proxyEscalation.get(key) || { useProxy: false, cleanStreak: 0 };
};

const updateEscalation = (host, proxy, blocked, hadProxy, taskId = null) => {
  if (taskId != null) taskEscalationKeys.set(taskId, escalationKeyFor(host, proxy));
  if (!hadProxy) return;
  const key = escalationKeyFor(host, proxy);
  const cur = proxyEscalation.get(key) || { useProxy: false, cleanStreak: 0 };
  if (blocked) {
    proxyEscalation.set(key, { useProxy: true, cleanStreak: 0, updatedAt: Date.now() });
  } else if (cur.useProxy) {
    const streak = cur.cleanStreak + 1;
    if (streak >= ESCALATION_CLEAN_THRESHOLD) {
      logger.info(`[StockMonitor] ${host} ${ESCALATION_CLEAN_THRESHOLD} clean proxy poll(s) — dropping back to datacenter IP for this proxy`);
      proxyEscalation.delete(key);
    } else {
      proxyEscalation.set(key, { useProxy: true, cleanStreak: streak, updatedAt: Date.now() });
    }
  }
};

export const cookieJarReady = (async () => {
  const persisted = await loadCookieJar();
  for (const [host, entry] of Object.entries(persisted)) {
    if (entry?.cookies) sessionCookies.set(host, entry.cookies);
    if (entry?.warmedAt) sessionCookieMeta.set(host, { warmedAt: entry.warmedAt });
  }
})();

let jarPersistTimer = null;
const persistJar = () => {
  // Cookie updates can happen several times during a single response burst.
  // Build one snapshot after a short quiet period instead of repeatedly walking
  // the entire cookie map for every Set-Cookie header. cookie-store.js already
  // debounces disk writes, so this second debounce targets CPU/allocation cost.
  if (jarPersistTimer) return;
  jarPersistTimer = setTimeout(() => {
    jarPersistTimer = null;
    const snap = {};
    const now = Date.now();
    for (const [h, v] of sessionCookies.entries()) {
      const meta = sessionCookieMeta.get(h);
      snap[h] = { cookies: v, warmedAt: meta?.warmedAt || now };
    }
    saveCookieJar(snap);
  }, 100);
};

export const getBlockStreak = (host) => blockStreaks.get(host) || 0;
export const getAdaptiveDelay = (host) => {
  const streak = blockStreaks.get(host) || 0;
  if (streak === 0) return 0;
  const base = Math.min(2000 * Math.pow(2, streak - 1), 60000);
  return base + Math.floor(Math.random() * 800);
};
const recordBlock = (host) => {
  blockStreaks.set(host, (blockStreaks.get(host) || 0) + 1);
  lastBlockAt.set(host, Date.now());
};
const recordSuccess = (host) => {
  blockStreaks.delete(host);
  // If polls have been clean for PAUSE_WARM_AFTER_CLEAN_MS, the TLS sidecar is
  // bypassing Imperva on its own — stop the proactive browser warm to save
  // residential proxy bandwidth. startAutoRefresh restarts automatically on the
  // next Imperva challenge (its guard allows restart once the timer is cleared).
  const last = lastBlockAt.get(host);
  if (last && Date.now() - last > PAUSE_WARM_AFTER_CLEAN_MS) {
    stopAutoRefresh(`https://${host}`);
    lastBlockAt.delete(host);
    logger.info(`[StockMonitor] ${host} clean for ${PAUSE_WARM_AFTER_CLEAN_MS / 60000} min — pausing proactive warm to conserve proxy`);
  }
};

export const getSessionCookies = (host) => sessionCookies.get(host) || null;

export const getSessionCookiesForPuppeteer = (host) => {
  const raw = sessionCookies.get(host);
  if (!raw) return [];
  return raw.split(';').map(p => p.trim()).filter(Boolean).map(pair => {
    const eq = pair.indexOf('=');
    if (eq < 0) return null;
    return {
      name: pair.slice(0, eq).trim(),
      value: pair.slice(eq + 1).trim(),
      domain: '.' + host.replace(/^www\./, ''),
      path: '/'
    };
  }).filter(Boolean);
};

export const isSessionFresh = (host) => {
  const meta = sessionCookieMeta.get(host);
  if (!meta) return false;
  return (Date.now() - meta.warmedAt) < COOKIE_TTL_MS;
};

export const markSessionWarmed = (host) => {
  sessionCookieMeta.set(host, { warmedAt: Date.now() });
  persistJar();
};

export const clearSessionCookies = (host) => {
  sessionCookies.delete(host);
  sessionCookieMeta.delete(host);
};

const extractChromeVersion = (ua) => {
  const m = ua.match(/Chrome\/(\d+)/);
  return m ? m[1] : '131';
};

const extractPlatform = (ua) => {
  if (/Macintosh/.test(ua)) return '"macOS"';
  if (/Linux/.test(ua)) return '"Linux"';
  return '"Windows"';
};

const REFERER_POOL = [
  null,
  'https://www.google.com/',
  'https://www.google.ca/',
  'https://www.bing.com/',
  'https://duckduckgo.com/'
];

const pickReferer = (productUrl) => {
  try {
    const host = new URL(productUrl).hostname;
    const sameSiteRef = `https://${host}/`;
    const idx = Math.floor(Math.random() * (REFERER_POOL.length + 3));
    return idx < REFERER_POOL.length ? REFERER_POOL[idx] : sameSiteRef;
  } catch (_) { return null; }
};

const buildHeaders = (ua, productUrl, { isApi = false } = {}) => {
  const chromeVer = extractChromeVersion(ua);
  const platform = extractPlatform(ua);
  const referer = pickReferer(productUrl);
  let sameSite = false;
  try { sameSite = referer && new URL(referer).hostname === new URL(productUrl).hostname; } catch (_) {}

  const h = {
    'User-Agent': ua,
    'Accept': isApi
      ? 'application/json, text/plain, */*'
      : 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'Accept-Language': 'en-CA,en-US;q=0.9,en;q=0.8,fr-CA;q=0.7',
    'Accept-Encoding': 'gzip, deflate, br, zstd',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache',
    'Sec-Ch-Ua': secChUa(chromeVer),
    'Sec-Ch-Ua-Mobile': '?0',
    'Sec-Ch-Ua-Platform': platform,
    'Sec-Fetch-Dest': isApi ? 'empty' : 'document',
    'Sec-Fetch-Mode': isApi ? 'cors' : 'navigate',
    'Sec-Fetch-Site': referer ? (sameSite ? 'same-origin' : 'cross-site') : 'none',
    'DNT': '1'
  };
  if (!isApi) {
    h['Upgrade-Insecure-Requests'] = '1';
    h['Sec-Fetch-User'] = '?1';
    h['Priority'] = 'u=0, i';
  }
  if (referer) h['Referer'] = referer;
  return h;
};

// Bot-block patterns: strictly match WAF/challenge pages only.
// Deliberately narrow to avoid false positives on legitimate error pages
// (404, OOS, payment declined, etc.) that happen to mention "blocked" or "error".
const BOT_BLOCK_PATTERNS = [
  /pardon our interruption/i,
  /checking your browser before accessing/i,
  /enable javascript and cookies to continue/i,
  /attention required.*cloudflare/i,
  /just a moment<\/title>/i,
  /press &amp; hold/i,
  /press and hold.*to confirm you are human/i,
  /please verify you are a human/i,
  /you have been blocked by/i,
  /this request has been blocked/i,
  /incapsula incident id/i,
  /captcha-delivery\.com/i,
  /perimeterx\.net\/take-over/i,
  /px-captcha/i,
  /kasada\.io/i,
  /kpsdk-tags/i,
  /ddos-guard\.net/i,
  /shape\.js\?a=/i,
  /challenge-platform.*cloudflare/i,
  /cf-chl-bypass/i,
  /sucuri-block/i,
  /_Incapsula_Resource.*challenge/i
];

export const detectVendor = (html, headers = {}) => {
  const h = (html || '').slice(0, 8000);
  const cookies = String(headers['set-cookie'] || '');
  const server = String(headers.server || '').toLowerCase();
  const headerStr = JSON.stringify(headers).toLowerCase();

  if (/visid_incap|incap_ses|reese84|_Incapsula_Resource/i.test(cookies + h)) return 'imperva';
  if (/_abck|ak_bmsc|bm_sz|bm_sv/i.test(cookies) || /akamai/i.test(server)) return 'akamai';
  if (/datadome|dd_cookie_test|x-dd-/i.test(cookies + headerStr)) return 'datadome';
  if (/_px3|_pxhd|pxcts|_pxvid|px-captcha|perimeterx/i.test(cookies + h)) return 'perimeterx';
  if (/kpsdk-cd|kpsdk-ct|kasada/i.test(cookies + h + headerStr)) return 'kasada';
  if (/cf-ray|__cf_bm|cf_clearance|cf-mitigated/i.test(cookies + headerStr) || /cloudflare/i.test(server)) return 'cloudflare';
  if (/TS\d{6}|f5_cspm/i.test(cookies)) return 'f5-shape';
  if (/sucuri/i.test(cookies + headerStr)) return 'sucuri';
  if (/AWSALB|x-amzn/i.test(cookies + headerStr) && /captcha|challenge/i.test(h)) return 'aws-waf';
  return 'unknown';
};

// Shared transport caches intentionally ignore size/style so 50—“100 tasks
// watching the same product URL can share one network response and parse it
// independently for their own size/style. This is the main residential-bandwidth
// optimization: one request can satisfy many monitors without delaying the poll.
const apiTransportKey = ({ apiUrl, proxy }) => `${apiUrl}|${proxyCacheKey(proxy)}`;
const htmlTransportKey = ({ pdpUrl, proxy }) => `${pdpUrl}|${proxyCacheKey(proxy)}`;

// What a poll actually costs, for budget accounting.
//
// A 304 Not Modified carries headers and nothing else, so the body we serve came
// from our own validator cache and was already paid for. Billing its full size
// again overstates residential usage by the whole payload and trips the monthly
// budget early — while the conditional request is the cheapest poll available.
// Exported so the rule is asserted directly rather than inferred from a mock.
export const billedPollBytes = ({ bodyLength = 0, notModified = false } = {}) => (
  notModified ? NOT_MODIFIED_COST_BYTES : Math.max(0, Number(bodyLength) || 0) + REQUEST_OVERHEAD_BYTES
);

// Partial fetch.
//
// Every consumer of the HTML is head-only: the bot-block scan reads the first
// 4000 bytes and every site parser reads title/price/size nodes from the top of the
// document. The bottom half of a product page is reviews, recommendation carousels
// and footer boilerplate — up to 2 MB of residential bandwidth that is parsed into
// nothing and then cached.
//
// `Range` therefore asks for the head only. It shrinks a poll by roughly 70-90% on
// a real PDP, which is the difference between a cheap poll and an expensive one.
// Safety: a Range response that turns out truncated simply misses the size nodes, so
// the caller checks the returned `partial` flag and re-fetches in full rather than
// reporting a false out-of-stock.
const RANGE_HEAD_BYTES = Math.max(16 * 1024, Number(process.env.MONITOR_RANGE_BYTES || 128 * 1024));
const rangeEnabled = () => String(process.env.MONITOR_PARTIAL_FETCH ?? 'true').toLowerCase() !== 'false';

const trimTransportMap = (map) => {
  if (map.size <= MAX_TRANSPORT_CACHE_ENTRIES) return;
  const now = Date.now();
  for (const [key, entry] of map) {
    if ((entry?.expiresAt || 0) <= now) map.delete(key);
  }
  while (map.size > MAX_TRANSPORT_CACHE_ENTRIES) {
    const first = map.keys().next().value;
    if (first === undefined) break;
    map.delete(first);
  }
};

const fetchApiTransport = async ({ apiUrl, apiHeaders, proxy }) => {
  const key = apiTransportKey({ apiUrl, proxy });
  const now = Date.now();
  const recent = apiTransportRecent.get(key);
  if (recent && recent.expiresAt > now) return recent.response;
  const existing = apiTransportInFlight.get(key);
  if (existing) return existing;

  const sharedPromise = (async () => {
    const proxyStr = proxy?.host
      ? `http://${proxy.username && proxy.password ? `${encodeURIComponent(proxy.username)}:${encodeURIComponent(proxy.password)}@` : ''}${proxy.host}:${proxy.port}`
      : null;

    const sharedValidator = httpValidators.get(`__transport_api__|${key}`);
    const headers = { ...apiHeaders };
    if (sharedValidator?.etag) headers['If-None-Match'] = sharedValidator.etag;
    if (sharedValidator?.lastModified) headers['If-Modified-Since'] = sharedValidator.lastModified;

    let body = null;
    let status = null;
    let respHeaders = {};
    const tlsResult = await tlsRequest({ url: apiUrl, headers, proxy: proxyStr, timeoutMs: 8000 });
    if (tlsResult.ok) {
      body = tlsResult.body;
      status = tlsResult.status;
      respHeaders = tlsResult.headers || {};
    } else {
      try {
        const gotResp = await gotScraping({
          url: apiUrl, headers, http2: true, ...(proxy ? {} : { agent: directGotAgents }),
          followRedirect: true, maxRedirects: 5, timeout: { request: 8000 }, decompress: true,
          https: tlsVerifyOption(),
          ...(proxy ? { proxyUrl: proxyStr } : {})
        });
        body = gotResp.body; status = gotResp.statusCode; respHeaders = gotResp.headers || {};
      } catch (err) {
        logger.warn(`[StockMonitor] API fallback request failed for ${apiUrl}: ${err.message}`);
        throw err;
      }
    }

    let notModified = false;
    if (status === 304 && sharedValidator?.body) {
      body = sharedValidator.body;
      status = 200;
      notModified = true;
    }

    const response = { body, status, headers: respHeaders };
    const etag = respHeaders?.etag || respHeaders?.ETag || sharedValidator?.etag || null;
    const lastModified = respHeaders?.['last-modified'] || respHeaders?.['Last-Modified'] || sharedValidator?.lastModified || null;
    if (body) {
      httpValidators.set(`__transport_api__|${key}`, { etag, lastModified, body, updatedAt: Date.now() });
      if (proxy?.proxy_type === 'residential') {
        recordResidentialBytes(billedPollBytes({
          bodyLength: Buffer.byteLength(String(body), 'utf8'),
          notModified
        }), 'monitor');
      }
    }
    apiTransportRecent.set(key, { response, expiresAt: Date.now() + API_RESPONSE_COALESCE_MS });
    trimTransportMap(apiTransportRecent);
    return response;
  })();

  apiTransportInFlight.set(key, sharedPromise);
  try { return await sharedPromise; }
  finally { apiTransportInFlight.delete(key); }
};

const fetchHtmlTransport = async ({ pdpUrl, headers: requestHeaders, proxy, full = false }) => {
  const key = htmlTransportKey({ pdpUrl, proxy });
  const now = Date.now();
  const recent = htmlTransportRecent.get(key);
  // A full refetch must not be answered by the coalesce cache, which may be holding
  // the very truncated response we are trying to escape.
  if (!full && recent && recent.expiresAt > now) return recent.response;
  const existing = !full && htmlTransportInFlight.get(key);
  if (existing) return existing;

  const sharedPromise = (async () => {
    const proxyStr = proxy?.host
      ? `http://${proxy.username && proxy.password ? `${encodeURIComponent(proxy.username)}:${encodeURIComponent(proxy.password)}@` : ''}${proxy.host}:${proxy.port}`
      : null;
    const sharedValidator = httpValidators.get(`__transport_html__|${key}`);
    const headers = { ...requestHeaders };
    if (sharedValidator?.etag) headers['If-None-Match'] = sharedValidator.etag;
    if (sharedValidator?.lastModified) headers['If-Modified-Since'] = sharedValidator.lastModified;
    // Head-only fetch (see RANGE_HEAD_BYTES). Skipped only when a CONDITIONAL request
    // is in play, because a 304 carries no body and the cached body is already in hand.
    // Keying on the mere existence of a validator was too coarse: after the first
    // fetch a validator always exists, so Range was sent once and never again.
    const conditional = Boolean(sharedValidator?.etag || sharedValidator?.lastModified);
    const wantsPartial = rangeEnabled() && !conditional && !full;

    if (wantsPartial) headers.Range = `bytes=0-${RANGE_HEAD_BYTES - 1}`;
    const resp = await gotScraping({
      url: pdpUrl,
      headers,
      http2: true, ...(proxy ? {} : { agent: directGotAgents }),
      followRedirect: true, maxRedirects: 6, timeout: { request: 10000 }, decompress: true,
      https: tlsVerifyOption(), ...(proxy ? { proxyUrl: proxyStr } : {})
    });
    let body = resp.body;
    let status = resp.statusCode;
    const respHeaders = resp.headers || {};
    let notModified = false;
    // A cached body inherits the partiality it was captured with. Without this a
    // 304 restores a truncated body, recomputes partial from the 304 (never 206) and
    // reports it as complete — so a parser miss is treated as a real out-of-stock
    // instead of triggering the full refetch.
    let partial = Boolean(sharedValidator?.partial);
    if (status === 304 && sharedValidator?.body) {
      body = sharedValidator.body;
      status = 200;
      notModified = true;
    }
    // A 206 means the server honoured the Range and the body is a head-only slice;
    // the caller uses this to know a miss on size nodes means "truncated", not
    // "out of stock". A 200 despite asking means the server ignored Range (some
    // CDNs do) and the body is already complete.
    if (wantsPartial && resp.statusCode === 206) partial = true;
    if (wantsPartial && resp.statusCode === 200) partial = false;
    const response = { html: body, status, headers: respHeaders, partial };

    // A 304 body came from our cache, so billing its full size again would
    // overstate residential usage for the cheapest request we can make.
    const billedBytes = (text) => billedPollBytes({
      bodyLength: Buffer.byteLength(String(text), 'utf8'),
      notModified
    });
    if (body && Buffer.byteLength(String(body), 'utf8') <= MAX_CACHED_HTML_BYTES) {
      const etag = respHeaders?.etag || respHeaders?.ETag || sharedValidator?.etag || null;
      const lastModified = respHeaders?.['last-modified'] || respHeaders?.['Last-Modified'] || sharedValidator?.lastModified || null;
      httpValidators.set(`__transport_html__|${key}`, { etag, lastModified, body, partial, updatedAt: Date.now() });

      if (proxy?.proxy_type === 'residential') recordResidentialBytes(billedBytes(body), 'monitor');
      htmlTransportRecent.set(key, { response, expiresAt: Date.now() + HTML_RESPONSE_COALESCE_MS });
      trimTransportMap(htmlTransportRecent);
    } else if (proxy?.proxy_type === 'residential' && body) {
      recordResidentialBytes(billedBytes(body), 'monitor');
    }
    return response;
  })();
  htmlTransportInFlight.set(key, sharedPromise);
  try { return await sharedPromise; }
  finally { htmlTransportInFlight.delete(key); }
};

// â”€â”€â”€ API-based stock check (fast path) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
// Hits the site's JSON product API directly — smaller payload, less WAF scrutiny,
// clean structured data. Uses TLS sidecar for Chrome JA3 fingerprint.
const tryApiCheck = async ({ checker, pdpUrl, size, style, ua, proxy, cookies, validatorKey }) => {
  // A checker may publish several candidate endpoints (retailers rename these
  // without notice). Trying them in order means a stale first URL degrades to a
  // working second URL instead of silently falling back to heavy HTML scraping.
  const apiUrls = (checker.extractApiUrls?.(pdpUrl, size, style)
    || [checker.extractApiUrl?.(pdpUrl, size, style)]).filter(Boolean);
  if (!apiUrls.length) return null;

  const host = new URL(pdpUrl).hostname;

  for (let index = 0; index < apiUrls.length; index++) {
    const apiUrl = apiUrls[index];
    // Scope validator (ETag/304) caching per endpoint so switching endpoints
    // does not reuse the wrong validator.
    const urlValidatorKey = `${validatorKey}#${index}`;
    const apiHeaders = {
      ...buildHeaders(ua, pdpUrl, { isApi: true }),
      ...(cookies ? { Cookie: cookies } : {}),
      ...getCachedValidatorHeaders(urlValidatorKey)
    };

    logger.debug(`[StockMonitor] API check: ${apiUrl}`);

    const transport = await fetchApiTransport({ apiUrl, apiHeaders, proxy });
    const body = transport.body;
    const status = transport.status;
    const respHeaders = transport.headers || {};

    if (status === 304) {
      const cached = getCached304Result(urlValidatorKey);
      if (cached) return { ...cached, __notModified: true };
      continue;
    }
    if (!body) continue;
    if (status === 401 || status === 403 || status === 429) {
      logger.warn(`[StockMonitor] API blocked (HTTP ${status}): ${apiUrl}`);
      return null; // Signal caller to try HTML route
    }

    // Update cookies from API response
    const setCookie = respHeaders['set-cookie'];
    if (setCookie) {
      mergeCookies(host, Array.isArray(setCookie) ? setCookie : [setCookie]);
    }

    let json;
    try { json = JSON.parse(body); } catch (_) {
      // Not JSON — might have returned HTML (redirect to challenge page)
      if (BOT_BLOCK_PATTERNS.some(p => p.test(body.slice(0, 3000)))) {
        logger.warn(`[StockMonitor] API endpoint returned a bot block page: ${apiUrl}`);
        return null;
      }
      continue;
    }

    const result = checker.parseStock?.(json, size, style);
    if (result) {
      logger.debug(`[StockMonitor] API result for ${pdpUrl}: inStock=${result.inStock}${result.availableSizes?.length ? ` sizes=[${result.availableSizes.slice(0, 5).join(',')}]` : ''}`);
      updateValidator(urlValidatorKey, respHeaders, result, 'api');
      return result;
    }
    // Reachable endpoint, but the payload shape was not usable — try the next.
  }

  return null;
};

// â”€â”€â”€ Cookie merge helper â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const mergeCookies = (host, incoming) => {
  const jar = new Map();
  const existing = sessionCookies.get(host) || '';
  existing.split(';').map(s => s.trim()).filter(Boolean).forEach(pair => {
    const eq = pair.indexOf('=');
    if (eq > 0) jar.set(pair.slice(0, eq).trim(), pair.slice(eq + 1).trim());
  });
  incoming.forEach(raw => {
    const first = raw.split(';')[0];
    const eq = first.indexOf('=');
    if (eq > 0) {
      const name = first.slice(0, eq).trim();
      const value = first.slice(eq + 1).trim();
      const isDeletion =
        !value || value === 'deleted' ||
        /expires=.*(?:1970|Thu,\s*0?1\s*Jan\s*1970)/i.test(raw) ||
        /max-age\s*=\s*0\b/i.test(raw);
      if (!isDeletion) jar.set(name, value);
      else jar.delete(name);
    }
  });
  const merged = Array.from(jar.entries()).map(([k, v]) => `${k}=${v}`).join('; ');
  if (merged === existing) return;
  sessionCookies.set(host, merged);
  persistJar();
};

// â”€â”€â”€ HTML-based stock check (fallback) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const tryHtmlCheck = async ({ checker, pdpUrl, size, style, ua, proxy, validatorKey }) => {
  await cookieJarReady;
  const host = new URL(pdpUrl).hostname;
  const existingCookies = sessionCookies.get(host) || '';

  const response = await fetchHtmlTransport({
    pdpUrl,
    headers: {
      ...buildHeaders(ua, pdpUrl),
      ...(existingCookies ? { Cookie: existingCookies } : {}),
      // Replay a fresh Kasada payload if we hold one — it is what turns a 429
      // into content, and it expires, so replaying when we have it is free.
      ...kasadaHeaders({ host, proxy }),
      ...getCachedValidatorHeaders(validatorKey)
    },
    proxy
  });
  const html = response.html;
  const status = response.status;
  const respHeaders = response.headers || {};

  if (status === 304) {
    const cached = getCached304Result(validatorKey);
    if (cached) return { html: '', status, headers: respHeaders, notModified: cached };
  }

  const setCookieHeader = respHeaders['set-cookie'];
  if (setCookieHeader) {
    mergeCookies(host, Array.isArray(setCookieHeader) ? setCookieHeader : [setCookieHeader]);
  }

  // `partial` comes from the transport, which computes it from the response status
  // (206 → truncated head, 200 → server ignored Range, 304 → inherited from the
  // cached body). It cannot be computed here because this function does not see the
  // raw response.
  return { html, status, headers: respHeaders, partial: Boolean(response?.partial) };
};

// â”€â”€â”€ Main checkStock entry point â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const EMPTY = { inStock: false, productName: null, price: null, imageUrl: null, availableSizes: [] };

/**
 * Public entry point. Wraps the raw check with:
 *   - a per-host circuit breaker (skip the network entirely when a site is
 *     hard-blocking, to protect the proxy/session and let it recover),
 *   - latency timing + per-host metrics (observability),
 *   - strict result validation (never surface a non-boolean "in stock").
 *   - datacenter-first proxy escalation: HTTP polls start on the datacenter IP;
 *     if blocked and a proxy is available, retries immediately with the proxy,
 *     then stays on proxy until ESCALATION_CLEAN_THRESHOLD clean polls, then
 *     drops back. Browser-based operations (warming) always use proxy.
 *
 * @param {string} productUrl  Product page URL
 * @param {{ proxy?, taskId?, siteId?, size?, style? }} opts
 */
const checkStockRaw = async (productUrl, { proxy = null, warmProxy = null, taskId = null, siteId = null, size = null, style = null } = {}) => {
  await cookieJarReady;

  let host;
  try { host = new URL(productUrl).hostname; } catch (_) {
    return { ...EMPTY, blocked: false, error: 'Invalid URL' };
  }

  // â”€â”€ Circuit breaker gate â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const gate = breaker.canRequest(host);
  if (!gate.allowed) {
    metrics.record(host, { outcome: 'blocked' });
    return {
      ...EMPTY,
      blocked: true,
      error: `Circuit open for ${host} — cooling down (${Math.ceil(gate.retryInMs / 1000)}s)`,
      circuit: gate.state,
      retryInMs: gate.retryInMs,
    };
  }

  const startedAt = Date.now();
  let outcome, source;

  // â”€â”€ Proxy escalation: start on datacenter, use proxy only if blocked â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const escState = getEscalation(host, proxy, taskId);
  const httpProxy = escState.useProxy ? proxy : null;

  // Pin one residential exit per task+host (no-op unless the operator configured
  // RESIDENTIAL_SESSION_TEMPLATE). Rotating per tick would reset the WAF's per-IP
  // history on every poll, which is both bot-like and billed per rotation.
  const pinned = httpProxy ? withAffinity(httpProxy, { taskId, role: 'monitor', host }).proxy : null;
  const pinnedProxy = pinned || httpProxy;

  try {
    let raw = await runStockCheck({ productUrl, host, proxy, warmProxy, httpProxy: pinnedProxy, siteId, size, style, taskId });

    // If blocked on datacenter and a proxy is available, retry once with proxy.
    if (raw.blocked && proxy && !escState.useProxy) {
      logger.info(`[StockMonitor] Task ${taskId} blocked on datacenter — escalating to proxy for ${host}`);
      // Pin on the escalation hop too: this is the request that starts the sticky
      // exit, so waiting a tick to pin it would burn a second IP for nothing.
      const escProxy = withAffinity(proxy, { taskId, role: 'monitor', host }).proxy || proxy;
      raw = await runStockCheck({ productUrl, host, proxy, warmProxy, httpProxy: escProxy, siteId, size, style, taskId });
      // Mark escalated regardless of retry outcome; if still blocked the next
      // poll will continue on proxy (circuit breaker handles repeated failures).
      if (proxy) proxyEscalation.set(escalationKeyFor(host, proxy), { useProxy: true, cleanStreak: 0, updatedAt: Date.now() });
    } else {
      updateEscalation(host, proxy, raw.blocked, !!proxy, taskId);
    }
    source = raw.__source;
    delete raw.__source;

    // Block / transient signals never get validated as stock results.
    if (raw.blocked) {
      // Retrying a banned exit wastes a whole task, so earn a new one.
      if (pinnedProxy) rotateAffinity({ taskId, role: 'monitor', host });
      breaker.recordFailure(host, raw.error || 'blocked');
      outcome = 'blocked';
      metrics.record(host, { outcome, latencyMs: Date.now() - startedAt, source });
      return raw;
    }
    if (raw.error) {
      // Soft error (timeout / transient) — count as failure but don't crash.
      breaker.recordFailure(host, raw.error);
      outcome = 'error';
      metrics.record(host, { outcome, latencyMs: Date.now() - startedAt, source, error: raw.error });
      return raw;
    }

    // â”€â”€ Validate before trusting the verdict â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    const validated = validateStockResult(raw);
    if (!validated) {
      breaker.recordSuccess(host); // the request itself succeeded
      outcome = 'outofstock';
      metrics.record(host, { outcome, latencyMs: Date.now() - startedAt, source });
      return { ...EMPTY, blocked: false, error: 'Unparseable response — treated as out of stock' };
    }

    // A low-confidence "in stock" (no name/price/sizes) is downgraded so we
    // don't fire a checkout on a phantom signal; the next poll re-confirms.
    const inStock = validated.inStock && validated.confident;
    breaker.recordSuccess(host);
    outcome = inStock ? 'instock' : 'outofstock';
    metrics.record(host, { outcome, latencyMs: Date.now() - startedAt, source });

    return {
      inStock,
      productName: validated.productName,
      price: validated.price,
      imageUrl: validated.imageUrl,
      availableSizes: validated.availableSizes,
      blocked: false,
      error: validated.inStock && !validated.confident ? 'Low-confidence stock signal — reconfirming' : null,
    };
  } catch (err) {
    // Last-resort guard: a monitor must NEVER die from an unhandled throw.
    breaker.recordFailure(host, err.message);
    metrics.record(host, { outcome: 'error', latencyMs: Date.now() - startedAt, error: err.message });
    logger.error(`[StockMonitor] Unhandled error checking ${productUrl}: ${err.stack || err.message}`);
    return { ...EMPTY, blocked: false, error: err.message };
  }
};


/**
 * Public coalesced stock check. When multiple tasks monitor the exact same
 * product with the same network identity inside a 300 ms window, they share one
 * request. This reduces RAM/CPU/network use without adding polling delay.
 */
export const checkStock = async (productUrl, opts = {}) => {
  const proxy = opts.proxy || null;
  const key = monitorCacheKey({ productUrl, proxy, siteId: opts.siteId || null, size: opts.size || null, style: opts.style || null });
  const now = Date.now();
  // When residential fallback is active, allow a slightly wider shared-result
  // window. This is intentionally short so multiple tasks watching the same
  // item can share one response without turning monitoring into a stale cache.
  const cacheWindow = proxy?.proxy_type === 'residential'
    ? RESIDENTIAL_RESULT_CACHE_MS
    : REQUEST_COALESCE_MS;
  const recent = recentCheckResults.get(key);
  if (recent && recent.expiresAt > now) return { ...recent.result };
  const existing = inFlightChecks.get(key);
  if (existing) return existing.then((result) => ({ ...result }));

  const promise = checkStockRaw(productUrl, opts).then((result) => {
    recentCheckResults.set(key, { result, expiresAt: Date.now() + cacheWindow });
    trimMap(recentCheckResults);
    return result;
  }).finally(() => {
    inFlightChecks.delete(key);
  });
  inFlightChecks.set(key, promise);
  return promise;
};

/**
 * Raw stock check (no breaker/metrics) — returns a result tagged with
 * `__source: 'api' | 'html'` so the wrapper can attribute metrics.
 *
 * @param proxy      Task proxy — used for browser-based operations (session
 *                   warming, Imperva warm) that ALWAYS need residential routing.
 * @param httpProxy  Effective HTTP proxy — null (datacenter) or proxy depending
 *                   on escalation state. Used only for plain HTTP requests.
 */
const runStockCheck = async ({ productUrl, host, proxy, warmProxy, httpProxy: rawHttpProxy, siteId, size, style, taskId = null }) => {
  const ua = /pokemoncenter\.com$/i.test(host) ? getStableUA(host) : nextUA();
  const checker = siteId && SITE_CHECKERS[siteId] ? SITE_CHECKERS[siteId] : autoDetectChecker(productUrl);

  // Pin the HTTP exit to the retailer's country too (no-op for providers without
  // dialect support). Browser launches do the same, so both paths agree — the
  // monitor's plain HTTP polls are what most of the blocks were coming from.
  const targetSite = targetingFor({ siteId });
  const httpProxy = applyTargeting(rawHttpProxy, targetSite).proxy;

  const existingCookies = sessionCookies.get(host) || '';
  const baseCacheKey = `${monitorCacheKey({ productUrl, proxy: httpProxy, siteId, size, style })}`;
  const apiValidatorKey = `${baseCacheKey}|api`;
  const htmlValidatorKey = `${baseCacheKey}|html`;

  // â”€â”€ Fast path: site-specific JSON API â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  try {
    const apiResult = await tryApiCheck({
      checker, pdpUrl: productUrl, size, style, ua, proxy: httpProxy, cookies: existingCookies, validatorKey: apiValidatorKey
    });
    if (apiResult) {
      recordSuccess(host);
      const { __notModified, ...result } = apiResult;
      return { ...result, blocked: false, error: null, __source: 'api', __notModified: Boolean(__notModified) };
    }
  } catch (err) {
    logger.warn(`[StockMonitor] API check error for ${productUrl}: ${err.message}`);
  }

  // â”€â”€ Slow path: fetch full HTML page â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  let html, status, respHeaders, htmlNotModified, htmlPartial = false;
  try {
    ({ html, status, headers: respHeaders, notModified: htmlNotModified, partial: htmlPartial } = await tryHtmlCheck({ checker, pdpUrl: productUrl, size, style, ua, proxy: httpProxy, validatorKey: htmlValidatorKey }));
  } catch (err) {
      const isTimeout = err.code === 'ETIMEDOUT' || err.code === 'ECONNRESET' || err.message?.includes('timeout');
    logger.warn(`[StockMonitor] HTML request failed for ${productUrl}: ${err.message}`);
    if (isTimeout) {
      return { ...EMPTY, blocked: false, error: 'Request timed out — retrying', __source: 'html' };
    }
    sessionCookies.delete(host);
    return { ...EMPTY, blocked: false, error: err.message, __source: 'html' };
  }

  if (status === 304 && htmlNotModified) {
    recordSuccess(host);
    return { ...htmlNotModified, blocked: false, error: null, __source: 'html', __notModified: true };
  }

  // â”€â”€ Kasada / F5 Shape: handle BEFORE the generic status branch â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  // Both answer with statuses the generic branch treats as a plain block (429 for
  // Kasada, 403/501 for Shape), and a plain block wipes cookies — which is the
  // wrong move for both. They get first refusal.
  const cookieHeaderNow = sessionCookies.get(host) || '';
  if (isKasadaChallenge({ status, body: html, headers: respHeaders })) {
    recordBlock(host);
    const outcome = await solveKasada({
      pageUrl: productUrl, proxy, ua, status, body: html, headers: respHeaders
    }).catch(() => null);
    if (outcome?.needBrowser) {
      warmSession(productUrl, sessionCookies, () => { markSessionWarmed(host); recordSuccess(host); }, warmProxy || proxy, siteId);
      if (!taskId || !isParked(taskId)) {
        startAutoRefresh(productUrl, sessionCookies, () => markSessionWarmed(host), warmProxy || proxy, siteId);
      }
    }
    if (outcome?.retry) {
      return { ...EMPTY, blocked: true, error: `Kasada ${outcome.reason} — retrying next cycle`, __source: 'html' };
    }
    return { ...EMPTY, blocked: true, error: 'Kasada challenge — browser solve required', __source: 'html' };
  }

  if (isShapeChallenge({ status, body: html, headers: respHeaders })) {
    recordBlock(host);
    const verdict = await solveShape({
      pageUrl: productUrl, proxy, ua, status, body: html, headers: respHeaders, cookieHeader: cookieHeaderNow
    }).catch(() => null);
    // Adoption matters more than the verdict: Shape accumulates, so a TSPD we
    // already hold must survive this cycle rather than be wiped by the 403 path.
    if (verdict?.cookies) {
      const merged = cookieHeaderNow
        ? `${cookieHeaderNow}; ${verdict.cookies}`
        : verdict.cookies;
      sessionCookies.set(host, merged);
      persistJar();
    }
    if (verdict?.needBrowser) {
      warmSession(productUrl, sessionCookies, () => { markSessionWarmed(host); recordSuccess(host); }, warmProxy || proxy, siteId);
      if (!taskId || !isParked(taskId)) {
        startAutoRefresh(productUrl, sessionCookies, () => markSessionWarmed(host), warmProxy || proxy, siteId);
      }
    }
    return { ...EMPTY, blocked: true, error: `F5 Shape ${verdict?.reason || 'challenge'} — retrying next cycle`, __source: 'html' };
  }

  // Handle HTTP error codes
  if (status === 403 || status === 429 || status === 503) {
    recordBlock(host);
    const meta = sessionCookieMeta.get(host);
    const ageMs = meta ? Date.now() - meta.warmedAt : Infinity;
    const PROTECT_WINDOW_MS = 5 * 60 * 1000;
    if (ageMs > PROTECT_WINDOW_MS) {
      logger.warn(`[StockMonitor] HTTP ${status} from ${productUrl} — wiping stale cookies (age ${(ageMs / 1000).toFixed(0)}s), backoff ${getAdaptiveDelay(host)}ms`);
      sessionCookies.delete(host);
      sessionCookieMeta.delete(host);
      persistJar();
    } else {
      logger.warn(`[StockMonitor] HTTP ${status} from ${productUrl} — keeping recently-warmed cookies (age ${(ageMs / 1000).toFixed(0)}s)`);
    }
    return { ...EMPTY, blocked: true, error: `HTTP ${status} — bot protection`, __source: 'html' };
  }

  // Check for Imperva JS challenge
  const setCookieRaw = respHeaders['set-cookie'];
  if (isImpervaChallenged(html, setCookieRaw)) {
    recordBlock(host);
    logger.info(`[StockMonitor] Imperva JS challenge on ${host} — warming session (streak ${blockStreaks.get(host)})`);
    warmSession(productUrl, sessionCookies, () => { markSessionWarmed(host); recordSuccess(host); }, warmProxy || proxy, siteId);
    // If the task already owns a shared prewarm pool, that pool is itself
    // responsible for keeping the warmed browser/session fresh. Avoid a second
    // periodic residential warm for the same task/site.
    if (!taskId || !isParked(taskId)) {
      startAutoRefresh(productUrl, sessionCookies, () => markSessionWarmed(host), warmProxy || proxy, siteId);
    }
    return { ...EMPTY, blocked: true, error: 'Imperva challenge — warming session (retry in ~25s)', __source: 'html' };
  }

  recordSuccess(host);

  // Skip DataDome/Akamai detection on Imperva-protected hosts (false-positive prevention)
  const isImpervaHost = /pokemoncenter\.com|footlocker\.|finishline\./i.test(host);

  if (!isImpervaHost) {
    const ddCookie = await detectAndSolveDataDome({ html, pageUrl: productUrl, ua, sessionCookies }).catch(() => null);
    if (ddCookie) {
      const prev = sessionCookies.get(host) || '';
      sessionCookies.set(host, prev
        ? prev.replace(/datadome=[^;]*/i, `datadome=${ddCookie}`)
        : `datadome=${ddCookie}`);
      logger.info(`[StockMonitor] DataDome cookie refreshed for ${host}`);
      return { ...EMPTY, blocked: true, error: 'DataDome solved — retrying next cycle', __source: 'html' };
    }

    const akamaiCookie = await detectAndSolveAkamai({ html, pageUrl: productUrl, ua, sessionCookies }).catch(() => null);
    if (akamaiCookie) {
      logger.info(`[StockMonitor] Akamai _abck refreshed for ${host}`);
      return { ...EMPTY, blocked: true, error: 'Akamai solved — retrying next cycle', __source: 'html' };
    }
  }

  // Bot-block check on the HTML we received
  const checkZone = html.slice(0, 4000);
  for (const pattern of BOT_BLOCK_PATTERNS) {
    if (pattern.test(checkZone)) {
      logger.warn(`[StockMonitor] Bot challenge page detected at ${productUrl} — clearing session`);
      sessionCookies.delete(host);
      return { ...EMPTY, blocked: true, error: 'Bot challenge page — retrying next cycle', __source: 'html' };
    }
  }

  // â”€â”€ Site-specific HTML parsing â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  let htmlResult = null;
  try {
    htmlResult = checker.parseHtml?.(html, size, style);
  } catch (err) {
    logger.warn(`[StockMonitor] HTML parser threw for ${productUrl}: ${err.message}`);
  }

  // A head-only slice is ambiguous when it yields nothing at all: the size nodes may
  // simply sit below the cut. Re-fetch once in full rather than reporting a false
  // out-of-stock. The parser normally returns an object even for a blank page, so the
  // decisive signal is "no sizes and no in-stock signal" — which is exactly the
  // profile of a body cut before the product grid.
  let parsedHtml = html;
  const ambiguous =
    htmlPartial &&
    (!htmlResult || (Array.isArray(htmlResult.availableSizes) && htmlResult.availableSizes.length === 0 && !htmlResult.inStock));
  if (ambiguous) {
    logger.info(`[StockMonitor] Partial head found nothing for ${productUrl} — refetching in full`);
    try {
      const full = await fetchHtmlTransport({
        pdpUrl: productUrl,
        headers: {
          ...buildHeaders(ua, productUrl),
          ...(sessionCookies.get(host) ? { Cookie: sessionCookies.get(host) } : {})
        },
        proxy: httpProxy,
        full: true
      });
      if (full?.html) {
        parsedHtml = full.html;
        htmlResult = checker.parseHtml?.(parsedHtml, size, style) || null;
      }
    } catch (err) {
      logger.warn(`[StockMonitor] Full refetch failed for ${productUrl}: ${err.message}`);
    }
  }

  if (htmlResult) {
    logger.info(`[StockMonitor] HTML result for ${productUrl}: inStock=${htmlResult.inStock}${size ? ` size=${size}` : ''}`);
    const parsed = {
      inStock: htmlResult.inStock ?? false,
      productName: htmlResult.productName ?? extractProductName(parsedHtml),
      price: htmlResult.price ?? extractPrice(parsedHtml),
      imageUrl: htmlResult.imageUrl ?? extractImage(parsedHtml),
      availableSizes: htmlResult.availableSizes ?? [],
    };
    updateValidator(htmlValidatorKey, respHeaders, parsed, 'html');
    return { ...parsed, blocked: false, error: null, __source: 'html' };
  }

  // â”€â”€ Generic HTML fallback â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const genericResult = {
    inStock,
    productName: extractProductName(html),
    price: extractPrice(html),
    imageUrl: extractImage(html),
    availableSizes: [],
  };
  updateValidator(htmlValidatorKey, respHeaders, genericResult, 'html');
  return { ...genericResult, blocked: false, error: null, __source: 'html' };
};

/** Reliability introspection — exposed via the API for observability. */
export const getReliabilitySnapshot = () => ({
  metrics: metrics.getAllMetrics(),
  circuits: breaker.getAllStates(),
});

// â”€â”€â”€ Generic parsers (last resort) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

const genericIsInStock = (html, size) => {
  const outPatterns = [
    /class="[^"]*(?:not-available|out-of-stock|sold-out)[^"]*"/i,
    /"availability"\s*:\s*"(?:not-available|OUT_OF_STOCK|UNAVAILABLE)"/i,
    /data-available="false"/i,
    /"orderable"\s*:\s*false/i,
    /"ATS"\s*:\s*0\b/i,
    /"available"\s*:\s*false\s*[,}]/i,
    /Currently unavailable/i
  ];
  const inPatterns = [
    /"orderable"\s*:\s*true/i,
    /"ATS"\s*:\s*[1-9]/i,
    /"availability"\s*:\s*"(?:IN_STOCK|AVAILABLE|PREORDER)"/i,
    /data-available="true"/i,
    /"available"\s*:\s*true\s*[,}]/i,
    /In Stock/i
  ];

  if (/add-to-cart[^>]*disabled/i.test(html)) return false;
  for (const p of outPatterns) if (p.test(html)) return false;
  for (const p of inPatterns) if (p.test(html)) return true;
  return false;
};

const extractProductName = (html) => {
  const m =
    html.match(/<title>([^<|—“-]{3,80})/i) ||
    html.match(/"name"\s*:\s*"([^"]{3,100})"/i) ||
    html.match(/class="[^"]*product-name[^"]*"[^>]*>\s*([^<]{3,80})/i) ||
    html.match(/property="og:title"\s+content="([^"]+)"/i);
  return m ? m[1].replace(/\s*[-|].*$/, '').trim() : null;
};

const extractPrice = (html) => {
  const m =
    html.match(/"price"\s*:\s*\{[^}]*"sales"\s*:\s*\{[^}]*"value"\s*:\s*([\d.]+)/i) ||
    html.match(/class="[^"]*sales[^"]*"[^>]*>[\s\S]{0,30}\$?([\d.,]+)/i) ||
    html.match(/property="product:price:amount"\s+content="([^"]+)"/i) ||
    html.match(/"\$?([\d]{1,4}\.\d{2})"/);
  return m ? `$${parseFloat(m[1].replace(/,/g, '')).toFixed(2)}` : null;
};

const extractImage = (html) => {
  const m =
    html.match(/property="og:image"\s+content="([^"]+)"/i) ||
    html.match(/"primaryImage"\s*:\s*\{[^}]*"url"\s*:\s*"([^"]+)"/i) ||
    html.match(/class="[^"]*primary-image[^"]*"[^>]*src="([^"]+)"/i);
  return m ? m[1] : null;
};
