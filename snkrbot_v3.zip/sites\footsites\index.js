import { tryRequestFirstAddToCart } from '../../helpers/browser-request-atc.js';
import { tuneSitePage } from '../../helpers/site-checkout-fastpath.js';
import logger from '../../helpers/logger.js';
import { captureOrderSuccess } from '../../helpers/order-capture.js';
import { solveCaptcha } from '../../helpers/captcha.js';
import { humanType, humanTypeInFrames, humanClick, humanSelect } from '../../helpers/human-type.js';
import {
  formatPostal, stripPhone, dismissAutocomplete, verifyFieldValue, requireCardIframe, FillReport, assertCriticalFields
} from '../../helpers/autofill-utils.js';
import {
  retryWithBackoff, hasCaptchaApiKey, guardedGoto, preOrderGuard,
  postClickGuard, takeFailureScreenshot
} from '../../helpers/checkout-guards.js';

import { waitForAnySelector } from '../../helpers/site-runtime.js';
import { assertActionButtonIntent } from '../../helpers/checkout-controls.js';

const TIMEOUT = 15000;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const findFirst = async (page, selectorList, timeout = TIMEOUT) => {
  const selector = await waitForAnySelector(page, selectorList, { timeout });
  if (!selector) return null;
  const el = await page.$(selector).catch(() => null);
  return el ? { el, selector } : null;
};

const clickFirst = async (page, selectorList, { stage = '' } = {}) => {
  const found = await findFirst(page, selectorList, TIMEOUT);
  if (!found) throw new Error(`Could not find clickable element at stage "${stage}" — tried [${selectorList.join(', ')}]`);
  await humanClick(page, found.selector);
  return found.selector;
};

const fillField = async (page, selectorList, value, { type = 'text', label = '', report = null } = {}) => {
  const name = label || 'unnamed';
  if (!value) { if (report) report.record(name, true, 'skipped (empty)'); return false; }
  const found = await findFirst(page, selectorList, 8000);
  if (!found) { if (report) report.record(name, false, 'selector not found'); return false; }
  const formatted = type === 'postal' ? formatPostal(value) : type === 'phone' ? stripPhone(value) : String(value);
  for (let attempt = 0; attempt < 2; attempt++) {
    await found.el.click({ clickCount: 3 }).catch(() => {});
    await page.keyboard.press('Backspace').catch(() => {});
    await humanType(page, found.selector, formatted);
    await dismissAutocomplete(page);
    await page.keyboard.press('Tab').catch(() => {});
    const v = await verifyFieldValue(page, found.selector, formatted, type);
    if (v.ok) { if (report) report.record(name, true); return true; }
    logger.warn(`[Footsites] ${name} did not stick on attempt ${attempt + 1} (got "${v.actual}", expected "${v.expected}"), retrying`);
  }
  if (report) report.record(name, false, 'verify failed after retry');
  return false;
};

const SELECTORS = {
  addToCart: [
    '[data-testid="add-to-cart"]', 'button.AddToBagButton',
    'button[data-action="add-to-cart"]', 'button.add-to-cart',
    'button[aria-label="Add to Cart"]', '#AddToCart'
  ],
  qtySelect: [
    'select[data-testid="quantity-selector"]', 'select[name="quantity"]',
    'input[name="quantity"]'
  ],
  checkout: [
    '[data-testid="checkout-button"]', 'a[href*="/checkout"]',
    'button.CheckoutButton', 'button.cart-checkout-button'
  ],
  guestCheckout: [
    'a[data-testid="guestCheckoutButton"]',
    'button[data-testid="guestCheckoutButton"]',
    'a[data-testid="continueAsGuest"]',
    'button[data-testid="continueAsGuest"]',
    'a.js-guestCheckout',
    'button.guest-continue',
    'a[href*="guest"]',
    'button[name="continue-as-guest"]'
  ],
  email: [
    'input#email', 'input[name="email"]', 'input[type="email"]',
    'input[data-testid="email-input"]'
  ],
  firstName: [
    'input[name="firstName"]', 'input[data-testid="first-name"]',
    'input#firstName', 'input[autocomplete="given-name"]'
  ],
  lastName: [
    'input[name="lastName"]', 'input[data-testid="last-name"]',
    'input#lastName', 'input[autocomplete="family-name"]'
  ],
  address1: [
    'input[name="address1"]', 'input[data-testid="address-line-1"]',
    'input[autocomplete="address-line1"]'
  ],
  address2: [
    'input[name="address2"]', 'input[data-testid="address-line-2"]',
    'input[autocomplete="address-line2"]'
  ],
  city: [
    'input[name="city"]', 'input[data-testid="city"]',
    'input[autocomplete="address-level2"]'
  ],
  state: [
    'select[name="state"]', 'select[data-testid="state"]',
    'select[autocomplete="address-level1"]'
  ],
  postalCode: [
    'input[name="zipCode"]', 'input[name="postalCode"]',
    'input[data-testid="postal-code"]', 'input[autocomplete="postal-code"]'
  ],
  phone: [
    'input[name="phone"]', 'input[data-testid="phone"]',
    'input[type="tel"]'
  ],
  continueToPayment: [
    'button[data-testid="continue-to-payment"]', 'button.ContinueButton',
    'button[type="submit"]', 'button.continue-checkout'
  ],
  cardNumber: [
    'input[name="cardNumber"]', 'input[data-testid="card-number"]',
    'input[autocomplete="cc-number"]', 'input#cardNumber'
  ],
  cardName: [
    'input[name="nameOnCard"]', 'input[data-testid="card-name"]',
    'input[autocomplete="cc-name"]'
  ],
  expMonth: [
    'select[name="expirationMonth"]', 'select[data-testid="exp-month"]',
    'select#expirationMonth'
  ],
  expYear: [
    'select[name="expirationYear"]', 'select[data-testid="exp-year"]',
    'select#expirationYear'
  ],
  cvv: [
    'input[name="cvv"]', 'input[data-testid="cvv"]',
    'input[autocomplete="cc-csc"]'
  ],
  placeOrder: [
    'button[data-testid="place-order"]', 'button.PlaceOrderButton',
    'button[type="submit"].place-order', 'button[aria-label="Place Order"]'
  ],
  orderConfirmation: [
    '[data-testid="order-confirmation"]', '.OrderConfirmation',
    '.order-confirmation', 'h1.order-confirmation-title',
    '.thank-you-message'
  ]
};

const handleCaptcha = async (page, task) => {
  if (!task.auto_solve_captchas) return;
  const hasKey = await hasCaptchaApiKey();
  if (!hasKey) return;
  try {
    const captchaInfo = await page.evaluate(() => {
      const el = document.querySelector('[data-sitekey], .g-recaptcha, .h-captcha');
      if (!el) return null;
      return { siteKey: el.dataset.sitekey || el.dataset.hcaptchaSitekey || null };
    }).catch(() => null);
    if (!captchaInfo || !captchaInfo.siteKey) return;
    logger.info(`[Footsites] Captcha detected — solving`);
    const token = await solveCaptcha({ siteKey: captchaInfo.siteKey, pageUrl: page.url(), page });
    await page.evaluate((tok) => {
      const ta = document.querySelector('textarea[name="g-recaptcha-response"], textarea[name="h-captcha-response"]');
      if (ta) ta.value = tok;
    }, token).catch(() => {});
  } catch (err) {
    logger.warn(`[Footsites] Captcha solve failed: ${err.message}`);
  }
};

const runFootsite = async ({ page, task }) => {
  const startedAt = Date.now();
  logger.info(`[Footsites] Starting checkout for task ${task.id}: ${task.url}`);
  await tuneSitePage(page, { navigationTimeoutMs: 30000 });
  page.setDefaultNavigationTimeout(30000);

  await guardedGoto(page, task.url, { taskId: task.id, stage: 'pdp_load' });
  await waitForAnySelector(page, SELECTORS.addToCart, { timeout: 8000 });

  if (task.quantity && task.quantity > 1) {
    const qtyFound = await findFirst(page, SELECTORS.qtySelect, 5000);
    if (qtyFound) {
      const tag = await qtyFound.el.evaluate((el) => el.tagName.toLowerCase());
      if (tag === 'select') await page.select(qtyFound.selector, String(task.quantity)).catch(() => {});
      else { await qtyFound.el.click({ clickCount: 3 }).catch(() => {}); await humanType(page, qtyFound.selector, String(task.quantity)); }
      logger.info(`[Footsites] Quantity set to ${task.quantity}`);
    }
  }

  await retryWithBackoff(async () => {
if (!(await tryRequestFirstAddToCart(page, SELECTORS.addToCart))) await clickFirst(page, SELECTORS.addToCart, { stage: 'add_to_cart' });
  }, { attempts: 3, baseMs: 1000, label: 'Footsites ATC' });
  logger.info('[Footsites] Added to cart');
  await waitForAnySelector(page, SELECTORS.checkout, { timeout: 6000 });

  await clickFirst(page, SELECTORS.checkout, { stage: 'proceed_to_checkout' });
  await page.waitForNavigation({ waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
  await postClickGuard(page, { taskId: task.id, stage: 'proceed_to_checkout' });
  await waitForAnySelector(page, [...SELECTORS.guestCheckout, ...SELECTORS.email], { timeout: 8000 });

  // Foot Locker shows a login/guest wall before the shipping form when not signed in.
  // Click "Continue as Guest" if it appears — if not shown, fall through silently.
  const guestBtn = await findFirst(page, SELECTORS.guestCheckout, 4000);
  if (guestBtn) {
    logger.info(`[Footsites] Task ${task.id} — guest checkout wall detected, clicking "${guestBtn.selector}"`);
    await humanClick(page, guestBtn.selector);
    await waitForAnySelector(page, SELECTORS.email, { timeout: 8000 });
    await postClickGuard(page, { taskId: task.id, stage: 'guest_checkout' });
  }

  const ship = task.shippingAddress;
  if (!ship) throw new Error('Shipping address missing at stage "fill_shipping"');
  const shipReport = new FillReport(task.id, 'Footsites Shipping');
  await fillField(page, SELECTORS.email, task.notification_email_address || ship.email, { label: 'email', report: shipReport });
  await fillField(page, SELECTORS.firstName, ship.first_name, { label: 'firstName', report: shipReport });
  await fillField(page, SELECTORS.lastName, ship.last_name, { label: 'lastName', report: shipReport });
  await fillField(page, SELECTORS.address1, ship.address1, { label: 'address1', report: shipReport });
  await fillField(page, SELECTORS.address2, ship.address2, { label: 'address2', report: shipReport });
  await fillField(page, SELECTORS.city, ship.city, { label: 'city', report: shipReport });
  await fillField(page, SELECTORS.postalCode, formatPostal(ship.zip), { label: 'postalCode', report: shipReport });
  await fillField(page, SELECTORS.phone, stripPhone(ship.phone), { label: 'phone', report: shipReport });
  const stateSel = await findFirst(page, SELECTORS.state, 3000);
  if (stateSel) await humanSelect(page, stateSel.selector, ship.state).catch(() => {});
  shipReport.log();
  assertCriticalFields(shipReport, ['email', 'firstName', 'lastName', 'address1', 'city', 'postalCode', 'phone']);

  const contPay = await findFirst(page, SELECTORS.continueToPayment, 5000);
  if (contPay) { await humanClick(page, contPay.selector); await waitForAnySelector(page, [...SELECTORS.cardNumber, ...SELECTORS.placeOrder], { timeout: 12000 }); await postClickGuard(page, { taskId: task.id, stage: 'continue_payment' }); }

  const pay = task.paymentProfile;
  if (!pay) throw new Error('Payment profile missing at stage "fill_payment"');

  await requireCardIframe(page, { timeout: 15000 });

  const payReport = new FillReport(task.id, 'Footsites Payment');
  const cardFilled = await humanTypeInFrames(page, SELECTORS.cardNumber.join(', '), pay.card_number.replace(/\s/g, ''), { tabAfter: true });
  payReport.record('cardNumber', cardFilled);
  await humanTypeInFrames(page, SELECTORS.cardName.join(', '), pay.card_holder_name, { tabAfter: true });
  const expMo = await findFirst(page, SELECTORS.expMonth, 3000);
  if (expMo) await humanSelect(page, expMo.selector, String(parseInt(pay.expiration_month, 10))).catch(() => {});
  const expYr = await findFirst(page, SELECTORS.expYear, 3000);
  if (expYr) await humanSelect(page, expYr.selector, String(pay.expiration_year)).catch(() => {});
  await humanTypeInFrames(page, SELECTORS.cvv.join(', '), pay.cvv, { tabAfter: true });
  payReport.log();
  assertCriticalFields(payReport, ['cardNumber']);

  await handleCaptcha(page, task);
  await preOrderGuard(page, { taskId: task.id });
  await assertActionButtonIntent(page, SELECTORS.placeOrder, { stage: 'place order', allow: /place order|submit order/i });
  await clickFirst(page, SELECTORS.placeOrder, { stage: 'place_order' });

  const confirmed = await Promise.race([
    findFirst(page, SELECTORS.orderConfirmation, 60000),
    page.waitForFunction(() => /thank.you|order.*confirm|confirmation/i.test(window.location.pathname + ' ' + document.title), { timeout: 60000 }).then(() => ({ url: true })).catch(() => null)
  ]);
  if (!confirmed) throw new Error('Order confirmation not detected at stage "confirm_order"');

  const orderNumber = await page.evaluate(() => {
    const el = document.querySelector('.order-number, [class*="orderNumber" i], [data-testid="order-number"]');
    return el ? el.textContent.trim() : null;
  }).catch(() => null);

  logger.info(`[Footsites] ✅ Order placed for task ${task.id}! Order: ${orderNumber || 'N/A'}`);
  await captureOrderSuccess({ page, taskId: task.id, orderNumber, productUrl: task.url, durationMs: Date.now() - startedAt }).catch(() => {});
};

export default runFootsite;
