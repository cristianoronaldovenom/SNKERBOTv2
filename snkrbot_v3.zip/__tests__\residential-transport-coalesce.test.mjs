import assert from 'node:assert/strict';
import fs from 'node:fs';
const src = fs.readFileSync(new URL('../helpers/stock-monitor.js', import.meta.url), 'utf8');
assert.match(src, /const API_RESPONSE_COALESCE_MS/);
assert.match(src, /const apiTransportInFlight = new Map\(\)/);
assert.match(src, /const htmlTransportInFlight = new Map\(\)/);
assert.match(src, /const escalationKeyFor = \(host, proxy\)/);
assert.match(src, /RESIDENTIAL_MONITOR_CLEAN_POLLS \|\| '1'/);
console.log('residential transport coalescing: ok');
