// Checkout admission policy — pure functions only.
//
// Why this is a separate module:
//   1. Chromium launch args used to be built inline inside launchBrowser(). That
//      made them untestable and let a real bug hide: `--disable-features` was
//      emitted TWICE (once statically, once under LIGHTWEIGHT_TASK_MODE — which
//      is ON by default). Chromium honours only the last occurrence, so the first
//      list was silently discarded on every default launch. That re-enabled
//      site-per-process (one renderer process per site, the single biggest RAM
//      cost of a headless page) and dropped WebRtcHideLocalIpsWithMdns. Pulling
//      the args out here, merged and deduped by construction, kills the class.
//   2. Admission has to weigh RAM and residential-proxy concurrency TOGETHER.
//      They were separate gates, so a host could pass one check while the other
//      was saturated — many armed checkouts all clear the byte budget and then
//      open one sticky gateway session each, which is what makes a residential
//      proxy slow rather than high quality.
//
// Everything here is deterministic and I/O-free, so policy is asserted directly
// instead of being inferred from a real launch.

import { displayArgs } from './launch-mode.js';

export const GB = 1024 ** 3;

// Baseline switches. Feature flags get their own element so the merge below has
// exactly one place to normalise them.
const BASE_ARGS = Object.freeze([
  '--no-sandbox',
  '--disable-setuid-sandbox',
  '--disable-accelerated-2d-canvas',
  '--no-first-run',
  '--no-zygote',
  '--disable-infobars',
  '--disable-blink-features=AutomationControlled',
  '--disable-extensions',
  '--disable-plugins-discovery',
  '--disable-default-apps',
  '--disable-background-networking',
  '--disable-background-timer-throttling',
  '--disable-renderer-backgrounding',
  '--disable-backgrounding-occluded-windows',
  '--disable-sync',
  '--disable-translate',
  '--hide-scrollbars',
  '--mute-audio',
  '--safebrowsing-disable-auto-update',
  '--metrics-recording-only',
  '--use-mock-keychain',
  '--ignore-certificate-errors',
  '--allow-running-insecure-content',
  '--enforce-webrtc-ip-permission-check',
  '--force-webrtc-ip-handling-policy=disable_non_proxied_udp'
]);

// Features ALWAYS disabled. site-per-process is a deliberate stealth trade: it
// keeps one renderer for the whole browsing context instead of one per origin,
// which is where most of a checkout page's RAM goes.
const CORE_DISABLED_FEATURES = Object.freeze([
  'IsolateOrigins',
  'site-per-process',
  'WebRtcHideLocalIpsWithMdns'
]);

// Low-RAM-only extra features. Cache/telemetry subsystems a checkout never
// reads, so dropping them shrinks both RAM and process count.
const LOW_RAM_DISABLED_FEATURES = Object.freeze([
  'Translate',
  'MediaRouter',
  'OptimizationHints',
  'AutofillServerCommunication',
  'InterestFeedContentSuggestions',
  'CalculateNativeWinOcclusion'
]);

// Collapse every `--disable-features=a,b` in `args` into exactly ONE occurrence.
// Order is preserved and duplicates removed, so the result is stable for tests.
export const mergeDisableFeatures = (args = []) => {
  const features = [];
  const seen = new Set();
  const kept = [];
  for (const arg of args) {
    if (!arg || typeof arg !== 'string') continue;
    if (!arg.startsWith('--disable-features=')) { kept.push(arg); continue; }
    for (const raw of arg.slice('--disable-features='.length).split(',')) {
      const f = raw.trim();
      if (!f || seen.has(f)) continue;
      seen.add(f);
      features.push(f);
    }
  }
  if (features.length > 0) kept.push(`--disable-features=${features.join(',')}`);
  return kept;
};

const positiveInt = (value, fallback) => {
  const n = Number.parseInt(value, 10);
  return Number.isFinite(n) && n > 0 ? n : fallback;
};

// Build the final argv. `rendererLimit` caps simultaneous renderer processes:
// Chromium recycles a renderer instead of growing the process tree, which is the
// difference between surviving and OOM-ing on a small box.
export const buildChromiumArgs = ({
  proxy = null,
  viewport = null,
  lightweight = false,
  lowRam = false,
  rendererLimit = null,
  heapCapMb = null,
  headless = true,
  extraArgs = []
} = {}) => {
  const args = [...BASE_ARGS];

  // GPU handling belongs to the launch MODE, not the base list: `--disable-gpu`
  // is correct under headless (there is no GPU) but on a real display it also
  // kills the compositor and brings back most of the headless tells.
  for (const arg of displayArgs(headless)) args.push(arg);

  // Caller-supplied switches (e.g. the env-gated --disable-dev-shm-usage) go in
  // before the merge, so any feature flag they carry is deduped too.
  for (const extra of extraArgs) if (extra && typeof extra === 'string') args.push(extra);

  if (viewport?.width && viewport?.height) {
    args.push(`--window-size=${viewport.width},${viewport.height}`);
  }
  if (proxy?.host) args.push(`--proxy-server=${proxy.host}:${proxy.port}`);
  if (proxy?.username) args.push('--proxy-bypass-list=<-loopback>');

  if (lightweight || lowRam) {
    // Small caches: a per-task profile dir is discarded after the run, so a
    // larger disk cache buys nothing and only costs I/O.
    args.push(
      '--disk-cache-size=8388608',
      '--media-cache-size=1048576',
      '--disable-component-update',
      '--disable-domain-reliability',
      '--disable-breakpad',
      '--disable-crash-reporter',
      '--disable-hang-monitor',
      '--disable-prompt-on-repost',
      '--no-default-browser-check'
    );
  }

  const disabled = [...CORE_DISABLED_FEATURES];
  if (lightweight || lowRam) disabled.push(...LOW_RAM_DISABLED_FEATURES);
  args.push(`--disable-features=${disabled.join(',')}`);

  const limit = positiveInt(rendererLimit, 0);
  if (limit > 0) args.push(`--renderer-process-limit=${limit}`);

  // Per-renderer heap ceiling. Chromium's default young/old-gen sizing assumes
  // it may grow; without a cap a single heavy PDP renderer can balloon past the
  // whole host budget before V8 ever feels pressure (it counts its own heap, not
  // the container's). A cap makes V8 collect early instead of swapping.
  // `--js-flags` is passed to the RENDERER via the browser process; a checkout
  // tab needs far less than this, so it is generous enough to be invisible.
  const heapMb = positiveInt(heapCapMb, 0);
  if (heapMb > 0) args.push(`--js-flags=--max-old-space-size=${heapMb}`, '--js-flags=--max-semi-space-size=4');

  if (lowRam) args.push('--memory-pressure-off');

  // Single merged occurrence, guaranteed even if a caller injected its own.
  return mergeDisableFeatures(args);
};

// Renderer ceiling for a host. Unknown host returns 0 so Chromium keeps its own
// default. Small hosts get a tight limit that still leaves room for the browser
// process plus a couple of utility renderers.
export const recommendedRendererLimit = ({ totalMemoryBytes = 0 } = {}) => {
  const gb = totalMemoryBytes / GB;
  if (gb <= 0) return 0;
  if (gb <= 2) return 2;
  if (gb <= 4) return 3;
  if (gb <= 8) return 5;
  return 0;
};

export const LOW_RAM_GB = 2.5;

// Renderer heap ceiling for a host. Roughly a quarter of it, clamped: below this
// V8 thrashes, above it the cap stops protecting anything.
export const recommendedHeapCapMb = ({ totalMemoryBytes = 0 } = {}) => {
  const gb = totalMemoryBytes / GB;
  if (gb <= 0) return 0;
  return Math.round(Math.min(768, Math.max(128, (gb * 1024) / 4)));
};

export const isLowRamHost = (snapshot = null) => {
  const limit = Number(snapshot?.limitBytes || 0);
  return limit > 0 && limit / GB <= LOW_RAM_GB;
};

// Combined admission decision. `memory` is a memory-guard snapshot shape.
//
// Contract: ADVISORY. A `false` result is a reason to slow down or degrade,
// never an exception — the caller must not fail a checkout for it.
export const checkoutAdmission = ({
  memory = null,
  proxy = null,
  activeResidential = 0,
  maxResidential = 0,
  bootReserveBytes = 0
} = {}) => {
  const reasons = [];
  const limit = Number(memory?.limitBytes || 0);
  const current = Number(memory?.currentBytes || 0);

  let headroomBytes = null;
  if (limit > 0) {
    headroomBytes = limit - current - Math.max(0, Number(bootReserveBytes) || 0);
    if (headroomBytes <= 0) reasons.push('memory_saturated');
  }

  const isResidential = proxy?.proxy_type === 'residential';
  const residentialFull = isResidential && maxResidential > 0
    && activeResidential >= maxResidential;
  if (residentialFull) reasons.push('residential_sessions_full');

  // The host is the hard constraint: if a run cannot fit, waiting for a gateway
  // port would not help. Proxy saturation alone only means "wait your turn".
  const waitForProxy = residentialFull && headroomBytes > 0;

  return {
    admit: reasons.length === 0,
    waitForProxy,
    reasons,
    headroomBytes,
    isResidential,
    lowRam: isLowRamHost(memory)
  };
};

export const __test__ = { BASE_ARGS, CORE_DISABLED_FEATURES, LOW_RAM_DISABLED_FEATURES };
