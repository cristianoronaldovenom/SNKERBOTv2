import { jest } from '@jest/globals';

jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));

jest.unstable_mockModule('../../db/index.js', () => ({
  default: () => ({ where: () => ({ first: async () => null }) })
}));

const {
  isOosFailure,
  isDeclineFailure,
  isSessionFailure,
  detectDecline
} = await import('../../helpers/decline-detector.js');

const {
  verifyCartHasItem,
  requireCardIframe,
  waitForCardIframeReady
} = await import('../../helpers/autofill-utils.js');

const fakePage = ({ html = '', body = '', querySelector = null, querySelectorAll = null } = {}) => ({
  evaluate: async (fn) => {
    const origDoc = globalThis.document;
    globalThis.document = {
      body: { innerText: body || html.replace(/<[^>]+>/g, '') },
      querySelector: querySelector || (() => null),
      querySelectorAll: querySelectorAll || (() => [])
    };
    try { return await fn(); } finally { globalThis.document = origDoc; }
  },
  mainFrame: () => null,
  frames: () => []
});

describe('decline-detector: expanded patterns', () => {
  test('isDeclineFailure catches AVS mismatch', () => {
    expect(isDeclineFailure('AVS mismatch — please check billing address')).toBe(true);
  });
  test('isDeclineFailure catches 3D Secure failure', () => {
    expect(isDeclineFailure('3D Secure failed at gateway')).toBe(true);
  });
  test('isDeclineFailure catches payment processor error', () => {
    expect(isDeclineFailure('Payment gateway error: unable to authorize')).toBe(true);
  });
  test('isOosFailure catches size unavailable', () => {
    expect(isOosFailure('Size 10 not available')).toBe(true);
  });
  test('isSessionFailure catches session expired', () => {
    expect(isSessionFailure('Your session has expired, please sign in again')).toBe(true);
  });
  test('isSessionFailure catches checkout timed out', () => {
    expect(isSessionFailure('Checkout timed out due to inactivity')).toBe(true);
  });
  test('isSessionFailure catches reservation expired', () => {
    expect(isSessionFailure('The reservation on your cart expired')).toBe(true);
  });
  test('isSessionFailure does NOT match a regular decline', () => {
    expect(isSessionFailure('Your card was declined by the bank')).toBe(false);
  });
});

describe('decline-detector: detectDecline classification', () => {
  test('classifies session expired correctly', async () => {
    const page = fakePage({ body: 'Your session has expired. Please refresh and try again.' });
    const result = await detectDecline(page);
    expect(result?.type).toBe('session_expired');
  });
  test('classifies decline before session-expired (priority)', async () => {
    const page = fakePage({ body: 'Payment declined. Your session has expired anyway.' });
    const result = await detectDecline(page);
    expect(result?.type).toBe('decline');
  });
  test('returns null on clean page', async () => {
    const page = fakePage({ body: 'Order summary: 1 item — proceed to payment' });
    const result = await detectDecline(page);
    expect(result).toBeNull();
  });
});

describe('autofill-utils: verifyCartHasItem', () => {
  test('returns empty=true when body says "your cart is empty"', async () => {
    const page = fakePage({
      body: 'Your cart is empty. Continue shopping.',
      querySelectorAll: () => []
    });
    const result = await verifyCartHasItem(page, { timeout: 200 });
    expect(result.empty).toBe(true);
  });
  test('returns empty=false when cart-count element shows 1', async () => {
    const page = fakePage({
      body: 'Cart (1 item)',
      querySelector: (sel) => {
        if (sel.includes('cart-count')) return { textContent: '1', getAttribute: () => null };
        return null;
      },
      querySelectorAll: () => []
    });
    const result = await verifyCartHasItem(page, { timeout: 200 });
    expect(result.empty).toBe(false);
    expect(result.count).toBe(1);
  });
  test('counts items by item selector when no count element', async () => {
    const page = fakePage({
      body: 'Cart',
      querySelectorAll: (sel) => {
        if (sel.includes('cart-item')) return [{}, {}];
        return [];
      }
    });
    const result = await verifyCartHasItem(page, { timeout: 200 });
    expect(result.empty).toBe(false);
    expect(result.count).toBe(2);
  });
});

describe('autofill-utils: requireCardIframe', () => {
  test('throws when iframe never appears', async () => {
    const page = {
      mainFrame: () => null,
      frames: () => []
    };
    await expect(requireCardIframe(page, { timeout: 200 })).rejects.toThrow(/iframe did not load/i);
  });
  test('waitForCardIframeReady (default) does NOT throw, returns null', async () => {
    const page = {
      mainFrame: () => null,
      frames: () => []
    };
    const result = await waitForCardIframeReady(page, { timeout: 200 });
    expect(result).toBeNull();
  });
});
