// Targeted English-only check for the files touched by the anti-bot work.
//
// scan-encoding.mjs walks the whole tree and takes minutes; this checks a given
// list so an edit loop can verify quickly. Same two signals as the full scanner
// (CJK characters and mojibake), so it cannot pass something the real one fails.
import fs from 'node:fs';

const CJK = /[\u4e00-\u9fff]/;
// Built from escapes so this file never trips its own detector.
// Covers the UTF-8-read-as-cp1252 shape that real mojibake produces: a leading
// 0xC3/0xE2 byte followed by the continuation bytes it was mis-decoded with.
const MOJIBAKE = new RegExp([
  '\\u00c3[\\u00a2\\u00a9\\u00a8\\u00a0]',  // Ã¢ / Ã© / Ã¨ / Ã<space>
  '\\u00e2\\u20ac',                        // â€
  '\\u00f0\\u0178'                         // ðŸ
].join('|'));

const files = process.argv.slice(2);
let bad = 0;
for (const file of files) {
  if (!fs.existsSync(file)) { console.log(`MISSING\t${file}`); bad++; continue; }
  const text = fs.readFileSync(file, 'utf8');
  const cjk = CJK.test(text);
  const moji = MOJIBAKE.test(text);
  if (cjk || moji) {
    console.log(`${cjk ? 'CJK' : ''}${cjk && moji ? '+' : ''}${moji ? 'MOJIBAKE' : ''}\t${file}`);
    bad++;
  }
}
console.log(`checked=${files.length} problems=${bad}`);
process.exit(bad === 0 ? 0 : 1);
