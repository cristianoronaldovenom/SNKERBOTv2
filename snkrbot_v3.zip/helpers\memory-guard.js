import os from 'node:os';
import fs from 'node:fs/promises';
import { cpuPerformanceMode } from './cpu-performance.js';

const MB = 1024 * 1024;
const GB = 1024 * MB;
const MEMORY_CACHE_TTL_MS = 1500;
// Under saturation the 1.5s cache is too coarse: a burst of prewarm decisions
// arriving inside one window all read the same snapshot and each conclude there
// is headroom, so the cap gets exceeded. A very short "storm" window is armed by
// a caller that just decided to park a browser.
const MEMORY_STORM_WINDOW_MS = 400;
let stormUntil = 0;

let cache = null;
let cacheExpiresAt = 0;

// Low-RAM parked-browser policy (see recommendedPrewarmCap).
const LOW_RAM_PARKING = String(process.env.PREWARM_LOW_RAM ?? 'false').trim().toLowerCase() === 'true';
const LOW_RAM_PARKING_GB = 2.5;

const readNumberFile = async (file) => {
  try {
    const raw = (await fs.readFile(file, 'utf8')).trim();
    if (!raw || raw === 'max') return null;
    const n = Number(raw);
    return Number.isFinite(n) && n > 0 ? n : null;
  } catch (_) {
    return null;
  }
};

const readCgroupMemory = async () => {
  // cgroup v2 (Docker / modern Linux)
  const [v2Current, v2Max] = await Promise.all([
    readNumberFile('/sys/fs/cgroup/memory.current'),
    readNumberFile('/sys/fs/cgroup/memory.max'),
  ]);
  if (v2Max) return { currentBytes: v2Current || 0, limitBytes: v2Max };

  // cgroup v1 fallback
  const [v1Current, v1Limit] = await Promise.all([
    readNumberFile('/sys/fs/cgroup/memory/memory.usage_in_bytes'),
    readNumberFile('/sys/fs/cgroup/memory/memory.limit_in_bytes'),
  ]);
  if (v1Limit && v1Limit < 1024 * GB) {
    return { currentBytes: v1Current || 0, limitBytes: v1Limit };
  }

  return null;
};

export const getMemorySnapshot = async () => {
  const now = Date.now();
  // Only serve a cached snapshot outside a parking storm, so a burst re-reads.
  if (cache && cacheExpiresAt > now && now >= stormUntil) return cache;

  const cgroup = await readCgroupMemory();
  const usage = process.memoryUsage();
  const rss = usage.rss;
  const heapUsed = usage.heapUsed;
  const external = usage.external;

  if (cgroup) {
    cache = {
      currentBytes: cgroup.currentBytes,
      limitBytes: cgroup.limitBytes,
      availableBytes: Math.max(0, cgroup.limitBytes - cgroup.currentBytes),
      rssBytes: rss,
      heapUsedBytes: heapUsed,
      externalBytes: external,
      source: 'cgroup',
    };
  } else {
    cache = {
      currentBytes: Math.max(0, os.totalmem() - os.freemem()),
      limitBytes: os.totalmem(),
      availableBytes: os.freemem(),
      rssBytes: rss,
      heapUsedBytes: heapUsed,
      externalBytes: external,
      source: 'host',
    };
  }

  cacheExpiresAt = now + MEMORY_CACHE_TTL_MS;
  return cache;
};

export const isMemoryPressure = async (threshold = 0.82) => {
  const m = await getMemorySnapshot();
  return m.limitBytes > 0 && (m.currentBytes / m.limitBytes) >= threshold;
};

// Parked Chromium instances are intentionally treated as a scarce resource.
// Keep the fast prewarm path when there is plenty of headroom, but automatically
// reduce the number of parked browsers on smaller/loaded machines.
//
// Contract: the operator's `prewarm_max_parked` is a hard CEILING. This only ever
// lowers it (a small or loaded host cannot be trusted to hold that many browsers),
// never raises it. `max` mode used to raise a configured 3 to 4, which silently
// exceeded the setting.
export const recommendedPrewarmCap = async (configuredCap, { allowParking = true } = {}) => {
  if (!allowParking) return 0;
  const configured = Math.max(0, Math.min(10, Number.parseInt(configuredCap, 10) || 0));
  if (configured === 0) return 0;
  const m = await getMemorySnapshot();

  // Hard ceiling contract: never exceed the operator's configured cap. The old
  // branches clamped to a bare literal (4 / 5 / the mode ceiling), so a
  // configured 2 could come back as 4.
  const ceiling = Math.min(configured, cpuPerformanceMode() === 'max' ? 6 : 4);

  const usedRatio = m.limitBytes > 0 ? m.currentBytes / m.limitBytes : 0;
  if (usedRatio >= 0.82) return 0;
  if (usedRatio >= 0.72) return Math.min(configured, 1);
  // A single parked browser is ~250-500MB of idle RAM that a checkout then has
  // to share. On a <=2.5GB host that idle browser is what pushes the box into
  // swap and makes the eventual checkout slower than a cold launch, so parking
  // is off by default there and only kept when the operator opts in.
  if (!LOW_RAM_PARKING && m.limitBytes > 0 && m.limitBytes <= LOW_RAM_PARKING_GB * GB) return 0;
  if (m.limitBytes <= 3 * GB) return Math.min(configured, 1);
  if (m.limitBytes <= 6 * GB) return Math.min(configured, 2);
  if (m.limitBytes >= 12 * GB && usedRatio < 0.55) return ceiling;
  if (m.limitBytes >= 8 * GB && usedRatio < 0.65) return Math.min(ceiling, 5);
  return Math.min(ceiling, 4);
};

export const __resetMemoryCache = () => {
  cache = null;
  cacheExpiresAt = 0;
  stormUntil = 0;
};

// Called by the prewarm engine right after it decides to park a browser: the
// next few hundred ms of capability checks must not reuse a pre-park snapshot.
export const armParkingStorm = () => { stormUntil = Date.now() + MEMORY_STORM_WINDOW_MS; };
