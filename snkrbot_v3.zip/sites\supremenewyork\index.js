import { tryRequestFirstAddToCart } from '../../helpers/browser-request-atc.js';
import { navigateCartUnlessReady } from '../../helpers/site-checkout-fastpath.js';
import logger from '../../helpers/logger.js';
import { captureOrderSuccess } from '../../helpers/order-capture.js';
import { humanType, humanTypeInFrames, humanClick, humanSelect } from '../../helpers/human-type.js';
import {
  formatPostal, stripPhone, dismissAutocomplete, verifyFieldValue,
  requireCardIframe, FillReport, assertCriticalFields
} from '../../helpers/autofill-utils.js';
import {
  retryWithBackoff, guardedGoto, preOrderGuard, postClickGuard,
  takeFailureScreenshot
} from '../../helpers/checkout-guards.js';

const SUPREME_BASE = 'https://www.supremenewyork.com';
import { waitForAnySelector } from '../../helpers/site-runtime.js';
import { assertActionButtonIntent } from '../../helpers/checkout-controls.js';

const TIMEOUT = 12000;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const findFirst = async (page, selectorList, timeout = TIMEOUT) => {
  const selector = await waitForAnySelector(page, selectorList, { timeout });
  if (!selector) return null;
  const el = await page.$(selector).catch(() => null);
  return el ? { el, selector } : null;
};

const clickFirst = async (page, selectorList, { stage = '' } = {}) => {
  const found = await findFirst(page, selectorList, TIMEOUT);
  if (!found) throw new Error(`Could not find clickable element at stage "${stage}" — tried [${selectorList.join(', ')}]`);
  await humanClick(page, found.selector);
  return found.selector;
};

const fillField = async (page, selectorList, value, { type = 'text', label = '', report = null } = {}) => {
  const name = label || 'unnamed';
  if (!value) { if (report) report.record(name, true, 'skipped (empty)'); return false; }
  const found = await findFirst(page, selectorList, 8000);
  if (!found) { if (report) report.record(name, false, 'selector not found'); return false; }
  const formatted = type === 'postal' ? formatPostal(value) : type === 'phone' ? stripPhone(value) : String(value);
  for (let attempt = 0; attempt < 2; attempt++) {
    await found.el.click({ clickCount: 3 }).catch(() => {});
    await page.keyboard.press('Backspace').catch(() => {});
    await humanType(page, found.selector, formatted);
    await dismissAutocomplete(page);
    await page.keyboard.press('Tab').catch(() => {});
    const v = await verifyFieldValue(page, found.selector, formatted, type);
    if (v.ok) { if (report) report.record(name, true); return true; }
    logger.warn(`[Supreme] ${name} did not stick on attempt ${attempt + 1} (got "${v.actual}", expected "${v.expected}"), retrying`);
  }
  if (report) report.record(name, false, 'verify failed after retry');
  return false;
};

const SELECTORS = {
  styleButtons: [
    '.styles a', '.style-thumb', 'a[data-style-id]',
    '.product-styles a', '.style-picker a'
  ],
  sizeSelect: [
    'select#size', 'select[name="size"]', 'select#s',
    'select[data-testid="size-select"]'
  ],
  addToCart: [
    'input[name="commit"]', 'input[value="add to cart"]',
    'button[name="commit"]', 'input.cart-update',
    'input[value="add to basket"]'
  ],
  qtySelect: [
    'select[name="qty"]', 'input[name="qty"]',
    'select#qty', 'select[name="quantity"]'
  ],
  cartCheckout: [
    'a.checkout', 'a[href*="/checkout"]',
    'input[value="checkout"]', 'button.checkout'
  ],
  name: [
    'input#order_billing_name', 'input[name="order[billing_name]"]',
    'input[placeholder*="name"]', 'input[name="name"]'
  ],
  email: [
    'input#order_email', 'input[name="order[email]"]',
    'input[type="email"]', 'input[name="email"]'
  ],
  phone: [
    'input#order_tel', 'input[name="order[tel]"]',
    'input[type="tel"]', 'input[name="phone"]'
  ],
  address1: [
    'input#order_billing_address', 'input[name="order[billing_address]"]',
    'input[name="address"]', 'input[placeholder*="address"]'
  ],
  address2: [
    'input#order_billing_address_2', 'input[name="order[billing_address_2]"]',
    'input[placeholder*="apt"]'
  ],
  city: [
    'input#order_billing_city', 'input[name="order[billing_city]"]',
    'input[name="city"]'
  ],
  state: [
    'select#order_billing_state', 'select[name="order[billing_state]"]',
    'select[name="state"]'
  ],
  postalCode: [
    'input#order_billing_zip', 'input[name="order[billing_zip]"]',
    'input[name="zip"]', 'input[name="postalCode"]'
  ],
  country: [
    'select#order_billing_country', 'select[name="order[billing_country]"]'
  ],
  cardNumber: [
    'input#nnapolygon', 'input[placeholder*="number"]',
    'input[autocomplete="cc-number"]', 'input#cnb',
    'input[name="credit_card[number]"]'
  ],
  expMonth: [
    'select#credit_card_month', 'select[name="credit_card[month]"]',
    'select[data-testid="exp-month"]'
  ],
  expYear: [
    'select#credit_card_year', 'select[name="credit_card[year]"]',
    'select[data-testid="exp-year"]'
  ],
  cvv: [
    'input#orcer', 'input#vval', 'input[placeholder*="CVV"]',
    'input[autocomplete="cc-csc"]', 'input[name="credit_card[verification_value]"]'
  ],
  termsCheckbox: [
    'input#order_terms', 'input[name="order[terms]"]',
    'input[type="checkbox"]#terms'
  ],
  submitOrder: [
    'input[name="commit"][value*="process"]',
    'input[value="process payment"]',
    'button[type="submit"]', 'input.cart-update'
  ],
  orderConfirmation: [
    '.order-confirmation', '#confirmation', '.thank-you',
    'p.order-confirmation-message', '.confirmation-number'
  ]
};

const runSupreme = async ({ page, task }) => {
  const startedAt = Date.now();
  logger.info(`[Supreme] Starting checkout for task ${task.id}: ${task.url}`);
  page.setDefaultNavigationTimeout(30000);

  await guardedGoto(page, task.url, { taskId: task.id, stage: 'pdp_load' });
  await waitForAnySelector(page, [...SELECTORS.addToCart, ...SELECTORS.styleButtons], { timeout: 8000 });

  if (task.keywords) {
    const kws = task.keywords.toLowerCase().split(',').map((s) => s.trim()).filter(Boolean);
    if (kws.length > 0) {
      logger.info(`[Supreme] Matching style for keywords [${kws.join(', ')}]`);
      const matched = await page.evaluate((kws, selectors) => {
        for (const sel of selectors) {
          const links = Array.from(document.querySelectorAll(sel));
          const hit = links.find((el) => {
            const text = (el.textContent || el.getAttribute('alt') || el.getAttribute('title') || '').toLowerCase();
            return kws.every((k) => text.includes(k));
          });
          if (hit) { hit.click(); return true; }
        }
        return false;
      }, kws, SELECTORS.styleButtons).catch(() => false);
      if (matched) await waitForAnySelector(page, SELECTORS.addToCart, { timeout: 2500 });
    }
  }

  if (task.size) {
    const sizeSel = await findFirst(page, SELECTORS.sizeSelect, 5000);
    if (sizeSel) {
      await humanSelect(page, sizeSel.selector, task.size).catch(() => {});
      logger.info(`[Supreme] Size set to "${task.size}"`);
      await waitForAnySelector(page, SELECTORS.addToCart, { timeout: 2000 });
    }
  }

  if (task.quantity && task.quantity > 1) {
    const qtyFound = await findFirst(page, SELECTORS.qtySelect, 3000);
    if (qtyFound) {
      const tag = await qtyFound.el.evaluate((el) => el.tagName.toLowerCase());
      if (tag === 'select') await page.select(qtyFound.selector, String(task.quantity)).catch(() => {});
      else { await qtyFound.el.click({ clickCount: 3 }).catch(() => {}); await humanType(page, qtyFound.selector, String(task.quantity)); }
      logger.info(`[Supreme] Quantity set to ${task.quantity}`);
    }
  }

  await retryWithBackoff(async () => {
if (!(await tryRequestFirstAddToCart(page, SELECTORS.addToCart))) await clickFirst(page, SELECTORS.addToCart, { stage: 'add_to_cart' });
  }, { attempts: 3, baseMs: 800, label: 'Supreme ATC' });
  logger.info('[Supreme] Added to cart');

  await navigateCartUnlessReady({ page, cartUrl: `${SUPREME_BASE}/shop/cart`, navigate: guardedGoto, taskId: task.id, stage: 'cart_load' });
  await waitForAnySelector(page, SELECTORS.cartCheckout, { timeout: 6000 });
  await clickFirst(page, SELECTORS.cartCheckout, { stage: 'cart_to_checkout' });
  await page.waitForNavigation({ waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
  await postClickGuard(page, { taskId: task.id, stage: 'cart_to_checkout' });
  await waitForAnySelector(page, [...SELECTORS.name, ...SELECTORS.email, ...SELECTORS.cardNumber], { timeout: 10000 });

  const ship = task.shippingAddress;
  if (!ship) throw new Error('Shipping address missing at stage "fill_checkout"');
  const pay = task.paymentProfile;
  if (!pay) throw new Error('Payment profile missing at stage "fill_checkout"');

  const report = new FillReport(task.id, 'Supreme Checkout');
  const fullName = `${ship.first_name} ${ship.last_name}`.trim();
  await fillField(page, SELECTORS.name, fullName, { label: 'name', report });
  await fillField(page, SELECTORS.email, task.notification_email_address || ship.email, { label: 'email', report });
  await fillField(page, SELECTORS.phone, stripPhone(ship.phone), { label: 'phone', report });
  await fillField(page, SELECTORS.address1, ship.address1, { label: 'address', report });
  await fillField(page, SELECTORS.address2, ship.address2, { label: 'address2', report });
  await fillField(page, SELECTORS.city, ship.city, { label: 'city', report });
  await fillField(page, SELECTORS.postalCode, formatPostal(ship.zip), { label: 'zip', report });

  const stateSel = await findFirst(page, SELECTORS.state, 3000);
  if (stateSel) await humanSelect(page, stateSel.selector, ship.state).catch(() => {});
  const countrySel = await findFirst(page, SELECTORS.country, 2000);
  if (countrySel && ship.country) await humanSelect(page, countrySel.selector, ship.country).catch(() => {});

  await requireCardIframe(page, { timeout: 10000 });

  const cardFilled = await humanTypeInFrames(page, SELECTORS.cardNumber.join(', '), pay.card_number.replace(/\s/g, ''), { tabAfter: true });
  report.record('cardNumber', cardFilled);
  const expMo = await findFirst(page, SELECTORS.expMonth, 3000);
  if (expMo) await humanSelect(page, expMo.selector, String(parseInt(pay.expiration_month, 10))).catch(() => {});
  const expYr = await findFirst(page, SELECTORS.expYear, 3000);
  if (expYr) await humanSelect(page, expYr.selector, String(pay.expiration_year)).catch(() => {});
  await humanTypeInFrames(page, SELECTORS.cvv.join(', '), pay.cvv, { tabAfter: true });
  report.log();
  assertCriticalFields(report, ['name', 'email', 'phone', 'address', 'city', 'zip']);

  const termsBox = await findFirst(page, SELECTORS.termsCheckbox, 2000);
  if (termsBox) {
    const checked = await termsBox.el.evaluate((el) => el.checked);
    if (!checked) await humanClick(page, termsBox.selector);
  }

  assertCriticalFields(report, ['name', 'email', 'phone', 'address', 'city', 'zip', 'cardNumber']);
  await preOrderGuard(page, { taskId: task.id });
  await assertActionButtonIntent(page, SELECTORS.submitOrder, { stage: 'submit order', allow: /process payment|submit order|place order/i });
  await clickFirst(page, SELECTORS.submitOrder, { stage: 'submit_order' });

  const confirmed = await Promise.race([
    findFirst(page, SELECTORS.orderConfirmation, 60000),
    page.waitForFunction(() => /thank.you|confirmation|order.*placed/i.test(document.title + ' ' + (document.body?.innerText || '').slice(0, 500)), { timeout: 60000 }).then(() => ({ url: true })).catch(() => null)
  ]);
  if (!confirmed) throw new Error('Order confirmation not detected at stage "confirm_order"');

  const orderNumber = await page.evaluate(() => {
    const el = document.querySelector('.confirmation-number, .order-number, [class*="orderNumber" i]');
    return el ? el.textContent.trim() : null;
  }).catch(() => null);

  logger.info(`[Supreme] ✅ Order placed for task ${task.id}! Order: ${orderNumber || 'N/A'}`);
  await captureOrderSuccess({ page, taskId: task.id, orderNumber, productUrl: task.url, durationMs: Date.now() - startedAt }).catch(() => {});
};

export default runSupreme;
