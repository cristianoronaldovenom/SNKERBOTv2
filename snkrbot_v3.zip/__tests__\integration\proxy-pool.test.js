import { jest } from '@jest/globals';

jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));

let proxyRows = [];
let dbShouldThrow = false;
const selectMock = jest.fn(async () => {
  if (dbShouldThrow) throw new Error('db down');
  return proxyRows;
});
const db = jest.fn(() => ({
  where: () => ({ select: selectMock })
}));
jest.unstable_mockModule('../../db/index.js', () => ({ default: db }));

const { pickBackupProxy, shouldRotateProxyAfterFailure, loadActiveProxies, __resetForTests: resetPool } =
  await import('../../helpers/proxy-pool.js');
const { __resetForTests: resetIntelligence, recordOutcome } =
  await import('../../helpers/proxy-intelligence.js');

beforeEach(() => {
  proxyRows = [];
  dbShouldThrow = false;
  selectMock.mockClear();
  // Both modules cache state for ~5s; without this a later test observes the
  // previous test's pool/intelligence snapshot instead of its own fixtures.
  resetPool();
  resetIntelligence();
});

describe('shouldRotateProxyAfterFailure', () => {
  test('true on a bot-detection-class failure', () => {
    expect(shouldRotateProxyAfterFailure({
      task: {}, lastResult: { ok: false, stage: 'imperva' }
    })).toBe(true);
  });

  test('true even when a shipping/billing address is attached (banned proxy blocks the order)', () => {
    expect(shouldRotateProxyAfterFailure({
      task: { shipping_address_id: 5, billing_address_id: 5 },
      lastResult: { ok: false, error: 'Access denied (Cloudflare 1015)' }
    })).toBe(true);
  });

  test('false on a non-detection failure (OOS / decline)', () => {
    expect(shouldRotateProxyAfterFailure({
      task: {}, lastResult: { ok: false, stage: 'atc', error: 'out of stock' }
    })).toBe(false);
  });

  test('false on a successful result', () => {
    expect(shouldRotateProxyAfterFailure({
      task: {}, lastResult: { ok: true }
    })).toBe(false);
  });

  test('respects the explicit rotate_on_retry === false opt-out', () => {
    expect(shouldRotateProxyAfterFailure({
      task: { rotate_on_retry: false }, lastResult: { ok: false, stage: 'imperva' }
    })).toBe(false);
  });
});

describe('pickBackupProxy', () => {
  test('excludes already-tried proxies and returns an untried one', async () => {
    proxyRows = [
      { id: 1, host: 'p1.example', port: 8000 },
      { id: 2, host: 'p2.example', port: 8000 },
      { id: 3, host: 'p3.example', port: 8000 }
    ];
    const picked = await pickBackupProxy({
      host: 'pokemoncenter.com',
      excludeIds: new Set([1, 2])
    });
    expect(picked.id).toBe(3);
  });

  test('returns null when every proxy is excluded', async () => {
    proxyRows = [{ id: 1, host: 'p1.example', port: 8000 }];
    const picked = await pickBackupProxy({ host: 'x.com', excludeIds: new Set([1]) });
    expect(picked).toBeNull();
  });

  test('returns null when the pool is empty', async () => {
    proxyRows = [];
    const picked = await pickBackupProxy({ host: 'x.com', excludeIds: new Set() });
    expect(picked).toBeNull();
  });

  test('prefers the higher-scoring proxy for the host (proxy-intelligence ranking)', async () => {
    proxyRows = [
      { id: 10, host: 'bad.example', port: 8000 },
      { id: 20, host: 'good.example', port: 8000 }
    ];
    // Give proxy 20 a winning record on the host, proxy 10 a losing one.
    recordOutcome(20, 'topps.com', { success: true, latencyMs: 200 });
    recordOutcome(20, 'topps.com', { success: true, latencyMs: 200 });
    recordOutcome(10, 'topps.com', { success: false });
    const picked = await pickBackupProxy({ host: 'topps.com', excludeIds: new Set() });
    expect(picked.id).toBe(20);
  });

  test('never throws when the DB is unreachable — returns null', async () => {
    dbShouldThrow = true;
    const picked = await pickBackupProxy({ host: 'x.com', excludeIds: new Set() });
    expect(picked).toBeNull();
  });
});

describe('loadActiveProxies', () => {
  test('filters to non-deleted proxies via the query builder', async () => {
    proxyRows = [{ id: 1, host: 'p1.example', port: 8000 }];
    const rows = await loadActiveProxies();
    expect(rows).toHaveLength(1);
    expect(db).toHaveBeenCalledWith('proxies');
  });
});
