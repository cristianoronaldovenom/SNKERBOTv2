import { describe, test, expect, beforeEach, afterEach, jest } from '@jest/globals';

describe('workflow optimizations', () => {
  test('startTask is single-flight for duplicate starts', async () => {
    jest.unstable_mockModule('../../db/index.js', () => ({ default: () => ({}) }));
    // Static/source-level regression assertion: the wrapper must use an
    // active-task promise map rather than queueing duplicate full workflows.
    const fs = await import('fs/promises');
    const src = await fs.readFile(new URL('../../scripts/start-task.js', import.meta.url), 'utf8');
    expect(src).toContain('const activeTaskRuns = new Map()');
    expect(src).toContain('joining existing workflow');
  });

  test('hot-stock workflow skips the second drop wait', async () => {
    const fs = await import('fs/promises');
    const src = await fs.readFile(new URL('../../scripts/start-task.js', import.meta.url), 'utf8');
    expect(src).toContain('hot-stock handoff — skipping drop-time wait');
    expect(src).toContain("if (typeof task._instockAt === 'number')");
  });
});
