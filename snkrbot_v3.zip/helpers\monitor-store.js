const monitors = {};
const clients = {};
const globalClients = new Set();
const lastBroadcastAt = new Map();
const lastBroadcastFingerprint = new Map();
const MIN_GLOBAL_BROADCAST_MS = 1000;
const MIN_TASK_TICK_BROADCAST_MS = 1000;
const lastTaskTickAt = new Map();
const lastTaskTickFingerprint = new Map();
let activeMonitorCount = 0;
const activeMonitorHostCounts = new Map();

const safeHostname = (url) => {
  try { return new URL(url).hostname; } catch (_) { return null; }
};

const clampText = (value, max) => value == null ? value : String(value).slice(0, max);
const normalizeMonitorPatch = (data = {}) => ({
  ...data,
  productName: clampText(data.productName, 256),
  imageUrl: clampText(data.imageUrl, 1024),
  error: clampText(data.error, 512),
  availableSizes: Array.isArray(data.availableSizes)
    ? data.availableSizes.slice(0, 64).map((v) => String(v).slice(0, 64))
    : data.availableSizes,
});

export const getMonitor = (taskId) => monitors[taskId];

export const setMonitor = (taskId, data) => {
  const previous = monitors[taskId];
  const next = { ...previous, ...normalizeMonitorPatch(data), updatedAt: Date.now() };
  monitors[taskId] = next;
  const wasActive = previous?.active === true;
  const isActive = next.active === true;
  if (!wasActive && isActive) {
    activeMonitorCount += 1;
    const host = safeHostname(next.url);
    if (host) activeMonitorHostCounts.set(host, (activeMonitorHostCounts.get(host) || 0) + 1);
  } else if (wasActive && !isActive) {
    activeMonitorCount = Math.max(0, activeMonitorCount - 1);
    const host = safeHostname(previous?.url);
    if (host) {
      const count = Math.max(0, (activeMonitorHostCounts.get(host) || 0) - 1);
      if (count === 0) activeMonitorHostCounts.delete(host);
      else activeMonitorHostCounts.set(host, count);
    }
  }
  const now = Date.now();
  const fingerprint = JSON.stringify({
    active: next.active !== false, status: next.status ?? next.state ?? null,
    inStock: next.inStock ?? null, blocked: next.blocked ?? null,
    productName: next.productName ?? null, price: next.price ?? null,
    error: next.error ?? null, stage: next.stage ?? null
  });
  const lastAt = lastBroadcastAt.get(taskId) || 0;
  const lastFp = lastBroadcastFingerprint.get(taskId);
  if (fingerprint !== lastFp || now - lastAt >= MIN_GLOBAL_BROADCAST_MS) {
    lastBroadcastAt.set(taskId, now);
    lastBroadcastFingerprint.set(taskId, fingerprint);
    broadcastAllClients({ taskId: Number(taskId), type: 'monitor', ...next });
  }
};

export const clearMonitor = (taskId) => {
  const m = monitors[taskId];
  const wasActive = m?.active === true;
  const host = wasActive ? safeHostname(m?.url) : null;
  if (m) {
    if (typeof m.cleanup === 'function') {
      try { m.cleanup(); } catch (_) {}
    }
    if (m.intervalId) {
      try { clearInterval(m.intervalId); } catch (_) {}
      try { clearTimeout(m.intervalId); } catch (_) {}
    }
    m.active = false;
  }
  delete monitors[taskId];
  lastBroadcastAt.delete(taskId);
  lastBroadcastFingerprint.delete(taskId);
  lastTaskTickAt.delete(taskId);
  lastTaskTickFingerprint.delete(taskId);
  if (wasActive) {
    activeMonitorCount = Math.max(0, activeMonitorCount - 1);
    if (host) {
      const count = Math.max(0, (activeMonitorHostCounts.get(host) || 0) - 1);
      if (count === 0) activeMonitorHostCounts.delete(host);
      else activeMonitorHostCounts.set(host, count);
    }
  }
  const stopped = { status: 'stopped', taskId: Number(taskId), type: 'monitor' };
  broadcastToClients(taskId, stopped);
  broadcastAllClients(stopped);
};

export const isMonitoring = (taskId) => !!monitors[taskId]?.active;

export const getActiveMonitorCount = () => activeMonitorCount;

export const getActiveMonitorHostCount = (host) => activeMonitorHostCounts.get(host) || 0;

export const broadcastMonitorTick = (taskId, data = {}) => {
  const now = Date.now();
  const fingerprint = JSON.stringify({
    status: data.status ?? null,
    inStock: data.inStock ?? null,
    blocked: data.blocked ?? null,
    productName: data.productName ?? null,
    price: data.price ?? null,
    imageUrl: data.imageUrl ?? null,
    availableSizes: data.availableSizes ?? null,
    error: data.error ?? null
  });
  const lastAt = lastTaskTickAt.get(taskId) || 0;
  const lastFp = lastTaskTickFingerprint.get(taskId);
  if (fingerprint === lastFp && now - lastAt < MIN_TASK_TICK_BROADCAST_MS) return false;
  lastTaskTickAt.set(taskId, now);
  lastTaskTickFingerprint.set(taskId, fingerprint);
  broadcastToClients(taskId, data);
  return true;
};


export const getAllMonitors = () => monitors;

export const addClient = (taskId, res) => {
  if (!clients[taskId]) clients[taskId] = new Set();
  clients[taskId].add(res);
};

export const removeClient = (taskId, res) => {
  clients[taskId]?.delete(res);
  if (clients[taskId]?.size === 0) delete clients[taskId];
};

export const broadcastToClients = (taskId, data) => {
  const taskClients = clients[taskId];
  if (!taskClients || taskClients.size === 0) return;
  const payload = `data: ${JSON.stringify(data)}\n\n`;
  for (const res of taskClients) {
    try {
      if (res.writableEnded || res.destroyed) { taskClients.delete(res); continue; }
      if (res.writableNeedDrain) continue;
      res.write(payload);
    } catch (_) { taskClients.delete(res); }
  }
  if (taskClients.size === 0) delete clients[taskId];
};

export const addGlobalClient = (res) => globalClients.add(res);

export const removeGlobalClient = (res) => globalClients.delete(res);

export const broadcastAllClients = (data) => {
  if (!globalClients.size) return;
  const payload = `data: ${JSON.stringify(data)}\n\n`;
  for (const res of globalClients) {
    try {
      if (res.writableEnded || res.destroyed) { globalClients.delete(res); continue; }
      if (res.writableNeedDrain) continue;
      res.write(payload);
    } catch (_) { globalClients.delete(res); }
  }
};
