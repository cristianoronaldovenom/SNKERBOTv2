import fs from 'fs/promises';
import path from 'path';
import logger from './logger.js';

const STORE_DIR = path.join(process.cwd(), '.local');
const STORE_PATH = path.join(STORE_DIR, 'cookie-jar.json');

let saveTimer = null;
let pendingJar = null;

export const loadCookieJar = async () => {
  try {
    const raw = await fs.readFile(STORE_PATH, 'utf8');
    const parsed = JSON.parse(raw);
    const now = Date.now();
    const fresh = {};
    for (const [host, entry] of Object.entries(parsed)) {
      if (entry?.warmedAt && (now - entry.warmedAt) < 9 * 60 * 1000) {
        fresh[host] = entry;
      }
    }
    logger.info(`[CookieStore] Loaded ${Object.keys(fresh).length} fresh session(s) from disk`);
    return fresh;
  } catch (err) {
    if (err.code !== 'ENOENT') logger.warn(`[CookieStore] Load failed: ${err.message}`);
    return {};
  }
};

export const saveCookieJar = (jar) => {
  pendingJar = jar;
  if (saveTimer) return;
  saveTimer = setTimeout(async () => {
    saveTimer = null;
    const snapshot = pendingJar;
    pendingJar = null;
    try {
      await fs.mkdir(STORE_DIR, { recursive: true });
      await fs.writeFile(STORE_PATH, JSON.stringify(snapshot, null, 2));
    } catch (err) {
      logger.warn(`[CookieStore] Save failed: ${err.message}`);
    }
  }, 500);
};
