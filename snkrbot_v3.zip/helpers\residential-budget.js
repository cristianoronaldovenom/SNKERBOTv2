import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';

const DEFAULT_ROLE_MB = 1024;
const monitorBudgetMb = Math.max(64, Number(
  process.env.RESIDENTIAL_MONITOR_MONTHLY_BUDGET_MB
  || process.env.RESIDENTIAL_MONTHLY_BUDGET_MB
  || DEFAULT_ROLE_MB
));
const checkoutBudgetMb = Math.max(64, Number(
  process.env.RESIDENTIAL_CHECKOUT_MONTHLY_BUDGET_MB
  || process.env.RESIDENTIAL_MONTHLY_BUDGET_MB
  || DEFAULT_ROLE_MB
));
const roleBudgetsMb = { monitor: monitorBudgetMb, checkout: checkoutBudgetMb };
const BUDGET_BYTES = {
  monitor: Math.floor(monitorBudgetMb * 1024 * 1024),
  checkout: Math.floor(checkoutBudgetMb * 1024 * 1024),
};
const totalBudgetBytes = BUDGET_BYTES.monitor + BUDGET_BYTES.checkout;
const strict = String(process.env.RESIDENTIAL_BUDGET_STRICT ?? 'true').toLowerCase() !== 'false';
const reserveMb = {
  monitor: Math.max(1, Number(process.env.RESIDENTIAL_MONITOR_RESERVE_MB || 8)),
  checkout: Math.max(1, Number(process.env.RESIDENTIAL_CHECKOUT_RESERVE_MB || 8)),
};
const RESERVE_BYTES = {
  monitor: Math.floor(reserveMb.monitor * 1024 * 1024),
  checkout: Math.floor(reserveMb.checkout * 1024 * 1024),
};
const STATE_FILE = process.env.RESIDENTIAL_BUDGET_FILE || path.join(process.cwd(), 'data', 'residential-bandwidth.json');
const FLUSH_MS = 3000;

const monthKey = (d = new Date()) => `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`;

let state = { month: monthKey(), bytes: 0, byRole: { monitor: 0, checkout: 0, other: 0 } };
let dirty = false;
let flushTimer = null;

const ensureFreshMonth = () => {
  const month = monthKey();
  if (state.month !== month) {
    state = { month, bytes: 0, byRole: { monitor: 0, checkout: 0, other: 0 } };
    dirty = true;
  }
};

const load = () => {
  try {
    const parsed = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
    if (parsed?.month === monthKey() && Number.isFinite(parsed.bytes)) {
      state = {
        month: parsed.month,
        bytes: Math.max(0, parsed.bytes),
        byRole: {
          monitor: Math.max(0, parsed.byRole?.monitor || 0),
          checkout: Math.max(0, parsed.byRole?.checkout || 0),
          other: Math.max(0, parsed.byRole?.other || 0),
        },
      };
    }
  } catch (_) {}
};

const flush = () => {
  flushTimer = null;
  ensureFreshMonth();
  if (!dirty) return;
  try {
    fs.mkdirSync(path.dirname(STATE_FILE), { recursive: true });
    const tmp = `${STATE_FILE}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(state));
    fs.renameSync(tmp, STATE_FILE);
    dirty = false;
  } catch (_) {}
};

const scheduleFlush = () => {
  if (flushTimer) return;
  flushTimer = setTimeout(flush, FLUSH_MS);
  flushTimer.unref?.();
};

load();
ensureFreshMonth();

export const getResidentialBudgetConfig = () => ({
  monthlyBudgetBytes: totalBudgetBytes,
  monthlyBudgetMb: Number(((totalBudgetBytes / 1024 / 1024)).toFixed(2)),
  roleBudgetsMb: { ...roleBudgetsMb },
  strict,
  reserveBytes: { ...RESERVE_BYTES },
  reserveMb: { ...reserveMb },
});

export const recordResidentialBytes = (bytes, role = 'other') => {
  const n = Math.max(0, Math.floor(Number(bytes) || 0));
  if (!n) return;
  ensureFreshMonth();
  state.bytes += n;
  const bucket = role === 'monitor' || role === 'checkout' ? role : 'other';
  state.byRole[bucket] += n;
  dirty = true;
  scheduleFlush();
};

export const remainingResidentialBytes = (role = null) => {
  ensureFreshMonth();
  if (role === 'monitor' || role === 'checkout') {
    return Math.max(0, BUDGET_BYTES[role] - state.byRole[role]);
  }
  return Math.max(0, totalBudgetBytes - state.bytes);
};

export const residentialBudgetExceeded = (role = null) => remainingResidentialBytes(role) <= 0;

// Remaining allowance as a 0..1 share of that role's own budget. Callers that
// shape behavior on pressure (poll backoff) need a ratio, and a ratio must be
// against the role's budget or a monitor would look starved because a checkout
// spent its own allowance.
export const remainingResidentialRatio = (role = 'monitor') => {
  ensureFreshMonth();
  const safeRole = role === 'monitor' ? 'monitor' : 'checkout';
  const budget = BUDGET_BYTES[safeRole];
  if (!Number.isFinite(budget) || budget <= 0) return null;
  return Math.max(0, Math.min(1, remainingResidentialBytes(safeRole) / budget));
};

// In strict mode, each role has its own monthly allowance and a small reserve
// so the last few megabytes are not consumed by a new session.
export const canStartResidentialSession = (role = 'checkout') => {
  if (!strict) return true;
  const safeRole = role === 'monitor' ? 'monitor' : 'checkout';
  return remainingResidentialBytes(safeRole) > RESERVE_BYTES[safeRole];
};

export const residentialBudgetStatus = () => {
  ensureFreshMonth();
  const totalRemaining = remainingResidentialBytes();
  const roleStatus = (role) => {
    const remaining = remainingResidentialBytes(role);
    const budget = BUDGET_BYTES[role];
    return {
      usedBytes: state.byRole[role],
      usedMb: Number((state.byRole[role] / 1024 / 1024).toFixed(2)),
      remainingBytes: remaining,
      remainingMb: Number((remaining / 1024 / 1024).toFixed(2)),
      monthlyBudgetMb: roleBudgetsMb[role],
      percentUsed: Number(((state.byRole[role] / budget) * 100).toFixed(2)),
      reserveMb: reserveMb[role],
    };
  };
  return {
    month: state.month,
    usedBytes: state.bytes,
    usedMb: Number((state.bytes / 1024 / 1024).toFixed(2)),
    remainingBytes: totalRemaining,
    remainingMb: Number((totalRemaining / 1024 / 1024).toFixed(2)),
    monthlyBudgetBytes: totalBudgetBytes,
    monthlyBudgetMb: Number((totalBudgetBytes / 1024 / 1024).toFixed(2)),
    percentUsed: Number(((state.bytes / totalBudgetBytes) * 100).toFixed(2)),
    strict,
    monitor: roleStatus('monitor'),
    checkout: roleStatus('checkout'),
    roleBudgetsMb: { ...roleBudgetsMb },
    byRole: {
      monitorMb: Number((state.byRole.monitor / 1024 / 1024).toFixed(2)),
      checkoutMb: Number((state.byRole.checkout / 1024 / 1024).toFixed(2)),
      otherMb: Number((state.byRole.other / 1024 / 1024).toFixed(2)),
    },
  };
};

export const flushResidentialBudget = () => flush();

// --- Live residential session concurrency -------------------------------------
//
// The monthly byte budget says nothing about how many residential SESSIONS are
// open simultaneously. Firing 100 admissions at once passes the byte check and
// then opens 100 sticky upstream sessions, which is precisely what turns a good
// residential gateway slow: the provider rotates/reuses the same pool of exit
// IPs and every request queues behind them. Cap it independently, per role.
//
// Semantics: bounded wait, never throws. After the timeout the caller is admitted
// anyway — a slightly over-subscribed gateway beats a missed drop. Release is an
// idempotent token, matching run-queue's slot contract.
const MAX_RESIDENTIAL_SESSIONS = Math.max(1, Number(
  process.env.RESIDENTIAL_MAX_SESSIONS_PER_ROLE || 4
));
const SESSION_WAIT_TIMEOUT_MS = Math.max(250, Number(
  process.env.RESIDENTIAL_SESSION_WAIT_MS || 2500
));
const sessionActive = { monitor: 0, checkout: 0 };
const sessionWaiters = { monitor: [], checkout: [] };

const safeRole = (role) => (role === 'monitor' ? 'monitor' : 'checkout');

export const activeResidentialSessions = (role = null) =>
  (role ? sessionActive[safeRole(role)] : sessionActive.monitor + sessionActive.checkout);

export const maxResidentialSessions = () => MAX_RESIDENTIAL_SESSIONS;

const takeSession = (role) => {
  sessionActive[role] += 1;
  let released = false;
  return () => {
    if (released) return;
    released = true;
    sessionActive[role] = Math.max(0, sessionActive[role] - 1);
    const next = sessionWaiters[role].shift();
    if (next) next();
  };
};

// Returns a release token, or null when the budget/role was not residential.
export const acquireResidentialSession = async (role = 'checkout') => {
  const safe = safeRole(role);
  if (sessionActive[safe] >= MAX_RESIDENTIAL_SESSIONS) {
    await new Promise((resolve) => {
      let settled = false;
      const done = () => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve();
      };
      const timer = setTimeout(() => {
        // Timed out: drop out of the queue so we do not get woken later and
        // double-count, then proceed over the cap.
        const q = sessionWaiters[safe];
        const idx = q.indexOf(done);
        if (idx >= 0) q.splice(idx, 1);
        done();
      }, SESSION_WAIT_TIMEOUT_MS);
      timer.unref?.();
      sessionWaiters[safe].push(done);
    });
  }
  return takeSession(safe);
};

export const __resetResidentialSessions = () => {
  sessionActive.monitor = 0;
  sessionActive.checkout = 0;
  sessionWaiters.monitor.length = 0;
  sessionWaiters.checkout.length = 0;
};

process.on('exit', flush);
process.on('SIGTERM', () => { flush(); });
process.on('SIGINT', () => { flush(); });
