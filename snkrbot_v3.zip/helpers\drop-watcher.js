// Drop-time hot poller — fires the checkout the millisecond stock appears.
//
// Why pro bots ship this: at major drops (Pokemon TCG restock, Topps Chrome),
// the product page goes from "Sold Out" to "Add to Cart" at a precise moment.
// A bot that polls every 5 seconds can lose a 3-second window. Stellar/Hidden
// poll the product API every 200-400ms starting 30s before drop time and fire
// the actual checkout pipeline within ~50ms of detecting stock.
//
// We use got-scraping (HTTP, no browser) for the polling so it's cheap and
// doesn't hold a Puppeteer page open for 30 seconds wasting RAM. Stock check
// is a cheap signal probe, not a full ATC; the real ATC happens in the
// site adapter once we trigger the run.
import { gotScraping } from 'got-scraping';
import logger from './logger.js';
import { tlsRequest, tlsPreconnect } from './tls-client.js';
import { directGotAgents } from './network-performance.js';

// Stealth HTTP fetch — try the Go TLS sidecar first (Chrome JA3 fingerprint),
// fall back to got-scraping (Node TLS) if the sidecar isn't running. Returns
// { body, statusCode } in either case, or { body:'', statusCode:0 } on error.
const stealthFetch = async (url, timeoutMs = 4000) => {
  const tls = await tlsRequest({
    url,
    timeoutMs,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
      'Accept-Language': 'en-CA,en-US;q=0.9,en;q=0.8',
      'Accept-Encoding': 'gzip, deflate, br',
      'Sec-Fetch-Dest': 'document',
      'Sec-Fetch-Mode': 'navigate',
      'Sec-Fetch-Site': 'none',
      'Upgrade-Insecure-Requests': '1'
    }
  });
  if (tls.ok) return { body: tls.body || '', statusCode: tls.status };
  // Fall back to got-scraping (Node OpenSSL TLS — distinguishable but works)
  try {
    const r = await gotScraping({ url, timeout: { request: timeoutMs }, throwHttpErrors: false, agent: directGotAgents });
    return { body: r.body || '', statusCode: r.statusCode };
  } catch (_) { return { body: '', statusCode: 0 }; }
};

// Site-specific stock signal probes. Each returns true when stock is detected.
// Add more sites as adapters are built out.
const STOCK_PROBES = {
  'pokemoncenter.ca': async (url) => {
    const { body, statusCode } = await stealthFetch(url);
    if (statusCode !== 200) return false;
    // Pokemon Center marks OOS via "out-of-stock" class or "Sold Out" text;
    // ATC button text is "Add to Cart" / "Add to bag".
    const oos = /out-of-stock|sold[\s-]?out|notify[\s-]?me/i.test(body);
    const hasAtc = /add[\s-]?to[\s-]?(cart|bag)|"availability":\s*"InStock"/i.test(body);
    return hasAtc && !oos;
  },
  'topps.com': async (url) => {
    const { body, statusCode } = await stealthFetch(url);
    if (statusCode !== 200) return false;
    const oos = /out[\s-]?of[\s-]?stock|sold[\s-]?out|"availability":\s*"OutOfStock"/i.test(body);
    const hasAtc = /add[\s-]?to[\s-]?(cart|bag)|"availability":\s*"InStock"/i.test(body);
    return hasAtc && !oos;
  },
  'walmart.ca': async (url) => {
    const { body, statusCode } = await stealthFetch(url);
    if (statusCode !== 200) return false;
    const oos = /out[\s-]?of[\s-]?stock|sold[\s-]?out|currently[\s-]?unavailable/i.test(body);
    const hasAtc = /add[\s-]?to[\s-]?cart|"availability":\s*"InStock"|"availabilityStatus":\s*"AVAILABLE"/i.test(body);
    return hasAtc && !oos;
  },
  'bestbuy.ca': async (url) => {
    const { body, statusCode } = await stealthFetch(url);
    if (statusCode !== 200) return false;

    // Prefer the explicit online-availability signal. In-store stock must not
    // trigger an online checkout attempt.
    if (/"isAvailableOnline"\s*:\s*true/i.test(body)) return true;
    if (/"isAvailableOnline"\s*:\s*false/i.test(body)) return false;

    const oos = /sold[\s-]?out|coming[\s-]?soon|not[\s-]?available/i.test(body);
    const hasAtc = /add[\s-]?to[\s-]?cart|addToCartButton|"availability":\s*"InStock"/i.test(body);
    return hasAtc && !oos;
  },
  'target.com': async (url) => {
    const { body, statusCode } = await stealthFetch(url);
    if (statusCode !== 200) return false;
    const oos = /out[\s-]?of[\s-]?stock|sold[\s-]?out|temporarily[\s-]?out/i.test(body);
    const hasAtc = /ship[\s-]?it|add[\s-]?to[\s-]?cart|"availability":\s*"InStock"/i.test(body);
    return hasAtc && !oos;
  },
  'gamestop.ca': async (url) => {
    const { body, statusCode } = await stealthFetch(url);
    if (statusCode !== 200) return false;
    const oos = /out[\s-]?of[\s-]?stock|sold[\s-]?out|not[\s-]?available|unavailable/i.test(body);
    const hasAtc = /add[\s-]?to[\s-]?cart|"availability":\s*"InStock"/i.test(body);
    return hasAtc && !oos;
  },
  'amazon.ca': async (url) => {
    const { body, statusCode } = await stealthFetch(url);
    if (statusCode !== 200) return false;
    const oos = /currently[\s-]?unavailable|out[\s-]?of[\s-]?stock|"outOfStock"/i.test(body);
    const hasAtc = /add[\s-]?to[\s-]?cart|id="add-to-cart-button"|"buyNow"/i.test(body);
    return hasAtc && !oos;
  }
};

const probeCache = new Map();
const PROBE_CACHE_MS = 200;
const PROBE_INFLIGHT = new Map();

const probeStockCoalesced = async (url, probe) => {
  const now = Date.now();
  const cached = probeCache.get(url);
  if (cached && cached.expiresAt > now) return cached.value;

  const inFlight = PROBE_INFLIGHT.get(url);
  if (inFlight) return inFlight;

  const promise = Promise.resolve().then(() => probe(url)).catch(() => false);
  PROBE_INFLIGHT.set(url, promise);
  try {
    const value = await promise;
    probeCache.set(url, { value: Boolean(value), expiresAt: Date.now() + PROBE_CACHE_MS });
    if (probeCache.size > 200) {
      const cutoff = Date.now();
      for (const [key, entry] of probeCache) { if (entry.expiresAt <= cutoff) probeCache.delete(key); }
    }
    return Boolean(value);
  } finally {
    PROBE_INFLIGHT.delete(url);
  }
};

const probeFor = (url) => {
  try {
    const host = new URL(url).hostname.replace(/^www\./, '');
    return STOCK_PROBES[host] || null;
  } catch (_) { return null; }
};

// Wait until startAt, but in the final 30s window switch to hot polling so
// we fire AT the millisecond stock appears (which is sometimes seconds before
// the official drop time on busy sites).
export const waitForDropAndStock = async ({ task, sleep, randInt, hotPollMs = 350 }) => {
  if (!task.start_at) return;
  const target = new Date(task.start_at).getTime();
  if (isNaN(target)) return;

  const HOT_WINDOW_MS = 30_000;
  const now = Date.now();
  const wait = target - now;
  if (wait <= 0) return;

  // Coarse wait until we enter the hot window
  if (wait > HOT_WINDOW_MS) {
    logger.info(`[DropWatcher] Task ${task.id} sleeping ${Math.round((wait - HOT_WINDOW_MS) / 1000)}s until T-30s hot-poll window`);
    await sleep(wait - HOT_WINDOW_MS);
  }

  const probe = probeFor(task.url);
  if (!probe) {
    // No probe registered for this site — fall back to plain wait + jitter
    const remaining = target - Date.now();
    if (remaining > 0) {
      const jitter = randInt ? randInt(-200, 800) : 0;
      logger.info(`[DropWatcher] Task ${task.id} no stock probe — plain wait ${remaining + jitter}ms`);
      await sleep(remaining + jitter);
    }
    return;
  }

  // CRITICAL: never block past drop time itself, only use polling to fire
  // EARLY if stock appears before drop. Once we hit T+0 we proceed regardless,
  // because (a) a probe might be wrong (markup drift, challenge page, rate
  // limit), and (b) blocking 5 minutes past drop is the opposite of "fire
  // immediately." Adaptive backoff after T+0: a few quick post-drop polls
  // for sites that release a hair late, then proceed.
  logger.info(`[DropWatcher] Task ${task.id} entering HOT POLL @ ${hotPollMs}ms intervals — racing to detect stock pre-drop`);
  // Pay the TCP/TLS/H2 setup now, not on the first probe: the pooled socket is
  // left warm so poll #1 costs one RTT instead of a full handshake.
  tlsPreconnect({ url: task.url }).catch(() => {});
  const POST_DROP_GRACE_MS = 8_000; // max 8s past drop to wait for late-release stock
  const deadline = target + POST_DROP_GRACE_MS;
  let polls = 0;
  let pollMs = hotPollMs;
  while (Date.now() < deadline) {
    polls += 1;
    const inStock = await probeStockCoalesced(task.url, probe);
    if (inStock) {
      const offset = Date.now() - target;
      logger.info(`[DropWatcher] Task ${task.id} STOCK DETECTED after ${polls} polls (${offset >= 0 ? '+' : ''}${offset}ms vs drop time) — firing checkout`);
      return;
    }
    // Adaptive pacing: stay aggressive in the final 5s before drop, ease off
    // afterward to avoid hammering origin if probe is broken.
    const msToDrop = target - Date.now();
    if (msToDrop < 0) pollMs = Math.min(1500, pollMs + 100); // backoff post-drop
    else if (msToDrop < 5_000) pollMs = hotPollMs; // stay hot in final 5s
    const jitter = Math.floor((Math.random() - 0.5) * 100);
    await sleep(pollMs + jitter);
  }
  logger.info(`[DropWatcher] Task ${task.id} grace window elapsed (${POST_DROP_GRACE_MS}ms past drop) — proceeding to checkout regardless of probe`);
};
