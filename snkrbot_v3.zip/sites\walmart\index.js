import { tryRequestFirstAddToCart } from '../../helpers/browser-request-atc.js';
import { navigateCartUnlessReady } from '../../helpers/site-checkout-fastpath.js';
import logger from '../../helpers/logger.js';
import { humanType, humanTypeInFrames, humanClick, humanSelect } from '../../helpers/human-type.js';
import {
  formatPostal, stripPhone, dismissAutocomplete, verifyFieldValue,
  requireCardIframe, verifyCartHasItem, FillReport,
  assertCriticalFields, dismissAddressSuggestion
} from '../../helpers/autofill-utils.js';
import {
  guardedGoto, preOrderGuard, postClickGuard, takeFailureScreenshot
} from '../../helpers/checkout-guards.js';
import { captureOrderSuccess } from '../../helpers/order-capture.js';
import { notify } from '../../helpers/notifier.js';

const BASE_URL = 'https://www.walmart.ca';
import { waitForAnySelector } from '../../helpers/site-runtime.js';
import { assertActionButtonIntent } from '../../helpers/checkout-controls.js';

const TIMEOUT = 15000;

const SELECTORS = {
  addToCart: [
    'button[data-testid="add-to-cart-btn"]',
    'button[aria-label="Add to cart"]',
    'button.prod-ProductCTA--primary',
    'button[data-automation="cta-button"]',
    'button.add-to-cart-btn',
    '[data-testid="add-to-cart"]'
  ],
  qtyInput: [
    'select.qty-selector',
    'input[data-testid="quantity-input"]',
    'select[aria-label="Quantity"]',
    'input[name="quantity"]',
    'select.product-quantity'
  ],
  cartCheckout: [
    'button[data-testid="checkout-btn"]',
    'a[href*="/checkout"]',
    'button.checkout-btn',
    '[data-automation="checkout-button"]'
  ],
  guestCheckout: [
    'button[data-testid="guest-checkout"]',
    'a[data-testid="continue-as-guest"]',
    'button.guest-checkout-btn'
  ],
  email:      ['input[name="email"]', 'input#email', 'input[type="email"]', 'input[data-testid="email-input"]'],
  firstName:  ['input[name="firstName"]', 'input[data-testid="first-name"]', 'input#firstName'],
  lastName:   ['input[name="lastName"]', 'input[data-testid="last-name"]', 'input#lastName'],
  address1:   ['input[name="addressLineOne"]', 'input[name="address1"]', 'input[data-testid="address-line-1"]'],
  address2:   ['input[name="addressLineTwo"]', 'input[name="address2"]', 'input[data-testid="address-line-2"]'],
  city:       ['input[name="city"]', 'input[data-testid="city"]'],
  state:      ['select[name="state"]', 'select[data-testid="state"]', 'select#state'],
  postalCode: ['input[name="postalCode"]', 'input[data-testid="postal-code"]', 'input[name="zipCode"]'],
  phone:      ['input[name="phone"]', 'input[data-testid="phone"]', 'input[type="tel"]'],
  cardNumber: ['input[name="cardNumber"]', 'input[data-testid="card-number"]', 'input[autocomplete="cc-number"]'],
  cardName:   ['input[name="cardHolderName"]', 'input[data-testid="card-name"]', 'input[autocomplete="cc-name"]'],
  expMonth:   ['select[name="expMonth"]', 'select[data-testid="exp-month"]'],
  expYear:    ['select[name="expYear"]', 'select[data-testid="exp-year"]'],
  cvv:        ['input[name="cvv"]', 'input[data-testid="cvv"]', 'input[autocomplete="cc-csc"]'],
  placeOrder: [
    'button[data-testid="place-order-btn"]',
    'button.place-order',
    'button[aria-label="Place order"]'
  ],
  orderConfirmation: [
    '.order-confirmation',
    '[data-testid="order-confirmation"]',
    '.thank-you-message',
    'h1.order-number'
  ]
};

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const findFirst = async (page, selectorList, timeout = TIMEOUT) => {
  const selector = await waitForAnySelector(page, selectorList, { timeout });
  if (!selector) return null;
  const el = await page.$(selector).catch(() => null);
  return el ? { el, selector } : null;
};

const clickFirst = async (page, selectorList, { stage = '' } = {}) => {
  const found = await findFirst(page, selectorList, TIMEOUT);
  if (!found) throw new Error(`Could not find clickable element at stage "${stage}" — tried [${selectorList.join(', ')}]`);
  await humanClick(page, found.selector);
  return found.selector;
};

const fillField = async (page, selectorList, value, { label = '', report = null } = {}) => {
  const name = label || 'unnamed';
  if (!value) { if (report) report.record(name, true, 'skipped (empty)'); return false; }
  const found = await findFirst(page, selectorList, 8000);
  if (!found) { if (report) report.record(name, false, 'selector not found'); return false; }
  await found.el.click({ clickCount: 3 }).catch(() => {});
  await page.keyboard.press('Backspace').catch(() => {});
  await humanType(page, found.selector, String(value));
  await dismissAutocomplete(page, found.selector);
  await page.keyboard.press('Tab').catch(() => {});
  if (report) report.record(name, true);
  return true;
};

// Prefer "Ship to home" over in-store pickup so a shippable order isn't silently
// converted to a pickup order (or stalled on an unselected fulfillment choice).
// Best-effort and non-fatal — mirrors the Pokemon Center autoselect pattern.
const selectFulfillment = async (page) => {
  const clicked = await page.evaluate(() => {
    const wanted = /ship(ping)?( to)?( home| it)?|deliver/i;
    const pickup = /pick ?up|in[- ]store/i;
    // Exclude marketing/help text that merely mentions "ship"/"delivery" so we
    // don't click a "Free shipping over $35" banner or a "delivery options" link.
    const bad = /free shipping|shipping over|options|instructions|estimate|policy|learn more|details|about/i;
    const radios = Array.from(document.querySelectorAll('input[type="radio"]'));
    for (const r of radios) {
      const label = (r.closest('label')?.textContent || r.getAttribute('aria-label') || '').trim();
      if (wanted.test(label) && !pickup.test(label) && !bad.test(label)) { r.click(); return label.slice(0, 40) || 'ship'; }
    }
    // Tile fallback is restricted to fulfillment-scoped radio widgets — never all
    // <button>s (a "Shipping" accordion header would otherwise get clicked).
    const tiles = Array.from(document.querySelectorAll(
      '[data-testid*="fulfillment" i] [role="radio"], [data-testid*="fulfillment" i] button, [role="radio"]'
    ));
    for (const t of tiles) {
      const txt = (t.textContent || t.getAttribute('aria-label') || '').trim();
      if (wanted.test(txt) && !pickup.test(txt) && !bad.test(txt)) { t.click(); return txt.slice(0, 40) || 'ship'; }
    }
    return null;
  }).catch(() => null);
  if (clicked) { logger.info(`[Walmart] Fulfillment set to shipping (${clicked})`); await sleep(75); }
};

// Autoselect the first available shipping method so checkout can advance to
// payment when Walmart requires an explicit choice. Best-effort, non-fatal.
const selectShippingMethod = async (page) => {
  const picked = await page.evaluate(() => {
    const groups = [
      'input[name*="shippingMethod" i]',
      'input[name*="deliveryMethod" i]',
      'input[data-testid*="shipping-option" i]',
      '.shipping-method-list input[type="radio"]',
      '[data-testid*="shipping-method" i] input[type="radio"]'
    ];
    for (const sel of groups) {
      const els = document.querySelectorAll(sel);
      if (els.length > 0) { els[0].click(); return sel; }
    }
    return null;
  }).catch(() => null);
  if (picked) { logger.info('[Walmart] Shipping method autoselected'); await sleep(75); }
  return !!picked;
};

// Advance the checkout wizard by clicking a Continue/Next button. Refuses to
// click any button whose text/label/testid looks like the final Place Order /
// Pay action — otherwise a generic type="submit" match could submit the order
// before payment is filled and before the pre-order 3DS/critical-field guards.
const clickContinueIfPresent = async (page, { stage, taskId, allowSubmit = false } = {}) => {
  const sel = allowSubmit
    ? 'button[data-testid="continue-btn"], button.continue-btn, button[type="submit"]'
    : 'button[data-testid="continue-btn"], button.continue-btn';
  const btn = await page.$(sel);
  if (!btn) return false;
  const meta = await btn.evaluate((b) =>
    `${b.textContent || ''} ${b.getAttribute('aria-label') || ''} ${b.getAttribute('data-testid') || ''}`
  ).catch(() => '');
  if (/place order|pay now|buy now|complete (order|purchase)|submit order/i.test(meta)) {
    logger.warn('[Walmart] clickContinueIfPresent skipped a Place-Order-like button — not clicking before payment');
    return false;
  }
  const enabled = await btn.evaluate((b) => !b.disabled).catch(() => true);
  if (!enabled) return false;
  await btn.click().catch(() => {});
  await sleep(75);
  await postClickGuard(page, { taskId, stage });
  return true;
};

const setQuantity = async (page, quantity) => {
  if (!quantity || quantity <= 1) return;
  const found = await findFirst(page, SELECTORS.qtyInput, 5000);
  if (!found) { logger.warn('[Walmart] Quantity input not found — proceeding with default qty'); return; }
  const tag = await found.el.evaluate((el) => el.tagName.toLowerCase());
  if (tag === 'select') {
    await page.select(found.selector, String(quantity)).catch(() => {});
  } else {
    await found.el.click({ clickCount: 3 }).catch(() => {});
    await page.keyboard.press('Backspace').catch(() => {});
    await humanType(page, found.selector, String(quantity));
  }
  await sleep(500);
  logger.info(`[Walmart] Quantity set to ${quantity}`);
};

const runWalmart = async ({ page, task }) => {
  const startedAt = Date.now();
  logger.info(`[Walmart] Starting checkout for task ${task.id}: ${task.url}`);
  page.setDefaultNavigationTimeout(30000);

  await guardedGoto(page, task.url, { taskId: task.id, stage: 'pdp_load' });
  await waitForAnySelector(page, SELECTORS.addToCart, { timeout: 10000 });

  await setQuantity(page, task.quantity);
if (!(await tryRequestFirstAddToCart(page, SELECTORS.addToCart))) await clickFirst(page, SELECTORS.addToCart, { stage: 'add_to_cart' });
  logger.info('[Walmart] Added to cart');

  await navigateCartUnlessReady({ page, cartUrl: `${BASE_URL}/cart`, navigate: guardedGoto, taskId: task.id, stage: 'cart_load' });

  const cartCheck = await verifyCartHasItem(page, { timeout: 6000 });
  if (cartCheck.empty) {
    const err = new Error('Cart is empty after add-to-cart — product may be out of stock');
    err.failureType = 'oos';
    throw err;
  }
  logger.info(`[Walmart] Cart verified (${cartCheck.count} item(s))`);

  await clickFirst(page, SELECTORS.cartCheckout, { stage: 'cart_to_checkout' });
  await page.waitForNavigation({ waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
  await postClickGuard(page, { taskId: task.id, stage: 'cart_to_checkout' });

  const guest = await findFirst(page, SELECTORS.guestCheckout, 4000);
  if (guest) { await humanClick(page, guest.selector); await waitForAnySelector(page, SELECTORS.email, { timeout: 8000 }); await postClickGuard(page, { taskId: task.id, stage: 'guest_checkout' }); }

  // Choose "Ship to home" over pickup before filling the address, so the order
  // isn't silently converted to (or stalled on) a pickup fulfillment choice.
  await selectFulfillment(page);

  const ship = task.shippingAddress;
  if (!ship) throw new Error('Shipping address missing at stage "fill_shipping"');
  const shipReport = new FillReport(task.id, 'Walmart Shipping');
  await fillField(page, SELECTORS.email, task.notification_email_address || ship.email, { label: 'email', report: shipReport });
  await fillField(page, SELECTORS.firstName, ship.first_name, { label: 'firstName', report: shipReport });
  await fillField(page, SELECTORS.lastName, ship.last_name, { label: 'lastName', report: shipReport });
  await fillField(page, SELECTORS.address1, ship.address1, { label: 'address1', report: shipReport });
  await fillField(page, SELECTORS.address2, ship.address2, { label: 'address2', report: shipReport });
  await fillField(page, SELECTORS.city, ship.city, { label: 'city', report: shipReport });
  await fillField(page, SELECTORS.postalCode, formatPostal(ship.zip), { label: 'postalCode', report: shipReport });
  await fillField(page, SELECTORS.phone, stripPhone(ship.phone), { label: 'phone', report: shipReport });
  const stateSel = await findFirst(page, SELECTORS.state, 3000);
  let stateOk = false;
  if (stateSel) stateOk = await page.select(stateSel.selector, ship.state).then(() => true).catch(() => false);
  shipReport.record('state', stateOk, stateOk ? '' : 'select failed');
  shipReport.log();
  // Abort loud if a core address field didn't fill — don't roll into payment with
  // a broken shipping form. (state is left out: province value-format mismatches
  // shouldn't hard-fail an otherwise-good run.)
  assertCriticalFields(shipReport, ['email', 'firstName', 'lastName', 'address1', 'city', 'postalCode', 'phone']);

  const advanced = await clickContinueIfPresent(page, { taskId: task.id, stage: 'continue_from_shipping', allowSubmit: true });
  if (advanced) {
    // Keep the entered address if Walmart pops its "verify your address" modal.
    await dismissAddressSuggestion(page);
  }

  // Autoselect a shipping method if Walmart surfaces the choice, and only advance
  // again when we actually picked one — never blind-click "continue" toward the
  // payment/place-order step. Non-fatal.
  const methodPicked = await selectShippingMethod(page);
  if (methodPicked) {
    await clickContinueIfPresent(page, { taskId: task.id, stage: 'continue_to_payment' });
  }

  const pay = task.paymentProfile;
  if (!pay) throw new Error('Payment profile missing at stage "fill_payment"');

  await requireCardIframe(page, { timeout: 15000 });

  const payReport = new FillReport(task.id, 'Walmart Payment');
  const cardSel = SELECTORS.cardName.join(', ');
  const numSel  = SELECTORS.cardNumber.join(', ');
  const cvvSel  = SELECTORS.cvv.join(', ');

  const nameOk = await humanTypeInFrames(page, cardSel, pay.card_holder_name, { tabAfter: true });
  payReport.record('cardName', nameOk, nameOk ? '' : 'not found in main or iframes');

  const numOk = await humanTypeInFrames(page, numSel, pay.card_number.replace(/\s/g, ''), { tabAfter: true });
  payReport.record('cardNumber', numOk, numOk ? '' : 'not found in main or iframes');

  const cvvOk = await humanTypeInFrames(page, cvvSel, pay.cvv, { tabAfter: true });
  payReport.record('cvv', cvvOk, cvvOk ? '' : 'not found in main or iframes');

  // Expiry month — try raw, integer, and zero-padded
  const rawMo  = String(pay.expiration_month);
  const intMo  = String(parseInt(rawMo, 10));
  const padMo  = intMo.padStart(2, '0');
  let moOk = false;
  const expMo = await findFirst(page, SELECTORS.expMonth, 2000);
  if (expMo) {
    for (const v of [rawMo, intMo, padMo]) {
      moOk = await humanSelect(page, expMo.selector, v).catch(() => false);
      if (moOk) break;
    }
  }
  payReport.record('expirationMonth', moOk, moOk ? '' : 'month select not found / value not accepted');

  const rawYr = String(pay.expiration_year);
  let yrOk = false;
  const expYr = await findFirst(page, SELECTORS.expYear, 2000);
  if (expYr) {
    yrOk = await humanSelect(page, expYr.selector, rawYr).catch(() => false);
    if (!yrOk) yrOk = await humanSelect(page, expYr.selector, rawYr.slice(-2)).catch(() => false);
  }
  payReport.record('expirationYear', yrOk, yrOk ? '' : 'year select not found / value not accepted');

  payReport.log();
  // Never click Place Order without the FULL card (incl. expiry) in the form —
  // a missing expiry guarantees a decline, so fail loud before the ambiguous submit.
  assertCriticalFields(payReport, ['cardName', 'cardNumber', 'cvv', 'expirationMonth', 'expirationYear']);

  const guardResult = await preOrderGuard(page, { taskId: task.id });
  if (guardResult.threeDSecure) {
    // Bot can't solve bank OTP/SMS. Stop before submit (clicking into 3DS leaves an
    // ambiguous "did it order?" state) and wake the user to finish manually.
    logger.warn(`[Walmart] Task ${task.id} — 3D Secure detected (${guardResult.threeDSecure.url}). NOT clicking Place Order; alerting for manual action.`);
    await takeFailureScreenshot(page, task.id, 'placeOrder-3ds').catch(() => {});
    await notify({
      taskId: task.id,
      success: false,
      message: '🔐 3D Secure / bank verification required before Place Order. The bot cannot solve OTP/SMS — please finish this order manually now.',
      stage: 'place_order_3ds',
      productUrl: task.url,
      siteId: task.site_id || 8
    }).catch(() => {});
    const err = new Error('3D Secure challenge requires manual verification — stopped before Place Order to avoid an ambiguous submit');
    err.failureType = 'human_required';
    throw err;
  }
  await assertActionButtonIntent(page, SELECTORS.placeOrder, { stage: 'place order', allow: /place order|submit order|complete order/i });
  await clickFirst(page, SELECTORS.placeOrder, { stage: 'place_order' });

  const confirmed = await Promise.race([
    findFirst(page, SELECTORS.orderConfirmation, 60000),
    page.waitForFunction(() => /thank-you|order-confirmation|confirmation/.test(window.location.pathname), { timeout: 60000 }).then(() => ({ url: true })).catch(() => null)
  ]);
  if (!confirmed) {
    await takeFailureScreenshot(page, task.id, 'confirm_order_fail');
    throw new Error('Order confirmation not detected at stage "confirm_order"');
  }

  const orderNumber = await page.evaluate(() => {
    const el = document.querySelector('h1.order-number, [data-testid="order-number"], .order-id, [class*="orderNumber" i]');
    return el ? el.textContent.trim() : null;
  }).catch(() => null);

  logger.info(`[Walmart] ✅ Order placed for task ${task.id}! Order: ${orderNumber || 'N/A'}`);
  await captureOrderSuccess({ page, taskId: task.id, orderNumber, productUrl: task.url, durationMs: Date.now() - startedAt }).catch(() => {});
};

export default runWalmart;
