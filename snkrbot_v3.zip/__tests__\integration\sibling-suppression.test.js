// Sibling duplicate suppression.
//
// The regression this guards: sibling-bus.js was implemented with zero callers. Two
// tasks armed on one product both hold a browser, a residential exit and a queue
// slot; once one wins, the other's resources are pure waste and it buys a duplicate
// order if it submits anyway.
//
// Both ends must be wired: a win must announce itself, and the pre-submit guard must
// abort on it. A bus nobody publishes to, or a publisher nobody listens to, is inert.
import { beforeEach, describe, expect, jest, test } from '@jest/globals';

jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));

const bus = await import('../../helpers/sibling-bus.js');
const { captureOrderSuccess } = await import('../../helpers/order-capture.js');
const { preOrderGuard } = await import('../../helpers/checkout-guards.js');

const URL_A = 'https://shop.example.com/products/crimson-foam';

beforeEach(() => bus.__resetForTests());

// Minimal page stub: captureOrderSuccess screenshots and writes, preOrderGuard probes
// the DOM. Both tolerate failures, so a thin stub is enough.
const pageStub = () => ({
  screenshot: async () => {},
  url: () => URL_A,
  evaluate: async () => ({}),
  content: async () => '<html></html>',
  title: async () => 'Crimson Foam'
});

describe('a win is announced', () => {
  test('captureOrderSuccess publishes to the bus', async () => {
    await captureOrderSuccess({
      page: pageStub(), taskId: 1, orderNumber: 'A-1', productUrl: URL_A
    });
    const win = bus.getRecentWin(URL_A);
    expect(win).toMatchObject({ taskId: 1, orderNumber: 'A-1' });
  });

  test('a win without a product URL still writes its receipt', async () => {
    const receipt = await captureOrderSuccess({ page: pageStub(), taskId: 2, orderNumber: 'A-2' });
    expect(receipt).toMatchObject({ receipt: expect.stringContaining('.json') });
    // No product URL means nothing to key the bus on.
    expect(bus.getRecentWin(URL_A)).toBeNull();
  });
});

describe('the guard aborts a duplicate', () => {
  test('preOrderGuard throws once a sibling has won', async () => {
    bus.notifyProductSuccess({ productUrl: URL_A, taskId: 9, orderNumber: 'Z-9' });
    await expect(preOrderGuard(pageStub(), { taskId: 10, productUrl: URL_A }))
      .rejects.toMatchObject({ siblingWon: true });
  });

  test('preOrderGuard passes when nobody has won', async () => {
    await expect(preOrderGuard(pageStub(), { taskId: 11, productUrl: URL_A })).resolves.toBeDefined();
  });

  test('a different product does not abort', async () => {
    bus.notifyProductSuccess({ productUrl: URL_A, taskId: 12 });
    await expect(preOrderGuard(pageStub(), {
      taskId: 13, productUrl: 'https://shop.example.com/products/other'
    })).resolves.toBeDefined();
  });

  test('without a product URL the guard still runs normally', async () => {
    await expect(preOrderGuard(pageStub(), { taskId: 14 })).resolves.toBeDefined();
  });
});
