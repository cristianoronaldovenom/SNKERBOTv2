/**
 * Lightweight operational ML: online logistic regression for retry timing.
 *
 * This model is intentionally NOT involved in CAPTCHA/WAF behavior, identity
 * changes, proxy selection, or checkout decisions. It only learns from the
 * application's own retry outcomes and nudges the wait time between retries.
 *
 * Goals:
 *   - preserve the existing retry behavior when data is sparse
 *   - reduce wasted waiting after operations that historically recover quickly
 *   - avoid retry storms after error patterns that rarely recover immediately
 *   - use <10 KB of memory and no third-party ML dependency
 *
 * The model is persisted as a tiny JSON file, debounced to avoid disk churn.
 */

import fs from 'node:fs';
import path from 'node:path';
import logger from './logger.js';

const ENABLED = String(process.env.OPS_ML_ENABLED ?? 'true').toLowerCase() !== 'false';
const DIM = 32;
const LEARNING_RATE = 0.08;
const L2 = 0.002;
const SAVE_DEBOUNCE_MS = 5000;
const MAX_ABS_WEIGHT = 3.5;
const DEFAULT_PROBABILITY = 0.5;

const root = process.cwd();
const stateDir = process.env.OPS_ML_STATE_DIR || path.join(root, 'data');
const statePath = process.env.OPS_ML_STATE_FILE || path.join(stateDir, 'ops-ml.json');

const state = {
  version: 1,
  observations: 0,
  bias: 0,
  weights: Array(DIM).fill(0),
};

let loaded = false;
let saveTimer = null;

const sigmoid = (x) => 1 / (1 + Math.exp(-Math.max(-12, Math.min(12, x))));

const hash = (text) => {
  let h = 2166136261;
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
};

const addFeature = (features, name, value = 1) => {
  const idx = hash(name) % DIM;
  features[idx] += value;
};

const errorClass = (err) => {
  const msg = String(err?.code || err?.message || err || '').toLowerCase();
  if (/timeout|timed? ?out|etimedout|esockettimedout/.test(msg)) return 'timeout';
  if (/econnreset|socket hang up|eai_again|enotfound|network|connection/.test(msg)) return 'network';
  if (/429|too many requests|rate limit/.test(msg)) return 'rate_limit';
  if (/5\d\d|bad gateway|gateway timeout|service unavailable/.test(msg)) return 'server';
  if (/selector|element|not found|detached/.test(msg)) return 'ui';
  if (/captcha|challenge|verification/.test(msg)) return 'challenge';
  return 'other';
};

const buildFeatures = ({ label = 'op', attempt = 0, err = null } = {}) => {
  const f = Array(DIM).fill(0);
  addFeature(f, 'bias', 1);
  addFeature(f, `label:${String(label).slice(0, 64)}`, 1);
  addFeature(f, `error:${errorClass(err)}`, 1);
  addFeature(f, 'attempt:0', attempt === 0 ? 1 : 0);
  addFeature(f, 'attempt:1', attempt === 1 ? 1 : 0);
  addFeature(f, 'attempt:2plus', attempt >= 2 ? 1 : 0);
  addFeature(f, 'transient', /timeout|network|429|5\d\d/i.test(String(err?.message || err || '')) ? 1 : 0);
  return f;
};

const ensureLoaded = () => {
  if (loaded) return;
  loaded = true;
  if (!ENABLED) return;
  try {
    const raw = fs.readFileSync(statePath, 'utf8');
    const parsed = JSON.parse(raw);
    if (parsed?.version === 1 && Array.isArray(parsed.weights) && parsed.weights.length === DIM) {
      state.observations = Number.isFinite(parsed.observations) ? parsed.observations : 0;
      state.bias = Number.isFinite(parsed.bias) ? parsed.bias : 0;
      state.weights = parsed.weights.map((w) => Number.isFinite(w) ? w : 0);
    }
  } catch (_) {
    // First run or unreadable state: start from the neutral prior.
  }
};

const scheduleSave = () => {
  if (!ENABLED || saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    try {
      fs.mkdirSync(stateDir, { recursive: true });
      fs.writeFileSync(statePath, JSON.stringify(state), { mode: 0o600 });
    } catch (err) {
      logger.warn(`[OpsML] Could not persist state: ${err.message}`);
    }
  }, SAVE_DEBOUNCE_MS);
};

export const predictRetrySuccess = (ctx = {}) => {
  ensureLoaded();
  if (!ENABLED || state.observations < 8) return DEFAULT_PROBABILITY;
  const features = buildFeatures(ctx);
  let z = state.bias;
  for (let i = 0; i < DIM; i++) z += features[i] * state.weights[i];
  return sigmoid(z);
};

export const recordRetryOutcome = ({ success, ...ctx } = {}) => {
  ensureLoaded();
  if (!ENABLED) return;

  const features = buildFeatures(ctx);
  const y = success ? 1 : 0;
  const before = predictRetrySuccess(ctx);
  const error = y - before;

  state.bias = Math.max(-MAX_ABS_WEIGHT, Math.min(MAX_ABS_WEIGHT,
    state.bias + LEARNING_RATE * error));
  for (let i = 0; i < DIM; i++) {
    const next = state.weights[i] + LEARNING_RATE * (error * features[i] - L2 * state.weights[i]);
    state.weights[i] = Math.max(-MAX_ABS_WEIGHT, Math.min(MAX_ABS_WEIGHT, next));
  }
  state.observations += 1;
  scheduleSave();
};

/**
 * Conservative multiplier only. The ML model is deliberately capped at ±15%
 * so a bad model can never turn a stable retry policy into an aggressive one.
 */
export const retryDelayMultiplier = (ctx = {}) => {
  const p = predictRetrySuccess(ctx);
  if (p >= 0.72) return 0.85;
  if (p <= 0.28) return 1.15;
  return 1;
};

export const stats = () => ({
  enabled: ENABLED,
  observations: state.observations,
  statePath,
});

export const reset = () => {
  state.observations = 0;
  state.bias = 0;
  state.weights = Array(DIM).fill(0);
  loaded = true;
  try { fs.rmSync(statePath, { force: true }); } catch (_) {}
};
