// Poll economy — decide how often a monitor is WORTH spending residential bytes.
//
// Why a separate module: `getAdaptiveDelay()` in stock-monitor only backs off
// after the WAF has already blocked us. That is reactive — the bytes are already
// spent. A monitor watching a product that has not changed in 40 minutes still
// polls at full speed and still pays an exit IP plus a full response body on
// every tick, which is the single largest residential cost in a long session.
//
// This module is the proactive half: a pure policy that answers "given what we
// know, how long until the next poll is justified?" It never guesses about stock
// — restocks are bursty and a slow poll misses them — so it is bounded hard and
// snaps back to full speed the moment anything looks interesting.
//
// Contract: pure and I/O-free (mirrors admission.js). Callers pass observations;
// this returns a delay. Advisory only — a caller may always poll early.
//
// Tier reasoning:
//   * HOT      — in stock, or a drop window is open. Full speed, no backoff.
//   * WARM     — recently changed but currently OOS. Moderate interval.
//   * COLD     — unchanged for a long run. Long interval, jittered so a fleet of
//                monitors on one host does not tick in lockstep.
//   * BLOCKED  — WAF streak present; defer to the existing block-streak backoff
//                (returned as a floor, never shorter than this module's tier).

const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));
const int = (v, fallback) => {
  const n = Number.parseInt(v, 10);
  return Number.isFinite(n) && n >= 0 ? n : fallback;
};

// Env-tunable so an operator can slow a whole fleet down without a code change.
const HOT_MS = Math.max(250, int(process.env.POLL_HOT_MS, 1000));
const WARM_MS = Math.max(HOT_MS, int(process.env.POLL_WARM_MS, 5000));
const COLD_MS = Math.max(WARM_MS, int(process.env.POLL_COLD_MS, 20000));
const COLD_AFTER_MS = Math.max(60_000, int(process.env.POLL_COLD_AFTER_MS, 10 * 60_000));
const WARM_AFTER_MS = Math.max(10_000, int(process.env.POLL_WARM_AFTER_MS, 90_000));
const MAX_JITTER_RATIO = clamp(Number(process.env.POLL_MAX_JITTER ?? 0.15) || 0, 0, 0.5);
const BUDGET_SQUEEZE = String(process.env.POLL_BUDGET_SQUEEZE ?? 'true').toLowerCase() !== 'false';

export const TIER = Object.freeze({ HOT: 'hot', WARM: 'warm', COLD: 'cold', BLOCKED: 'blocked' });

// Classify from observations. Order matters: HOT outranks everything, because
// being wrong about HOT costs a missed restock and being wrong about COLD only
// costs bytes.
export const classify = ({
  inStock = false,
  dropWindowOpen = false,
  blockStreak = 0,
  msSinceChange = null,
} = {}) => {
  if (inStock || dropWindowOpen) return TIER.HOT;
  if (Number(blockStreak) > 0) return TIER.BLOCKED;
  const quietFor = Number(msSinceChange);
  if (Number.isFinite(quietFor) && quietFor >= COLD_AFTER_MS) return TIER.COLD;
  if (Number.isFinite(quietFor) && quietFor >= WARM_AFTER_MS) return TIER.WARM;
  return TIER.HOT;
};

const TIER_BASE_MS = Object.freeze({
  [TIER.HOT]: HOT_MS,
  [TIER.WARM]: WARM_MS,
  [TIER.COLD]: COLD_MS,
  // A blocked host already has stock-monitor's exponential backoff; this is the
  // floor so the two do not stack into a minute of silence.
  [TIER.BLOCKED]: WARM_MS,
});

// Deterministic jitter from a seed so repeated calls for one task agree (a delay
// that reshuffles on every read cannot be asserted in tests or logged usefully).
export const jitterFor = (key, ratio = MAX_JITTER_RATIO) => {
  if (!ratio) return 0;
  let h = 0;
  const s = String(key ?? '');
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  // 0..1 stable per key
  const unit = (h % 10_000) / 10_000;
  return (unit * 2 - 1) * ratio; // -ratio .. +ratio
};

// Main entry. Returns { delayMs, tier, reason }.
//
// `budgetRemainingRatio` (0..1) squeezes every tier when the monthly residential
// allowance is running out — a monitor that is still polling at full speed with
// 2% of the budget left is what makes the checkout starve later.
export const nextPollDelay = ({
  key = null,
  budgetRemainingRatio = null,
  minMs = 0,
  maxMs = null,
  ...observation
} = {}) => {
  const tier = classify(observation);
  let delay = TIER_BASE_MS[tier];
  const reasons = [tier];

  // Blocked callers get the greater of this floor and their own backoff.
  if (tier === TIER.BLOCKED) {
    const streak = Math.max(1, int(observation.blockStreak, 1));
    delay = Math.max(delay, Math.min(60_000, 2000 * (2 ** (streak - 1))));
    reasons.push(`block_streak_${streak}`);
  }

  if (BUDGET_SQUEEZE && Number.isFinite(budgetRemainingRatio)) {
    const ratio = clamp(budgetRemainingRatio, 0, 1);
    // Under 10% left, stretch everything up to 3x; at 0% pin to the cold tier so
    // the last bytes go to checkouts rather than idle polling.
    if (ratio <= 0) {
      reasons.push('budget_exhausted');
    } else if (ratio < 0.1) {
      const factor = 1 + (1 - ratio / 0.1) * 2;
      delay *= factor;
      reasons.push(`budget_squeeze_${factor.toFixed(2)}`);
    }
  }

  // Jitter is applied here (not to the base) so a squeeze composes with it.
  const jitter = jitterFor(key, MAX_JITTER_RATIO);
  if (jitter) {
    delay *= 1 + jitter;
    reasons.push('jitter');
  }

  // An exhausted budget is a FLOOR, applied after jitter — otherwise the
  // negative jitter lobe would drop below the cold interval and let idle polling
  // spend the last bytes.
  if (reasons.includes('budget_exhausted')) delay = Math.max(delay, COLD_MS);

  delay = Math.floor(clamp(delay, minMs || 0, maxMs ?? Number.MAX_SAFE_INTEGER));
  return { delayMs: delay, tier, reason: reasons.join('+') };
};

export const pollEconomyConfig = () => ({
  hotMs: HOT_MS,
  warmMs: WARM_MS,
  coldMs: COLD_MS,
  coldAfterMs: COLD_AFTER_MS,
  warmAfterMs: WARM_AFTER_MS,
  maxJitterRatio: MAX_JITTER_RATIO,
  budgetSqueeze: BUDGET_SQUEEZE,
});
