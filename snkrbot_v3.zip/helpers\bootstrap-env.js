// Runtime bootstrap — make a bare machine able to RUN the bot.
//
// Why this exists: `start.sh` and the Dockerfile both assume the host already
// has Chromium and a prebuilt Go sidecar. On a fresh VM, a Replit clone or a
// Windows box the two things that actually matter — a Chrome binary and the Go
// TLS sidecar — are simply absent, and every task then fails one at a time with
// an error that never mentions the real cause. This module finds, and when
// missing downloads, the vital runtimes into `.local/` inside the repo.
//
// Contract, and it matters:
//   ADVISORY. Nothing here throws. A failed download must never stop boot —
//   the same rule helpers/admission.js follows. The bot degrades (Node TLS
//   instead of the sidecar, no browser) instead of refusing to start.
//
// Supply chain: every artefact is verified against the publisher's own SHA256
// before it is moved into place. Versions are pinned here, not floaty, so two
// machines booted a week apart run the same bits.
//
// Escape hatches: BOOTSTRAP_DISABLE=1 (never touch the network),
// BOOTSTRAP_OFFLINE=1 (report gaps, never download), BOOTSTRAP_DIR=<path>,
// and a *_URL / *_VERSION override per runtime for air-gapped mirrors.

import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const LOCAL_DIR = process.env.BOOTSTRAP_DIR
  ? path.resolve(process.env.BOOTSTRAP_DIR)
  : path.join(ROOT, '.local');
const BIN_DIR = path.join(LOCAL_DIR, 'bin');
const CACHE_DIR = path.join(LOCAL_DIR, 'downloads');
const RUNTIME_DIR = path.join(LOCAL_DIR, 'runtimes');

const DOWNLOAD_TIMEOUT_MS = 180_000;

export const isWindows = process.platform === 'win32';
const exe = (name) => (isWindows ? `${name}.exe` : name);
const plat = process.platform;
const arch = process.arch;

export class BootstrapError extends Error {
  constructor(message, { url, cause } = {}) {
    super(message);
    this.name = 'BootstrapError';
    this.url = url;
    this.cause = cause;
  }
}

const sha256 = (bytes) => crypto.createHash('sha256').update(bytes).digest('hex');

// ── PATH lookup ──────────────────────────────────────────────────────────────
// fs-based rather than spawning `which`/`where`: it is synchronous, has no
// shell quoting problems on Windows paths with spaces, and cannot hang.
export const findOnPath = (name, { env = process.env } = {}) => {
  const candidates = isWindows
    ? [name, `${name}.exe`, `${name}.cmd`, `${name}.bat`]
    : [name];
  for (const dir of String(env.PATH || env.Path || '').split(path.delimiter)) {
    if (!dir) continue;
    for (const candidate of candidates) {
      const full = path.join(dir, candidate);
      try {
        if (fs.statSync(full).isFile()) return full;
      } catch (_) { /* not here */ }
    }
  }
  return null;
};

// Our own installs win over PATH exactly once they exist, so a version we
// verified is not shadowed by an older system one.
export const findManaged = (name) => {
  try {
    const full = path.join(BIN_DIR, exe(name));
    if (fs.statSync(full).isFile()) return full;
  } catch (_) { /* not installed */ }
  return null;
};

export const resolveRuntime = (name) => findManaged(name) || findOnPath(name);

// ── Managed-install environment ──────────────────────────────────────────────
// A managed install sometimes needs more than a PATH entry: Go refuses to run
// without GOROOT, which is why a copied go.exe exits 2 with
// "GOROOT is not set". The root is written beside the binary at install time and
// re-read here so every later launch — including ones started long after the
// install — runs the tree in place.
const MANAGED_ENV = {
  go: (binDir) => ({ GOROOT: path.join(RUNTIME_DIR, findRootStamp(binDir) || '') })
};

const rootStampPath = () => path.join(BIN_DIR, '.goroot');
const findRootStamp = () => {
  try { return fs.readFileSync(rootStampPath(), 'utf8').trim() || null; } catch (_) { return null; }
};

export const managedEnv = (name) => {
  if (!findManaged(name)) return {};
  const build = MANAGED_ENV[name];
  if (!build) return {};
  const env = build(BIN_DIR);
  // Only hand back a GOROOT that really exists; a stale stamp would make things
  // worse than leaving the variable unset.
  return env.GOROOT && fs.existsSync(env.GOROOT) ? env : {};
};

// ── Version parsing ──────────────────────────────────────────────────────────
// `node -v` prints "v22.14.0". `go version` prints
// "go version go1.25.3 windows/amd64". `python --version` prints
// "Python 3.12.7". All three reduce to an int triple so comparison is
// arithmetic, not string games ("1.9" < "1.10" breaks lexically).
export const parseVersion = (text) => {
  const m = String(text || '').match(/(\d+)\.(\d+)\.(\d+)/);
  return m ? [Number(m[1]), Number(m[2]), Number(m[3])] : null;
};

export const versionAtLeast = (actual, minimum) => {
  const a = Array.isArray(actual) ? actual : parseVersion(actual);
  const b = Array.isArray(minimum) ? minimum : parseVersion(minimum);
  if (!a || !b) return false;
  for (let i = 0; i < 3; i++) {
    if (a[i] > b[i]) return true;
    if (a[i] < b[i]) return false;
  }
  return true;
};

const VERSION_ARGS = {
  node: ['-v'],
  go: ['version'],
  python: ['--version']
};

// `spawn` with a hard timeout. Never rejects: a hung binary resolves null so a
// broken install is reported as "not usable" instead of wedging boot.
// `env` is merged over process.env — Go needs GOROOT pointing at its tree, and a
// bare copied go.exe otherwise exits 2 with "GOROOT is not set".
export const readVersion = (bin, name, { timeoutMs = 8000, env = null } = {}) => new Promise((resolve) => {
  let done = false;
  const finish = (value) => { if (!done) { done = true; resolve(value); } };
  let child;
  try {
    child = spawn(bin, VERSION_ARGS[name] || ['--version'], {
      windowsHide: true,
      env: env ? { ...process.env, ...env } : process.env
    });
  } catch (_) {
    return finish(null);
  }
  let out = '';
  const timer = setTimeout(() => {
    try { child.kill(); } catch (_) {}
    finish(null);
  }, timeoutMs);
  child.stdout?.on('data', (d) => { out += d; });
  child.stderr?.on('data', (d) => { out += d; });
  child.on('error', () => { clearTimeout(timer); finish(null); });
  child.on('close', () => { clearTimeout(timer); finish(parseVersion(out) ? out : null); });
});

// ── Runtime specs ────────────────────────────────────────────────────────────
// `url` is the published artefact, `binPath` is where the binary sits INSIDE the
// archive — vendor layouts disagree (Go puts it at the root, Node and the
// standalone CPython build bury it in a directory named after the release), so
// it is declared rather than guessed.
const NODE_VERSION = process.env.BOOTSTRAP_NODE_VERSION || '22.14.0';
const GO_VERSION = process.env.BOOTSTRAP_GO_VERSION || '1.25.3';
const PYTHON_VERSION = process.env.BOOTSTRAP_PYTHON_VERSION || '3.12.7';

const NODE_ARCHIVE = `${({ win32: 'win', darwin: 'darwin', linux: 'linux' })[plat]}-${
  ({ x64: 'x64', arm64: 'arm64' })[arch]}`;
const GO_ARCHIVE = `${({ win32: 'windows', darwin: 'darwin', linux: 'linux' })[plat]}-${
  ({ x64: 'amd64', arm64: 'arm64' })[arch]}`;

export const SPECS = {
  node: {
    label: 'Node.js',
    minimum: '20.0.0',
    version: NODE_VERSION,
    offlineUrl: `https://nodejs.org/dist/v${NODE_VERSION}/`,
    url: process.env.BOOTSTRAP_NODE_URL
      || `https://nodejs.org/dist/v${NODE_VERSION}/node-v${NODE_VERSION}-${NODE_ARCHIVE}.${isWindows ? 'zip' : 'tar.gz'}`,
    // Node publishes one file covering the whole release; it is fetched and the
    // single matching line used, so the pin stays one version string.
    checksumUrl: process.env.BOOTSTRAP_NODE_CHECKSUM_URL
      || `https://nodejs.org/dist/v${NODE_VERSION}/SHASUMS256.txt`,
    checksumPattern: (url) => url.split('/').pop(),
    binPath: (archiveName) => `${archiveName}/${exe('node')}`
  },
  go: {
    label: 'Go',
    minimum: '1.21.0',
    version: GO_VERSION,
    offlineUrl: 'https://go.dev/dl/',
    url: process.env.BOOTSTRAP_GO_URL
      || `https://go.dev/dl/go${GO_VERSION}.${GO_ARCHIVE}.${isWindows ? 'zip' : 'tar.gz'}`,
    // go.dev/dl/<file>.sha256 is an HTML download page, not a digest. The only
    // machine-readable source is the release JSON index, matched on filename.
    checksumUrl: () => 'https://go.dev/dl/?mode=json&include=all',
    checksumPattern: (url) => url.split('/').pop(),
    checksumJson: true,
    binPath: (archiveName) => `go/bin/${exe('go')}`,
    // go.exe locates its standard library relative to GOROOT, so the tree must be
    // kept and named. The value is persisted next to the binary and re-applied on
    // every later run (see managedEnv).
    rootDir: () => 'go'
  },
  python: {
    label: 'Python',
    minimum: '3.10.0',
    version: PYTHON_VERSION,
    offlineUrl: 'https://www.python.org/downloads/',
    // The standalone CPython builds are the only distribution shipping a
    // relocatable tree with a real checksum file, which is what an unprivileged
    // install into .local needs. The asset name embeds a build date, so it is
    // overridable instead of being guessed beyond the Linux default below.
    url: process.env.BOOTSTRAP_PYTHON_URL || '',
    checksumUrl: process.env.BOOTSTRAP_PYTHON_CHECKSUM_URL || '',
    checksumPattern: null,
    binPath: (archiveName) => `${archiveName}/bin/${exe('python3')}`
  }
};

// Fill in the standalone-build default only when the caller gave nothing, so a
// Linux host without BOOTSTRAP_PYTHON_URL still gets a best-effort attempt
// instead of a guaranteed "no URL" skip. Windows/macOS users normally already
// have python on PATH via the official installer.
if (!SPECS.python.url && plat === 'linux') {
  const triple = arch === 'arm64' ? 'aarch64-unknown-linux-gnu' : 'x86_64-unknown-linux-gnu';
  const tag = '20241016';
  SPECS.python.url = `https://github.com/astral-sh/python-build-standalone/releases/download/${tag}/cpython-${PYTHON_VERSION}+${tag}-${triple}-install_only.tar.gz`;
  SPECS.python.checksumUrl = `https://github.com/astral-sh/python-build-standalone/releases/download/${tag}/SHA256SUMS`;
  SPECS.python.checksumPattern = (url) => url.split('/').pop();
}

// Python is the one runtime nothing in the request path calls today, so it is
// checked but only downloaded when asked for. Node and Go are load-bearing: the
// launcher IS node, and the TLS sidecar is built with Go.
export const RUNTIMES = ['node', 'go', 'python'];
export const REQUIRED_BY_DEFAULT = ['node', 'go'];

// ── HTTP ─────────────────────────────────────────────────────────────────────
const fetchBytes = async (url, { timeoutMs = DOWNLOAD_TIMEOUT_MS } = {}) => {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      redirect: 'follow',
      signal: controller.signal,
      headers: { 'user-agent': 'sneakerbot-bootstrap' }
    });
    if (!res.ok) throw new BootstrapError(`HTTP ${res.status} for ${url}`, { url });
    return Buffer.from(await res.arrayBuffer());
  } finally {
    clearTimeout(timer);
  }
};

// Extract with the platform tar. bsdtar ships with Windows 10 1803+ and reads
// both .zip and .tar.gz, so one code path covers every archive we fetch.
const extract = (archive, destDir) => new Promise((resolve, reject) => {
  const args = isWindows ? ['-xf', archive, '-C', destDir] : ['-xzf', archive, '-C', destDir];
  let child;
  try {
    child = spawn(isWindows ? 'tar.exe' : 'tar', args, { windowsHide: true });
  } catch (err) {
    return reject(new BootstrapError('tar is unavailable; cannot extract archive', { cause: err }));
  }
  let err = '';
  child.stderr?.on('data', (d) => { err += d; });
  child.on('error', reject);
  child.on('close', (code) => (code === 0
    ? resolve()
    : reject(new BootstrapError(`tar exited ${code}: ${err.trim().slice(0, 300)}`))));
});

// Resolve the publisher's digest for `url`. Returns null when there is no
// checksum endpoint; callers then record the install as unverified rather than
// pretending it was checked.
const expectChecksum = async (spec, url) => {
  const checksumUrl = typeof spec.checksumUrl === 'function' ? spec.checksumUrl(url) : spec.checksumUrl;
  if (!checksumUrl) return null;
  const body = (await fetchBytes(checksumUrl)).toString('utf8');
  const wanted = spec.checksumPattern ? spec.checksumPattern(url) : null;

  // Release-index form: an array of releases, each with a `files` array carrying
  // filename + sha256. Go publishes this and nothing else machine-readable.
  if (spec.checksumJson) {
    const releases = JSON.parse(body);
    for (const release of releases) {
      for (const file of release.files || []) {
        if (file.filename === wanted && /^[0-9a-f]{64}$/i.test(file.sha256 || '')) {
          return file.sha256.toLowerCase();
        }
      }
    }
    return null;
  }

  if (wanted) {
    const line = body.split('\n').find((l) => l.trim().endsWith(wanted));
    return line ? line.trim().split(/\s+/)[0].toLowerCase() : null;
  }
  const token = body.trim().split(/\s+/)[0].toLowerCase();
  return /^[0-9a-f]{64}$/.test(token) ? token : null;
};

// ── Ensure one runtime ───────────────────────────────────────────────────────
// The result shape is stable so callers (and tests) never parse prose.
export const ensureRuntime = async (name, { download = true } = {}) => {
  const spec = SPECS[name];
  if (!spec) return { name, status: 'unknown', detail: `no spec for "${name}"` };

  const found = resolveRuntime(name);
  if (found) {
    // A managed install carries its own env (GOROOT); a system one does not.
    const printed = await readVersion(found, name, { env: findManaged(name) ? managedEnv(name) : null });
    if (!printed) {
      return { name, status: 'broken', path: found, detail: `${found} exists but does not report a version` };
    }
    const parsed = parseVersion(printed);
    if (!versionAtLeast(parsed, spec.minimum)) {
      return {
        name,
        status: 'outdated',
        path: found,
        version: parsed.join('.'),
        detail: `${spec.label} ${parsed.join('.')} is below the required ${spec.minimum}`
      };
    }
    return { name, status: 'ok', path: found, version: parsed.join('.') };
  }

  if (!download) return { name, status: 'missing', detail: `${spec.label} not found on PATH or in ${BIN_DIR}` };
  if (!spec.url) {
    return { name, status: 'missing', detail: `${spec.label} not found and no download URL is configured` };
  }

  try {
    await fsp.mkdir(CACHE_DIR, { recursive: true });
    await fsp.mkdir(BIN_DIR, { recursive: true });
    const archiveName = new URL(spec.url).pathname.split('/').pop();
    const archive = path.join(CACHE_DIR, archiveName);

    const expected = await expectChecksum(spec, spec.url).catch(() => null);
    // A cached archive is re-hashed: a half-written or tampered file must not be
    // reused just because the filename matches.
    if (fs.existsSync(archive) && expected) {
      const onDisk = sha256(await fsp.readFile(archive));
      if (onDisk !== expected) await fsp.rm(archive, { force: true });
    }
    if (!fs.existsSync(archive)) {
      const bytes = await fetchBytes(spec.url);
      if (expected) {
        const actual = sha256(bytes);
        if (actual !== expected) {
          throw new BootstrapError(
            `checksum mismatch for ${archiveName}: expected ${expected}, got ${actual}`, { url: spec.url }
          );
        }
      }
      await fsp.writeFile(archive, bytes);
    }

    const stageDir = path.join(RUNTIME_DIR, `${name}-${spec.version}`);
    await fsp.rm(stageDir, { recursive: true, force: true });
    await fsp.mkdir(stageDir, { recursive: true });
    await extract(archive, stageDir);

    const source = path.join(stageDir, spec.binPath(archiveName));
    if (!fs.existsSync(source)) {
      throw new BootstrapError(`${archiveName} did not contain ${spec.binPath(archiveName)}`);
    }
    const target = path.join(BIN_DIR, exe(name));
    await fsp.copyFile(source, target);
    if (!isWindows) await fsp.chmod(target, 0o755);

    // Record the runtime tree for runtimes that need one (Go's GOROOT), then
    // re-read it so the verification below runs under the same env a later
    // launch will use — otherwise a working install verifies as broken.
    if (spec.rootDir) {
      await fsp.writeFile(
        rootStampPath(), path.join(path.relative(RUNTIME_DIR, stageDir), spec.rootDir())
      );
    }
    const verifyEnv = spec.rootDir ? managedEnv(name) : null;

    // Prove it runs before declaring success: an archive that extracted but
    // whose binary needs a loader we lack is not an install.
    const printed = await readVersion(target, name, { env: verifyEnv });
    const parsed = parseVersion(printed || '');
    if (!parsed || !versionAtLeast(parsed, spec.minimum)) {
      return { name, status: 'broken', path: target, detail: 'downloaded binary does not run' };
    }
    return {
      name,
      status: 'installed',
      path: target,
      version: parsed.join('.'),
      verified: Boolean(expected)
    };
  } catch (err) {
    return { name, status: 'failed', detail: err.message };
  }
};

// ── Chromium ─────────────────────────────────────────────────────────────────
// cluster.js launched `PUPPETEER_EXECUTABLE_PATH || '/usr/bin/chromium'` with no
// existence check, so a Windows or macOS host got a Linux path and every launch
// died with ENOENT. This resolves a real binary, and can fetch Chrome for
// Testing when there is none.
const CHROME_CANDIDATES = {
  win32: [
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe'
  ],
  darwin: [
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    '/Applications/Chromium.app/Contents/MacOS/Chromium'
  ],
  linux: [
    '/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/google-chrome',
    '/usr/bin/google-chrome-stable', '/snap/bin/chromium'
  ]
};

const statFile = (p) => {
  try { return fs.statSync(p).isFile(); } catch (_) { return false; }
};

// Where a downloaded browser was placed. On Linux it is a single copied binary,
// but macOS and Windows need the surrounding tree, so the exact path is recorded
// rather than derived — otherwise the install is invisible on the next launch.
const chromeStampPath = () => path.join(BIN_DIR, '.chrome-path');

export const resolveChromiumPath = ({ env = process.env } = {}) => {
  const fromEnv = env.PUPPETEER_EXECUTABLE_PATH || env.CHROME_PATH || '';
  if (fromEnv && statFile(fromEnv)) return { path: fromEnv, source: 'env' };
  const managed = findManaged('chrome');
  if (managed) return { path: managed, source: 'managed' };
  try {
    const stamped = fs.readFileSync(chromeStampPath(), 'utf8').trim();
    if (stamped && statFile(stamped)) return { path: stamped, source: 'managed' };
  } catch (_) { /* never installed */ }
  const onPath = findOnPath('chrome', { env }) || findOnPath('google-chrome', { env });
  if (onPath) return { path: onPath, source: 'path' };
  for (const candidate of CHROME_CANDIDATES[plat] || []) {
    if (statFile(candidate)) return { path: candidate, source: 'well-known' };
  }
  return { path: null, source: 'missing' };
};

// Depth-first search for a specific file name inside an extracted tree.
const findFile = (dir, wanted) => {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      const hit = findFile(full, wanted);
      if (hit) return hit;
    } else if (entry.name === wanted) {
      return full;
    }
  }
  return null;
};

const CFT_API = 'https://googlechromelabs.github.io/chrome-for-testing/last-known-good-versions-with-downloads.json';
const CFT_PLATFORM = { win32: 'win64', darwin: arch === 'arm64' ? 'mac-arm64' : 'mac-x64', linux: 'linux64' }[plat];

export const ensureChromium = async ({ download = true } = {}) => {
  const found = resolveChromiumPath();
  if (found.path) return { name: 'chromium', status: 'ok', path: found.path, source: found.source };
  if (!download || !CFT_PLATFORM) {
    return { name: 'chromium', status: 'missing', detail: 'no Chrome/Chromium binary found' };
  }
  try {
    const catalogue = JSON.parse((await fetchBytes(CFT_API, { timeoutMs: 20_000 })).toString('utf8'));
    const stable = catalogue?.channels?.Stable;
    const url = stable?.downloads?.chrome?.find((d) => d.platform === CFT_PLATFORM)?.url;
    if (!url) throw new BootstrapError(`Chrome for Testing has no ${CFT_PLATFORM} build`);

    await fsp.mkdir(CACHE_DIR, { recursive: true });
    await fsp.mkdir(RUNTIME_DIR, { recursive: true });
    const archive = path.join(CACHE_DIR, url.split('/').pop());
    await fsp.writeFile(archive, await fetchBytes(url));

    const stageDir = path.join(RUNTIME_DIR, `chrome-${stable.version}`);
    await fsp.rm(stageDir, { recursive: true, force: true });
    await fsp.mkdir(stageDir, { recursive: true });
    await extract(archive, stageDir);

    const wanted = isWindows ? 'chrome.exe' : (plat === 'darwin' ? 'Google Chrome for Testing' : 'chrome');
    const source = findFile(stageDir, wanted);
    if (!source) throw new BootstrapError(`Chrome archive did not contain ${wanted}`);

    // Linux Chrome runs from a lone binary well enough to be useful; on macOS
    // and Windows the neighbouring tree (frameworks, resources) is mandatory, so
    // those platforms point at the staged copy in place.
    let resolved = source;
    if (plat === 'linux') {
      const target = path.join(BIN_DIR, exe('chrome'));
      await fsp.mkdir(BIN_DIR, { recursive: true });
      await fsp.copyFile(source, target);
      await fsp.chmod(target, 0o755);
      resolved = target;
    }
    // Stamped on every platform so the next launch resolves it without the env.
    await fsp.mkdir(BIN_DIR, { recursive: true });
    await fsp.writeFile(chromeStampPath(), resolved);
    return { name: 'chromium', status: 'installed', path: resolved, version: stable.version };
  } catch (err) {
    return { name: 'chromium', status: 'failed', detail: err.message };
  }
};

// ── Orchestration ────────────────────────────────────────────────────────────
const envFlag = (name) => ['1', 'true', 'yes', 'on']
  .includes(String(process.env[name] || '').trim().toLowerCase());

// Never throws. Returns { ok, results, warnings } where `ok` only means
// "nothing load-bearing is missing" — not "boot succeeded".
export const bootstrapRuntimes = async ({
  runtimes = REQUIRED_BY_DEFAULT, chromium = true, download = true
} = {}) => {
  const results = [];
  const warnings = [];
  const allowDownload = download && !envFlag('BOOTSTRAP_DISABLE') && !envFlag('BOOTSTRAP_OFFLINE');

  // Runtimes already present may still need wiring (Go's GOROOT). Apply that up
  // front so a sidecar build launched later in this same process works.
  // Managed binaries are also prepended to PATH, because a `spawn('go')` in the
  // sidecar build resolves through PATH and `.local/bin` is not on it otherwise.
  if (fs.existsSync(BIN_DIR)) {
    process.env.PATH = `${BIN_DIR}${path.delimiter}${process.env.PATH || ''}`;
  }
  for (const name of runtimes) {
    Object.assign(process.env, managedEnv(name));
  }

  for (const name of runtimes) {
    const result = await ensureRuntime(name, { download: allowDownload });
    results.push(result);
    // An install only just made needs the same env treatment.
    if (result.status === 'installed') {
      Object.assign(process.env, managedEnv(name));
      warnings.push(`${SPECS[name].label} was installed into ${BIN_DIR} — restart so PATH picks it up.`);
    } else if (result.status !== 'ok') {
      warnings.push(`${SPECS[name].label}: ${result.detail}`);
    }
  }

  if (chromium) {
    const chrome = await ensureChromium({ download: allowDownload });
    results.push(chrome);
    if (chrome.status === 'installed') {
      // Hand the resolved path to anything reading the env during this boot, so
      // a browser downloaded a moment ago is usable without a restart.
      process.env.PUPPETEER_EXECUTABLE_PATH = chrome.path;
      warnings.push(`Chromium was installed at ${chrome.path}.`);
    } else if (chrome.status !== 'ok') {
      warnings.push(`Chromium: ${chrome.detail || 'not found'} — browser tasks will fail.`);
    }
  }

  // Python is checked but never load-bearing; Chromium is excluded here because
  // it is a browser, reported on its own line.
  const loadBearing = results.filter((r) => r.name !== 'python' && r.name !== 'chromium');
  const ok = loadBearing.every((r) => r.status === 'ok' || r.status === 'installed');
  return { ok, results, warnings };
};

export const formatReport = (report) => report.warnings
  .map((w) => `[bootstrap] WARNING ${w}`)
  .join('\n');
