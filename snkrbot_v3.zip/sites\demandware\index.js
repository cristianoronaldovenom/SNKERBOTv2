import { tryRequestFirstAddToCart } from '../../helpers/browser-request-atc.js';
import { tuneSitePage } from '../../helpers/site-checkout-fastpath.js';
import logger from '../../helpers/logger.js';
import { captureOrderSuccess } from '../../helpers/order-capture.js';
import { humanType, humanTypeInFrames, humanClick, humanSelect } from '../../helpers/human-type.js';
import {
  formatPostal, stripPhone, dismissAutocomplete, verifyFieldValue,
  requireCardIframe, FillReport, assertCriticalFields
} from '../../helpers/autofill-utils.js';
import {
  retryWithBackoff, guardedGoto, preOrderGuard, postClickGuard,
  takeFailureScreenshot
} from '../../helpers/checkout-guards.js';

import { waitForAnySelector } from '../../helpers/site-runtime.js';
import { assertActionButtonIntent } from '../../helpers/checkout-controls.js';

const TIMEOUT = 15000;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const findFirst = async (page, selectorList, timeout = TIMEOUT) => {
  const selector = await waitForAnySelector(page, selectorList, { timeout });
  if (!selector) return null;
  const el = await page.$(selector).catch(() => null);
  return el ? { el, selector } : null;
};

const clickFirst = async (page, selectorList, { stage = '' } = {}) => {
  const found = await findFirst(page, selectorList, TIMEOUT);
  if (!found) throw new Error(`Could not find clickable element at stage "${stage}" — tried [${selectorList.join(', ')}]`);
  await humanClick(page, found.selector);
  return found.selector;
};

const fillField = async (page, selectorList, value, { type = 'text', label = '', report = null } = {}) => {
  const name = label || 'unnamed';
  if (!value) { if (report) report.record(name, true, 'skipped (empty)'); return false; }
  const found = await findFirst(page, selectorList, 8000);
  if (!found) { if (report) report.record(name, false, 'selector not found'); return false; }
  const formatted = type === 'postal' ? formatPostal(value) : type === 'phone' ? stripPhone(value) : String(value);
  for (let attempt = 0; attempt < 2; attempt++) {
    await found.el.click({ clickCount: 3 }).catch(() => {});
    await page.keyboard.press('Backspace').catch(() => {});
    await humanType(page, found.selector, formatted);
    await dismissAutocomplete(page);
    await page.keyboard.press('Tab').catch(() => {});
    const v = await verifyFieldValue(page, found.selector, formatted, type);
    if (v.ok) { if (report) report.record(name, true); return true; }
    logger.warn(`[Demandware] ${name} did not stick on attempt ${attempt + 1} (got "${v.actual}", expected "${v.expected}"), retrying`);
  }
  if (report) report.record(name, false, 'verify failed after retry');
  return false;
};

const SELECTORS = {
  addToCart: [
    '.add-to-cart', 'button.add-to-cart', 'button[data-action="add-to-cart"]',
    'button.add-to-cart-btn', '#add-to-cart-button', 'button[name="addToCart"]'
  ],
  qtyInput: [
    'select.quantity-select', 'input[name="Quantity"]', 'input.quantity-select',
    'select[name="quantity"]', 'input[name="quantity"]'
  ],
  checkout: [
    '.checkout-btn', 'a.checkout-btn', 'button.checkout-btn',
    'a[href*="/checkout"]', 'button[name="dwfrm_cart_checkoutCart"]'
  ],
  guestCheckout: [
    'button.guest-continue', 'button[name="dwfrm_login_unregistered"]',
    'a.guest-checkout', 'button[data-action="guest"]'
  ],
  email: [
    'input[name="dwfrm_billing_billingAddress_email_emailAddress"]',
    'input[name="email"]', 'input#email', 'input[type="email"]'
  ],
  firstName: [
    'input[name="dwfrm_shipping_shippingAddress_addressFields_firstName"]',
    'input[name="firstName"]', 'input#shippingFirstName'
  ],
  lastName: [
    'input[name="dwfrm_shipping_shippingAddress_addressFields_lastName"]',
    'input[name="lastName"]', 'input#shippingLastName'
  ],
  address1: [
    'input[name="dwfrm_shipping_shippingAddress_addressFields_address1"]',
    'input[name="address1"]', 'input#shippingAddressOne'
  ],
  address2: [
    'input[name="dwfrm_shipping_shippingAddress_addressFields_address2"]',
    'input[name="address2"]'
  ],
  city: [
    'input[name="dwfrm_shipping_shippingAddress_addressFields_city"]',
    'input[name="city"]', 'input#shippingCity'
  ],
  state: [
    'select[name="dwfrm_shipping_shippingAddress_addressFields_states_stateCode"]',
    'select[name="state"]', 'select#shippingState'
  ],
  postalCode: [
    'input[name="dwfrm_shipping_shippingAddress_addressFields_postalCode"]',
    'input[name="postalCode"]', 'input[name="zipCode"]'
  ],
  phone: [
    'input[name="dwfrm_shipping_shippingAddress_addressFields_phone"]',
    'input[name="phone"]', 'input[type="tel"]'
  ],
  shippingSubmit: [
    'button.submit-shipping', 'button[name="submit-shipping"]',
    'button[data-action="submit-shipping"]'
  ],
  cardNumber: [
    'input[name="dwfrm_billing_creditCardFields_cardNumber"]',
    'input#cardNumber', 'input[name="cardNumber"]', 'input[autocomplete="cc-number"]'
  ],
  cardOwner: [
    'input[name="dwfrm_billing_creditCardFields_cardOwner"]',
    'input#cardOwner', 'input[name="cardholderName"]', 'input[autocomplete="cc-name"]'
  ],
  expMonth: [
    'select[name="dwfrm_billing_creditCardFields_expirationMonth"]',
    'select#expirationMonth'
  ],
  expYear: [
    'select[name="dwfrm_billing_creditCardFields_expirationYear"]',
    'select#expirationYear'
  ],
  cvv: [
    'input[name="dwfrm_billing_creditCardFields_securityCode"]',
    'input#securityCode', 'input[autocomplete="cc-csc"]', 'input[name="cvv"]'
  ],
  paymentSubmit: [
    'button.submit-payment', 'button[name="submit-payment"]',
    'button[data-action="submit-payment"]'
  ],
  placeOrder: [
    'button.place-order', 'button[name="submit-order"]',
    'button[data-action="place-order"]'
  ],
  orderConfirmation: [
    '.order-confirmation-number', '.order-thank-you',
    'h1.order-thank-you-msg', '[data-testid="order-confirmation"]'
  ]
};

const runDemandware = async ({ page, task }) => {
  const startedAt = Date.now();
  logger.info(`[Demandware] Starting checkout for task ${task.id}: ${task.url}`);
  await tuneSitePage(page, { navigationTimeoutMs: 30000 });
  page.setDefaultNavigationTimeout(30000);

  await guardedGoto(page, task.url, { taskId: task.id, stage: 'pdp_load' });
  await waitForAnySelector(page, SELECTORS.addToCart, { timeout: 8000 });

  if (task.quantity && task.quantity > 1) {
    const qtyFound = await findFirst(page, SELECTORS.qtyInput, 5000);
    if (qtyFound) {
      const tag = await qtyFound.el.evaluate((el) => el.tagName.toLowerCase());
      if (tag === 'select') await page.select(qtyFound.selector, String(task.quantity)).catch(() => {});
      else { await qtyFound.el.click({ clickCount: 3 }).catch(() => {}); await humanType(page, qtyFound.selector, String(task.quantity)); }
      logger.info(`[Demandware] Quantity set to ${task.quantity}`);
    }
  }

  await retryWithBackoff(async () => {
if (!(await tryRequestFirstAddToCart(page, SELECTORS.addToCart))) await clickFirst(page, SELECTORS.addToCart, { stage: 'add_to_cart' });
  }, { attempts: 3, baseMs: 1000, label: 'Demandware ATC' });
  logger.info('[Demandware] Added to cart');
  await waitForAnySelector(page, SELECTORS.checkout, { timeout: 5000 });

  await clickFirst(page, SELECTORS.checkout, { stage: 'cart_to_checkout' });
  await page.waitForNavigation({ waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
  await postClickGuard(page, { taskId: task.id, stage: 'cart_to_checkout' });
  await waitForAnySelector(page, [...SELECTORS.guestCheckout, ...SELECTORS.email], { timeout: 8000 });

  const guest = await findFirst(page, SELECTORS.guestCheckout, 4000);
  if (guest) { await humanClick(page, guest.selector); await waitForAnySelector(page, SELECTORS.email, { timeout: 8000 }); await postClickGuard(page, { taskId: task.id, stage: 'guest_checkout' }); }

  const ship = task.shippingAddress;
  if (!ship) throw new Error('Shipping address missing at stage "fill_shipping"');
  const shipReport = new FillReport(task.id, 'Demandware Shipping');
  await fillField(page, SELECTORS.email, task.notification_email_address || ship.email, { label: 'email', report: shipReport });
  await fillField(page, SELECTORS.firstName, ship.first_name, { label: 'firstName', report: shipReport });
  await fillField(page, SELECTORS.lastName, ship.last_name, { label: 'lastName', report: shipReport });
  await fillField(page, SELECTORS.address1, ship.address1, { label: 'address1', report: shipReport });
  await fillField(page, SELECTORS.address2, ship.address2, { label: 'address2', report: shipReport });
  await fillField(page, SELECTORS.city, ship.city, { label: 'city', report: shipReport });
  await fillField(page, SELECTORS.postalCode, formatPostal(ship.zip), { label: 'postalCode', report: shipReport });
  await fillField(page, SELECTORS.phone, stripPhone(ship.phone), { label: 'phone', report: shipReport });
  const stateSel = await findFirst(page, SELECTORS.state, 3000);
  if (stateSel) await humanSelect(page, stateSel.selector, ship.state).catch(() => {});
  shipReport.log();
  assertCriticalFields(shipReport, ['email', 'firstName', 'lastName', 'address1', 'city', 'postalCode', 'phone']);

  await clickFirst(page, SELECTORS.shippingSubmit, { stage: 'submit_shipping' });
  await postClickGuard(page, { taskId: task.id, stage: 'submit_shipping' });
  await waitForAnySelector(page, SELECTORS.cardNumber, { timeout: 12000 });

  const pay = task.paymentProfile;
  if (!pay) throw new Error('Payment profile missing at stage "fill_payment"');

  await requireCardIframe(page, { timeout: 15000 });

  const payReport = new FillReport(task.id, 'Demandware Payment');
  await humanTypeInFrames(page, SELECTORS.cardOwner.join(', '), pay.card_holder_name, { tabAfter: true });
  const cardFilled = await humanTypeInFrames(page, SELECTORS.cardNumber.join(', '), pay.card_number.replace(/\s/g, ''), { tabAfter: true });
  payReport.record('cardNumber', cardFilled);
  const expMo = await findFirst(page, SELECTORS.expMonth, 3000);
  if (expMo) await humanSelect(page, expMo.selector, String(parseInt(pay.expiration_month, 10))).catch(() => {});
  const expYr = await findFirst(page, SELECTORS.expYear, 3000);
  if (expYr) await humanSelect(page, expYr.selector, String(pay.expiration_year)).catch(() => {});
  await humanTypeInFrames(page, SELECTORS.cvv.join(', '), pay.cvv, { tabAfter: true });
  payReport.log();
  assertCriticalFields(payReport, ['cardNumber', 'cardOwner', 'expirationMonth', 'expirationYear', 'cvv']);

  await clickFirst(page, SELECTORS.paymentSubmit, { stage: 'submit_payment' });
  await postClickGuard(page, { taskId: task.id, stage: 'submit_payment' });
  await waitForAnySelector(page, SELECTORS.placeOrder, { timeout: 12000 });

  await preOrderGuard(page, { taskId: task.id });
  await assertActionButtonIntent(page, SELECTORS.placeOrder, { stage: 'place order', allow: /place order|submit order/i });
  await clickFirst(page, SELECTORS.placeOrder, { stage: 'place_order' });

  const confirmed = await Promise.race([
    findFirst(page, SELECTORS.orderConfirmation, 60000),
    page.waitForFunction(() => /thank-you|order-confirmation|confirmation/.test(window.location.pathname), { timeout: 60000 }).then(() => ({ url: true })).catch(() => null)
  ]);
  if (!confirmed) {
    await takeFailureScreenshot(page, task.id, 'confirm_order_fail');
    throw new Error('Order confirmation not detected at stage "confirm_order"');
  }
  const orderNumber = await page.evaluate(() => {
    const el = document.querySelector('.order-number, .order-confirmation-number, [class*="orderNumber" i]');
    return el ? el.textContent.trim() : null;
  }).catch(() => null);

  logger.info(`[Demandware] ✅ Order placed for task ${task.id}! Order: ${orderNumber || 'N/A'}`);
  await captureOrderSuccess({ page, taskId: task.id, orderNumber, productUrl: task.url, durationMs: Date.now() - startedAt }).catch(() => {});
};

export default runDemandware;
