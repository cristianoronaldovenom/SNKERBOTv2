import axios from 'axios';
import logger from './logger.js';
import db from '../db/index.js';

const getSetting = async (key) => {
  try {
    const r = await db('settings').where({ key }).first();
    return r?.value || null;
  } catch (_) { return null; }
};

const formatDuration = (ms) => {
  if (!ms || ms < 0) return null;
  if (ms < 1000) return `${ms}ms`;
  const s = ms / 1000;
  if (s < 60) return `${s.toFixed(1)}s`;
  return `${Math.floor(s / 60)}m ${Math.round(s % 60)}s`;
};

const SITE_NAMES = {
  1: 'Footsites', 2: 'Shopify', 3: 'Demandware', 4: 'Nike',
  5: 'Supreme NY', 6: 'Pokemon Center', 7: 'Topps',
  8: 'Walmart', 9: 'Best Buy', 10: 'Target',
  11: 'GameStop', 12: 'Amazon'
};

const extractProductImage = (url) => {
  try {
    const u = new URL(url);
    const host = u.hostname.replace(/^www\./, '');
    if (host.includes('pokemoncenter')) return 'https://assets.pokemon.com/assets/cms2/img/misc/gus/pokemon-center-logo.png';
    if (host.includes('topps')) return 'https://www.topps.com/on/demandware.static/Sites-Topps-Site/-/default/topps-logo.svg';
    if (host.includes('walmart')) return 'https://i5.walmartimages.ca/en/ip/favicon.ico';
    if (host.includes('bestbuy')) return 'https://www.bestbuy.ca/favicon.ico';
    if (host.includes('target')) return 'https://target.scene7.com/is/content/Target/GUEST_c5fc26d5-8f3c-42e3-b47b-44aa8b29f25e';
    if (host.includes('amazon')) return 'https://www.amazon.ca/favicon.ico';
    if (host.includes('nike')) return 'https://www.nike.com/favicon.ico';
    if (host.includes('gamestop')) return 'https://www.gamestop.ca/favicon.ico';
    return null;
  } catch (_) { return null; }
};

const extractSiteName = (url, siteId) => {
  if (siteId && SITE_NAMES[siteId]) return SITE_NAMES[siteId];
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch (_) { return 'Unknown Site'; }
};

const sendDiscord = async (webhookUrl, p) => {
  const color = p.success ? 0x00ff9c : 0xff3b5c;
  const siteName = extractSiteName(p.productUrl, p.siteId);
  const thumbnail = extractProductImage(p.productUrl);

  const fields = [
    { name: 'Site', value: siteName, inline: true },
    { name: 'Task ID', value: String(p.taskId), inline: true }
  ];
  if (p.stage && !p.success) fields.push({ name: 'Stage', value: p.stage, inline: true });
  if (p.orderNumber)   fields.push({ name: 'Order #', value: `\`${p.orderNumber}\``, inline: true });
  if (p.profileLabel)  fields.push({ name: 'Profile', value: p.profileLabel, inline: true });
  if (p.retryCount != null && p.retryCount > 0) {
    fields.push({ name: 'Attempt', value: `${p.retryCount + 1}`, inline: true });
  }
  const dur = formatDuration(p.durationMs);
  if (dur) fields.push({ name: 'Speed', value: dur, inline: true });
  if (p.productUrl) fields.push({ name: 'Product', value: `[Link](${String(p.productUrl).slice(0, 200)})`, inline: false });
  if (p.screenshotUrl) fields.push({ name: 'Screenshot', value: `[View](${String(p.screenshotUrl).slice(0, 500)})`, inline: false });

  const embed = {
    title: p.success ? 'Checkout Successful' : 'Checkout Failed',
    description: p.message || (p.success ? 'Order placed.' : 'Bot did not complete checkout.'),
    color,
    fields,
    footer: { text: `SneakerBot | ${new Date().toLocaleTimeString('en-US', { hour12: true, hour: '2-digit', minute: '2-digit', second: '2-digit' })}` },
    timestamp: new Date().toISOString()
  };

  if (thumbnail) embed.thumbnail = { url: thumbnail };

  await axios.post(webhookUrl, { embeds: [embed] }, { timeout: 8000 });
};

const sendHttp = async (webhookUrl, payload) => {
  await axios.post(webhookUrl, {
    ...payload,
    durationFormatted: formatDuration(payload.durationMs),
    timestamp: new Date().toISOString()
  }, { timeout: 8000 });
};

export const notify = async ({
  taskId, message, success,
  stage = null, productUrl = null, orderNumber = null,
  screenshotUrl = null, profileLabel = null,
  retryCount = 0, durationMs = null, siteId = null
}) => {
  const [discordUrl, httpUrl] = await Promise.all([
    getSetting('discord_webhook_url'),
    getSetting('webhook_url')
  ]);

  const payload = { taskId, message, success, stage, productUrl, orderNumber, screenshotUrl, profileLabel, retryCount, durationMs, siteId };

  await Promise.allSettled([
    discordUrl ? sendDiscord(discordUrl, payload).then(
      () => logger.info(`[Notifier] Discord sent for task ${taskId}`),
      (err) => logger.warn(`[Notifier] Discord failed: ${err.message}`)
    ) : Promise.resolve(),
    httpUrl ? sendHttp(httpUrl, payload).then(
      () => logger.info(`[Notifier] HTTP webhook sent for task ${taskId}`),
      (err) => logger.warn(`[Notifier] HTTP webhook failed: ${err.message}`)
    ) : Promise.resolve()
  ]);
};

export const sendTestNotification = async (channel) => {
  const url = await getSetting(channel === 'discord' ? 'discord_webhook_url' : 'webhook_url');
  if (!url) throw new Error(`No ${channel} webhook URL configured`);
  const payload = {
    taskId: 0,
    message: `Test notification from SneakerBot at ${new Date().toLocaleString()}`,
    success: true,
    stage: 'test',
    durationMs: 1234,
    profileLabel: 'TestProfile',
    orderNumber: 'TEST-12345'
  };
  if (channel === 'discord') await sendDiscord(url, payload);
  else await sendHttp(url, payload);
};
