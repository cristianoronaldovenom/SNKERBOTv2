export const up = (knex) =>
  knex.schema.createTable('task_runs', (t) => {
    t.increments('id').primary();
    t.integer('task_id').notNullable().references('id').inTable('tasks').onDelete('CASCADE');
    t.integer('attempt').notNullable().defaultTo(1);
    t.string('status', 32).notNullable();         // success | failed | preflight_fail | aborted
    t.string('stage_failed', 64).nullable();
    t.string('order_number', 64).nullable();
    t.integer('duration_ms').nullable();
    t.text('error_message').nullable();
    t.string('screenshot_url', 500).nullable();
    t.string('profile_label', 128).nullable();
    t.string('proxy_host', 128).nullable();
    t.timestamp('started_at').notNullable().defaultTo(knex.fn.now());
    t.timestamp('finished_at').nullable();
    t.index(['task_id', 'started_at']);
    t.index(['status']);
  });

export const down = (knex) => knex.schema.dropTableIfExists('task_runs');
