import { jest } from '@jest/globals';

jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));

const { buildDataDomeFingerprint } = await import('../../helpers/datadome.js');

const chromeWin = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';
const chromeMac = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';
const edge = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0';
const firefox = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0';
const safari = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_5_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Safari/605.1.15';
const linux = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

describe('DataDome payload coherence', () => {
  test('platform follows the UA family', () => {
    expect(buildDataDomeFingerprint(chromeWin).pf).toBe('Win32');
    expect(buildDataDomeFingerprint(edge).pf).toBe('Win32');
    expect(buildDataDomeFingerprint(chromeMac).pf).toBe('MacIntel');
    expect(buildDataDomeFingerprint(safari).pf).toBe('MacIntel');
    expect(buildDataDomeFingerprint(linux).pf).toBe('Linux x86_64');
  });

  test('renderer follows the engine', () => {
    expect(buildDataDomeFingerprint(chromeWin).glrd).toMatch(/D3D11/);
    expect(buildDataDomeFingerprint(chromeMac).glrd).toMatch(/ANGLE \(Apple/);
    expect(buildDataDomeFingerprint(safari).glrd).toBe('Apple GPU');
    expect(buildDataDomeFingerprint(firefox).glrd).not.toMatch(/ANGLE/);
  });

  test('navigator.vendor follows the engine', () => {
    expect(buildDataDomeFingerprint(chromeWin).vnd).toBe('Google Inc.');
    expect(buildDataDomeFingerprint(firefox).vnd).toBe('');
    expect(buildDataDomeFingerprint(safari).vnd).toBe('Apple Computer, Inc.');
  });

  test('locale drives lg and leads the language list', () => {
    const fp = buildDataDomeFingerprint(chromeWin, { locale: 'de-DE' });
    expect(fp.lg).toBe('de-DE');
    expect(JSON.parse(fp.lgs)[0]).toBe('de-DE');
  });

  test('screen geometry comes from the profile, not a hardcoded 1920x1080', () => {
    const fp = buildDataDomeFingerprint(chromeWin, {
      locale: 'en-CA',
      geo: { screenWidth: 1440, screenHeight: 900, availHeight: 810, dpr: 2 }
    });
    expect(fp.br_ow).toBe(1440);
    expect(fp.br_oh).toBe(900);
  });

  test('defaults to 1920x1080 only when no geometry is supplied', () => {
    const fp = buildDataDomeFingerprint(chromeWin);
    expect(fp.br_ow).toBe(1920);
    expect(fp.br_oh).toBe(1080);
  });
});
