import assert from 'node:assert/strict';
import fs from 'node:fs/promises';

// This file used to be a bare top-level assert script, which Jest rejects with
// "Your test suite must contain at least one test." Wrapping the same assertions
// in a test() keeps the coverage and makes the suite actually run.
const sites = ['amazon','bestbuy','demandware','footsites','gamestop','nike','pokemoncenter','supremenewyork','topps','target','walmart'];

test('every site adapter uses the request-first ATC bridge', async () => {
  for (const site of sites) {
    const src = await fs.readFile(`sites/${site}/index.js`, 'utf8');
    assert.match(src, /browser-request-atc\.js/, `${site} should have the request-first ATC bridge`);
  }
});

test('the ATC bridge only submits same-origin POST forms', async () => {
  const helper = await fs.readFile('helpers/browser-request-atc.js', 'utf8');
  assert.match(helper, /same-origin/);
  assert.match(helper, /method:\s*'POST'/);
  assert.match(helper, /actionRe/);
});
