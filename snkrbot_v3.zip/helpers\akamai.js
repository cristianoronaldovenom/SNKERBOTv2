import { spawn } from 'child_process';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import logger from './logger.js';
import { tlsRequest } from './tls-client.js';

const __dirname = dirname(fileURLToPath(import.meta.url));

const BMP_PORT = 1337;
const BMP_HOST = '127.0.0.1';
const BMP_URL = `http://${BMP_HOST}:${BMP_PORT}/akamai/bmp`;
const BINARY = join(__dirname, '..', 'vendor', 'akamai-bmp-server');
const DEVICES = join(__dirname, '..', 'vendor', 'akamai-bmp-devices.json');

let serverProcess = null;
let serverReady = false;

export const startAkamaiServer = () => {
  return new Promise((resolve) => {
    if (serverReady) return resolve(true);

    logger.info('[Akamai] Starting BMP generator server...');

    serverProcess = spawn(BINARY, [
      '--host', BMP_HOST,
      '--port', String(BMP_PORT),
      '--devicepath', DEVICES
    ], { stdio: ['ignore', 'pipe', 'pipe'] });

    serverProcess.stdout.on('data', (data) => {
      const msg = data.toString().trim();
      logger.info(`[Akamai] ${msg}`);
      if (msg.includes('Starting server')) {
        serverReady = true;
        resolve(true);
      }
    });

    serverProcess.stderr.on('data', (data) => {
      logger.warn(`[Akamai] ${data.toString().trim()}`);
    });

    serverProcess.on('error', (err) => {
      logger.error(`[Akamai] Failed to start server: ${err.message}`);
      serverReady = false;
      resolve(false);
    });

    serverProcess.on('exit', (code) => {
      logger.warn(`[Akamai] Server exited with code ${code}`);
      serverReady = false;
    });

    setTimeout(() => {
      if (!serverReady) {
        serverReady = true;
        resolve(true);
      }
    }, 3000);
  });
};

export const stopAkamaiServer = () => {
  if (serverProcess) {
    serverProcess.kill('SIGTERM');
    serverProcess = null;
    serverReady = false;
    logger.info('[Akamai] BMP server stopped');
  }
};

const APP_MAP = {
  'amazon.ca':         'com.amazon.mshop.android.shopping',
  'amazon.com':        'com.amazon.mshop.android.shopping',
  'pokemoncenter.com': 'com.pokemoncenter.app',
  'footlocker.com':    'com.footlocker.confirmed',
  'nike.com':          'com.nike.omega',
  'jdsports.com':      'com.jd.sports',
  'adidas.com':        'com.adidas.confirmed.app',
  default:             'com.example.app'
};

const getAppId = (url) => {
  try {
    const host = new URL(url).hostname;
    for (const [domain, appId] of Object.entries(APP_MAP)) {
      if (domain === 'default') continue;
      if (host.includes(domain)) return appId;
    }
  } catch (_) {}
  return APP_MAP.default;
};

export const getAkamaiSensor = async ({ url, version = '3.3.4', challenge = false }) => {
  if (!serverReady) {
    const started = await startAkamaiServer();
    if (!started) {
      logger.warn('[Akamai] Server not available — skipping sensor generation');
      return null;
    }
    await new Promise(r => setTimeout(r, 500));
  }

  try {
    const body = JSON.stringify({
      app: getAppId(url),
      lang: 'en_CA',
      version,
      challenge,
      powUrl: url
    });

    const res = await fetch(BMP_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body,
      signal: AbortSignal.timeout(8000)
    });

    if (!res.ok) {
      logger.warn(`[Akamai] BMP server returned ${res.status}`);
      return null;
    }

    const data = await res.json();
    logger.info(`[Akamai] Sensor generated — device: ${data.brand} ${data.model} (Android ${data.androidVersion})`);
    return data;
  } catch (err) {
    logger.warn(`[Akamai] Sensor request failed: ${err.message}`);
    return null;
  }
};

// Parse all Set-Cookie headers from a TLS sidecar response into a name→value map.
// The sidecar serialises response headers as { 'set-cookie': string | string[] }.
const parseCookies = (headers = {}) => {
  const raw = headers['set-cookie'] || headers['Set-Cookie'] || [];
  const list = Array.isArray(raw) ? raw : (raw ? [raw] : []);
  const out = {};
  for (const h of list) {
    const m = h.match(/^([^=]+)=([^;]*)/);
    if (m) out[m[1].trim()] = m[2].trim();
  }
  return out;
};

// Submit Akamai BMP sensor data and return harvested session cookies.
// MUST route through the TLS sidecar — Akamai cross-validates the sensor
// payload against the TLS ClientHello (JA3/JA4). Raw fetch() exposes a
// Node.js/OpenSSL fingerprint that causes instant sensor rejection.
export const submitAkamaiSensor = async ({ sensorData, pageUrl, existingCookies = '', ua }) => {
  try {
    const origin = new URL(pageUrl).origin;
    const bmUrl = `${origin}/_bm/ajax_done`;

    const result = await tlsRequest({
      method: 'POST',
      url: bmUrl,
      headers: {
        'content-type': 'application/x-www-form-urlencoded',
        'user-agent': ua || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
        'origin': origin,
        'referer': pageUrl,
        'accept': '*/*',
        'accept-language': 'en-CA,en-US;q=0.9,en;q=0.8',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        ...(existingCookies ? { 'cookie': existingCookies } : {})
      },
      body: `sensor_data=${encodeURIComponent(sensorData)}`,
      timeoutMs: 12000
    });

    if (!result.ok) {
      logger.warn(`[Akamai] Sensor submission failed: ${result.error}`);
      return null;
    }

    // Harvest ALL Akamai session cookies from the response.
    // _abck is the primary validation cookie; bm_sz and ak_bmsc are also
    // required for Amazon and other sites to pass downstream bot checks.
    const cookies = parseCookies(result.headers);
    const abck = cookies['_abck'];
    if (abck) {
      const names = Object.keys(cookies).filter(k => cookies[k]);
      logger.info(`[Akamai] Session cookies obtained: ${names.join(', ')}`);
      return {
        _abck:   abck,
        bm_sz:   cookies['bm_sz']   || null,
        ak_bmsc: cookies['ak_bmsc'] || null
      };
    }

    logger.warn(`[Akamai] No _abck in response (status ${result.status})`);
    return null;
  } catch (err) {
    logger.warn(`[Akamai] Sensor submit failed: ${err.message}`);
    return null;
  }
};

export const detectAndSolveAkamai = async ({ html, pageUrl, ua, sessionCookies }) => {
  const head = html.slice(0, 5000);
  const isAkamaiBlock =
    /<title>[^<]*Access Denied[^<]*<\/title>/i.test(head) &&
    (/Reference\s*&#?\d*;\s*[a-f0-9.#]{10,}/i.test(head) ||
     /\.akamaihd\.net|akamai\.net|akamaized\.net/i.test(head) ||
     /bm-verify|sec-bcm/i.test(html.slice(0, 20000)));

  if (!isAkamaiBlock) return null;

  const host = new URL(pageUrl).hostname;
  const existing = sessionCookies?.get?.(host) || '';

  logger.info(`[Akamai] Bot challenge detected on ${host}`);

  // Attempt 1: standard sensor (challenge=false)
  let sensorResult = await getAkamaiSensor({ url: pageUrl });
  let cookieResult = sensorResult?.sensor
    ? await submitAkamaiSensor({ sensorData: sensorResult.sensor, pageUrl, existingCookies: existing, ua })
    : null;

  // Attempt 2: when Akamai rejects the first sensor it issues a challenge token.
  // Regenerating with challenge=true produces sensor data that embeds the
  // challenge response, which typically passes the second validation round.
  if (!cookieResult) {
    logger.info(`[Akamai] First sensor rejected — retrying with challenge=true`);
    sensorResult = await getAkamaiSensor({ url: pageUrl, challenge: true });
    if (sensorResult?.sensor) {
      cookieResult = await submitAkamaiSensor({
        sensorData: sensorResult.sensor,
        pageUrl,
        existingCookies: existing,
        ua
      });
    }
  }

  if (!cookieResult) return null;

  // Merge all obtained Akamai cookies into the persisted session string.
  let merged = existing;
  const mergeCookie = (name, value) => {
    if (!value) return;
    const re = new RegExp(`${name}=[^;]*`, 'i');
    if (re.test(merged)) {
      merged = merged.replace(re, `${name}=${value}`);
    } else {
      merged = merged ? `${merged}; ${name}=${value}` : `${name}=${value}`;
    }
  };
  mergeCookie('_abck',   cookieResult._abck);
  mergeCookie('bm_sz',   cookieResult.bm_sz);
  mergeCookie('ak_bmsc', cookieResult.ak_bmsc);

  sessionCookies?.set?.(host, merged);
  logger.info(`[Akamai] Cookies refreshed for ${host} (_abck + bm_sz + ak_bmsc)`);
  return cookieResult._abck;
};
