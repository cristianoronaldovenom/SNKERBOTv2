import { jest } from '@jest/globals';
import fs from 'node:fs/promises';
import path from 'node:path';

jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));

const { bestbuyCheck } = await import('../../helpers/site-stock-apis.js');

const ROOT = process.cwd();
const read = (rel) => fs.readFile(path.resolve(ROOT, rel), 'utf8');

// ─── Best Buy adapter: regression + power checks ──────────────────────────────

describe('Best Buy adapter hardening', () => {
  test('imports assertActionButtonIntent (it is called at Place Order)', async () => {
    const src = await read('sites/bestbuy/index.js');
    expect(src).toMatch(/import\s*\{[^}]*assertActionButtonIntent[^}]*\}\s*from\s*'\.\.\/\.\.\/helpers\/checkout-controls\.js'/);
    expect(src).toMatch(/await assertActionButtonIntent\(page, SELECTORS\.placeOrder/);
  });

  test('every adapter that calls assertActionButtonIntent imports it', async () => {
    const sites = (await fs.readdir(path.resolve(ROOT, 'sites'), { withFileTypes: true }))
      .filter((d) => d.isDirectory())
      .map((d) => d.name);

    for (const site of sites) {
      const src = await read(`sites/${site}/index.js`);
      const calls = (src.match(/(?<![\w.])assertActionButtonIntent\s*\(/g) || []).length;
      if (!calls) continue;
      expect(src).toMatch(/from\s*'\.\.\/\.\.\/helpers\/checkout-controls\.js'/);
    }
  });

  test('polls the PDP instead of a single-shot load', async () => {
    const src = await read('sites/bestbuy/index.js');
    expect(src).toMatch(/BESTBUY_MONITOR_ATTEMPTS/);
    expect(src).toMatch(/const monitorAndAtc/);
    expect(src).toMatch(/for \(let attempt = 0; attempt < MONITOR_MAX_ATTEMPTS/);
    // Backoff must exist so the loop is not a hot spin.
    expect(src).toMatch(/const computePollDelay/);
  });

  test('reads PDP stock state before acting (sold out vs not ready)', async () => {
    const src = await read('sites/bestbuy/index.js');
    expect(src).toMatch(/const readPdpState/);
    expect(src).toMatch(/state\.soldOut \|\| !state\.atcReady/);
  });

  test('detects bot blocks and refreshes the Akamai session', async () => {
    const src = await read('sites/bestbuy/index.js');
    expect(src).toMatch(/detectBotBlockOnPage/);
    expect(src).toMatch(/detectAndSolveAkamai/);
    expect(src).toMatch(/const refreshAkamaiSession/);
    expect(src).toMatch(/domain: '\.bestbuy\.ca'/);
  });

  test('gates every post-PDP stage on the block/captcha guard', async () => {
    const src = await read('sites/bestbuy/index.js');
    expect(src).toMatch(/if \(stage\.name !== 'monitorAndAtc'\) await guardedStage\(page, task, stage\.name\)/);
    // The PDP loop refreshes the session itself instead of clicking a stale button.
    expect(src).toMatch(/bot-block on PDP/);
  });

  test('auto-solves captcha and notifies on 3D Secure', async () => {
    const src = await read('sites/bestbuy/index.js');
    expect(src).toMatch(/const handleCaptcha/);
    expect(src).toMatch(/hasCaptchaApiKey/);
    expect(src).toMatch(/notify\(\{[\s\S]*stage: 'place_order_3ds'/);
  });

  test('does not double-add when ATC partially succeeded', async () => {
    const src = await read('sites/bestbuy/index.js');
    expect(src).toMatch(/verifyCartHasItem\(page, \{ timeout: 2500 \}\)/);
    expect(src).toMatch(/ATC recovered/);
  });
});

// ─── Pokemon Center adapter: power checks ─────────────────────────────────────

describe('Pokemon Center adapter power', () => {
  test('consumes and deposits stockpiled captcha tokens', async () => {
    const src = await read('sites/pokemoncenter/index.js');
    expect(src).toMatch(/consumeToken\(captchaInfo\.type, captchaInfo\.siteKey\)/);
    expect(src).toMatch(/depositToken\(/);
  });

  test('arms a background pre-solver for the detected sitekey', async () => {
    const src = await read('sites/pokemoncenter/index.js');
    expect(src).toMatch(/const armStockpile/);
    expect(src).toMatch(/ensureStockpiling\(/);
    expect(src).toMatch(/armStockpile\('PokemonCenter'/);
  });

  test('does not re-navigate the PDP on every poll', async () => {
    const src = await read('sites/pokemoncenter/index.js');
    expect(src).toMatch(/let onPdp = false/);
    expect(src).toMatch(/if \(!onPdp\)/);
  });

  test('derives the _abck cookie domain from the PDP host', async () => {
    const src = await read('sites/pokemoncenter/index.js');
    expect(src).toMatch(/domain: `\.\$\{pdpHost\.replace/);
  });

  test('does not double-add when ATC partially succeeded', async () => {
    const src = await read('sites/pokemoncenter/index.js');
    expect(src).toMatch(/ATC already applied/);
  });
});


// ─── Best Buy stock API: size gating ─────────────────────────────────────────

describe('bestbuyCheck.parseStock size gating', () => {
  test('uses the explicit online flag when no size is requested', () => {
    const r = bestbuyCheck.parseStock({ product: { name: 'X', availability: { isAvailableOnline: true } } });
    expect(r.inStock).toBe(true);
  });

  test('in-store-only availability does NOT arm an online checkout', () => {
    const r = bestbuyCheck.parseStock({ product: { name: 'X', availability: { isAvailableOnline: false } } });
    expect(r.inStock).toBe(false);
  });

  test('rejects when the requested size itself is unavailable', () => {
    const r = bestbuyCheck.parseStock({
      product: {
        name: 'X',
        availability: { isAvailableOnline: true },
        variants: [{ name: '9', isAvailableOnline: false }, { name: '10', isAvailableOnline: true }]
      }
    }, '9');
    expect(r.inStock).toBe(false);
    expect(r.availableSizes).toEqual(['10']);
  });

  test('accepts when the requested size is available', () => {
    const r = bestbuyCheck.parseStock({
      product: {
        name: 'X',
        availability: { isAvailableOnline: true },
        variants: [{ name: '9', isAvailableOnline: true }]
      }
    }, '9');
    expect(r.inStock).toBe(true);
  });

  test('treats a "coming soon" page as out of stock', () => {
    const r = bestbuyCheck.parseHtml('<p>Coming soon</p><button>Add to Cart</button>');
    expect(r.inStock).toBe(false);
  });
});

// ─── Lightsail / Linux portability ───────────────────────────────────────────

describe('Lightsail portability', () => {
  const SHELL_FILES = ['start.sh', 'deploy-lightsail.sh', 'Dockerfile', 'docker-compose.yml'];

  test('shell + container files are LF-only (no CRLF)', async () => {
    for (const rel of SHELL_FILES) {
      const buf = await fs.readFile(path.resolve(ROOT, rel));
      expect(buf.includes(0x0d)).toBe(false);
    }
  });

  test('every .sh in the repo is LF-only (a single CRLF breaks bash)', async () => {
    const walk = async (dir) => {
      const out = [];
      for (const entry of await fs.readdir(dir, { withFileTypes: true })) {
        // .local holds bootstrap-installed runtimes — the Go tree alone is tens of
        // thousands of files nobody here owns, and walking it blew the 5s timeout.
        if (entry.name === 'node_modules' || entry.name === '.git' || entry.name === '.local') continue;
        const full = path.join(dir, entry.name);
        if (entry.isDirectory()) out.push(...await walk(full));
        else if (entry.name.endsWith('.sh')) out.push(full);
      }
      return out;
    };
    const scripts = await walk(ROOT);
    expect(scripts.length).toBeGreaterThan(0);
    for (const script of scripts) {
      const buf = await fs.readFile(script);
      expect({ file: path.relative(ROOT, script), crlf: buf.includes(0x0d) })
        .toEqual({ file: path.relative(ROOT, script), crlf: false });
    }
  });

  test('.gitattributes pins LF for the files Linux parses', async () => {
    const ga = await read('.gitattributes');
    expect(ga).toMatch(/^\* text=auto$/m);
    expect(ga).toMatch(/^\*\.sh\s+text eol=lf$/m);
    expect(ga).toMatch(/^Dockerfile\s+text eol=lf$/m);
  });

  test('deploy script health check matches the app health route', async () => {
    const app = await read('app.js');
    const deploy = await read('deploy-lightsail.sh');
    const route = app.match(/app\.get\('(\/healthz?)'/)?.[1];
    expect(route).toBeTruthy();
    expect(deploy).toContain('/healthz');
  });

  test('systemd unit restarts the bot and runs start.sh', async () => {
    const deploy = await read('deploy-lightsail.sh');
    expect(deploy).toMatch(/Restart=always/);
    expect(deploy).toMatch(/ExecStart=\$APP_DIR\/start\.sh/);
  });

  // start.sh used to `exec node app.js`, which bypassed launcher.mjs entirely —
  // so neither the runtime bootstrap nor the threadpool sizing ever ran under
  // systemd or Docker, exactly the environments that lack a browser and Go.
  test('start.sh boots through launcher.mjs so bootstrap runs', async () => {
    const start = await read('start.sh');
    expect(start).toMatch(/exec node launcher\.mjs/);
    expect(start).not.toMatch(/exec node app\.js/);
  });

  // A redeploy used to run `rsync --delete` without excluding the database, so
  // every deploy silently replaced production state with the dev copy.
  test('redeploy preserves the database and runtime state', async () => {
    const deploy = await read('deploy-lightsail.sh');
    const rsyncLine = deploy.split('\n').findIndex((l) => l.includes('rsync -a --delete'));
    expect(rsyncLine).toBeGreaterThan(-1);

    const block = deploy.split('\n').slice(rsyncLine, rsyncLine + 14).join('\n');
    for (const keep of ['sneakerbot.db', 'profiles', 'orders', '.local', '.env']) {
      expect(block).toContain(`--exclude '${keep}'`);
    }
  });

  // .dockerignore once excluded a file the Dockerfile COPYs, so `docker build`
  // failed on the COPY line.
  test('every file the Dockerfile COPYs survives .dockerignore', async () => {
    const dockerfile = await read('Dockerfile');
    const ignore = (await read('.dockerignore'))
      .split('\n')
      .map((l) => l.trim())
      .filter((l) => l && !l.startsWith('#'));

    const copied = [...dockerfile.matchAll(/^\s*COPY\s+(?!--from)(.+)$/gm)]
      .flatMap((m) => m[1].trim().split(/\s+/).slice(0, -1));

    const ignored = (rel) => ignore.some((pat) => {
      if (pat.startsWith('!')) return false;
      const clean = pat.replace(/\/$/, '');
      return rel === clean || rel.startsWith(`${clean}/`) || clean === '*';
    });

    for (const rel of copied) {
      if (rel === '.' || rel.includes('*')) continue;
      expect({ file: rel, ignored: ignored(rel) }).toEqual({ file: rel, ignored: false });
    }
  });

  // The Akamai helper is spawned with --devicepath pointing at this file, so it
  // must exist in the image and not only in the build context.
  test('Dockerfile ships the Akamai device database', async () => {
    const dockerfile = await read('Dockerfile');
    expect(dockerfile).toContain('vendor/akamai-bmp-devices.json');
  });

  test('deploy verifies the service came up instead of reporting blind success', async () => {
    const deploy = await read('deploy-lightsail.sh');
    expect(deploy).toMatch(/healthz/);
    expect(deploy).toMatch(/journalctl -u sneakerbot\.service/);
  });
});

// ─── Multi-endpoint API fallback ─────────────────────────────────────────────

describe('stock API endpoint fallback', () => {
  test('bestbuyCheck publishes primary + legacy candidate endpoints', async () => {
    const { bestbuyCheck } = await import('../../helpers/site-stock-apis.js');
    const urls = bestbuyCheck.extractApiUrls('https://www.bestbuy.ca/en-ca/product/foo/12345678');
    expect(urls.length).toBeGreaterThan(1);
    expect(urls[0]).toContain('/api/2.0/json/product/12345678');
    expect(urls[1]).toContain('/api/v2/json/product/12345678');
    expect(bestbuyCheck.extractApiUrl('https://www.bestbuy.ca/en-ca/product/foo/12345678')).toBe(urls[0]);
  });

  test('pokemonCenterCheck publishes primary + SFCC controller endpoints', async () => {
    const { pokemonCenterCheck } = await import('../../helpers/site-stock-apis.js');
    const urls = pokemonCenterCheck.extractApiUrls('https://www.pokemoncenter.com/en-ca/product/foo/SKU-1');
    expect(urls.length).toBeGreaterThan(1);
    expect(urls[1]).toContain('Product-Variation?pid=SKU-1');
  });

  test('unparseable PDP urls yield no candidates (not a crash)', async () => {
    const { bestbuyCheck, pokemonCenterCheck } = await import('../../helpers/site-stock-apis.js');
    expect(bestbuyCheck.extractApiUrls('https://www.bestbuy.ca/')).toEqual([]);
    expect(pokemonCenterCheck.extractApiUrls('https://www.pokemoncenter.com/')).toEqual([]);
  });

  test('SFCC native Product-Variation payload shape is understood', async () => {
    const { footsitesCheck } = await import('../../helpers/site-stock-apis.js');
    const r = footsitesCheck.parseStock({ product: { name: 'P', availability: { orderable: true, ats: 5 } } });
    expect(r.inStock).toBe(true);
    const oos = footsitesCheck.parseStock({ product: { name: 'P', availability: { orderable: false, ats: 0 } } });
    expect(oos.inStock).toBe(false);
  });
});

