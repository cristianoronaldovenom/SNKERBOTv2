import logger from './logger.js';
import {
  typingFatigueMultiplier,
  hesitationMs,
  interFieldPauseMs,
  gazeTimeMs,
  microTremor
} from './ml-behavior.js';

const HOME_ROW = new Set('asdfghjkl;'.split(''));
const randInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

// Per-page session-start tracking for typing fatigue model.
// WeakMap so abandoned pages are GC'd automatically.
const sessionStartTimes = new WeakMap();
const getSessionStart = (frameOrPage) => {
  const root = frameOrPage?.mainFrame?.() ?? frameOrPage;
  if (!sessionStartTimes.has(root)) sessionStartTimes.set(root, Date.now());
  return sessionStartTimes.get(root);
};

const humanDelay = (char, fatigueMult = 1.0) => {
  let base = randInt(55, 140);
  if (HOME_ROW.has(char.toLowerCase())) base -= 20;
  if (/[A-Z!@#$%^&*()_+]/.test(char)) base += randInt(20, 60);
  if (/\s/.test(char)) base += randInt(20, 80);
  if (Math.random() < 0.04) base += randInt(180, 420);
  return Math.max(35, Math.round(base * fatigueMult));
};

const fastFillMainFrame = async (frame, handle, text) => {
  // Programmatic fill is only used in the main page frame. Hosted payment
  // iframes keep the existing keyboard path for compatibility.
  if (typeof frame.mainFrame !== 'function') return false;
  if (String(process.env.CHECKOUT_FAST_FILL ?? 'true').toLowerCase() === 'false') return false;
  try {
    return await handle.evaluate((el, val) => {
      const tag = el?.tagName?.toLowerCase();
      if (!el || (tag !== 'input' && tag !== 'textarea')) return false;
      const type = (el.getAttribute('type') || 'text').toLowerCase();
      if (type === 'file' || type === 'checkbox' || type === 'radio') return false;
      const proto = tag === 'textarea' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
      if (!setter) return false;
      el.focus();
      setter.call(el, String(val));
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      el.dispatchEvent(new Event('blur', { bubbles: true }));
      const normalized = (v) => String(v ?? '').replace(/\s+/g, ' ').trim();
      return normalized(el.value) === normalized(val);
    }, text);
  } catch (_) {
    return false;
  }
};

export const humanType = async (frame, selector, value, opts = {}) => {
  if (value == null || value === '') return false;
  const text = String(value);

  const handle = await frame.$(selector);
  if (!handle) return false;

  const fast = opts.fast ?? (String(process.env.CHECKOUT_FAST_FILL ?? 'true').toLowerCase() !== 'false');
  if (fast) {
    const filledFast = await fastFillMainFrame(frame, handle, text);
    if (filledFast) {
      if (opts.tabAfter) await frame.keyboard.press('Tab').catch(() => {});
      return true;
    }
  }

  const box = await handle.boundingBox().catch(() => null);
  if (box && frame.mouse) {
    const targetX = box.x + box.width / 2 + randInt(-8, 8);
    const targetY = box.y + box.height / 2 + randInt(-4, 4);
    await frame.mouse.move(targetX, targetY, { steps: randInt(8, 18) }).catch(() => {});
    await new Promise(r => setTimeout(r, randInt(40, 110)));
  }

  await handle.click({ clickCount: 3 }).catch(() => {});
  await new Promise(r => setTimeout(r, randInt(50, 120)));

  await frame.evaluate((el) => {
    el.focus();
    el.value = '';
    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set
               || Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value')?.set;
    if (setter) setter.call(el, '');
    el.dispatchEvent(new Event('input',  { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }, handle);

  const fatigueMult = typingFatigueMultiplier(getSessionStart(frame));
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];

    if (Math.random() < 0.025 && /[a-z]/i.test(ch) && i > 0 && i < text.length - 1) {
      const wrong = String.fromCharCode(97 + randInt(0, 25));
      await frame.keyboard.type(wrong, { delay: humanDelay(wrong, fatigueMult) });
      await new Promise(r => setTimeout(r, randInt(80, 200)));
      await frame.keyboard.press('Backspace');
      await new Promise(r => setTimeout(r, randInt(40, 120)));
    }

    await frame.keyboard.type(ch, { delay: humanDelay(ch, fatigueMult) });
  }

  await frame.evaluate((el) => {
    const finalVal = el.value;
    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set
               || Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value')?.set;
    if (setter) setter.call(el, finalVal);
    el.dispatchEvent(new Event('input',  { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur',   { bubbles: true }));
    const reactKey = Object.keys(el).find(k => k.startsWith('__reactProps$') || k.startsWith('__reactEventHandlers$'));
    if (reactKey) {
      const props = el[reactKey];
      if (typeof props.onChange === 'function') {
        try { props.onChange({ target: el, currentTarget: el, type: 'change', bubbles: true, persist: () => {} }); } catch (_) {}
      }
      if (typeof props.onBlur === 'function') {
        try { props.onBlur({ target: el, currentTarget: el, type: 'blur', bubbles: true, persist: () => {} }); } catch (_) {}
      }
    }
  }, handle).catch(() => {});

  if (opts.tabAfter) {
    const fieldType = opts.fieldType || 'text';
    await new Promise(r => setTimeout(r, interFieldPauseMs(fieldType)));
    await frame.keyboard.press('Tab').catch(() => {});
  }

  return true;
};

export const humanTypeInFrames = async (page, selector, value, opts = {}) => {
  const main = await humanType(page, selector, value, opts);
  if (main) return true;

  for (const frame of page.frames()) {
    if (frame === page.mainFrame()) continue;
    try {
      const filled = await humanType(frame, selector, value, opts);
      if (filled) {
        logger.info(`[HumanType] Filled "${selector}" inside iframe ${frame.url().slice(0, 60)}`);
        return true;
      }
    } catch (_) {}
  }
  return false;
};

export const humanSelect = async (page, selector, value) => {
  if (value == null || value === '') return false;
  const handle = await page.$(selector);
  if (!handle) return false;

  const fastUi = String(process.env.CHECKOUT_FAST_UI ?? 'true').toLowerCase() === 'true';
  if (fastUi) {
    try {
      const resolved = await page.$eval(selector, (el, val) => {
        const options = Array.from(el.options || []);
        let resolvedVal = String(val);
        const exactMatch = options.find(o => o.value === resolvedVal);
        if (!exactMatch) {
          const needle = resolvedVal.toLowerCase();
          const textMatch = options.find(o =>
            o.text.toLowerCase().trim() === needle ||
            o.text.toLowerCase().trim().startsWith(needle) ||
            o.value.toLowerCase() === needle
          );
          if (textMatch) resolvedVal = textMatch.value;
        }
        return options.some(o => o.value === resolvedVal) ? resolvedVal : null;
      }, String(value));
      if (resolved != null) {
        const selected = await page.select(selector, resolved).catch(() => []);
        if (selected.includes(resolved)) return true;
      }
    } catch (_) {}
  }

  await handle.click().catch(() => {});
  const selectPause = fastUi ? randInt(5, 25) : randInt(80, 200);
  await new Promise(r => setTimeout(r, selectPause));

  const ok = await page.evaluate((sel, val) => {
    const el = document.querySelector(sel);
    if (!el) return false;
    el.focus();

    // Resolve the actual <option> value to set. Try in order:
    // 1. Exact value match (e.g. val="ON" and option value="ON")
    // 2. Case-insensitive text match (e.g. val="Ontario" → option text "Ontario", value "ON")
    // 3. Case-insensitive value match (e.g. val="ontario" vs value "ON" — skip; covered by text)
    const options = Array.from(el.options || []);
    let resolvedVal = String(val);
    const exactMatch = options.find(o => o.value === resolvedVal);
    if (!exactMatch) {
      const needle = resolvedVal.toLowerCase();
      const textMatch = options.find(o =>
        o.text.toLowerCase().trim() === needle ||
        o.text.toLowerCase().trim().startsWith(needle) ||
        o.value.toLowerCase() === needle
      );
      if (textMatch) resolvedVal = textMatch.value;
    }

    const setter = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, 'value')?.set;
    if (setter) setter.call(el, resolvedVal); else el.value = resolvedVal;
    el.dispatchEvent(new Event('input',  { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur',   { bubbles: true }));
    const reactKey = Object.keys(el).find(k => k.startsWith('__reactProps$'));
    if (reactKey && typeof el[reactKey].onChange === 'function') {
      try { el[reactKey].onChange({ target: el, currentTarget: el, type: 'change', persist: () => {} }); } catch (_) {}
    }
    return el.value === resolvedVal;
  }, selector, String(value));

  return ok;
};

// Cubic Bezier curve from (x1,y1) to (x2,y2) with two random control points
// offset perpendicular to the straight line. Models the natural arc a real
// human's wrist makes — flat linear movement is a bot signal that Imperva,
// Datadome and Cloudflare bot-fight all explicitly score against.
const bezierPath = (x1, y1, x2, y2, steps) => {
  const dx = x2 - x1;
  const dy = y2 - y1;
  const dist = Math.sqrt(dx * dx + dy * dy) || 1;
  // Perpendicular unit vector — controls curve "side"
  const nx = -dy / dist;
  const ny = dx / dist;
  // Random arc magnitude scales with distance, max ~25% of distance
  const arc1 = (Math.random() * 0.20 + 0.05) * dist * (Math.random() < 0.5 ? -1 : 1);
  const arc2 = (Math.random() * 0.20 + 0.05) * dist * (Math.random() < 0.5 ? -1 : 1);
  const cp1x = x1 + dx * 0.33 + nx * arc1;
  const cp1y = y1 + dy * 0.33 + ny * arc1;
  const cp2x = x1 + dx * 0.66 + nx * arc2;
  const cp2y = y1 + dy * 0.66 + ny * arc2;
  const points = [];
  for (let i = 1; i <= steps; i++) {
    const t = i / steps;
    const u = 1 - t;
    // Standard cubic Bezier formula
    const x = u*u*u*x1 + 3*u*u*t*cp1x + 3*u*t*t*cp2x + t*t*t*x2;
    const y = u*u*u*y1 + 3*u*u*t*cp1y + 3*u*t*t*cp2y + t*t*t*y2;
    points.push({ x, y });
  }
  return points;
};

// Track the cursor position so successive movements start from where the last
// one ended (real users don't teleport between clicks).
const cursorState = new WeakMap();

// Exported for site adapters that want ML-aware clicks on high-stakes buttons
// (Place Order, Complete Payment). Pass importance='critical'|'navigate'|'form'.
export const humanClickImportant = async (page, selectorOrHandle, importance = 'navigate') => {
  const delay = hesitationMs(importance);
  await new Promise(r => setTimeout(r, delay));
  return humanClick(page, selectorOrHandle);
};

export const humanClick = async (page, selectorOrHandle) => {
  const handle = typeof selectorOrHandle === 'string'
    ? await page.$(selectorOrHandle)
    : selectorOrHandle;
  if (!handle) return false;

  if (page?.__checkoutFastUI && String(process.env.CHECKOUT_FAST_UI ?? 'true').toLowerCase() === 'true') {
    try {
      await handle.click({ delay: 0 });
      return true;
    } catch (_) {
      // Fall through to the verified mouse path.
    }
  }

  const box = await handle.boundingBox().catch(() => null);
  if (!box) {
    // No bounding box — element is hidden or detached. Try a direct click but
    // surface failure so retry logic can react instead of swallowing it.
    try {
      await handle.click();
      return true;
    } catch (err) {
      logger.warn(`[HumanClick] Direct click fallback failed: ${err.message}`);
      return false;
    }
  }

  // Land on a random point inside the element, biased toward center
  const targetX = box.x + box.width / 2 + randInt(-Math.floor(box.width / 4), Math.floor(box.width / 4));
  const targetY = box.y + box.height / 2 + randInt(-Math.floor(box.height / 4), Math.floor(box.height / 4));

  // Gaze time: dwell proportional to element area before moving the mouse.
  // Real users look at an element for a moment before clicking it.
  const gazePause = gazeTimeMs(box);
  await new Promise(r => setTimeout(r, gazePause));

  const last = cursorState.get(page) || { x: randInt(100, 800), y: randInt(100, 600) };
  const dist = Math.hypot(targetX - last.x, targetY - last.y);
  // Step count proportional to distance — short hops are quick, long sweeps slower
  const steps = Math.max(12, Math.min(45, Math.floor(dist / 12)));
  const points = bezierPath(last.x, last.y, targetX, targetY, steps);

  for (const p of points) {
    // Apply micro-tremor jitter to each path point — human hands have
    // involuntary 8–12Hz physiological tremor (±1–3px). Bots with
    // perfectly smooth linear paths are detected by Imperva/DataDome
    // behavioral analytics that measure path entropy.
    const tremor = microTremor();
    await page.mouse.move(p.x + tremor.dx, p.y + tremor.dy);
    // Variable per-step delay simulates wrist acceleration/deceleration
    await new Promise(r => setTimeout(r, randInt(2, 9)));
  }
  cursorState.set(page, { x: targetX, y: targetY });

  // Brief settle pause before pressing — humans don't click the instant
  // their cursor stops
  await new Promise(r => setTimeout(r, randInt(45, 140)));
  await page.mouse.down();
  await new Promise(r => setTimeout(r, randInt(35, 95)));
  await page.mouse.up();
  return true;
};
