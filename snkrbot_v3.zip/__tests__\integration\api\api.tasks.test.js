import { jest } from '@jest/globals';
import express from 'express';
import request from 'supertest';
import knex from 'knex';
import { createTracker, MockClient } from 'knex-mock-client';

// ESM mock: replace the real db (which connects via knexfile at import time) with
// a knex-mock instance BEFORE routes/index.js is dynamically imported in
// beforeAll. Must use jest.unstable_mockModule — plain jest.mock does NOT
// intercept ESM imports under --experimental-vm-modules.
const db = knex({ client: MockClient });
jest.unstable_mockModule('../../../db/index.js', () => ({ default: db }));

// Body for create/update requests — must NOT include server-managed fields like
// `id` (Joi rejects unknown keys → 400). The DB-row fixture is testTaskCreated.
const testTask = {
  url: 'https://www.testUrl.co.uk/productName',
  site_id: 1,
  billing_address_id: 3,
  shipping_address_id: 4,
  notification_email_address: 'jsmith@gmail.com'
};

const testTaskCreated = {
  id: 1,
  ...testTask,
  has_been_used: false,
  created_at: '2021-01-01T17:29:51.957Z',
  updated_at: '2021-01-01T17:29:51.957Z',
  is_deleted: false,
  auto_solve_captchas: true
};

let tracker;
let app;
const urlTasks = '/v1/tasks';

beforeAll(async () => {
  const router = (await import('../../../routes/index.js')).default;

  app = express();
  app.use(express.json());
  app.use(express.urlencoded({ extended: false }));
  app.use('/v1', router);

  tracker = createTracker(db);
});

afterEach(() => {
  tracker.reset();
});

afterAll(() => {
  db.destroy();
});

describe('GET /tasks', () => {
  it('should find multiple tasks', async () => {
    const testTasks = [
      testTaskCreated,
      { ...testTaskCreated, id: 2 },
      { ...testTaskCreated, id: 3 }
    ];
    tracker.on.select('tasks').response(testTasks);

    const response = await request(app).get(urlTasks);

    expect(response.status).toBe(200);
    expect(response.body.message).toBe('Tasks successfully found');
    expect(response.body.data).toEqual(testTasks);
  });

  it('should find a single proxy', async () => {
    const testTasks = [testTaskCreated];
    tracker.on.select('tasks').response(testTasks);

    const response = await request(app).get(urlTasks);

    expect(response.status).toBe(200);
    expect(response.body.message).toBe('Tasks successfully found');
    expect(response.body.data).toEqual(testTasks);
  });

  it('should find no tasks', async () => {
    const testTasks = [];
    tracker.on.select('tasks').response(testTasks);

    const response = await request(app).get(urlTasks);

    expect(response.status).toBe(200);
    expect(response.body.message).toBe('Tasks not found');
    expect(response.body.data).toEqual(testTasks);
  });
});

describe('GET /tasks/:id', () => {
  it('should findOne single proxy', async () => {
    tracker.on.select('tasks').response(testTaskCreated);

    const response = await request(app).get(`${urlTasks}/1`);

    expect(response.status).toBe(200);
    expect(response.body.message).toBe('Task successfully found');
    expect(response.body.data).toEqual(testTaskCreated);
  });

  it('should not findOne proxy', async () => {
    tracker.on.select('tasks').response(undefined);

    const response = await request(app).get(`${urlTasks}/2`);

    expect(response.status).toBe(200);
    expect(response.body.message).toBe('Task not found');
    expect(response.body.data).toBeUndefined();
  });
});

describe('POST /tasks', () => {
  it('should create an proxy', async () => {
    tracker.on.insert('into "tasks"').response([testTaskCreated]);

    const response = await request(app).post(urlTasks).send(testTask);

    expect(response.status).toBe(200);
    expect(response.body.message).toBe('Task successfully created');
    expect(response.body.data).toEqual(testTaskCreated);
  });

  it('should create no proxy when db insert fails', async () => {
    const testTaskWithError = {
      ...testTask,
      url:
        'https://www.testUrl.co.uk/' +
        'testWithTooManyCharacterstestWithTooManyCharacterstestWithTooManyCharacterstestWithTooManyCharacterstestWithTooManyCharacters' +
        'testWithTooManyCharacterstestWithTooManyCharacterstestWithTooManyCharacterstestWithTooManyCharacterstestWithTooManyCharacters'
    };
    tracker.on.insert('into "tasks"').simulateError(new Error('DB insert failure'));

    const response = await request(app).post(urlTasks).send(testTaskWithError);

    expect(response.status).toBe(500);
    expect(response.body.success).toBeFalsy();
    expect(response.body.message).toContain('DB insert failure');
    expect(response.body.data).toEqual({});
  });

  it('should create no proxy when validation fails', async () => {
    const testTaskWithError = {
      ...testTask,
      site_id: 'not-a-number'
    };
    tracker.on.insert('into "tasks"').simulateError(new Error('Validation failure'));

    const response = await request(app).post(urlTasks).send(testTaskWithError);

    expect(response.status).toBe(400);
    expect(response.body.success).toBeFalsy();
    expect(response.body.message).toBe('Validation Failed');
    expect(response.body.data.body[0].message).toEqual('"site_id" must be a number');
  });
});

describe('PATCH /tasks:id', () => {
  it('should update known address', async () => {
    tracker.on.update('"tasks"').response([testTaskCreated]);

    const response = await request(app).patch(`${urlTasks}/1`).send(testTask);

    expect(response.status).toBe(200);
    expect(response.body.message).toBe('Task successfully updated');
    expect(response.body.data).toEqual(testTaskCreated);
  });
});

describe('POST /tasks:id/enable-payment', () => {
  // The whole point of the lock is that it survives the reconciler, so re-arming
  // has to be an explicit operator action. This endpoint is that action: it must
  // clear all three lock columns and drop the stale payment_locked status so the
  // next sweep sees an armable task, without touching the stop-loss columns.
  it('clears the lock, the decline count, and the stale status', async () => {
    const locked = {
      ...testTaskCreated,
      last_status: 'payment_locked',
      pay_fail_count: 5,
      pay_disabled_at: '2026-10-24T12:00:00.000Z',
      pay_disabled_reason: 'Payment declined 5/5',
      disabled_at: '2026-10-20T00:00:00.000Z',
      disabled_reason: 'stop loss'
    };

    tracker.on.select('tasks').response(locked);
    tracker.on.update('"tasks"').response([locked]);

    const response = await request(app).post(`${urlTasks}/1/enable-payment`);

    expect(response.status).toBe(200);
    expect(response.body.success).toBe(true);

    // knex-mock records positional bindings: [payload values..., where values...].
    const updates = tracker.history.update.map((u) => u.bindings);
    expect(updates).toHaveLength(2);
    // Exactly three payload columns — the stop-loss columns must be untouched.
    expect(updates[0]).toEqual([0, null, null, '1']);
    // The status must stop saying payment_locked, or the badge and the monitor
    // guard both keep treating a re-enabled task as parked.
    expect(updates[1][0]).toBe('');
  });

  it('404s a missing task instead of clearing nothing', async () => {
    tracker.on.select('tasks').response(undefined);

    const response = await request(app).post(`${urlTasks}/1/enable-payment`);

    expect(response.status).toBe(404);
    expect(response.body.success).toBe(false);
    expect(response.body.message).toMatch(/not found/i);
    expect(tracker.history.update).toHaveLength(0);
  });
});
