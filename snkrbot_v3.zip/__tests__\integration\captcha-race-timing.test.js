// Turnstile race timing. The cascade used Promise.allSettled, which resolves
// only once BOTH providers settle — so a slow loser held the winning token
// hostage and racing bought nothing. These tests run on real timers because the
// whole point is wall-clock behaviour.
import { jest } from '@jest/globals';

jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));

jest.unstable_mockModule('../../helpers/captcha-harvester.js', () => ({
  createHarvesterChallenge: jest.fn(),
  solveInPage: jest.fn()
}));

let settings = {};
const firstMock = jest.fn(async function () {
  const key = this.__key;
  return key in settings ? { key, value: settings[key] } : undefined;
});
const db = jest.fn(() => ({
  where: (criteria) => ({ __key: criteria.key, first: firstMock })
}));
jest.unstable_mockModule('../../db/index.js', () => ({ default: db }));

// axios shims: `fast` resolves on the first poll, `slow` needs two polls.
const postMock = jest.fn();
const getMock = jest.fn();
jest.unstable_mockModule('axios', () => ({ default: { post: postMock, get: getMock } }));

const { solveCloudflareTurnstile, __resetCaptureState } = await import('../../helpers/captcha.js');
const { __resetForTests: resetStockpile } = await import('../../helpers/token-stockpile.js');

const FAST_TAG = 'fast'.padEnd(40, 'x');
const SLOW_TAG = 'slow'.padEnd(40, 'y');

const wire = ({ fastMs, slowMs }) => {
  const start = Date.now();
  const elapsed = () => Date.now() - start;
  postMock.mockImplementation(async (url, body) => {
    if (url.includes('capsolver')) {
      // createTask is immediate; the first poll is 1.2s later.
      if (url.endsWith('/createTask')) return { data: { errorId: 0, taskId: 'cs' } };
      if (elapsed() >= fastMs) return { data: { errorId: 0, status: 'ready', solution: { token: FAST_TAG } } };
      return { data: { errorId: 0, status: 'processing' } };
    }
    if (url.includes('2captcha')) {
      if (url.endsWith('/in.php')) return { data: { status: 1, request: '2c' } };
      if (elapsed() >= slowMs) return { data: { status: 1, request: SLOW_TAG } };
      return { data: { status: 0, request: 'CAPCHA_NOT_READY' } };
    }
    throw new Error(`unexpected ${url}`);
  });
  getMock.mockImplementation(async (url) => {
    if (url.includes('2captcha/res.php')) {
      if (elapsed() >= slowMs) return { data: { status: 1, request: SLOW_TAG } };
      return { data: { status: 0, request: 'CAPCHA_NOT_READY' } };
    }
    throw new Error(`unexpected ${url}`);
  });
};

beforeEach(() => {
  settings = { captcha_api_key: '2C', capsolver_api_key: 'CS' };
  postMock.mockReset();
  getMock.mockReset();
  __resetCaptureState();
  // The stockpile is process-wide, so a token minted by an earlier case would
  // short-circuit the next solve and the poll-count assertions would see nothing.
  resetStockpile();
});

test('returns the first token instead of waiting for the slow loser', async () => {
  wire({ fastMs: 1000, slowMs: 4000 });
  const t0 = Date.now();
  const token = await solveCloudflareTurnstile({ siteKey: 'S', pageUrl: 'https://x.test/p' });
  const took = Date.now() - t0;
  expect(token).toBe(FAST_TAG);
  // A 4s loser must not dominate a 1.3s win (allSettled would have cost ~4s).
  expect(took).toBeLessThan(3000);
}, 15_000);

test('cancels the losing provider so its poll loop stops', async () => {
  wire({ fastMs: 1300, slowMs: 60_000 });
  const before = getMock.mock.calls.length + postMock.mock.calls.length;
  await solveCloudflareTurnstile({ siteKey: 'S', pageUrl: 'https://x.test/p' });
  const atReturn = getMock.mock.calls.length + postMock.mock.calls.length;
  // Let any orphaned poll loop fire if it survived.
  await new Promise((r) => setTimeout(r, 3000));
  const afterWait = getMock.mock.calls.length + postMock.mock.calls.length;
  expect(atReturn).toBeGreaterThan(before);
  // The aborted 2Captcha loop must not keep polling after the race resolved.
  const loserPollsAfterWin = afterWait - atReturn;
  expect(loserPollsAfterWin).toBeLessThanOrEqual(1);
}, 20_000);

test('falls through when both racers fail', async () => {
  postMock.mockImplementation(async (url) => {
    if (url.includes('capsolver')) {
      return { data: url.endsWith('/createTask') ? { errorId: 1, errorDescription: 'dead' } : { errorId: 1 } };
    }
    if (url.includes('2captcha')) {
      return { data: url.endsWith('/in.php') ? { status: 0, request: 'ERROR' } : { status: 0, request: 'ERROR' } };
    }
    throw new Error(`unexpected ${url}`);
  });
  getMock.mockImplementation(async () => ({ data: { status: 0, request: 'ERROR' } }));
  await expect(
    solveCloudflareTurnstile({ siteKey: 'S', pageUrl: 'https://x.test/p' })
  ).rejects.toThrow(/All captcha providers failed/);
}, 20_000);
