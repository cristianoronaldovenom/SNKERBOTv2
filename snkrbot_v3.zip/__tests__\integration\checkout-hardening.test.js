import { jest } from '@jest/globals';

jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));

const {
  FillReport,
  assertCriticalFields,
  chooseAddressKeepButton,
  detectCardType
} = await import('../../helpers/autofill-utils.js');

const reportWith = (fields) => {
  const r = new FillReport(1, 'test');
  for (const [name, ok] of Object.entries(fields)) r.record(name, ok);
  return r;
};

describe('assertCriticalFields — abort before Place Order on a half-filled form', () => {
  test('does NOT throw when every critical field filled OK', () => {
    const r = reportWith({ address1: true, postalCode: true, cardNumber: true });
    expect(() => assertCriticalFields(r, ['address1', 'postalCode', 'cardNumber'])).not.toThrow();
  });

  test('throws a classified error when a critical field failed', () => {
    const r = reportWith({ address1: true, postalCode: false, cardNumber: true });
    let caught = null;
    try { assertCriticalFields(r, ['address1', 'postalCode']); } catch (e) { caught = e; }
    expect(caught).not.toBeNull();
    expect(caught.failureType).toBe('checkout_fill_failed');
    expect(caught.message).toMatch(/postalCode/);
  });

  test('ignores a failure on a NON-critical field', () => {
    const r = reportWith({ address1: true, address2: false });
    expect(() => assertCriticalFields(r, ['address1'])).not.toThrow();
  });

  test('lists every missing critical field in the message', () => {
    const r = reportWith({ cardNumber: false, cvv: false, cardOwner: true });
    let caught = null;
    try { assertCriticalFields(r, ['cardNumber', 'cvv', 'cardOwner']); } catch (e) { caught = e; }
    expect(caught.message).toMatch(/cardNumber/);
    expect(caught.message).toMatch(/cvv/);
    expect(caught.message).not.toMatch(/cardOwner/);
  });
});

describe('chooseAddressKeepButton — keep the entered address, never edit/cancel', () => {
  const MODAL = 'We could not verify your address. Did you mean 123 Main Street?';

  test('returns -1 when there is no verification modal (text absent)', () => {
    expect(chooseAddressKeepButton('Your order summary', ['Continue', 'Edit'])).toBe(-1);
  });

  test('picks the "Use original address" button when present', () => {
    const buttons = ['Edit address', 'Use original address'];
    expect(chooseAddressKeepButton(MODAL, buttons)).toBe(1);
  });

  test('prefers keep-address over a generic Continue button', () => {
    const buttons = ['Continue', 'Keep my address', 'Edit'];
    expect(chooseAddressKeepButton(MODAL, buttons)).toBe(1);
  });

  test('matches "use the address you entered"', () => {
    const buttons = ['Cancel', 'Use the address you entered'];
    expect(chooseAddressKeepButton(MODAL, buttons)).toBe(1);
  });

  test('NEVER returns an edit/cancel/change button', () => {
    const buttons = ['Edit', 'Cancel', 'Change address', 'Go back'];
    expect(chooseAddressKeepButton(MODAL, buttons)).toBe(-1);
  });

  test('returns -1 when only ambiguous Continue/Edit are offered (won\'t risk the suggested address)', () => {
    const buttons = ['Edit address', 'Continue'];
    expect(chooseAddressKeepButton(MODAL, buttons)).toBe(-1);
  });

  test('does NOT pick an ambiguous "Use this address" button (could be the suggested rewrite)', () => {
    const buttons = ['Edit', 'Use this address'];
    expect(chooseAddressKeepButton(MODAL, buttons)).toBe(-1);
  });

  test('does NOT pick a generic "Confirm" button', () => {
    const buttons = ['Cancel', 'Confirm'];
    expect(chooseAddressKeepButton(MODAL, buttons)).toBe(-1);
  });
});

describe('detectCardType — accurate network or null (never a wrong default)', () => {
  test('Visa', () => expect(detectCardType('4111 1111 1111 1111')).toBe('Visa'));
  test('MasterCard 5-series', () => expect(detectCardType('5555 5555 5555 4444')).toBe('MasterCard'));
  test('MasterCard 2-series', () => expect(detectCardType('2221000000000009')).toBe('MasterCard'));
  test('Amex', () => expect(detectCardType('3782 822463 10005')).toBe('Amex'));
  test('Discover', () => expect(detectCardType('6011000990139424')).toBe('Discover'));
  test('returns null on an unrecognized BIN (no silent Visa default)', () => {
    expect(detectCardType('9999000000000000')).toBeNull();
  });
  test('returns null on empty/garbage input', () => {
    expect(detectCardType('')).toBeNull();
    expect(detectCardType(null)).toBeNull();
  });
});
