// Small, dependency-free runtime primitives shared by latency-sensitive site adapters.
import { semanticSelector } from './semantic-recovery.js';
// Prefer one browser-side readiness wait over repeated Node/CDP selector probes.
export const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, Math.max(0, ms)));

const visible = (node) => {
  const r = node.getBoundingClientRect();
  const s = window.getComputedStyle(node);
  return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none';
};

export const waitForAnySelector = async (page, selectors, { timeout = 15000, requireEnabled = false } = {}) => {
  const list = [...new Set((selectors || []).filter(Boolean))];
  if (!list.length) return null;

  // First try one fast semantic recovery pass. This is intentionally early so
  // harmless selector drift does not consume the entire explicit-selector timeout.
  // If the page is still rendering, the normal mutation wait below remains the
  // primary path and will pick up the explicit selector as soon as it appears.
  const earlyRecovered = await semanticSelector(page, list, { minScore: requireEnabled ? 8 : 7 }).catch(() => null);
  if (earlyRecovered) return earlyRecovered;

  // Prefer a browser-side mutation wait. This removes dozens of Node↔Chrome
  // round trips on reactive checkout pages while still returning the same
  // selector string used by callers.
  try {
    const found = await page.waitForFunction(({ selectorList, mustEnable }) => {
      const visibleNow = (el) => {
        if (!el) return false;
        const r = el.getBoundingClientRect();
        const st = getComputedStyle(el);
        return r.width > 0 && r.height > 0 && st.display !== 'none' && st.visibility !== 'hidden';
      };
      for (const selector of selectorList) {
        let el = null;
        try { el = document.querySelector(selector); } catch (_) { continue; }
        if (!visibleNow(el)) continue;
        if (mustEnable && (el.disabled || el.getAttribute('aria-disabled') === 'true')) continue;
        return selector;
      }
      return false;
    }, { timeout, polling: 'mutation' }, { selectorList: list, mustEnable: requireEnabled });
    return await found.jsonValue();
  } catch (_) {
    // Fallback for pages whose readiness depends on timers/paint rather than DOM mutations.
  }

  const deadline = Date.now() + timeout;
  while (Date.now() < deadline) {
    const found = await page.evaluate(({ selectors: selectorList, requireEnabled: mustEnable }) => {
      const isVisible = (node) => {
        if (!node) return false;
        const r = node.getBoundingClientRect();
        const s = window.getComputedStyle(node);
        return r.width > 0 && r.height > 0 && s.display !== 'none' && s.visibility !== 'hidden';
      };
      for (const selector of selectorList) {
        let el = null;
        try { el = document.querySelector(selector); } catch (_) { continue; }
        if (!isVisible(el)) continue;
        if (mustEnable && (el.disabled || el.getAttribute('aria-disabled') === 'true')) continue;
        return selector;
      }
      return null;
    }, { selectors: list, requireEnabled }).catch(() => null);
    if (found) return found;
    await sleep(90);
  }

  // Markup changes are common on long-lived checkout pages. Before surfacing a
  // selector failure, make one semantic recovery pass using the site's existing
  // selector hints (field names, autocomplete, data-testid, labels, and action
  // text). This is deliberately conservative: final-order controls require
  // explicit order semantics and destructive controls are penalized.
  const recovered = await semanticSelector(page, list, { minScore: requireEnabled ? 8 : 7 }).catch(() => null);
  if (recovered) return recovered;
  return null;
};

export const waitForUrlOrSelector = async (page, { urlPattern = null, selectors = [], timeout = 15000 } = {}) => {
  const selectorList = [...new Set((selectors || []).filter(Boolean))];
  const pattern = urlPattern ? urlPattern.source : null;

  try {
    const hit = await page.waitForFunction(({ patternText, selectorList: list }) => {
      const visibleNow = (el) => {
        if (!el) return false;
        const r = el.getBoundingClientRect();
        const st = getComputedStyle(el);
        return r.width > 0 && r.height > 0 && st.display !== 'none' && st.visibility !== 'hidden';
      };
      if (patternText) {
        try { if (new RegExp(patternText).test(location.href)) return { url: true, selector: null }; } catch (_) {}
      }
      for (const selector of list) {
        try {
          const el = document.querySelector(selector);
          if (visibleNow(el)) return { url: false, selector };
        } catch (_) {}
      }
      return false;
    }, { timeout, polling: 'mutation' }, { patternText: pattern, selectorList });
    return await hit.jsonValue();
  } catch (_) {
    const deadline = Date.now() + timeout;
    while (Date.now() < deadline) {
      const hit = await page.evaluate(({ patternText, list }) => {
        const isVisible = (el) => {
          if (!el) return false;
          const r = el.getBoundingClientRect();
          const s = window.getComputedStyle(el);
          return r.width > 0 && r.height > 0 && s.display !== 'none' && s.visibility !== 'hidden';
        };
        if (patternText) {
          try { if (new RegExp(patternText).test(location.href)) return { url: true, selector: null }; } catch (_) {}
        }
        for (const selector of list) {
          try {
            const el = document.querySelector(selector);
            if (isVisible(el)) return { url: false, selector };
          } catch (_) {}
        }
        return null;
      }, { patternText: pattern, list: selectorList }).catch(() => null);
      if (hit) return hit;
      await sleep(90);
    }
  }
  return null;
};

export const waitForPostClickState = async (page, selectors, { timeout = 12000, fallbackMs = 75 } = {}) => {
  const list = [...new Set((selectors || []).filter(Boolean))];
  if (!list.length) {
    if (fallbackMs > 0) await sleep(fallbackMs);
    return null;
  }
  const ready = await waitForAnySelector(page, list, { timeout });
  if (ready) return ready;
  if (fallbackMs > 0) await sleep(fallbackMs);
  return null;
};

export const classifySiteError = (error, failureType, stage) => {
  const err = error instanceof Error ? error : new Error(String(error || 'Unknown error'));
  if (failureType) err.failureType = failureType;
  if (stage) err.stage = stage;
  return err;
};
