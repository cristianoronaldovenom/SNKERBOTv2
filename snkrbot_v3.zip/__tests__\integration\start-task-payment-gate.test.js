// The start-task gate is the only thing standing between an armed task with a
// dead card and a full browser launch, so it is worth testing at the seam rather
// than trusting the source shape. Everything below the gate is stubbed: if the
// gate fails to trip, `launchBrowser` is what we observe.
import { jest } from '@jest/globals';
import knex from 'knex';
import { createTracker, MockClient } from 'knex-mock-client';

const db = knex({ client: MockClient });
jest.unstable_mockModule('../../db/index.js', () => ({ default: db }));
jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));

const launched = jest.fn(async () => { throw new Error('stop after launch'); });
const notified = jest.fn(async () => {});
let startTask;
let tracker;

const acquired = jest.fn(async () => released);
const released = jest.fn();
let proxyType = 'residential';

beforeAll(async () => {
  jest.unstable_mockModule('../../helpers/residential-budget.js', () => ({
    acquireResidentialSession: (...a) => acquired(...a),
    activeResidentialSessions: () => 0,
    maxResidentialSessions: () => 4
  }));
  jest.unstable_mockModule('../../helpers/memory-guard.js', () => ({
    getMemorySnapshot: async () => ({ limitBytes: 8 * 1024 ** 3, currentBytes: 1024 ** 3 })
  }));
  jest.unstable_mockModule('../../helpers/cluster.js', () => ({
    launchBrowser: (...a) => launched(...a),
    getNewPage: async () => ({})
  }));
  jest.unstable_mockModule('../../helpers/notifier.js', () => ({ notify: (...a) => notified(...a) }));
  jest.unstable_mockModule('../../helpers/preflight.js', () => ({
    preflightTask: async () => ({ ok: true, issues: [] }), logPreflight: () => {}
  }));
  jest.unstable_mockModule('../../helpers/business-hours.js', () => ({
    PC_SITE_ID: 6, isWithinBusinessHours: () => true, businessHoursEnabled: async () => false
  }));
  jest.unstable_mockModule('../../helpers/drop-watcher.js', () => ({ waitForDropAndStock: async () => {} }));
  jest.unstable_mockModule('../../helpers/task-cache.js', () => ({
    storePageInTaskCache: async () => {}, removePageFromTaskCache: async () => {}
  }));
  jest.unstable_mockModule('../../helpers/prewarm-engine.js', () => ({
    adoptPrewarm: async () => null, disposePrewarm: async () => {}
  }));
  jest.unstable_mockModule('../../helpers/run-queue.js', () => ({ acquireSlot: async () => () => {} }));
  jest.unstable_mockModule('../../helpers/site-performance.js', () => ({ getSitePerformanceProfile: () => ({}) }));
  jest.unstable_mockModule('../../helpers/task-proxies.js', () => ({
    resolveTaskProxy: async () => ({
      proxy: { id: 9, host: 'proxy.example', port: 8000, proxy_type: proxyType },
      source: 'assigned'
    }),
    sanitizeProxyMeta: (p) => p
  }));
  jest.unstable_mockModule('../../helpers/email.js', () => ({ sendSuccessEmail: async () => {} }));
  jest.unstable_mockModule('../../helpers/bot-learner.js', () => ({
    getBotLearnerRecommendation: async () => ({ arm: null, confidence: 0, totalPulls: 0 }),
    recordBotLearnerOutcome: async () => {}
  }));
  jest.unstable_mockModule('../../helpers/request-checkout/index.js', () => ({
    tryRequestCheckout: async () => null, requestModeEnabled: () => false
  }));
  jest.unstable_mockModule('../../helpers/monitor-store.js', () => ({
    broadcastToClients: () => {}, broadcastAllClients: () => {}
  }));
  jest.unstable_mockModule('../../helpers/decline-detector.js', () => ({
    detectDecline: async () => null, isOosFailure: () => false, isDeclineFailure: () => false,
    isSessionFailure: () => false, getAlternatePaymentProfiles: async () => []
  }));
  jest.unstable_mockModule('../../helpers/cookie-pool.js', () => ({
    injectCookies: async () => {}, harvestCookies: async () => {}, hasFreshCookies: () => false
  }));
  jest.unstable_mockModule('../../helpers/session-warmer.js', () => ({ warmInPlace: async () => {} }));
  jest.unstable_mockModule('../../helpers/resource-blocker.js', () => ({ enableResourceBlocker: async () => {} }));
  jest.unstable_mockModule('../../helpers/proxy-pool.js', () => ({
    pickBackupProxy: async () => null, shouldRotateProxyAfterFailure: () => false,
    isProxyTransportFailure: () => false, markProxyTransportFailure: () => {},
    markProxyTransportSuccess: () => {}
  }));
  jest.unstable_mockModule('../../helpers/identity-rotator.js', () => ({
    rotateIdentity: async () => {}, shouldRotateAfterFailure: () => false
  }));
  jest.unstable_mockModule('../../helpers/proxy-intelligence.js', () => ({ recordOutcome: () => {} }));
  jest.unstable_mockModule('../../helpers/stage-timer.js', () => ({
    StageTimer: class { mark() {} summary() { return {}; } }
  }));
  jest.unstable_mockModule('../../helpers/sibling-bus.js', () => ({
    notifyProductSuccess: () => {}, subscribeToSiblings: () => () => {},
    throwIfSiblingWon: () => {}, SiblingWonError: class extends Error {}
  }));
  jest.unstable_mockModule('../../helpers/order-capture.js', () => ({ captureOrderSuccess: async () => {} }));
  startTask = (await import('../../scripts/start-task.js')).default;
  tracker = createTracker(db);
});

beforeEach(() => { launched.mockClear(); notified.mockClear(); });
afterEach(() => { tracker.reset(); launched.mockClear(); acquired.mockClear(); released.mockClear(); });
afterAll(() => db.destroy());

const baseTask = (overrides = {}) => ({
  id: 42,
  url: 'https://www.pokemoncenter.com/product/1',
  site_id: 6,
  max_retries: 0,
  pay_fail_count: 0,
  pay_disabled_at: null,
  pay_disabled_reason: null,
  ...overrides
});

it('a locked task throws at stage payment_locked and never launches a browser', async () => {
  tracker.on.update('"tasks"').response([]);

  const err = await startTask(baseTask({
    pay_fail_count: 5,
    pay_disabled_at: new Date('2026-10-24T12:00:00Z'),
    pay_disabled_reason: 'Payment locked after 5/5 consecutive declines — fix the card, then re-enable from the dashboard'
  })).catch((e) => e);

  expect(err).toBeInstanceOf(Error);
  expect(err.message).toMatch(/5\/5 consecutive declines/);
  // The browser is the expensive part; it must not have been touched.
  expect(launched).not.toHaveBeenCalled();
  // The operator gets told why, with a stage the notifier/dashboard understands.
  expect(notified).toHaveBeenCalled();
  const payload = notified.mock.calls[0][0];
  expect(payload.stage).toBe('payment_locked');
  expect(payload.taskId).toBe(42);
});

it('the gate persists the payment_locked status so the badge and monitor agree', async () => {
  tracker.on.update('"tasks"').response([]);

  await startTask(baseTask({ pay_fail_count: 5, pay_disabled_at: new Date() })).catch(() => {});

  // [last_run_at, last_status, id]
  expect(tracker.history.update[0].bindings).toContain('payment_locked');
});

it('an unlocked task falls through to the launch path', async () => {
  tracker.on.update('"tasks"').response([]);
  tracker.on.insert('into "task_runs"').response([]);
  // `any` is the only matcher that sees raw statements.
  tracker.on.any(/UPDATE tasks/).response([{
    consecutive_failures: 1, max_failures: null, disabled_at: null, disabled_reason: null
  }]);

  // launchBrowser is stubbed to throw so the run ends right after the gate.
  const result = await startTask(baseTask()).catch((e) => e);

  expect(launched).toHaveBeenCalled();
  expect(notified.mock.calls.every((c) => c[0].stage !== 'payment_locked')).toBe(true);
  // The classified failure must survive the catch block. Regression: `proxy` was
  // a try-scoped const reported from the catch, so every failed attempt threw
  // ReferenceError instead of returning its result — the caller then saw a crash
  // instead of a failure it could record or retry, and the stop-loss SQL below
  // (which only runs after a failed attempt) never executed.
  expect(result).toBeUndefined();
  expect(tracker.history.all.some((q) => /UPDATE tasks/.test(q.sql || ''))).toBe(true);
  // proxyHost must survive into the run record: with a try-scoped `proxy` the
  // per-proxy success/failure statistics silently lost their host correlation.
  const runInsert = tracker.history.insert.find((q) => /task_runs/.test(q.sql || ''));
  expect(runInsert.bindings).toContain('proxy.example');
});

it('a residential checkout acquires and releases a gateway session', async () => {
  tracker.on.update('"tasks"').response([]);
  tracker.on.insert('into "task_runs"').response([]);
  tracker.on.any(/UPDATE tasks/).response([{
    consecutive_failures: 1, max_failures: null, disabled_at: null, disabled_reason: null
  }]);

  await startTask(baseTask()).catch(() => {});

  expect(acquired).toHaveBeenCalled();
  // The release must run in `finally`, after the classified failure — a stranded
  // token permanently shrinks residential capacity until process restart.
  expect(released).toHaveBeenCalled();
});

it('a non-residential run does not consume a gateway session', async () => {
  tracker.on.update('"tasks"').response([]);
  tracker.on.insert('into "task_runs"').response([]);
  tracker.on.any(/UPDATE tasks/).response([{
    consecutive_failures: 1, max_failures: null, disabled_at: null, disabled_reason: null
  }]);
  // resolveTaskProxy is mocked to a datacenter-style endpoint for this case.
  proxyType = 'datacenter';
  try {
    await startTask(baseTask()).catch(() => {});
  } finally {
    proxyType = 'residential';
  }

  expect(acquired).not.toHaveBeenCalled();
});

