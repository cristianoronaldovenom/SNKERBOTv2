import { jest } from '@jest/globals';

jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));

const breaker = await import('../../helpers/circuit-breaker.js');
const metrics = await import('../../helpers/monitor-metrics.js');
const { validateStockResult } = await import('../../helpers/site-stock-apis.js');
const { runStageWithRecovery } = await import('../../helpers/stage-retry.js');
const liveness = await import('../../helpers/proxy-liveness.js');

describe('stage retry vs a dead exit', () => {
  const transient = () => Object.assign(new Error('net::ERR_CONNECTION_RESET'), { failureType: 'transient' });

  beforeEach(() => liveness.__resetLiveness());

  test('a dead exit fails fast and asks for rotation instead of retrying', async () => {
    for (let i = 0; i < liveness.livenessConfig().deadFailures; i++) liveness.recordFailure(11);
    const fn = jest.fn(async () => { throw transient(); });

    await expect(runStageWithRecovery(fn, { stage: 'fill', attempts: 3, baseMs: 1, proxyId: 11 }))
      .rejects.toMatchObject({ needsProxyRotation: true });
    // One attempt only — the retries would have hit the same dead IP.
    expect(fn).toHaveBeenCalledTimes(1);
  });

  test('a healthy exit still retries normally', async () => {
    liveness.recordLatency(12, 120);
    const fn = jest.fn(async () => { throw transient(); });
    await expect(runStageWithRecovery(fn, { stage: 'fill', attempts: 3, baseMs: 1, proxyId: 12 })).rejects.toThrow();
    expect(fn).toHaveBeenCalledTimes(3);
  });

  test('without a proxyId nothing changes', async () => {
    const fn = jest.fn(async () => { throw transient(); });
    await expect(runStageWithRecovery(fn, { stage: 'fill', attempts: 2, baseMs: 1 })).rejects.toThrow();
    expect(fn).toHaveBeenCalledTimes(2);
  });
});

describe('circuit breaker', () => {
  beforeEach(() => breaker.reset());

  test('starts CLOSED and allows requests', () => {
    const gate = breaker.canRequest('a.com');
    expect(gate.allowed).toBe(true);
    expect(gate.state).toBe('CLOSED');
  });

  test('opens after the failure threshold and short-circuits requests', () => {
    for (let i = 0; i < 5; i++) breaker.recordFailure('a.com', 'block');
    const gate = breaker.canRequest('a.com');
    expect(gate.allowed).toBe(false);
    expect(gate.state).toBe('OPEN');
    expect(gate.retryInMs).toBeGreaterThan(0);
  });

  test('does not open below the threshold', () => {
    for (let i = 0; i < 4; i++) breaker.recordFailure('a.com', 'block');
    expect(breaker.canRequest('a.com').allowed).toBe(true);
  });

  test('a single success resets the consecutive-failure streak', () => {
    breaker.recordFailure('a.com');
    breaker.recordFailure('a.com');
    breaker.recordSuccess('a.com');
    expect(breaker.getState('a.com').consecutiveFailures).toBe(0);
  });

  test('isolates breakers per host', () => {
    for (let i = 0; i < 5; i++) breaker.recordFailure('a.com');
    expect(breaker.canRequest('a.com').allowed).toBe(false);
    expect(breaker.canRequest('b.com').allowed).toBe(true);
  });
});

describe('validateStockResult — false-positive prevention', () => {
  test('only a strict boolean true counts as in stock', () => {
    expect(validateStockResult({ inStock: true, price: '$10' }).inStock).toBe(true);
    expect(validateStockResult({ inStock: 'yes' }).inStock).toBe(false);
    expect(validateStockResult({ inStock: 1 }).inStock).toBe(false);
    expect(validateStockResult({ inStock: {} }).inStock).toBe(false);
    expect(validateStockResult({ inStock: 'true' }).inStock).toBe(false);
  });

  test('an in-stock claim with no name/price/sizes is low-confidence', () => {
    expect(validateStockResult({ inStock: true }).confident).toBe(false);
    expect(validateStockResult({ inStock: true, productName: 'Dunk Low' }).confident).toBe(true);
    expect(validateStockResult({ inStock: true, availableSizes: ['10'] }).confident).toBe(true);
  });

  test('out-of-stock verdicts are always actionable', () => {
    expect(validateStockResult({ inStock: false }).confident).toBe(true);
  });

  test('returns null for structurally unusable input', () => {
    expect(validateStockResult(null)).toBeNull();
    expect(validateStockResult(undefined)).toBeNull();
    expect(validateStockResult('nope')).toBeNull();
    expect(validateStockResult(42)).toBeNull();
  });

  test('sanitizes sizes and string fields', () => {
    const r = validateStockResult({ inStock: true, availableSizes: ['10', null, 42, ' 9 ', ''] });
    expect(r.availableSizes).toEqual(['10', '9']);
    const r2 = validateStockResult({ inStock: false, productName: '   ', price: '  $5 ' });
    expect(r2.productName).toBeNull();
    expect(r2.price).toBe('$5');
  });
});

describe('monitor metrics', () => {
  beforeEach(() => metrics.reset());

  test('aggregates outcomes and computes rates', () => {
    metrics.record('m.com', { outcome: 'instock', latencyMs: 100, source: 'api' });
    metrics.record('m.com', { outcome: 'outofstock', latencyMs: 80, source: 'api' });
    metrics.record('m.com', { outcome: 'blocked', latencyMs: 40 });
    metrics.record('m.com', { outcome: 'error', latencyMs: 200, error: 'timeout' });

    const m = metrics.getMetrics('m.com');
    expect(m.checks).toBe(4);
    expect(m.inStock).toBe(1);
    expect(m.blocked).toBe(1);
    expect(m.errors).toBe(1);
    expect(m.successRate).toBe(0.5); // (4 - 1 blocked - 1 error) / 4
    expect(m.blockRate).toBe(0.25);
    expect(m.lastError).toBe('timeout');
    expect(m.latency.p50).not.toBeNull();
  });

  test('returns null for an unknown host', () => {
    expect(metrics.getMetrics('never-seen.com')).toBeNull();
  });
});
