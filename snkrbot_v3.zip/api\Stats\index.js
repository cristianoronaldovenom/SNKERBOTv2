import { Router } from 'express';
import db from '../../db/index.js';
import { getAllMonitors } from '../../helpers/monitor-store.js';
import { getDashboardStatsCache, setDashboardStatsCache } from '../../helpers/dashboard-stats-cache.js';

const router = Router();

router.get('/', async (req, res, next) => {
  try {
    const cached = getDashboardStatsCache();
    if (cached) return res.json({ success: true, message: 'Stats', data: cached });

    const [tasksTotal, tasksDeleted, addresses, payments, proxies, recentLogs, recentLogsErr] = await Promise.all([
      db('tasks').count({ c: '*' }).first().then(r => Number(r?.c || 0)),
      db('tasks').where({ is_deleted: true }).count({ c: '*' }).first().then(r => Number(r?.c || 0)),
      db('addresses').count({ c: '*' }).first().then(r => Number(r?.c || 0)),
      db('payment_profiles').count({ c: '*' }).first().then(r => Number(r?.c || 0)),
      db('proxies').count({ c: '*' }).first().then(r => Number(r?.c || 0)),
      db('logs').count({ c: '*' }).first().then(r => Number(r?.c || 0)).catch(() => 0),
      db('logs').where('level', 'error').count({ c: '*' }).first().then(r => Number(r?.c || 0)).catch(() => 0)
    ]);

    const [runCounts, activeMonitors] = await Promise.all([
      db('task_runs')
        .select(db.raw(`SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as wins`), db.raw('COUNT(*) as total'))
        .first()
        .catch(() => ({ wins: 0, total: 0 })),
      Promise.resolve(Object.keys(getAllMonitors()).length),
    ]);
    const successfulCheckouts = Number(runCounts?.wins || 0);
    const runTotal = Number(runCounts?.total || 0);
    const activeTasks = tasksTotal - tasksDeleted;
    const successRate = runTotal > 0 ? Math.round((successfulCheckouts / runTotal) * 100) : 0;

    const data = {
      activeTasks,
      successfulCheckouts,
      successRate,
      activeMonitors,
      addresses,
      payments,
      proxies,
      recentLogs,
      recentLogsErr,
      runTotal,
      generatedAt: new Date().toISOString()
    };
    setDashboardStatsCache(data, 2000);
    return res.json({ success: true, message: 'Stats', data });
  } catch (err) { next(err); }
});

export default router;
