import db from '../db/index.js';
import { resolveTaskProxy } from './task-proxies.js';
import logger from './logger.js';

const isExpired = (mm, yyyy) => {
  const m = parseInt(mm, 10);
  let y = parseInt(yyyy, 10);
  if (!m || !y || m < 1 || m > 12) return true;
  // Accept a 2-digit year (`26`): `new Date(26, m, 0)` is 1926, which made every
  // card created before the schema was tightened read as expired.
  if (y < 100) y += 2000;
  const now = new Date();
  // `new Date(y, monthIndex, 0)` with monthIndex === m is the LAST day of month m
  // (1-based), i.e. the real expiry day — a card is valid through that day.
  const exp = new Date(y, m, 0, 23, 59, 59);
  return exp < now;
};

const luhnValid = (num) => {
  const digits = String(num || '').replace(/\D/g, '');
  if (digits.length < 12 || digits.length > 19) return false;
  let sum = 0, alt = false;
  for (let i = digits.length - 1; i >= 0; i--) {
    let n = parseInt(digits[i], 10);
    if (alt) { n *= 2; if (n > 9) n -= 9; }
    sum += n;
    alt = !alt;
  }
  return sum % 10 === 0;
};

export const preflightTask = async (task) => {
  const issues = [];
  const warnings = [];

  if (!task.url || !/^https?:\/\//i.test(task.url)) {
    issues.push('Task URL is missing or invalid');
  } else {
    try { new URL(task.url); } catch { issues.push('Task URL cannot be parsed'); }
  }

  if (!task.site_id) issues.push('Site is not selected');

  const ship = task.shipping_address_id
    ? await db('addresses').where({ id: task.shipping_address_id }).first()
    : null;
  if (!task.shipping_address_id) {
    issues.push('No shipping address attached');
  } else if (!ship) {
    issues.push('Shipping address not found in database');
  } else {
    for (const f of ['first_name', 'last_name', 'address1', 'city', 'state', 'zip', 'phone', 'email']) {
      if (!ship[f] || String(ship[f]).trim() === '') issues.push(`Shipping address missing "${f}"`);
    }
    if (ship.email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(ship.email)) {
      warnings.push(`Shipping email "${ship.email}" looks malformed`);
    }
  }

  const pay = task.payment_profile_id
    ? await db('payment_profiles').where({ id: task.payment_profile_id }).first()
    : null;
  if (!task.payment_profile_id) {
    issues.push('No payment profile attached');
  } else if (!pay) {
    issues.push('Payment profile not found in database');
  } else {
    if (!pay.card_number) issues.push('Card number missing on payment profile');
    else if (!luhnValid(pay.card_number)) warnings.push('Card number fails Luhn check (may be a test card)');
    if (!pay.card_holder_name) issues.push('Cardholder name missing');
    if (!pay.cvv || pay.cvv.length < 3) issues.push('CVV missing or too short');
    if (isExpired(pay.expiration_month, pay.expiration_year)) {
      issues.push(`Card expired (${pay.expiration_month}/${pay.expiration_year})`);
    }
  }

  const email = task.notification_email_address || ship?.email;
  if (!email) {
    warnings.push('No notification email — you will not get success email');
  }

  const [monitorProxy, checkoutProxy] = await Promise.all([
    resolveTaskProxy(task, 'monitor'),
    resolveTaskProxy(task, 'checkout'),
  ]);
  if (monitorProxy.source === 'missing') warnings.push('Monitoring proxy assignment is missing/deleted — monitoring may use a direct connection');
  if (checkoutProxy.source === 'missing') warnings.push('Checkout proxy assignment is missing/deleted — checkout may use a direct connection');
  if (!monitorProxy.proxy) warnings.push('No monitoring proxy resolved — stock monitoring will use a direct connection');
  if (!checkoutProxy.proxy) warnings.push('No checkout proxy resolved — checkout will use a direct connection');

  if (task.start_at) {
    const startAt = new Date(task.start_at);
    if (isNaN(startAt.getTime())) {
      issues.push(`Invalid start_at timestamp: ${task.start_at}`);
    } else if (startAt < new Date(Date.now() - 60_000)) {
      warnings.push(`start_at is in the past (${startAt.toISOString()}) — task will fire immediately`);
    }
  }

  const ok = issues.length === 0;
  return { ok, issues, warnings, summary: ok ? `Preflight OK${warnings.length ? ` (${warnings.length} warning${warnings.length > 1 ? 's' : ''})` : ''}` : `${issues.length} blocking issue${issues.length > 1 ? 's' : ''}` };
};

export const logPreflight = (taskId, result) => {
  if (result.ok) {
    logger.info(`[Preflight] task ${taskId}: ${result.summary}`);
  } else {
    logger.warn(`[Preflight] task ${taskId}: ${result.summary} — ${result.issues.join('; ')}`);
  }
  result.warnings.forEach((w) => logger.warn(`[Preflight] task ${taskId} warning: ${w}`));
};
