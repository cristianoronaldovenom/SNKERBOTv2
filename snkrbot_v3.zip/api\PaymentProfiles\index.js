import { Router } from 'express';
import { validate } from 'express-validation';
import * as controller from './controller.js';
import { createPaymentProfileSchema, updatePaymentProfileSchema } from './validation.js';

const router = Router();

router.get('/', controller.findAll);
router.get('/:id', controller.findOne);
router.post('/', validate(createPaymentProfileSchema, {}, {}), controller.create);
router.patch('/:id', validate(updatePaymentProfileSchema, {}, {}), controller.update);
router.delete('/:id', controller.remove);

export default router;
