// Renders the real stealth script from cluster.js and syntax-checks it, plus
// asserts the profile-derived values actually land in the output. The script is
// a template literal, so a bad interpolation only fails at runtime in a browser —
// i.e. mid-drop — unless something like this catches it.
import vm from 'node:vm';
import assert from 'node:assert/strict';
import { brandVersionList } from '../helpers/client-hints.js';

// cluster.js pulls in puppeteer at import time; stub what the module graph needs
// by reading the source and evaluating only the builder, which is pure.
const src = await (await import('node:fs/promises')).readFile(new URL('../helpers/cluster.js', import.meta.url), 'utf8');

const start = src.indexOf('const buildStealthScript = (profile) => `');
const end = src.indexOf('\n`;', src.indexOf('function toString'));
const body = src.slice(start, end + 3);
assert.ok(body.startsWith('const buildStealthScript'), 'stealth script builder not found');

const factory = new Function(`${body}; return buildStealthScript;`)();

const base = {
  ua: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
  chromeVer: '131', fullVer: '131.0.6778.204',
  platform: '"macOS"', platformVer: '"14.5.0"', arch: '"arm"', bitness: '"64"', model: '""', mobile: '?0',
  vendor: 'Google Inc.', cores: 8, mem: 16, gpu: 'Apple M1',
  webglVendor: 'Google Inc. (Apple)', webglRenderer: 'ANGLE (Apple, Apple M1, Metal)',
  canvasSeed: 123456, audioSeed: 654321, fontSeed: 111,
  tz: 'America/Toronto',
  brands: brandVersionList(131),
  brandsFull: brandVersionList(131, { fullVersion: '131.0.6778.204' }),
  geo: { screenWidth: 1512, screenHeight: 982, availWidth: 1512, availHeight: 892, availTop: 25, availLeft: 0, screenX: 0, screenY: 25, outerWidth: 1486, outerHeight: 982, innerWidth: 1470, innerHeight: 860, dpr: 2 }
};

const script = factory(base);
// Must parse as a standalone script.
new vm.Script(script);

// Profile values must actually be interpolated (not left as literals).
assert.match(script, /"Apple M1"/, 'GPU must be interpolated');
assert.match(script, /Not_A Brand/, 'GREASE brand must be interpolated');
assert.match(script, /1512/, 'screen width must be profile-derived');
assert.doesNotMatch(script, /\$\{/, 'no uninterpolated placeholders may survive');
assert.match(script, /_glVendor/, 'vendor must come from the shared constant');
// The ternary carries both literals, so assert on the interpolated profile JSON.
assert.match(script, /"webglVendor":"Google Inc\. \(Apple\)"/, 'macOS profile must carry the Apple vendor');

// Executing getParameter must actually return the profile vendor. This is the
// check that matters: readback happens at runtime, not at template time.
const readVendor = (src) => {
  const ctx = {
    WebGLRenderingContext: class {}, WebGL2RenderingContext: class {},
    Plugin: class {}, MimeType: class {}, PluginArray: class {},
    HTMLCanvasElement: class {}, CanvasRenderingContext2D: class {},
    AudioBuffer: class {}, Notification: { permission: 'default' },
    navigator: { languages: [], permissions: { query: () => {} }, getGamepads: () => {}, userAgentData: null },
    screen: {}, document: { fonts: { check: () => {} } }, performance: {},
    Element: class {}
  };
  ctx.window = ctx;
  ctx.window.chrome = undefined;
  ctx.WebGLRenderingContext.prototype.getParameter = function () { return 'native'; };
  ctx.WebGL2RenderingContext.prototype.getParameter = function () { return 'native'; };
  ctx.HTMLCanvasElement.prototype.toDataURL = function () {};
  ctx.CanvasRenderingContext2D.prototype.getImageData = function () {};
  ctx.AudioBuffer.prototype.getChannelData = function () {};
  ctx.Element.prototype.attachShadow = function () {};
  ctx.navigator.permissions.query = () => {};
  ctx.Notification.permission = 'default';
  vm.createContext(ctx);
  new vm.Script(src).runInContext(ctx);
  return vm.runInContext(
    'WebGLRenderingContext.prototype.getParameter.call({}, 37445)', ctx
  );
};

assert.equal(readVendor(script), 'Google Inc. (Apple)', 'macOS must report the Apple WebGL vendor');
assert.equal(
  readVendor(factory({ ...base, platform: '"Windows"', webglVendor: 'Google Inc. (Intel)', gpu: 'Intel(R) UHD Graphics 620' })),
  'Google Inc. (Intel)',
  'Windows must report the Intel WebGL vendor'
);

// A Windows profile must not leak the Apple vendor through getParameter.
const winScript = factory({ ...base, platform: '"Windows"', webglVendor: 'Google Inc. (Intel)', gpu: 'Intel(R) UHD Graphics 620' });
new vm.Script(winScript);
assert.match(winScript, /"webglVendor":"Google Inc\. \(Intel\)"/);

// ── Regression: double-defineProperty on non-configurable own props ─────────
// Block 16 defined `brands` twice. The second call threw TypeError, the
// surrounding try/catch swallowed it, and mobile/platform/getHighEntropyValues
// were never applied — userAgentData stayed genuine while navigator.userAgent
// was spoofed. Execute the script against a real object and check the spoof
// actually landed.
const runInSandbox = (src, extra = {}) => {
  const data = { brands: [{ brand: 'Genuine', version: '99' }], mobile: false, platform: 'GenuineOS', getHighEntropyValues: async () => ({}) };
  const ctx = {
    WebGLRenderingContext: class {}, WebGL2RenderingContext: class {},
    Plugin: class {}, MimeType: class {}, PluginArray: class {}, Navigator: class {},
    HTMLCanvasElement: class {}, CanvasRenderingContext2D: class {},
    AudioBuffer: class {}, Notification: { permission: 'default' },
    screen: {}, document: { fonts: { check: () => {} } }, performance: {},
    history: { length: 1 },
    Element: class {}
  };
  // navigator must be a real Navigator INSTANCE: block 1 defines webdriver on
  // Navigator.prototype, so a plain-object navigator would never see it and the
  // assertion would pass for the wrong reason.
  ctx.navigator = Object.assign(new ctx.Navigator(), {
    languages: [], permissions: { query: () => {} }, getGamepads: () => {},
    userAgentData: data,
    connection: { rtt: 1, downlink: 1, effectiveType: '3g', saveData: true },
    // A headless-style estimate: quota 0 is the implausible value under test.
    storage: { estimate: () => Promise.resolve({ quota: 0, usage: 0 }) }
  });
  ctx.window = ctx;
  ctx.window.chrome = undefined;
  Object.assign(ctx, extra);
  ctx.WebGLRenderingContext.prototype.getParameter = function () { return 'native'; };
  ctx.WebGL2RenderingContext.prototype.getParameter = function () { return 'native'; };
  ctx.HTMLCanvasElement.prototype.toDataURL = function () {};
  ctx.CanvasRenderingContext2D.prototype.getImageData = function () {};
  ctx.AudioBuffer.prototype.getChannelData = function () {};
  // Emulate the real attachShadow contract: returns a root carrying the
  // requested mode and exposes it on the host only when open.
  ctx.Element.prototype.attachShadow = function (init) {
    const root = { mode: (init || {}).mode || 'open', host: this };
    if (root.mode === 'open') this.shadowRoot = root;
    return root;
  };
  ctx.navigator.permissions.query = () => {};
  vm.createContext(ctx);
  new vm.Script(src).runInContext(ctx);
  return ctx;
};

const sandbox = runInSandbox(script);
assert.equal(sandbox.navigator.userAgentData.mobile, false, 'mobile must be spoofed from the profile');
assert.equal(sandbox.navigator.userAgentData.platform, 'macOS', 'platform must be spoofed even though brands was already defined');
assert.equal(
  JSON.stringify(sandbox.navigator.userAgentData.brands.map((b) => b.brand)),
  JSON.stringify(base.brands.map((b) => b.brand)),
  'brands must be overridden with the profile GREASE list'
);

// ── Regression: navigator.languages must come from the profile timezone ─────
// It was defined in two blocks; the second (tz-aware) one threw on the
// non-configurable property and the hardcoded en-CA list survived for every
// profile, including US-timezone ones.
const usSandbox = runInSandbox(factory({ ...base, platform: '"Windows"', tz: 'America/New_York', webglVendor: 'Google Inc. (Intel)', gpu: 'Intel(R) UHD Graphics 620' }));
assert.ok(
  !usSandbox.navigator.languages.includes('en-CA'),
  `a New York profile must not report en-CA, got ${JSON.stringify(usSandbox.navigator.languages)}`
);
assert.equal(usSandbox.navigator.languages[0], 'en-US', 'US timezone must lead with en-US');

// ── Regression: getHighEntropyValues echoes only the requested hints ────────
const hinted = await sandbox.navigator.userAgentData.getHighEntropyValues(['architecture']);
assert.equal(hinted.architecture, 'arm');
assert.ok('brands' in hinted, 'brands is always present, like real Chrome');
assert.ok(!('model' in hinted), `unrequested hints must be omitted, got ${Object.keys(hinted)}`);

// ── Regression: canvas noise must be stable across repeat reads ─────────────
// Canvas noise used to be re-added on every read, so toDataURL() twice gave two
// hashes and fp libraries — which always double-read — saw a moving target.
const canvasSandbox = (() => {
  const ctx2 = {
    WebGLRenderingContext: class {}, WebGL2RenderingContext: class {},
    Plugin: class {}, MimeType: class {}, PluginArray: class {},
    HTMLCanvasElement: class {}, CanvasRenderingContext2D: class {},
    AudioBuffer: class {}, Notification: { permission: 'default' },
    navigator: { languages: [], permissions: { query: () => {} }, getGamepads: () => {}, userAgentData: null },
    screen: {}, document: { fonts: { check: () => {} } }, performance: {},
    Element: class {}
  };
  ctx2.window = ctx2;
  ctx2.window.chrome = undefined;
  ctx2.WebGLRenderingContext.prototype.getParameter = function () { return 'native'; };
  ctx2.WebGL2RenderingContext.prototype.getParameter = function () { return 'native'; };
  // Native stubs go on the PROTOTYPE BEFORE the script runs, so the script
  // captures them as the originals and its wrapper calls straight through.
  const pixels = new Uint8ClampedArray(64 * 64 * 4).fill(200);
  ctx2.CanvasRenderingContext2D.prototype.getImageData = function () {
    return { data: Uint8ClampedArray.from(pixels) };
  };
  ctx2.CanvasRenderingContext2D.prototype.putImageData = function (img) {
    pixels.set(img.data);
  };
  ctx2.HTMLCanvasElement.prototype.toDataURL = function () {
    return 'data:' + JSON.stringify(Array.from(pixels.slice(0, 40)));
  };
  ctx2.AudioBuffer.prototype.getChannelData = function () {};
  // Emulate the real attachShadow contract: returns a root carrying the
  // requested mode and exposes it on the host only when open.
  ctx2.Element.prototype.attachShadow = function (init) {
    const root = { mode: (init || {}).mode || 'open', host: this };
    if (root.mode === 'open') this.shadowRoot = root;
    return root;
  };
  ctx2.navigator.permissions.query = () => {};
  vm.createContext(ctx2);
  new vm.Script(script).runInContext(ctx2);

  // A canvas of the patched realm whose context routes to the stubs above.
  const fakeCanvas = new ctx2.HTMLCanvasElement();
  fakeCanvas.width = 64;
  fakeCanvas.height = 64;
  const fakeCtx = new ctx2.CanvasRenderingContext2D();
  fakeCanvas.getContext = () => fakeCtx;
  fakeCtx.canvas = fakeCanvas;
  return { fakeCanvas, fakeCtx, pixels };
})();

const { fakeCanvas, fakeCtx, pixels } = canvasSandbox;
const pristine = 'data:' + JSON.stringify(Array.from(new Uint8ClampedArray(64 * 64 * 4).fill(200).slice(0, 40)));

const firstRead = fakeCanvas.toDataURL();
assert.notEqual(firstRead, pristine, 'noise must actually be applied on the first read');
const secondRead = fakeCanvas.toDataURL();
assert.equal(secondRead, firstRead, 'toDataURL must be byte-stable across reads (no per-read re-noising)');

// A mixed getImageData → toDataURL sequence must stay stable too.
const viaImageData = fakeCtx.getImageData(0, 0, 64, 64);
assert.equal(viaImageData.data.length, pixels.length);
const thirdRead = fakeCanvas.toDataURL();
assert.equal(thirdRead, firstRead, 'getImageData after toDataURL must not re-noison the canvas');

// ── Regression: closed shadow roots must read back as null ─────────────────
// The old wrapper was a pure passthrough, so a page that checks
// `el.shadowRoot === null` saw a root where a real browser gives null.
const shadowSandbox = runInSandbox(script);
const shadowEl = new shadowSandbox.Element();
const closedRoot = shadowEl.attachShadow({ mode: 'closed' });
assert.ok(closedRoot, 'attachShadow must still return the root');
assert.equal(closedRoot.mode, 'open', 'the root is built on the open path so it stays reachable');
assert.equal(shadowEl.shadowRoot, null, 'a closed root must read back as null, like a real browser');

const openEl = new shadowSandbox.Element();
const openRoot = openEl.attachShadow({ mode: 'open' });
assert.equal(openEl.shadowRoot, openRoot, 'an open root must still be readable');

// ── Regression: WebRTC must not leak the real IP via STUN ───────────────────
// The old wrapper only stripped iceServers from the constructor argument, so a
// createOffer({iceServers}) call re-introduced STUN and srflx candidates
// exposed the host IP. It also re-bound createOffer pointlessly.
const rtcSandbox = runInSandbox(script);
const seenConfigs = [];
class FakePC {
  constructor(cfg) { seenConfigs.push(cfg); this.cfg = cfg; }
  createOffer(o) { seenConfigs.push(o); return Promise.resolve({ type: 'offer' }); }
}
// The original must exist before the script runs so the wrapper can capture it.
const rtcCtx = runInSandbox(script, { RTCPeerConnection: FakePC });
const pc = new rtcCtx.RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] });
assert.equal(pc.cfg.iceServers.length, 0, 'constructor STUN servers must be dropped');
assert.ok(pc instanceof FakePC, 'the wrapper must stay an instanceof the original');
pc.createOffer({ iceServers: [{ urls: 'stun:x' }] });
assert.equal(seenConfigs[seenConfigs.length - 1].iceServers.length, 0, 'createOffer STUN servers must be dropped too');

// ── Regression: connection.rtt/downlink frozen per launch ───────────────────
const rtt = sandbox.navigator.connection.rtt;
assert.equal(sandbox.navigator.connection.rtt, rtt, 'rtt must not be re-randomised per read');
// Both connection blocks define the same keys. Without `configurable` the second
// pass throws inside its own try/catch and silently drops whatever only it sets —
// `type` was missing for that reason, and NetworkInformation.type is checked
// alongside effectiveType by network-aware fingerprinters.
assert.equal(sandbox.navigator.connection.type, 'wifi', 'connection.type must be spoofed');
assert.equal(sandbox.navigator.connection.effectiveType, '4g', 'effectiveType must be spoofed');

// ── Regression: webdriver must be a boolean on the prototype, not undefined ──
// Asserting `=== false` (not `!navigator.webdriver`) is deliberate: undefined is
// also falsy, which is exactly how the old `get: () => undefined` version slipped
// through every casual check while breaking strict typeof-based ones.
assert.equal(sandbox.navigator.webdriver, false, 'webdriver must read as false, like real Chrome');
assert.ok('webdriver' in sandbox.navigator, "'webdriver' must stay an in-navigator property");
assert.ok(
  !Object.prototype.hasOwnProperty.call(sandbox.navigator, 'webdriver'),
  'webdriver must live on Navigator.prototype, not be an own property of the instance'
);

// ── Regression: navigator.language must equal languages[0] ──────────────────
assert.equal(
  usSandbox.navigator.language, usSandbox.navigator.languages[0],
  'language must track languages[0]; a mismatch is a one-line fingerprint check'
);

// ── Regression: focus/visibility coherence ──────────────────────────────────
// A page that claims visibilityState 'visible' but answers hasFocus() false is
// advertising a background tab.
assert.equal(sandbox.document.visibilityState, 'visible');
assert.equal(sandbox.document.hidden, false);
assert.equal(sandbox.document.hasFocus(), true, 'hasFocus must agree with visibilityState');

// ── Regression: presence tells that headless leaves empty ───────────────────
assert.equal(sandbox.screen.orientation.type, 'landscape-primary', 'screen orientation must match a landscape screen');
assert.equal(sandbox.screen.orientation.angle, 0);
assert.equal(sandbox.history.length >= 2, true, `history.length was never populated, got ${sandbox.history.length}`);

// ── Regression: work-area origin ────────────────────────────────────────────
// Headless reports screenX/screenY/availTop/availLeft as 0 on every platform.
// On a macOS profile the menu bar must push a maximised window down, and a
// maximised window is pinned to the work-area origin, so screenX === availLeft.
assert.equal(sandbox.screen.availTop, 25, 'macOS must reserve the menu bar in availTop');
assert.equal(sandbox.screen.availLeft, 0);
assert.equal(sandbox.screenY, 25, 'screenY must sit below the menu bar');
assert.equal(sandbox.screenX, 0);
assert.equal(sandbox.screenTop, 25, 'screenTop must mirror screenY');
assert.equal(sandbox.screenLeft, 0, 'screenLeft must mirror screenX');
assert.equal(sandbox.screen.availTop, sandbox.screenY, 'work-area top must equal window top for a maximised window');

// performance.memory is Chromium-only and was absent; a fingerprint script reads
// all three keys, so they must be plausible numbers, not an empty object.
const mem = sandbox.performance.memory;
assert.ok(mem, 'performance.memory must exist on a Chrome profile');
for (const key of ['jsHeapSizeLimit', 'totalJSHeapSize', 'usedJSHeapSize']) {
  assert.equal(typeof mem[key], 'number', `${key} must be numeric`);
  assert.ok(mem[key] > 0, `${key} must be positive`);
}
assert.ok(mem.usedJSHeapSize <= mem.totalJSHeapSize, 'used heap must not exceed total heap');
assert.ok(mem.totalJSHeapSize <= mem.jsHeapSizeLimit, 'total heap must not exceed the limit');
// Stable across reads, like the real thing.
assert.equal(sandbox.performance.memory.jsHeapSizeLimit, mem.jsHeapSizeLimit);

// ── Regression: newly patched functions must stringify as native code ───────
// The toString whitelist is exhaustive by design: a replacement that is not on
// it returns its real source, which is a one-line detection.
for (const [label, fn] of [
  ['document.hasFocus', sandbox.document.hasFocus],
  ['navigator.storage.estimate', sandbox.navigator.storage.estimate]
]) {
  assert.match(fn.toString(), /native code/, `${label} must stringify as native code`);
}

// A zero quota is the implausible value a headless profile reports; it must be
// replaced with something a real disk-backed profile could plausibly hold.
const estimate = await sandbox.navigator.storage.estimate();
assert.ok(estimate.quota > 1024 ** 3, `quota must be repaired, got ${estimate.quota}`);

console.log('PASS: stealth script renders and parses for macOS + Windows profiles (profile-derived vendor, no placeholders)');
console.log('PASS: no double-defineProperty dropouts (userAgentData, languages), canvas noise stable, connection frozen');
console.log('PASS: webdriver=false on the prototype, language/languages agree, focus and visibility agree, presence tells filled');
