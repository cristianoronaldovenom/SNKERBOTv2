// Tiny process-local cache for dashboard aggregate stats. The dashboard is read-heavy
// and the underlying counters change much less often than the UI refreshes.
let cached = null;
let expiresAt = 0;

export const getDashboardStatsCache = () => (cached && expiresAt > Date.now()) ? cached : null;
export const setDashboardStatsCache = (value, ttlMs = 2000) => {
  cached = value;
  expiresAt = Date.now() + Math.max(250, ttlMs);
  return value;
};
export const clearDashboardStatsCache = () => {
  cached = null;
  expiresAt = 0;
};
