// Circuit breaker behaviour: the gate that stops a hard-blocked host from being
// hammered. These pin the HALF_OPEN probe lifecycle, because a wedged breaker
// silently converts "blocked for 30s" into "blocked forever".
import { jest } from '@jest/globals';

jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));

const { canRequest, recordSuccess, recordFailure, getState, reset } =
  await import('../../helpers/circuit-breaker.js');

const HOST = 'shop.test';

beforeEach(() => {
  reset();
  jest.useFakeTimers();
  jest.setSystemTime(new Date('2026-01-01T00:00:00Z'));
});

afterEach(() => { jest.useRealTimers(); });

// Drive the breaker to OPEN, then past the cooldown into HALF_OPEN.
const openThenCoolDown = (opts = {}) => {
  for (let i = 0; i < 5; i += 1) recordFailure(HOST, 'blocked');
  expect(canRequest(HOST, opts).allowed).toBe(false);
  jest.advanceTimersByTime(31_000);
};

test('opens only after the failure threshold', () => {
  for (let i = 0; i < 4; i += 1) recordFailure(HOST, 'blocked');
  expect(canRequest(HOST).allowed).toBe(true);
  recordFailure(HOST, 'blocked');
  expect(canRequest(HOST).allowed).toBe(false);
  expect(getState(HOST).state).toBe('OPEN');
});

test('cooldown expiry admits exactly one probe', () => {
  openThenCoolDown();
  const first = canRequest(HOST);
  expect(first.allowed).toBe(true);
  expect(first.state).toBe('HALF_OPEN');
  expect(canRequest(HOST).allowed).toBe(false);
});

test('a successful probe closes the circuit and resets the counter', () => {
  openThenCoolDown();
  canRequest(HOST);
  recordSuccess(HOST);
  expect(getState(HOST).state).toBe('CLOSED');
  expect(getState(HOST).consecutiveFailures).toBe(0);
  expect(getState(HOST).openCount).toBe(0);
});

test('a failed probe re-opens with a longer cooldown', () => {
  openThenCoolDown();
  canRequest(HOST);
  recordFailure(HOST, 'still blocked');
  expect(getState(HOST).state).toBe('OPEN');
  // Second open = 60s, not 30s.
  expect(getState(HOST).retryInMs).toBeGreaterThan(30_000);
});

test('a probe that never reports back does not wedge the host forever', () => {
  openThenCoolDown();
  expect(canRequest(HOST).allowed).toBe(true);
  // Caller vanishes: no recordSuccess, no recordFailure.
  expect(canRequest(HOST).allowed).toBe(false);
  // Past halfOpenMaxProbeMs (15s) the slot is reclaimed.
  jest.advanceTimersByTime(16_000);
  const retry = canRequest(HOST);
  expect(retry.allowed).toBe(true);
  expect(retry.state).toBe('HALF_OPEN');
  // And still only one at a time afterwards.
  expect(canRequest(HOST).allowed).toBe(false);
});

test('a fresh probe is not reclaimed while it is still young', () => {
  openThenCoolDown();
  canRequest(HOST);
  jest.advanceTimersByTime(5_000);
  expect(canRequest(HOST).allowed).toBe(false);
});

test('success on a CLOSED circuit leaves probes alone', () => {
  recordSuccess(HOST);
  expect(getState(HOST).state).toBe('CLOSED');
  expect(getState(HOST).halfOpenProbes).toBe(0);
});
