// Residential exit-IP affinity (sticky sessions).
//
// The problem: `residential-budget.js` caps how many residential sessions are
// OPEN at once and how many bytes go through them, but nothing stops a monitor
// from consuming a NEW exit IP on every single poll. Most residential gateways
// hand out a fresh exit unless the username carries a session token, so a task
// polling every second burns through dozens of IPs a minute and — worse — looks
// like a bot, because a real shopper keeps one IP across a browsing session.
//
// Two wins from pinning an exit per (task, role, host):
//   1. stealth — the IP stays constant, so the WAF's per-IP history accumulates
//      instead of resetting, and cookie reputation stays coherent.
//   2. cost — providers bill per IP *rotation* as often as per byte, and a
//      reused exit keeps its warm TLS/HTTP2 connection with the gateway.
//
// Provider support differs, so this is opt-in: `RESIDENTIAL_SESSION_TEMPLATE`
// carries a `{session}` placeholder that is substituted into the proxy username
// (the near-universal convention: `user-session-abc123`). With no template the
// proxy is returned untouched, which is exactly today's behaviour.
//
// Rotation is *earned*, not timed: a sticky exit is kept until it is
// quarantined/blocked, the task moves host, or the TTL elapses. A clock-based
// rotation would churn IPs on a fixed, fingerprintable beat.

import logger from './logger.js';

const MAX_SESSIONS = 2048;
const DEFAULT_TTL_MS = 30 * 60_000;

// Read at CALL time, not module load: the template is operator config and
// reading it eagerly makes the module impossible to test without cache-busting
// imports, and impossible to change without a restart.
const template = () => String(process.env.RESIDENTIAL_SESSION_TEMPLATE || '').trim();
const ttlMs = () => Math.max(60_000, Number(process.env.RESIDENTIAL_AFFINITY_TTL_MS || DEFAULT_TTL_MS));

export const affinityEnabled = () => template().includes('{session}');

// `${taskId}|${role}|${host}` → { token, expiresAt, createdAt }
// `__rot__${key}` entries are rotation counters, not live sessions.
const sticky = new Map();

const keyFor = (taskId, role, host) => `${taskId ?? 'anon'}|${role || 'checkout'}|${host || ''}`;

// Stable, non-guessable-but-deterministic token. Derived from the key plus a
// salt so two tasks never collide, but recomputed identically for one task so a
// release+reacquire inside the TTL lands on the SAME exit.
const tokenFor = (key, salt = 0) => {
  let h1 = 0x811c9dc5;
  let h2 = 0x1000193;
  const s = `${key}#${salt}`;
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    h1 = Math.imul(h1 ^ c, 0x01000193) >>> 0;
    h2 = Math.imul(h2 ^ c, 0x85ebca6b) >>> 0;
  }
  return (h1.toString(36) + h2.toString(36)).slice(0, 16);
};

const sweep = (now) => {
  if (sticky.size < MAX_SESSIONS) return;
  for (const [k, v] of sticky) {
    if (v.expiresAt <= now) sticky.delete(k);
  }
  while (sticky.size >= MAX_SESSIONS) {
    const first = sticky.keys().next().value;
    if (first === undefined) break;
    sticky.delete(first);
  }
};

// Apply the session token to a proxy's username. Returns a COPY — never mutates
// the caller's proxy object, which may be cached in the pool or be a DB row.
const applyToken = (proxy, token) => {
  if (proxy.username.includes(token)) return { proxy, applied: false, reason: 'already_affine' };
  const username = template()
    .replace('{session}', token)
    .replace('{user}', proxy.username);
  return { proxy: { ...proxy, username }, applied: true, reason: 'affined' };
};

// Pin (or reuse) an exit for this task+role+host.
//
// Returns `{ proxy, session, reused, reason }`. `proxy` is the original object
// when affinity is unavailable, so a caller can assign it back unconditionally.
export const withAffinity = (proxy, { taskId = null, role = 'checkout', host = null } = {}) => {
  if (!proxy) return { proxy: null, session: null, reused: false, reason: 'no_proxy' };
  if (proxy.proxy_type !== 'residential') return { proxy, session: null, reused: false, reason: 'not_residential' };
  if (!affinityEnabled()) return { proxy, session: null, reused: false, reason: 'disabled' };
  if (!proxy.username) return { proxy, session: null, reused: false, reason: 'no_username' };

  const now = Date.now();
  const key = keyFor(taskId, role, host);
  const hit = sticky.get(key);

  if (hit && hit.expiresAt > now) {
    const applied = applyToken(proxy, hit.token);
    hit.expiresAt = now + ttlMs();           // sliding while in use
    return { proxy: applied.proxy, session: hit.token, reused: true, reason: 'reused' };
  }

  sweep(now);
  const rotations = sticky.get(`__rot__${key}`)?.rotations || 0;
  const token = tokenFor(key, rotations);
  sticky.set(key, { token, createdAt: now, expiresAt: now + ttlMs() });
  const applied = applyToken(proxy, token);
  if (applied.applied && hit) {
    logger.info(`[ResidentialAffinity] Rotated exit for task ${taskId ?? 'anon'} on ${host || 'unknown'}`);
  }
  return { proxy: applied.proxy, session: token, reused: false, reason: applied.reason };
};

// Force a NEW exit next time (call on a ban/block — retrying a banned IP is what
// burns a task). Keeps a rotation counter so a token can never repeat, even
// after many rotations on the same key.
export const rotateAffinity = ({ taskId = null, role = 'checkout', host = null } = {}) => {
  const key = keyFor(taskId, role, host);
  const had = sticky.delete(key);
  const counter = `__rot__${key}`;
  const previous = sticky.get(counter)?.rotations || 0;
  sticky.set(counter, { token: '', createdAt: 0, expiresAt: 0, rotations: previous + 1 });
  return Boolean(had);
};

export const affinitySessionFor = ({ taskId = null, role = 'checkout', host = null } = {}) =>
  sticky.get(keyFor(taskId, role, host))?.session || null;

export const releaseAffinity = ({ taskId = null, role = 'checkout', host = null } = {}) => {
  sticky.delete(keyFor(taskId, role, host));
};

// Diagnostic view for /v1/settings and debug logs.
export const affinitySnapshot = () => {
  const now = Date.now();
  const out = [];
  for (const [key, v] of sticky) {
    if (key.startsWith('__rot__') || !v.token) continue;
    const [taskId, role, host] = key.split('|');
    out.push({
      taskId, role, host,
      session: v.token,
      ageMs: now - v.createdAt,
      expiresInMs: Math.max(0, v.expiresAt - now)
    });
  }
  return out;
};

export const __resetAffinity = () => sticky.clear();
export const affinityConfig = () => ({ enabled: affinityEnabled(), template: template() || null, ttlMs: ttlMs() });
