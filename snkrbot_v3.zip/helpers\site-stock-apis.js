/**
 * Per-site stock monitoring strategies.
 *
 * Why this exists: HTML scraping of 500 KB–2 MB product pages is unreliable
 * (heavy JS rendering, WAF blocks, opaque structure). Every major retailer
 * exposes a JSON API endpoint that returns clean structured availability data —
 * often without authentication and with much lighter WAF scrutiny. We hit those
 * first, parse deterministically, and only fall back to HTML when no API exists.
 *
 * Each checker exports:
 *   extractApiUrl(pdpUrl, size, style) → string | null
 *   parseStock(json, size, style)      → StockResult | null
 *   parseHtml(html, size, style)       → StockResult | null
 *
 * StockResult: { inStock, productName, price, imageUrl, availableSizes }
 */

import logger from './logger.js';

const safeJson = (str) => { try { return JSON.parse(str); } catch (_) { return null; } };

const normalize = (partial) => ({
  inStock: false,
  productName: null,
  price: null,
  imageUrl: null,
  availableSizes: [],
  ...partial,
});

/**
 * Validate and sanitize a parser's output before the monitor acts on it.
 *
 * Why this matters more than anything else here: a false-positive "in stock"
 * fires a real checkout — burning the session, proxy, captcha credits, and
 * potentially placing a wrong order. So an in-stock verdict must be *coerced
 * from a real boolean true*, never from a truthy accident (a non-empty string,
 * an object, NaN, etc.). Anything ambiguous is forced to "not in stock", which
 * is the safe direction (worst case: we miss a poll, then catch it on the next).
 *
 * Returns null when the result is structurally unusable so the caller can fall
 * back to the next strategy instead of trusting garbage.
 */
export const validateStockResult = (result) => {
  if (result == null || typeof result !== 'object') return null;

  // inStock MUST be a strict boolean. Reject anything else as "unknown → false".
  const inStock = result.inStock === true;

  const str = (v) => (typeof v === 'string' && v.trim() ? v.trim().slice(0, 300) : null);
  const sizes = Array.isArray(result.availableSizes)
    ? result.availableSizes.filter(s => typeof s === 'string' && s.trim()).map(s => s.trim()).slice(0, 100)
    : [];

  // A claim of "in stock" with zero parseable signal (no name, no price, no
  // sizes) is suspicious — treat it as low-confidence and don't act on it.
  const hasSignal = !!str(result.productName) || !!str(result.price) || sizes.length > 0;

  return {
    inStock,
    confident: inStock ? hasSignal : true, // OOS verdicts are always actionable
    productName: str(result.productName),
    price: str(result.price),
    imageUrl: str(result.imageUrl),
    availableSizes: sizes,
  };
};

// ─── Helpers ──────────────────────────────────────────────────────────────────

const extractNextData = (html) => {
  const m = html.match(/<script[^>]+id=["']__NEXT_DATA__["'][^>]*>([^<]+)<\/script>/i);
  return m ? safeJson(m[1]) : null;
};

const sizeMatches = (variantTitle, size) => {
  if (!size) return true;
  if (variantTitle == null || variantTitle === '') return false;
  const s = String(size).toLowerCase().trim();
  const v = String(variantTitle).toLowerCase().trim();
  if (!v) return false;
  return v === s || v.includes(s) || s.includes(v);
};

// ─── Shopify ──────────────────────────────────────────────────────────────────
// Works for site_id 2 (generic Shopify) and 7 (Topps, which is Shopify-hosted).
// The /products/{handle}.json endpoint is public, unauthenticated, and never WAF-blocked.
export const shopifyCheck = {
  extractApiUrl(pdpUrl) {
    try {
      const u = new URL(pdpUrl);
      const m = u.pathname.match(/\/products\/([^/?#]+)/);
      if (!m) return null;
      return `${u.origin}/products/${m[1]}.json`;
    } catch (_) { return null; }
  },

  parseStock(data, size) {
    const product = data?.product;
    if (!product) return null;
    const variants = product.variants || [];
    if (variants.length === 0) return null;

    const available = variants.filter(v => v.available);
    const target = size
      ? available.find(v => sizeMatches(v.title, size) || sizeMatches(v.option1, size) || sizeMatches(v.option2, size))
      : available[0];

    return normalize({
      inStock: size ? !!target : available.length > 0,
      productName: product.title,
      price: variants[0]?.price ? `$${parseFloat(variants[0].price).toFixed(2)}` : null,
      imageUrl: product.images?.[0]?.src || null,
      availableSizes: available.map(v => v.title),
    });
  },

  parseHtml(html, size) {
    // Shopify embeds window.ShopifyAnalytics.meta or product JSON in script tags
    const scriptMatch = html.match(/var\s+meta\s*=\s*(\{[^;]+\});/) ||
                        html.match(/"product"\s*:\s*(\{"id":\d+[^;]{10,})\s*[,;]/);
    if (scriptMatch) {
      const p = safeJson(scriptMatch[1])?.product || safeJson(scriptMatch[1]);
      if (p?.variants) {
        const available = (p.variants || []).filter(v => v.available);
        const target = size ? available.find(v => sizeMatches(v.title, size)) : available[0];
        return normalize({
          inStock: size ? !!target : available.length > 0,
          productName: p.title,
          availableSizes: available.map(v => v.title),
        });
      }
    }
    // Last resort: check for a non-disabled ATC button in HTML
    const atcMatch = html.match(/id=["']?add-to-cart[^>]*>([^<]+)</i);
    const disabled = /add-to-cart[^>]*(disabled|soldout|sold.out)[^>]*>/i.test(html);
    return normalize({ inStock: !!atcMatch && !disabled });
  },
};

// ─── Footsites (Salesforce Commerce Cloud / SFCC) ────────────────────────────
// Covers: footlocker.com, champssports.com, kidsfootlocker.com, eastbay.com, finishline.com
export const footsitesCheck = {
  extractApiUrl(pdpUrl) {
    try {
      const u = new URL(pdpUrl);
      // URL ends with /{numericId}.html or /{alphanumericId}.html
      const m = u.pathname.match(/\/([A-Za-z0-9_-]{6,20})\.html$/);
      const productId = m ? m[1] : null;
      if (!productId) return null;
      // SFCC product detail API — includes all size variations with ATS
      return `${u.origin}/api/2.0/json/products/pdp/${productId}?locale=en_US&includeAvailability=true`;
    } catch (_) { return null; }
  },

  parseStock(data, size) {
    // SFCC response wraps the product in data.result, data.product (native
    // Product-Variation controller), or returns it directly at the root.
    const result = data?.result || data?.product || data;
    if (!result) return null;

    // Top-level orderable / ATS (also accept the nested availability.* shape
    // used by the native Product-Variation endpoint).
    const topOrderable = result.orderable ?? result.availability?.orderable;
    const topATS = result.ATS ?? result.availability?.ATS ?? result.availability?.ats;

    // Per-size availability from variationAttributes
    const attrs = result.variationAttributes || [];
    const sizeAttr = attrs.find(a => a.id === 'size' || a.attributeId === 'size');
    let availableSizes = [];

    if (sizeAttr?.values) {
      availableSizes = sizeAttr.values
        .filter(v => v.orderable !== false && (v.ATS == null || v.ATS > 0))
        .map(v => v.displayValue || v.value);
    }

    // Size-specific check
    let inStock;
    if (size && sizeAttr?.values?.length) {
      const match = sizeAttr.values.find(v =>
        sizeMatches(v.displayValue, size) || sizeMatches(v.value, size)
      );
      inStock = match ? (match.orderable !== false && (match.ATS == null || match.ATS > 0)) : false;
    } else {
      inStock = topOrderable === true || (typeof topATS === 'number' && topATS > 0);
    }

    return normalize({
      inStock,
      productName: result.name || result.productName,
      price: result.price?.sales?.formatted || result.priceValue ? `$${result.priceValue}` : null,
      imageUrl: result.imageUrls?.[0] || result.images?.[0]?.url || null,
      availableSizes,
    });
  },

  parseHtml(html, size) {
    // SFCC embeds the full product model as JSON in the page
    const modelMatch = html.match(/productModel\s*=\s*({.{50,}}?});?\s*[\n\r]/);
    if (modelMatch) {
      const model = safeJson(modelMatch[1]);
      if (model) return footsitesCheck.parseStock(model, size);
    }

    // Pattern-based fallback
    if (/"orderable"\s*:\s*true/i.test(html)) return normalize({ inStock: true });
    const atsMatch = html.match(/"ATS"\s*:\s*(\d+)/i);
    if (atsMatch) return normalize({ inStock: parseInt(atsMatch[1]) > 0 });
    if (/"orderable"\s*:\s*false/i.test(html)) return normalize({ inStock: false });
    return null;
  },
};

// ─── Demandware (generic SFCC) ────────────────────────────────────────────────
// Same SFCC JSON structure as Footsites, slightly different URL patterns
export const demandwareCheck = {
  extractApiUrl(pdpUrl) {
    try {
      const u = new URL(pdpUrl);
      // Common SFCC patterns: /p/Product-Name/123456789, /product/123456789
      const m = u.pathname.match(/\/(?:p|product)\/(?:[^/]+\/)?([A-Za-z0-9_-]{4,30})\/?$/);
      const pid = m ? m[1] : null;
      if (!pid) return null;
      // Try the SFCC Product-Show API
      return `${u.origin}/on/demandware.store/Sites-Site/default/Product-Variation?pid=${pid}&format=json`;
    } catch (_) { return null; }
  },
  parseStock: footsitesCheck.parseStock,
  parseHtml: footsitesCheck.parseHtml,
};

// ─── Nike ─────────────────────────────────────────────────────────────────────
// Nike uses Next.js; __NEXT_DATA__ has complete product/SKU availability.
// The public Nike API is fragile with auth; __NEXT_DATA__ is more stable.
export const nikeCheck = {
  extractApiUrl(pdpUrl) {
    try {
      const u = new URL(pdpUrl);
      // /t/product-name/DR9868-100 or /ca/t/product-name/DR9868-100
      const parts = u.pathname.split('/').filter(Boolean);
      const styleCode = parts[parts.length - 1]; // last segment = style-color
      if (!styleCode || styleCode.length < 4) return null;
      const market = u.hostname.includes('.ca') || u.pathname.startsWith('/ca') ? 'CA' : 'US';
      const channelId = market === 'CA'
        ? 'a7c6f91b-0c12-40d0-9b38-7e8f4e14f92b'
        : 'd9a5bc42-4b9c-4976-858a-f159cf99c647';
      return `https://api.nike.com/product_feed/rollup_threads/v2?filter=id(${styleCode})&filter=language(en)&filter=marketplace(${market})&filter=channelId(${channelId})&select=threads.products.merch.availability,threads.products.price,threads.products.skus`;
    } catch (_) { return null; }
  },

  parseStock(data, size) {
    const objects = data?.objects || [];
    if (!objects.length) return normalize({ inStock: false });

    const products = objects.flatMap(o =>
      o?.publishedContent?.properties?.products || []
    );

    if (!products.length) return normalize({ inStock: false });

    // Availability strings: 'AVAILABLE', 'SCARCE', 'LAST_SIZES', 'SOLD_OUT', 'UNAVAILABLE'
    let inStock;
    const skus = products.flatMap(p => p.skus || []);
    const availableSizes = skus
      .filter(s => !['SOLD_OUT', 'UNAVAILABLE'].includes(s.availability?.toUpperCase?.()))
      .map(s => s.countSize || s.localizedSize);

    if (size) {
      const match = skus.find(s => sizeMatches(s.localizedSize || s.countSize, size));
      inStock = match ? !['SOLD_OUT', 'UNAVAILABLE'].includes(match.availability?.toUpperCase?.()) : false;
    } else {
      inStock = products.some(p =>
        !['SOLD_OUT', 'UNAVAILABLE'].includes(p?.merch?.availability?.toUpperCase?.())
      ) || availableSizes.length > 0;
    }

    const price = products[0]?.price?.currentPrice;
    return normalize({
      inStock,
      productName: objects[0]?.publishedContent?.properties?.title || null,
      price: price ? `$${price}` : null,
      availableSizes,
    });
  },

  parseHtml(html, size) {
    const nextData = extractNextData(html);
    if (nextData) {
      // Navigate several possible paths in Next.js page props
      const props = nextData?.props?.pageProps;
      const product =
        props?.initialState?.PdpInitialState?.product ||
        props?.product ||
        props?.initialState?.Threads?.products?.[0];

      if (product) {
        const skus = product.skus || product.productSkus || [];
        const available = skus.filter(s =>
          s.available !== false &&
          s.localizedAvailability !== 'Sold Out' &&
          !['SOLD_OUT','UNAVAILABLE'].includes(s.availability?.toUpperCase?.())
        );
        const availableSizes = available.map(s => s.localizedSize || s.countSize || s.nikeSize);

        let inStock;
        if (size) {
          const match = available.find(s => sizeMatches(s.localizedSize || s.nikeSize, size));
          inStock = !!match;
        } else {
          inStock = available.length > 0;
        }

        return normalize({
          inStock,
          productName: product.fullTitle || product.displayName || product.title,
          price: product.currentPrice ? `$${product.currentPrice}` : null,
          availableSizes,
        });
      }
    }

    // Pattern fallback
    return normalize({
      inStock: /"available"\s*:\s*true/i.test(html) && !/"available"\s*:\s*false/i.test(html),
    });
  },
};

// ─── Supreme NY ───────────────────────────────────────────────────────────────
export const supremeCheck = {
  extractApiUrl(pdpUrl) {
    try {
      const u = new URL(pdpUrl);
      // /shop/{category}/{itemId} or /shop/{itemId}
      const m = u.pathname.match(/\/shop\/(?:[^/]+\/)?([a-z0-9]+)(?:\/[a-z0-9]+)?$/i);
      const itemId = m ? m[1] : null;
      if (!itemId) return null;
      return `https://www.supremenewyork.com/shop/${itemId}.json`;
    } catch (_) { return null; }
  },

  parseStock(data, size) {
    const styles = data?.styles || [];
    const sizes = styles.flatMap(s => s.sizes || []);
    const available = sizes.filter(s => s.stock_level > 0);
    const availableSizes = available.map(s => s.name);

    let inStock;
    if (size) {
      const match = sizes.find(s => sizeMatches(s.name, size));
      inStock = match ? match.stock_level > 0 : false;
    } else {
      inStock = available.length > 0;
    }

    return normalize({
      inStock,
      productName: data?.name,
      price: data?.price ? `$${(data.price / 100).toFixed(2)} USD` : null,
      imageUrl: styles[0]?.image_url || null,
      availableSizes,
    });
  },

  parseHtml(html, size) {
    const m = html.match(/"sizes"\s*:\s*(\[[^\]]+\])/);
    if (m) {
      const sizes = safeJson(m[1]) || [];
      const available = sizes.filter(s => s.stock_level > 0);
      const target = size ? available.find(s => sizeMatches(s.name, size)) : available[0];
      return normalize({ inStock: size ? !!target : available.length > 0, availableSizes: available.map(s => s.name) });
    }
    return normalize({ inStock: /"stock_level"\s*:\s*[1-9]/i.test(html) });
  },
};

// ─── Pokemon Center Canada (SFCC) ─────────────────────────────────────────────
export const pokemonCenterCheck = {
  extractApiUrl(pdpUrl) {
    try {
      const u = new URL(pdpUrl);
      // /en-ca/product/{product-name}/{sku}
      const m = u.pathname.match(/\/product\/[^/]+\/([^/?#]+)/);
      const sku = m ? m[1] : null;
      if (!sku) return null;
      return `${u.origin}/api/2.0/json/products/pdp/${sku}?locale=en_CA&includeAvailability=true`;
    } catch (_) { return null; }
  },

  // Fallback to the native SFCC Product-Variation controller when the JSON API
  // shim is unavailable/challenged. Same availability semantics, and the parse
  // path below understands the `product.availability` shape it returns.
  extractApiUrls(pdpUrl) {
    const first = pokemonCenterCheck.extractApiUrl(pdpUrl);
    if (!first) return [];
    const sku = first.match(/\/pdp\/([^?]+)\?/)?.[1];
    if (!sku) return [first];
    let origin = 'https://www.pokemoncenter.com';
    try { origin = new URL(pdpUrl).origin; } catch (_) {}
    return [
      first,
      `${origin}/on/demandware.store/Sites-PokemonCenter-Site/en_CA/Product-Variation?pid=${sku}&quantity=1`
    ];
  },

  parseStock: footsitesCheck.parseStock,
  parseHtml: footsitesCheck.parseHtml,
};

// ─── Topps (Shopify) ──────────────────────────────────────────────────────────
export const toppsCheck = {
  extractApiUrl: shopifyCheck.extractApiUrl,
  parseStock: shopifyCheck.parseStock,
  parseHtml: shopifyCheck.parseHtml,
};

// ─── Walmart Canada ───────────────────────────────────────────────────────────
export const walmartCheck = {
  extractApiUrl(pdpUrl) {
    try {
      const u = new URL(pdpUrl);
      // /en/ip/{product-name}/{itemId}
      const m = u.pathname.match(/\/ip\/[^/]+\/(\d{10,16})/) ||
                u.pathname.match(/\/(\d{10,16})(?:\/|$)/);
      const itemId = m ? m[1] : null;
      if (!itemId) return null;
      return `https://www.walmart.ca/api/product-page/v2?item=${itemId}&lang=en`;
    } catch (_) { return null; }
  },

  parseStock(data, size) {
    // Walmart API returns either data.item or data directly
    const item = data?.item || data;
    const offers = item?.offerInfo || item?.offers?.[0] || item;
    const status = offers?.availabilityStatus || item?.availabilityStatus;
    const inStock = status === 'IN_STOCK' || offers?.available === true;

    return normalize({
      inStock,
      productName: item?.name || item?.productName,
      price: offers?.currentPrice ? `$${offers.currentPrice} CAD` : null,
      imageUrl: item?.images?.[0]?.url || item?.imageUrl || null,
    });
  },

  parseHtml(html, size) {
    // Walmart Canada uses Next.js
    const nextData = extractNextData(html);
    if (nextData) {
      const item =
        nextData?.props?.pageProps?.initialData?.data?.product ||
        nextData?.props?.pageProps?.product;
      if (item) {
        const inStock = item.availabilityStatus === 'IN_STOCK' ||
                        item.sellableOnline === true;
        return normalize({ inStock, productName: item.name });
      }
    }
    // Pattern-based fallback
    if (/"availabilityStatus"\s*:\s*"IN_STOCK"/i.test(html)) return normalize({ inStock: true });
    if (/"availabilityStatus"\s*:\s*"OUT_OF_STOCK"/i.test(html)) return normalize({ inStock: false });
    return normalize({ inStock: /add to cart/i.test(html) && !/out of stock/i.test(html) });
  },
};

// ─── Best Buy Canada ──────────────────────────────────────────────────────────
export const bestbuyCheck = {
  extractApiUrl(pdpUrl) {
    try {
      const u = new URL(pdpUrl);
      // /en-ca/product/{name}/{sku}.aspx or /{sku}
      const m = u.pathname.match(/\/(\d{7,10})(?:\.aspx)?(?:\/|$)/);
      const sku = m ? m[1] : null;
      if (!sku) return null;
      return `https://www.bestbuy.ca/api/2.0/json/product/${sku}?lang=en-CA`;
    } catch (_) { return null; }
  },

  // Best Buy has shipped both the /api/2.0/json and the legacy /api/v2/json
  // product endpoints. Keeping both means a rename cannot silently drop
  // monitoring onto full HTML page fetches.
  extractApiUrls(pdpUrl) {
    const first = bestbuyCheck.extractApiUrl(pdpUrl);
    if (!first) return [];
    const sku = first.match(/\/(\d{7,10})\?/)?.[1];
    if (!sku) return [first];
    return [first, `https://www.bestbuy.ca/api/v2/json/product/${sku}?lang=en-CA`];
  },

  parseStock(data, size) {
    const product = data?.product || data;
    const online = product?.availability?.isAvailableOnline === true;
    // Best Buy's in-store availability must NOT trigger an online checkout.
    // The browser flow below purchases for delivery/pickup through the online
    // cart, so only the explicit online flag is a valid hot-poll signal.

    // Size-level gating. A PDP can be "available online" while the one size the
    // task wants is gone; firing checkout on the product-level flag then burns a
    // session on a size that cannot be added. When the payload exposes per-variant
    // availability, the requested size must itself be orderable.
    const variants = product?.variants || product?.options || product?.skus || [];
    const variantList = Array.isArray(variants) ? variants : [];
    const availableSizes = variantList
      .filter((v) => v && (v.isAvailableOnline === true || v.available === true || v.availability?.isAvailableOnline === true))
      .map((v) => v.name || v.label || v.value || v.size)
      .filter(Boolean);

    let inStock = online;
    if (size && variantList.length) {
      const match = variantList.find((v) =>
        sizeMatches(v?.name || v?.label || v?.value || v?.size, size)
      );
      if (match) {
        inStock = match.isAvailableOnline === true
          || match.available === true
          || match.availability?.isAvailableOnline === true;
      }
    }

    return normalize({
      inStock,
      productName: product?.name,
      price: product?.salePrice
        ? `$${product.salePrice} CAD`
        : product?.regularPrice ? `$${product.regularPrice} CAD` : null,
      imageUrl: product?.image?.main || null,
      availableSizes,
    });
  },

  parseHtml(html, size) {
    const nextData = extractNextData(html);
    if (nextData) {
      const product = nextData?.props?.pageProps?.product;
      if (product) return bestbuyCheck.parseStock(product, size);
    }
    if (/"isAvailableOnline"\s*:\s*true/i.test(html)) return normalize({ inStock: true });
    if (/"isAvailableOnline"\s*:\s*false/i.test(html)) return normalize({ inStock: false });
    // "Coming soon"/"notify me" pages still render an Add to Cart string in some
    // layouts, so they must be excluded before the loose ATC fallback.
    if (/coming soon|notify me when available/i.test(html)) return normalize({ inStock: false });
    return normalize({ inStock: /add to cart/i.test(html) && !/sold out/i.test(html) });
  },
};

// ─── Target ───────────────────────────────────────────────────────────────────
export const targetCheck = {
  extractApiUrl(pdpUrl) {
    try {
      const u = new URL(pdpUrl);
      // /p/{name}/-/A-{tcin}
      const m = u.pathname.match(/A-(\d{8,9})/);
      const tcin = m ? m[1] : null;
      if (!tcin) return null;
      return `https://redsky.target.com/redsky_aggregations/v1/web/pdp_client_v1?tcin=${tcin}&pricing_store_id=&key=9f36ced7e0891f7c3b3b59e0b7f1b4de`;
    } catch (_) { return null; }
  },

  parseStock(data, size) {
    const product = data?.data?.product;
    if (!product) return null;
    const shipping = product?.fulfillment?.shipping_options?.availability_status;
    const storeStatus = product?.fulfillment?.store_options?.[0]?.availability_status;
    const inStock = shipping === 'IN_STOCK' || storeStatus === 'IN_STOCK';

    return normalize({
      inStock,
      productName: product?.item?.product_description?.title,
      price: product?.price?.current_retail ? `$${product.price.current_retail} USD` : null,
      imageUrl: product?.item?.enrichment?.images?.primary_image_url || null,
    });
  },

  parseHtml(html, size) {
    if (/"availability_status"\s*:\s*"IN_STOCK"/i.test(html)) return normalize({ inStock: true });
    if (/"availability_status"\s*:\s*"OUT_OF_STOCK"/i.test(html)) return normalize({ inStock: false });
    const nextData = extractNextData(html);
    if (nextData) {
      const product = nextData?.props?.pageProps?.['__REDUX_STATE__']?.pdp?.buyingOptions;
      if (product) return normalize({ inStock: !!product.isDeliveryAvailable });
    }
    return normalize({ inStock: /add to cart/i.test(html) && !/out of stock/i.test(html) });
  },
};

// ─── GameStop Canada (SFCC) ───────────────────────────────────────────────────
export const gamestopCheck = {
  extractApiUrl(pdpUrl) {
    try {
      const u = new URL(pdpUrl);
      // /en-ca/games/{pid} or ?Product_ID={pid}
      const qParam = new URL(pdpUrl).searchParams.get('Product_ID');
      if (qParam) return `${u.origin}/on/demandware.store/Sites-GameStopCA-Site/en_CA/Product-Variation?pid=${qParam}&format=json`;
      const m = u.pathname.match(/\/([A-Z0-9_-]{4,20})(?:\/|$)/);
      const pid = m ? m[1] : null;
      if (!pid) return null;
      return `${u.origin}/on/demandware.store/Sites-GameStopCA-Site/en_CA/Product-Variation?pid=${pid}&format=json`;
    } catch (_) { return null; }
  },

  parseStock(data, size) {
    const product = data?.product || data;
    const orderable = product?.orderable || product?.availability?.orderable;
    const available = product?.availability?.isAvailable;
    return normalize({
      inStock: orderable === true || available === true,
      productName: product?.productName || product?.name,
      price: product?.price?.sales?.formatted || null,
    });
  },

  parseHtml: footsitesCheck.parseHtml,
};

// ─── Amazon Canada ────────────────────────────────────────────────────────────
// Amazon has no public product API — HTML-only detection.
export const amazonCheck = {
  extractApiUrl() { return null; },
  parseStock() { return null; },

  parseHtml(html, size) {
    // Definitive in-stock signals
    if (/id=["']add-to-cart-button["']/i.test(html)) {
      const disabled = /id=["']add-to-cart-button["'][^>]*disabled/i.test(html);
      return normalize({ inStock: !disabled });
    }
    if (/id=["']buy-now-button["']/i.test(html)) return normalize({ inStock: true });
    // Availability text
    if (/<span[^>]*id=["']?availability["']?[^>]*>[^<]*In Stock/i.test(html)) return normalize({ inStock: true });
    if (/<span[^>]*id=["']?availability["']?[^>]*>[^<]*Currently unavailable/i.test(html)) return normalize({ inStock: false });
    if (/<span[^>]*id=["']?availability["']?[^>]*>[^<]*Out of Stock/i.test(html)) return normalize({ inStock: false });
    // JSON in page
    if (/"isAvailable"\s*:\s*true/i.test(html)) return normalize({ inStock: true });
    return normalize({ inStock: false });
  },
};

// ─── Site routing ──────────────────────────────────────────────────────────────

const autoCheckerCache = new Map();
const AUTO_CHECKER_CACHE_MAX = 256;

export const SITE_CHECKERS = {
  1: footsitesCheck,
  2: shopifyCheck,
  3: demandwareCheck,
  4: nikeCheck,
  5: supremeCheck,
  6: pokemonCenterCheck,
  7: toppsCheck,
  8: walmartCheck,
  9: bestbuyCheck,
  10: targetCheck,
  11: gamestopCheck,
  12: amazonCheck,
};

/**
 * Auto-detect checker from URL hostname when siteId is not known.
 */
export const autoDetectChecker = (url) => {
  try {
    const host = new URL(url).hostname.toLowerCase();
    const cached = autoCheckerCache.get(host);
    if (cached) return cached;

    let checker = shopifyCheck;
    if (/footlocker|champssports|kidsfootlocker|eastbay|finishline/.test(host)) checker = footsitesCheck;
    else if (/nike\.com/.test(host)) checker = nikeCheck;
    else if (/supreme/.test(host)) checker = supremeCheck;
    else if (/pokemoncenter/.test(host)) checker = pokemonCenterCheck;
    else if (/topps\.com/.test(host)) checker = toppsCheck;
    else if (/walmart\.ca/.test(host)) checker = walmartCheck;
    else if (/bestbuy\.ca/.test(host)) checker = bestbuyCheck;
    else if (/target\.com/.test(host)) checker = targetCheck;
    else if (/gamestop\.ca/.test(host)) checker = gamestopCheck;
    else if (/amazon\.ca/.test(host)) checker = amazonCheck;

    if (autoCheckerCache.size >= AUTO_CHECKER_CACHE_MAX) {
      autoCheckerCache.delete(autoCheckerCache.keys().next().value);
    }
    autoCheckerCache.set(host, checker);
    return checker;
  } catch (_) {
    return shopifyCheck;
  }
};
