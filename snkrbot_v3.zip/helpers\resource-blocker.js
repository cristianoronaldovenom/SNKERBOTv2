import logger from './logger.js';

const BLOCKED_RESOURCE_TYPES = new Set([
  'image', 'media', 'font', 'texttrack', 'eventsource',
  'websocket', 'manifest', 'other'
]);

const BLOCKED_DOMAINS = [
  'google-analytics.com', 'googletagmanager.com', 'facebook.net',
  'facebook.com', 'doubleclick.net', 'hotjar.com', 'fullstory.com',
  'segment.io', 'segment.com', 'mixpanel.com', 'amplitude.com',
  'optimizely.com', 'crazyegg.com', 'newrelic.com', 'nr-data.net',
  'sentry.io', 'bugsnag.com', 'clarity.ms', 'bing.com/bat',
  'snap.licdn.com', 'ads-twitter.com', 'tiktok.com/i18n',
  'pinterest.com/ct', 'criteo.com', 'taboola.com', 'outbrain.com',
  'bazaarvoice.com', 'trustpilot.com/tp', 'yotpo.com',
  'cdn.shopify.com/s/trekkie', 'cdn.shopify.com/s/javascripts/tricorder',
  'monorail-edge.shopifysvc.com', 'bat.bing.com'
];

const BLOCKED_EXTENSIONS = [
  '.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg', '.ico', '.bmp',
  '.woff', '.woff2', '.ttf', '.eot', '.otf',
  '.mp4', '.webm', '.ogg', '.mp3', '.wav', '.flac',
  '.avif', '.tiff'
];

const isBlockedDomain = (url) => {
  try {
    const hostname = new URL(url).hostname;
    return BLOCKED_DOMAINS.some((d) => hostname.includes(d));
  } catch (_) {
    return false;
  }
};

const isBlockedExtension = (url) => {
  try {
    const pathname = new URL(url).pathname.toLowerCase();
    return BLOCKED_EXTENSIONS.some((ext) => pathname.endsWith(ext));
  } catch (_) {
    return false;
  }
};

const SITE_RESOURCE_OVERRIDES = Object.freeze({
  2: { // Shopify: dynamic checkout surfaces can use long-lived event channels.
    allowResourceTypes: new Set(['websocket', 'eventsource'])
  },
  6: { // Pokémon Center: keep document/script/xhr/fetch focus to minimize PDP noise.
    allowResourceTypes: new Set()
  },
  12: { // Amazon: preserve script/xhr/fetch; do not broaden asset loading.
    allowResourceTypes: new Set()
  },
});

const toCdpPatterns = () => {
  const patterns = [];
  for (const domain of BLOCKED_DOMAINS) {
    if (domain.includes('/')) patterns.push(`*://*.${domain}*`);
    else patterns.push(`*://*.${domain}/*`, `*://${domain}/*`);
  }
  for (const ext of BLOCKED_EXTENSIONS) patterns.push(`*${ext}*`);
  return patterns;
};

const CDP_BLOCK_PATTERNS = Object.freeze(toCdpPatterns());

export const enableResourceBlocker = async (page, { mode = 'checkout', siteId = null } = {}) => {
  try {
    // CDP-level URL blocking removes a Node request event + promise hop for each
    // asset. That is materially cheaper when many checkout pages are active.
    // We intentionally block only URLs whose role is unambiguously non-critical
    // (trackers, media, images, fonts) so checkout logic remains unchanged.
    const cdp = await page.target().createCDPSession();
    const patterns = [...CDP_BLOCK_PATTERNS];
    if (mode === 'monitor') {
      // The browser path is used only as a fallback/session warm, so keep the
      // same conservative URL list without blocking generic scripts/XHR.
    }
    await cdp.send('Network.setBlockedURLs', { urls: patterns });
    page.__resourceBlockerCdp = cdp;
    page.__resourceBlockerPatterns = patterns;
    logger.info(`[ResourceBlocker] CDP URL blocking enabled in "${mode}" mode for site ${siteId ?? 'generic'} (${patterns.length} patterns)`);
    return;
  } catch (err) {
    // Older Chromium/CDP builds may not expose Network.setBlockedURLs. Fall back
    // to the original request interception path rather than changing behavior.
    logger.warn(`[ResourceBlocker] CDP blocker unavailable: ${err.message}; using request interception fallback`);
  }

  try {
    await page.setRequestInterception(true);

    page.on('request', (req) => {
      const resourceType = req.resourceType();
      const url = req.url();

      if (isBlockedDomain(url)) {
        req.abort('blockedbyclient').catch(() => {});
        return;
      }

      const override = SITE_RESOURCE_OVERRIDES[Number(siteId)] || null;

      if (mode === 'checkout') {
        if (BLOCKED_RESOURCE_TYPES.has(resourceType) && !override?.allowResourceTypes?.has(resourceType)) {
          req.abort('blockedbyclient').catch(() => {});
          return;
        }
        if (isBlockedExtension(url)) {
          req.abort('blockedbyclient').catch(() => {});
          return;
        }
      }

      if (mode === 'monitor') {
        if (resourceType !== 'document' && resourceType !== 'xhr' && resourceType !== 'fetch' && resourceType !== 'script') {
          req.abort('blockedbyclient').catch(() => {});
          return;
        }
      }

      req.continue().catch(() => {});
    });
  } catch (err) {
    logger.warn(`[ResourceBlocker] Failed to enable: ${err.message}`);
  }
};

export const disableResourceBlocker = async (page) => {
  try { await page.setRequestInterception(false); } catch (_) {}
  try { await page.__resourceBlockerCdp?.send('Network.setBlockedURLs', { urls: [] }); } catch (_) {}
  try { await page.__resourceBlockerCdp?.detach(); } catch (_) {}
  page.__resourceBlockerCdp = null;
  page.__resourceBlockerPatterns = null;
};
