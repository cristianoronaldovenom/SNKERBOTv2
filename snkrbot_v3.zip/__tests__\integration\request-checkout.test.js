import { jest } from '@jest/globals';

jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));

const tlsRequest = jest.fn();
jest.unstable_mockModule('../../helpers/tls-client.js', () => ({ tlsRequest }));

const getSessionCookies = jest.fn(() => '');
jest.unstable_mockModule('../../helpers/stock-monitor.js', () => ({ getSessionCookies }));

const extractApiUrl = jest.fn();
jest.unstable_mockModule('../../helpers/site-stock-apis.js', () => ({
  shopifyCheck: { extractApiUrl }
}));

// requestModeEnabled() reads db('settings'); mock a chainable that returns null
// (→ feature defaults OFF) so importing the engine never opens a real connection.
jest.unstable_mockModule('../../db/index.js', () => ({
  default: () => ({ where: () => ({ first: async () => null }) })
}));

const { classifyShopifyResponse, tokenizeCard } = await import('../../helpers/request-checkout/shopify.js');
const { prefillShopifyCheckout } = await import('../../helpers/request-checkout/shopify.js');
const { HttpSession } = await import('../../helpers/request-checkout/http-session.js');
const { tryRequestCheckout, prepareRequestCheckout, requestModeEnabled, isRequestModeSupported } = await import('../../helpers/request-checkout/index.js');

beforeEach(() => {
  tlsRequest.mockReset();
  getSessionCookies.mockReset();
  getSessionCookies.mockReturnValue('');
  extractApiUrl.mockReset();
});

describe('classifyShopifyResponse', () => {
  test('detects anti-bot challenge', () => {
    expect(classifyShopifyResponse('<title>Just a moment...</title>')).toBe('challenge');
    expect(classifyShopifyResponse('Please verify you are a human')).toBe('challenge');
  });
  test('detects queue/waiting room', () => {
    expect(classifyShopifyResponse('You are in line. Estimated wait 5 min')).toBe('queue');
  });
  test('detects out of stock', () => {
    expect(classifyShopifyResponse('This product is sold out')).toBe('oos');
    expect(classifyShopifyResponse('Cannot find variant')).toBe('oos');
  });
  test('detects decline', () => {
    expect(classifyShopifyResponse('Your card was declined')).toBe('decline');
    expect(classifyShopifyResponse('Insufficient funds')).toBe('decline');
  });
  test('detects expired session', () => {
    expect(classifyShopifyResponse('Your cart is empty')).toBe('session');
    expect(classifyShopifyResponse('your session has expired')).toBe('session');
  });
  test('returns null for an ordinary page', () => {
    expect(classifyShopifyResponse('<html><body>Nike Dunk Low</body></html>')).toBeNull();
    expect(classifyShopifyResponse('')).toBeNull();
  });
});

describe('HttpSession cookie jar', () => {
  test('accumulates Set-Cookie across requests and sends merged Cookie header', async () => {
    tlsRequest
      .mockResolvedValueOnce({ ok: true, status: 200, headers: { 'set-cookie': 'a=1; path=/' }, body: '' })
      .mockResolvedValueOnce({ ok: true, status: 200, headers: { 'set-cookie': ['b=2; path=/'] }, body: '' });

    const s = new HttpSession({ cookieHeader: 'warm=0' });
    await s.get('https://shop.com/one');
    await s.get('https://shop.com/two');

    expect(s.cookieHeader).toBe('warm=0; a=1; b=2');
    // First call carried only the warm cookie...
    expect(tlsRequest.mock.calls[0][0].headers.Cookie).toBe('warm=0');
    // ...second call carried the warm cookie + the one absorbed from call #1.
    expect(tlsRequest.mock.calls[1][0].headers.Cookie).toBe('warm=0; a=1');
    expect(tlsRequest.mock.calls[0][0].headers['User-Agent']).toMatch(/Chrome\/131/);
  });
});

describe('tokenizeCard (Shopify card vault — no charge)', () => {
  test('POSTs a correctly shaped card payload and returns the session id', async () => {
    tlsRequest.mockResolvedValueOnce({ ok: true, status: 200, body: JSON.stringify({ id: 'sess_abc123' }) });

    const res = await tokenizeCard({
      pay: {
        card_number: '4242 4242 4242 4242',
        card_holder_name: 'Jane Doe',
        expiration_month: 9,
        expiration_year: '27',
        cvv: '123',
      },
    });

    expect(res).toEqual({ ok: true, sessionId: 'sess_abc123' });
    const call = tlsRequest.mock.calls[0][0];
    expect(call.method).toBe('POST');
    expect(call.url).toBe('https://deposit.shopifycs.com/sessions');
    const sent = JSON.parse(call.body).credit_card;
    expect(sent.number).toBe('4242424242424242'); // spaces stripped
    expect(sent.month).toBe(9);
    expect(sent.year).toBe(2027); // 2-digit year expanded
    expect(sent.verification_value).toBe('123');
  });

  test('keeps 4-digit years intact', async () => {
    tlsRequest.mockResolvedValueOnce({ ok: true, status: 200, body: JSON.stringify({ id: 'x' }) });
    await tokenizeCard({ pay: { card_number: '1', expiration_month: 1, expiration_year: 2030, cvv: '9' } });
    expect(JSON.parse(tlsRequest.mock.calls[0][0].body).credit_card.year).toBe(2030);
  });

  test('non-200 from the vault returns ok:false without throwing', async () => {
    tlsRequest.mockResolvedValueOnce({ ok: true, status: 422, body: '{}' });
    const res = await tokenizeCard({ pay: { card_number: '1', expiration_month: 1, expiration_year: 30, cvv: '9' } });
    expect(res.ok).toBe(false);
    expect(res.error).toMatch(/422/);
  });

  test('missing card never throws', async () => {
    const res = await tokenizeCard({ pay: {} });
    expect(res.ok).toBe(false);
    expect(tlsRequest).not.toHaveBeenCalled();
  });
});

describe('prefillShopifyCheckout dryRun (read-only, never mutates)', () => {
  test('resolves variant from URL and probes /cart.js with NO cart mutation', async () => {
    // Only the read-only /cart.js GET should fire (variant comes from the URL).
    tlsRequest.mockResolvedValueOnce({ ok: true, status: 200, headers: {}, body: '{"item_count":0}' });

    const res = await prefillShopifyCheckout({
      task: { id: 1, site_id: 2, url: 'https://shop.com/products/x?variant=999' },
      dryRun: true,
    });

    expect(res.ok).toBe(true);
    expect(res.dryRun).toBe(true);
    expect(res.variantId).toBe('999');
    expect(res.checkoutUrl).toBeNull();

    expect(tlsRequest).toHaveBeenCalledTimes(1);
    const call = tlsRequest.mock.calls[0][0];
    expect(call.method).toBe('GET');
    expect(call.url).toBe('https://shop.com/cart.js');
    // Safety: dry-run must NEVER hit a mutating endpoint.
    const urls = tlsRequest.mock.calls.map((c) => c[0].url);
    expect(urls.some((u) => u.includes('/cart/add.js'))).toBe(false);
  });

  test('a challenged probe returns ok:false (so caller falls back to browser)', async () => {
    tlsRequest.mockResolvedValueOnce({ ok: true, status: 200, headers: {}, body: 'Just a moment...' });
    const res = await prefillShopifyCheckout({
      task: { id: 2, site_id: 2, url: 'https://shop.com/products/x?variant=1' },
      dryRun: true,
    });
    expect(res.ok).toBe(false);
    expect(res.classified).toBe('challenge');
  });

  test('no resolvable variant → ok:false, no network probe', async () => {
    extractApiUrl.mockReturnValue('https://shop.com/products/x.json');
    tlsRequest.mockResolvedValueOnce({
      ok: true, status: 200,
      body: JSON.stringify({ product: { variants: [{ id: 1, title: 'US 9', available: false }] } }),
    });
    const res = await prefillShopifyCheckout({
      task: { id: 3, site_id: 2, url: 'https://shop.com/products/x', size: '12' },
      dryRun: true,
    });
    expect(res.ok).toBe(false);
    expect(res.stage).toBe('variant');
    // Only the variant JSON lookup fired — no /cart.js probe.
    expect(tlsRequest).toHaveBeenCalledTimes(1);
  });
});

describe('tryRequestCheckout router + gate', () => {
  test('unsupported site returns a reason without touching the network', async () => {
    const res = await tryRequestCheckout({ task: { id: 1, site_id: 4, url: 'https://nike.com/x' } });
    expect(res.ok).toBe(false);
    expect(res.reason).toMatch(/unsupported/);
    expect(tlsRequest).not.toHaveBeenCalled();
  });

  test('isRequestModeSupported only allows generic Shopify (2)', () => {
    expect(isRequestModeSupported(2)).toBe(true);
    expect(isRequestModeSupported(7)).toBe(false);
    expect(isRequestModeSupported(4)).toBe(false);
  });

  test('requestModeEnabled defaults to false when the setting is absent', async () => {
    await expect(requestModeEnabled()).resolves.toBe(false);
  });

  test('missing url never throws', async () => {
    const res = await tryRequestCheckout({ task: { id: 9, site_id: 2 } });
    expect(res.ok).toBe(false);
  });
});

describe('always resolves on network rejection (never throws into the checkout path)', () => {
  test('tokenizeCard resolves ok:false if the vault request rejects', async () => {
    tlsRequest.mockRejectedValueOnce(new Error('ECONNRESET'));
    const res = await tokenizeCard({ pay: { card_number: '1', expiration_month: 1, expiration_year: 30, cvv: '9' } });
    expect(res.ok).toBe(false);
    expect(res.error).toMatch(/ECONNRESET/);
  });

  test('prefillShopifyCheckout dryRun resolves ok:false if the probe rejects', async () => {
    tlsRequest.mockRejectedValueOnce(new Error('socket hang up'));
    const res = await prefillShopifyCheckout({
      task: { id: 4, site_id: 2, url: 'https://shop.com/products/x?variant=1' },
      dryRun: true,
    });
    expect(res.ok).toBe(false);
    // variant came from the URL, so the rejection happens on the /cart.js probe.
    expect(res.stage === 'dry_run' || res.stage === 'error').toBe(true);
  });

  test('tryRequestCheckout swallows a rejecting probe', async () => {
    tlsRequest.mockRejectedValueOnce(new Error('boom'));
    const res = await tryRequestCheckout({
      task: { id: 5, site_id: 2, url: 'https://shop.com/products/x?variant=1' },
      dryRun: true,
    });
    expect(res.ok).toBe(false);
  });
});


describe('live request-first Shopify hot path wiring', () => {
  test('prepareRequestCheckout is wired into monitor hot path', async () => {
    expect(typeof prepareRequestCheckout).toBe('function');
    const fs = await import('node:fs/promises');
    const src = await fs.readFile(new URL('../../api/Tasks/monitor.js', import.meta.url), 'utf8');
    // Accept the dedicated checkout-proxy form as well as the plain activeProxy.
    expect(src).toMatch(/prepareRequestCheckout\(\{ task: freshTask, proxy: (?:checkoutProxy \|\| )?activeProxy \}/);
    expect(src).toMatch(/checkout_preopened/);
  });
});
