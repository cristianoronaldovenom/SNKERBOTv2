import logger from './logger.js';
import { saveCookieJar } from './cookie-store.js';
import { moveMouse, humanScroll, idleMouseEntropy } from './human-mouse.js';

const warmingInProgress = new Set();
const refreshTimers = new Map();
const lastWarmedAt = new Map();       // host → timestamp of most recent successful warm (any path)
const WARM_TIMEOUT = 25000;
const REFRESH_INTERVAL_MS = 7 * 60 * 1000;  // 7 min — cookie TTL is 9 min; warmInPlace at checkout is the safety net
const MIN_REWARM_GAP_MS = 5 * 60 * 1000;   // skip browser launch if any warm happened within 5 min

// Resource types and tracker domains to block during warm browser sessions.
// The warm only needs document + script + XHR to solve the Imperva challenge;
// blocking everything else cuts per-warm proxy bandwidth by ~60-70%.
const WARM_BLOCK_TYPES = new Set(['image', 'media', 'font', 'texttrack', 'eventsource', 'websocket', 'manifest', 'other', 'stylesheet']);
const WARM_BLOCK_DOMAINS = [
  'google-analytics.com', 'googletagmanager.com', 'facebook.net', 'doubleclick.net',
  'hotjar.com', 'fullstory.com', 'segment.io', 'segment.com', 'mixpanel.com',
  'newrelic.com', 'nr-data.net', 'sentry.io', 'bugsnag.com', 'clarity.ms',
  'snap.licdn.com', 'taboola.com', 'outbrain.com', 'criteo.com', 'bat.bing.com'
];
const WARM_BLOCK_EXTS = new Set(['.png','.jpg','.jpeg','.gif','.webp','.svg','.ico','.bmp','.avif','.tiff','.woff','.woff2','.ttf','.eot','.otf','.mp4','.webm','.ogg','.mp3','.wav']);

const enableWarmResourceBlocking = async (page) => {
  const patterns = [
    ...Array.from(WARM_BLOCK_EXTS).map((ext) => `*${ext}*`),
    ...Array.from(WARM_BLOCK_DOMAINS).map((domain) => `*://${domain}/*`),
    '*://*.google-analytics.com/*', '*://*.googletagmanager.com/*', '*://*.facebook.net/*',
    '*://*.doubleclick.net/*', '*://*.hotjar.com/*', '*://*.fullstory.com/*', '*://*.segment.io/*',
    '*://*.segment.com/*', '*://*.mixpanel.com/*', '*://*.newrelic.com/*', '*://*.nr-data.net/*',
    '*://*.sentry.io/*', '*://*.bugsnag.com/*', '*://*.clarity.ms/*', '*://*.snap.licdn.com/*',
    '*://*.taboola.com/*', '*://*.outbrain.com/*', '*://*.criteo.com/*', '*://*.bat.bing.com/*',
  ];

  try {
    const cdp = await page.target().createCDPSession();
    await cdp.send('Network.enable');
    const resourcePatterns = Array.from(WARM_BLOCK_TYPES).flatMap((type) => {
      if (type === 'image') return []; // extension rules catch common images; keep document/script/xhr/fetch untouched
      return [];
    });
    await cdp.send('Network.setBlockedURLs', { urls: [...patterns, ...resourcePatterns] });
    page.__warmResourceBlockerCdp = cdp;
    return;
  } catch (_) {
    // Older Chromium builds: retain the proven interception fallback.
  }

  await page.setRequestInterception(true);
  page.on('request', (req) => {
    try {
      const url = req.url();
      const type = req.resourceType();
      if (WARM_BLOCK_TYPES.has(type)) { req.abort(); return; }
      const ext = url.split('?')[0].slice(url.lastIndexOf('.')).toLowerCase();
      if (WARM_BLOCK_EXTS.has(ext)) { req.abort(); return; }
      const hostname = new URL(url).hostname;
      if (WARM_BLOCK_DOMAINS.some(d => hostname.endsWith(d))) { req.abort(); return; }
      req.continue();
    } catch (_) { req.continue(); }
  });
};

const isImpervaChallenged = (html, setCookieHeader) => {
  if (!html) return false;
  const cookies = Array.isArray(setCookieHeader)
    ? setCookieHeader.join(' ')
    : (setCookieHeader || '');
  const hasIncapCookie = /visid_incap|incap_ses/i.test(cookies);
  const hasChallengePage = /onProtectionInitialized|Pardon Our Interruption|reeseSkipExpiration/i.test(html.slice(0, 3000));
  return hasIncapCookie && hasChallengePage;
};

const randInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

const simulateHumanBehavior = async (page) => {
  try {
    const vp = page.viewport() || { width: 1280, height: 800 };

    // Start with idle mouse entropy — real users move their mouse while the
    // challenge JS is measuring them, not only after it has fired.
    await idleMouseEntropy(page, { durationMs: randInt(1200, 2500) });

    // Scroll down as if reading content
    await humanScroll(page, { direction: 'down', totalPx: randInt(220, 550) });
    await new Promise(r => setTimeout(r, randInt(350, 900)));

    // More organic mouse movement mid-page
    const cur = {
      x: randInt(200, vp.width - 200),
      y: randInt(150, vp.height - 150)
    };
    const moves = randInt(2, 5);
    let pos = cur;
    for (let i = 0; i < moves; i++) {
      const next = {
        x: Math.max(30, Math.min(vp.width - 30, pos.x + randInt(-200, 200))),
        y: Math.max(30, Math.min(vp.height - 30, pos.y + randInt(-130, 130)))
      };
      await moveMouse(page, pos, next);
      pos = next;
      await new Promise(r => setTimeout(r, randInt(150, 450)));
    }

    // Scroll back up slightly (natural reading behavior)
    await new Promise(r => setTimeout(r, randInt(300, 700)));
    await humanScroll(page, { direction: 'up', totalPx: randInt(80, 200) });
  } catch (_) {}
};

export const warmSession = async (url, sessionCookies, onSuccess, proxy = null, siteId = null) => {
  const host = new URL(url).hostname;

  if (warmingInProgress.has(host)) {
    logger.info(`[SessionWarmer] Already warming ${host}, skipping duplicate`);
    return false;
  }

  warmingInProgress.add(host);
  logger.info(`[SessionWarmer] Launching stealth browser to solve Imperva challenge for ${host}`);

  let browser;
  try {
    const { launchBrowser, getNewPage } = await import('./cluster.js');
    // siteId lets the launch pin the exit to the retailer's country; without it a
    // US-only store gets warmed through whatever foreign exit the gateway returns.
    browser = await launchBrowser({ proxy, siteId: siteId ?? null });
    const page = await getNewPage({ browser, proxy, role: 'monitor', siteId });
    if (proxy) logger.info(`[SessionWarmer] Routing through proxy ${proxy.host}:${proxy.port}`);

    await enableWarmResourceBlocking(page);
    page.setDefaultNavigationTimeout(WARM_TIMEOUT);

    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: WARM_TIMEOUT });

    await page.waitForFunction(
      () => {
        const title = document.title || '';
        const h1 = document.querySelector('h1')?.textContent || '';
        return !title.includes('Pardon') && !h1.includes('Pardon') && !window.onProtectionInitialized;
      },
      { timeout: 15000, polling: 500 }
    ).catch(() => {
      logger.warn(`[SessionWarmer] Challenge may not have resolved for ${host}`);
    });

    await simulateHumanBehavior(page);

    await new Promise(r => setTimeout(r, randInt(1200, 2200)));

    const puppeteerCookies = await page.cookies();
    if (puppeteerCookies.length === 0) {
      logger.warn(`[SessionWarmer] No cookies obtained for ${host}`);
      return false;
    }

    const cookieStr = puppeteerCookies
      .map(c => `${c.name}=${c.value}`)
      .join('; ');

    sessionCookies.set(host, cookieStr);
    if (typeof onSuccess === 'function') onSuccess();

    const jarSnapshot = {};
    for (const [h, v] of sessionCookies.entries()) {
      jarSnapshot[h] = { cookies: v, warmedAt: Date.now() };
    }
    saveCookieJar(jarSnapshot);

    const incapCount = puppeteerCookies.filter(c =>
      c.name.startsWith('visid_incap') || c.name.startsWith('incap_ses') || c.name === 'reese84'
    ).length;

    lastWarmedAt.set(host, Date.now());
    logger.info(`[SessionWarmer] ✅ Session warmed for ${host} — ${puppeteerCookies.length} cookies (${incapCount} Imperva)`);
    return true;
  } catch (err) {
    logger.error(`[SessionWarmer] Failed for ${host}: ${err.message}`);
    return false;
  } finally {
    warmingInProgress.delete(host);
    if (browser) {
      try { await browser.close(); } catch (_) {}
    }
  }
};

export const waitForImpervaToResolve = async (page, { timeout = 25000 } = {}) => {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    const state = await page.evaluate(() => {
      const html = document.documentElement.outerHTML;
      const hasIncapIframe = !!document.querySelector('iframe#main-iframe[src*="_Incapsula"]') || html.includes('_Incapsula_Resource');
      const hasPardon = (document.title || '').includes('Pardon') || (document.body?.innerText || '').includes('Pardon Our Interruption');
      const bodyLen = document.body?.innerHTML?.length || 0;
      return { hasIncapIframe, hasPardon, bodyLen, title: document.title, url: location.href };
    }).catch(() => null);
    if (!state) { await new Promise(r => setTimeout(r, 500)); continue; }
    const challenged = state.hasIncapIframe || state.hasPardon;
    const tinyShell = state.bodyLen < 1500;
    if (!challenged && !tinyShell) return { resolved: true, ...state };
    await new Promise(r => setTimeout(r, 800));
  }
  const final = await page.evaluate(() => ({ bodyLen: document.body?.innerHTML?.length || 0, title: document.title })).catch(() => ({}));
  return { resolved: false, ...final };
};

export const warmInPlace = async (page, url) => {
  const host = new URL(url).hostname;
  logger.info(`[SessionWarmer] In-place warming on existing browser for ${host}`);
  try {
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: WARM_TIMEOUT });
    const result = await waitForImpervaToResolve(page, { timeout: 25000 });
    if (!result.resolved) {
      logger.warn(`[SessionWarmer] Imperva still challenging after 25s — bodyLen=${result.bodyLen}, title="${result.title}"`);
    } else {
      logger.info(`[SessionWarmer] Imperva resolved — page loaded (bodyLen=${result.bodyLen})`);
    }
    await simulateHumanBehavior(page);
    await new Promise(r => setTimeout(r, randInt(1200, 2200)));
    const cookies = await page.cookies();
    const incap = cookies.filter(c => c.name.startsWith('visid_incap') || c.name.startsWith('incap_ses') || c.name === 'reese84');
    if (incap.length > 0 && result.resolved) lastWarmedAt.set(host, Date.now());
    logger.info(`[SessionWarmer] ✅ In-place warmed ${cookies.length} cookies (${incap.length} Imperva) — bound to current browser fingerprint`);
    return incap.length > 0 && result.resolved;
  } catch (err) {
    logger.error(`[SessionWarmer] In-place warm failed: ${err.message}`);
    return false;
  }
};

export const startAutoRefresh = (url, sessionCookies, onSuccess, proxy = null, siteId = null) => {
  const host = new URL(url).hostname;
  if (refreshTimers.has(host)) return;

  // Self-rescheduling timer with ±20s jitter (a fixed interval is itself a
  // detectable signal) that re-warms through the SAME proxy used for checkout —
  // so refreshed cookies keep a consistent IP↔session identity instead of
  // silently re-warming from the datacenter IP (which makes the session look
  // like it teleported between networks).
  const schedule = () => {
    const jitter = randInt(-20_000, 20_000);
    const timer = setTimeout(async () => {
      if (!refreshTimers.has(host)) return; // stopped while waiting
      // Skip browser launch if a warm (auto or in-place) happened recently —
      // warmInPlace at checkout start may have just refreshed the session,
      // saving an entire proxy browser session worth of bandwidth.
      const last = lastWarmedAt.get(host) || 0;
      if (Date.now() - last < MIN_REWARM_GAP_MS) {
        logger.info(`[SessionWarmer] Session for ${host} warmed ${Math.round((Date.now() - last) / 1000)}s ago — skipping browser launch, rescheduling`);
        if (refreshTimers.has(host)) schedule();
        return;
      }
      logger.info(`[SessionWarmer] Auto-refreshing session for ${host} (proactive, before TTL${proxy ? ', via task proxy' : ''})`);
      try {
        await warmSession(url, sessionCookies, onSuccess, proxy, siteId);
      } catch (err) {
        logger.warn(`[SessionWarmer] Auto-refresh failed for ${host}: ${err.message}`);
      }
      if (refreshTimers.has(host)) schedule(); // re-arm only if still active
    }, REFRESH_INTERVAL_MS + jitter);
    refreshTimers.set(host, timer);
  };

  schedule();
  logger.info(`[SessionWarmer] Auto-refresh scheduled ~every ${REFRESH_INTERVAL_MS / 60000} min for ${host}${proxy ? ' (proxy-bound)' : ''}`);
};

export const stopAutoRefresh = (url) => {
  const host = new URL(url).hostname;
  const t = refreshTimers.get(host);
  if (t) {
    clearTimeout(t);
    refreshTimers.delete(host);
  }
};

export const hasAutoRefresh = (url) => refreshTimers.has(new URL(url).hostname);

export { isImpervaChallenged };
