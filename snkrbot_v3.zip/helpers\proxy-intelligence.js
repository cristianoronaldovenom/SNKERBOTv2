// Proxy intelligence — per-proxy, per-hostname scoring and blacklisting.
//
// Why this exists: not all residential proxies are equal for a given retailer.
// A proxy that works great for Pokemon Center may be flagged by Foot Locker
// (different ASN reputation databases per site). Without scoring, you'd burn
// a flagged proxy on every attempt until it gets permanently banned.
//
// This module tracks per-(proxyId, hostname) outcomes and:
//   1. Scores proxies by success rate + average latency
//   2. Blacklists proxies that hit consecutive failures (exponential backoff)
//   3. Recommends the best proxy from a candidate list for a given site
//
// All state is in-memory. Restart clears history (desired behavior — a proxy
// banned in a previous session might have rotated IPs by now).

import logger from './logger.js';

// score[proxyId][hostname] = { wins, losses, streak, totalLatencyMs, latencySamples, blacklistedUntil }
const scores = new Map();
const MAX_SCORE_ENTRIES = 5000;

const pruneScores = () => {
  if (scores.size <= MAX_SCORE_ENTRIES) return;
  const cutoff = scores.size - Math.max(100, Math.floor(MAX_SCORE_ENTRIES * 0.9));
  const oldest = Array.from(scores.entries())
    .sort((a, b) => (a[1].touchedAt || 0) - (b[1].touchedAt || 0))
    .slice(0, cutoff);
  for (const [key] of oldest) scores.delete(key);
};

const getEntry = (proxyId, hostname) => {
  const key = `${proxyId}::${hostname}`;
  if (!scores.has(key)) {
    pruneScores();
    scores.set(key, {
      wins: 0, losses: 0, streak: 0,
      totalLatencyMs: 0, latencySamples: 0,
      blacklistedUntil: 0,
      touchedAt: Date.now(),
    });
  }
  const entry = scores.get(key);
  entry.touchedAt = Date.now();
  return entry;
};

// Exponential blacklist: 1st fail = 2min, 2nd = 4min, 3rd = 8min, cap 60min
const blacklistDurationMs = (consecutiveLosses) =>
  Math.min(60 * 60_000, (2 ** Math.max(0, consecutiveLosses - 1)) * 60_000);

// Record transport-level outcomes only. Site-side policy decisions (403/429/challenge)
// are intentionally not used to rank or blacklist proxies.
export const recordOutcome = (proxyId, hostname, { success, latencyMs = null }) => {
  if (!proxyId || !hostname) return;
  const e = getEntry(proxyId, hostname);
  if (success) {
    e.wins++;
    e.streak = Math.max(0, e.streak + 1);   // positive streak
    e.blacklistedUntil = 0;                  // clear any soft blacklist on success
    if (latencyMs != null && latencyMs > 0) {
      e.totalLatencyMs += latencyMs;
      e.latencySamples++;
    }
    logger.debug(`[ProxyIntelligence] Proxy ${proxyId} → ${hostname}: WIN (${e.wins}W/${e.losses}L, streak ${e.streak})`);
  } else {
    e.losses++;
    e.streak = Math.min(0, e.streak - 1);   // negative streak (consecutive losses)
    const consecutive = Math.abs(e.streak);
    if (consecutive >= 2) {
      const ms = blacklistDurationMs(consecutive);
      e.blacklistedUntil = Date.now() + ms;
      logger.warn(`[ProxyIntelligence] Proxy ${proxyId} → ${hostname}: ${consecutive} consecutive failures — blacklisted for ${Math.round(ms / 60_000)}min`);
    } else {
      logger.info(`[ProxyIntelligence] Proxy ${proxyId} → ${hostname}: LOSS (${e.wins}W/${e.losses}L)`);
    }
  }
};

// Returns true if the proxy should not be used for this host right now.
export const isBlacklisted = (proxyId, hostname) => {
  if (!proxyId || !hostname) return false;
  const e = getEntry(proxyId, hostname);
  if (e.blacklistedUntil <= Date.now()) {
    if (e.blacklistedUntil > 0) {
      // Blacklist expired — reset streak so it gets another fair chance
      e.blacklistedUntil = 0;
      e.streak = 0;
    }
    return false;
  }
  return true;
};

// Returns the time in ms until the proxy's blacklist expires (0 if not blacklisted).
export const blacklistRemainingMs = (proxyId, hostname) => {
  if (!proxyId || !hostname) return 0;
  const e = getEntry(proxyId, hostname);
  return Math.max(0, e.blacklistedUntil - Date.now());
};

// Composite score for proxy suitability on a given host. Higher = better.
// Formula: (win-rate * 100) - (avg_latency_penalty) + (streak bonus)
// Win-rate is weighted toward 50% when sample count is low (shrinkage).
const computeScore = (proxyId, hostname) => {
  const e = getEntry(proxyId, hostname);
  if (isBlacklisted(proxyId, hostname)) return -9999;

  const total = e.wins + e.losses;
  // Bayesian-style shrinkage: blend with 0.5 prior when N is small
  const prior = 0.5;
  const priorWeight = 3;
  const winRate = total === 0 ? prior : (e.wins + prior * priorWeight) / (total + priorWeight);

  const avgLatency = e.latencySamples > 0 ? e.totalLatencyMs / e.latencySamples : 5000;
  // Latency penalty: 0ms → 0 pts, 5000ms → -50 pts (linear)
  const latencyPenalty = Math.min(50, avgLatency / 100);

  // Streak bonus: each consecutive win adds 5 pts, cap 25 pts
  const streakBonus = Math.min(25, Math.max(0, e.streak) * 5);

  return winRate * 100 - latencyPenalty + streakBonus;
};

// From a list of proxy IDs (from the DB), pick the best one for this hostname.
// Filters out blacklisted proxies first, then ranks survivors by score.
// Returns null if all candidates are blacklisted or the list is empty.
export const selectBestProxy = (hostname, proxyIds) => {
  if (!Array.isArray(proxyIds) || proxyIds.length === 0) return null;
  const eligible = proxyIds.filter((id) => !isBlacklisted(id, hostname));
  if (eligible.length === 0) {
    logger.warn(`[ProxyIntelligence] All ${proxyIds.length} proxy candidates blacklisted for ${hostname} — using first one anyway`);
    return proxyIds[0]; // fallback: better to try than to fail immediately
  }
  eligible.sort((a, b) => computeScore(b, hostname) - computeScore(a, hostname));
  const best = eligible[0];
  logger.debug(`[ProxyIntelligence] Selected proxy ${best} for ${hostname} (score ${computeScore(best, hostname).toFixed(1)})`);
  return best;
};

// Diagnostic snapshot for /v1/settings or debug logging.
export const proxyIntelligenceReport = () => {
  const report = [];
  for (const [key, e] of scores.entries()) {
    const [proxyId, hostname] = key.split('::');
    const blacklistedMs = Math.max(0, e.blacklistedUntil - Date.now());
    report.push({
      proxyId, hostname,
      wins: e.wins, losses: e.losses,
      winRate: e.wins + e.losses > 0 ? (e.wins / (e.wins + e.losses)).toFixed(2) : 'n/a',
      avgLatencyMs: e.latencySamples > 0 ? Math.round(e.totalLatencyMs / e.latencySamples) : null,
      streak: e.streak,
      blacklistedForMs: blacklistedMs || null,
      score: computeScore(proxyId, hostname).toFixed(1)
    });
  }
  return report.sort((a, b) => parseFloat(b.score) - parseFloat(a.score));
};

// For testing: wipe all state
export const __resetForTests = () => scores.clear();
