import db from '../../db/index.js';
import logger from '../../helpers/logger.js';

const TASK_FIELDS = [
  'url', 'site_id', 'billing_address_id', 'shipping_address_id', 'payment_profile_id',
  'proxy_id', 'monitor_proxy_id', 'checkout_proxy_id', 'monitor_proxy_mode', 'checkout_proxy_mode', 'notification_email_address', 'auto_solve_captchas', 'size', 'style',
  'coupon_code', 'keywords', 'start_at', 'max_retries', 'quick_mode'
];

const toIntList = (v) => {
  if (!Array.isArray(v)) return null;
  const out = v.map((x) => parseInt(x, 10)).filter((n) => Number.isInteger(n) && n > 0);
  return out.length ? out : null;
};

// POST /v1/tasks/:id/clone
// Body:
//   { count?: 5,
//     shipping_address_ids?: [2,3,4,5,6],   // round-robin across these
//     payment_profile_ids?:  [1,2],         // round-robin across these
//     proxy_ids?:            [1,2,3] }      // round-robin across these
//
// If a list is omitted, the source task's value is reused on every clone.
export const clone = async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    const base = await db('tasks').where({ id, is_deleted: false }).first();
    if (!base) return res.status(404).json({ success: false, message: 'Source task not found', data: {} });

    const rawCount = parseInt(req.body.count, 10);
    if (!Number.isInteger(rawCount) || rawCount < 1 || rawCount > 50) {
      return res.status(400).json({ success: false, message: 'count must be an integer between 1 and 50', data: {} });
    }
    const count = rawCount;
    const shipIds  = toIntList(req.body.shipping_address_ids);
    const payIds   = toIntList(req.body.payment_profile_ids);
    const proxyIds = toIntList(req.body.proxy_ids);
    const monitorProxyIds = toIntList(req.body.monitor_proxy_ids);
    const checkoutProxyIds = toIntList(req.body.checkout_proxy_ids);

    const inserted = [];
    for (let i = 0; i < count; i++) {
      const row = {};
      for (const f of TASK_FIELDS) row[f] = base[f];
      if (shipIds)  row.shipping_address_id = shipIds[i % shipIds.length];
      if (payIds)   row.payment_profile_id  = payIds[i % payIds.length];
      if (proxyIds) row.proxy_id            = proxyIds[i % proxyIds.length];
      if (monitorProxyIds) row.monitor_proxy_id = monitorProxyIds[i % monitorProxyIds.length];
      if (checkoutProxyIds) row.checkout_proxy_id = checkoutProxyIds[i % checkoutProxyIds.length];
      // Reset run-state columns so clones look fresh.
      row.has_been_used = false;
      row.retry_count = 0;
      row.last_status = '';
      row.last_order_number = '';
      row.last_duration_ms = 0;
      const [created] = await db('tasks').insert(row).returning('*');
      inserted.push(created);
    }
    logger.info(`[Tasks] Cloned task ${id} into ${inserted.length} new task(s)`);
    return res.json({ success: true, message: `Cloned into ${inserted.length} task(s)`, data: inserted });
  } catch (err) { next(err); }
};
