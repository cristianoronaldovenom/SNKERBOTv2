import db from '../db/index.js';

// Pokemon Center (site_id 6) is only allowed to run during business hours in
// Eastern Time. Using the IANA zone name lets Intl handle EST/EDT (DST) for us,
// so 8am–6pm ET stays correct year-round without manual offset math.
const TZ = 'America/New_York';
const ET_HOUR_FORMATTER = new Intl.DateTimeFormat('en-US', { timeZone: TZ, hour: 'numeric', hourCycle: 'h23' });

export const PC_SITE_ID = 6;
export const BUSINESS_START_HOUR = 8;  // 8am ET, inclusive
export const BUSINESS_END_HOUR = 18;   // 6pm ET, exclusive

// Current hour (0–23) in Eastern Time for the given date.
//
// `hourCycle: 'h23'` is set explicitly (not just `hour12: false`) because with
// hour12:false some ICU builds still emit the h24 cycle and render midnight as
// "24". h23 pins the 0–23 range.
export const getEtHour = (date = new Date()) => {
  const parts = ET_HOUR_FORMATTER.formatToParts(date);
  const hour = parseInt(parts.find((p) => p.type === 'hour')?.value ?? '0', 10);
  // Intl can render midnight as "24" in some environments — normalize to 0.
  return Number.isFinite(hour) ? hour % 24 : 0;
};

// True when `date` falls inside the 8am–6pm ET window.
export const isWithinBusinessHours = (date = new Date()) => {
  const hour = getEtHour(date);
  return hour >= BUSINESS_START_HOUR && hour < BUSINESS_END_HOUR;
};

// Master switch so the user can disable the Pokemon Center auto start/stop
// scheduler without a code change. Cache briefly because this function is used
// from the monitor hot path as well as the scheduler.
let enabledCache = { value: true, expiresAt: 0 };
const ENABLED_TTL_MS = 5000;
export const businessHoursEnabled = async () => {
  const now = Date.now();
  if (enabledCache.expiresAt > now) return enabledCache.value;
  try {
    const row = await db('settings').where({ key: 'pc_business_hours_enabled' }).first();
    if (row == null) enabledCache.value = true;
    else {
      const v = String(row.value).trim().toLowerCase();
      enabledCache.value = !['false', '0', 'off', 'no', ''].includes(v);
    }
  } catch (_) {
    enabledCache.value = true;
  }
  enabledCache.expiresAt = now + ENABLED_TTL_MS;
  return enabledCache.value;
};
