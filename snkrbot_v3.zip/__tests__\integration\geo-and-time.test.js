// Geo jitter geometry and hour-window correctness. Both are cheap maths that
// quietly skew anti-fraud signals when wrong.
import { jest } from '@jest/globals';

jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));
jest.unstable_mockModule('../../db/index.js', () => ({ default: () => ({ where: () => ({ first: async () => null }) }) }));

const { getGeoForTimezone } = await import('../../helpers/geo-consistency.js');
const { getEtHour, isWithinBusinessHours } = await import('../../helpers/business-hours.js');
const { syntheticMouseStats } = await import('../../helpers/human-mouse.js');

// Longitude must compress by cos(lat). At Toronto (~43.65) a 5 km radius is
// ~0.065 deg of longitude; the old latitude-only scale gave ~0.045 deg, i.e. the
// jitter was always too wide east-west.
test('longitude jitter is scaled by latitude, latitude jitter is not', () => {
  const toronto = { lat: 43.6532, lng: -79.3832 };
  const samples = Array.from({ length: 300 }, () => getGeoForTimezone('America/Toronto'));
  const maxLatDelta = Math.max(...samples.map((s) => Math.abs(s.lat - toronto.lat)));
  const maxLngDelta = Math.max(...samples.map((s) => Math.abs(s.lng - toronto.lng)));

  // 5 km / 111 km per deg = 0.045 deg latitude ceiling.
  expect(maxLatDelta).toBeLessThanOrEqual(0.0451);
  // Longitude ceiling is that divided by cos(43.65) ≈ 0.062.
  expect(maxLngDelta).toBeLessThanOrEqual(0.063);
  expect(maxLngDelta).toBeGreaterThan(maxLatDelta);
});

test('an unmapped timezone falls back to the default city', () => {
  const geo = getGeoForTimezone('Asia/Tokyo');
  expect(geo.matched).toBe(false);
  expect(geo.tz).toBe('America/Toronto');
});

test('business hours are evaluated in Eastern time, not the host zone', () => {
  // 2026-06-15 15:00 UTC = 11:00 EDT → inside 8-18.
  expect(getEtHour(new Date('2026-06-15T15:00:00Z'))).toBe(11);
  expect(isWithinBusinessHours(new Date('2026-06-15T15:00:00Z'))).toBe(true);
  // 2026-06-15 23:00 UTC = 19:00 EDT → outside.
  expect(isWithinBusinessHours(new Date('2026-06-15T23:00:00Z'))).toBe(false);
  // 2026-06-15 03:00 UTC = 23:00 EDT (previous day) → outside.
  expect(isWithinBusinessHours(new Date('2026-06-15T03:00:00Z'))).toBe(false);
});

test('midnight renders as hour 0, never 24', () => {
  // 2026-01-01 05:00 UTC = 00:00 EST.
  expect(getEtHour(new Date('2026-01-01T05:00:00Z'))).toBe(0);
  expect(isWithinBusinessHours(new Date('2026-01-01T05:00:00Z'))).toBe(false);
});

test('synthetic mouse stats are finite and the end-angle spread is real', () => {
  const s = syntheticMouseStats();
  for (const v of Object.values(s)) expect(Number.isFinite(v)).toBe(true);
  expect(s.es_distmdn).toBeGreaterThan(0);
  // End angles previously reused each sample's own start angle, collapsing the
  // spread; a real ±20 deg turn keeps this well above zero.
  expect(s.es_angemdn).toBeGreaterThan(5);
});
