export const up = (knex) =>
  knex.schema.alterTable('tasks', (table) => {
    table.timestamp('start_at').nullable();
    table.integer('max_retries').notNullable().defaultTo(2);
    table.integer('retry_count').notNullable().defaultTo(0);
    table.boolean('quick_mode').notNullable().defaultTo(true);
    table.timestamp('last_run_at').nullable();
    table.string('last_status', 30).defaultTo('').nullable();
    table.string('last_order_number', 100).defaultTo('').nullable();
    table.integer('last_duration_ms').defaultTo(0).nullable();
  });

export const down = (knex) =>
  knex.schema.alterTable('tasks', (table) => {
    table.dropColumn('start_at');
    table.dropColumn('max_retries');
    table.dropColumn('retry_count');
    table.dropColumn('quick_mode');
    table.dropColumn('last_run_at');
    table.dropColumn('last_status');
    table.dropColumn('last_order_number');
    table.dropColumn('last_duration_ms');
  });
