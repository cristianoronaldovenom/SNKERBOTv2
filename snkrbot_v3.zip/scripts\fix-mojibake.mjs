import fs from 'node:fs';

// Repair UTF-8 that was once decoded as Latin-1 and then re-encoded. Each entry
// is the exact mojibake sequence as it exists in the file today.
const REPAIRS = [
  ['\u00e2\u20ac\u201d', '\u2014'],   // em dash
  ['\u00e2\u2020\u2019', '\u2192'],   // right arrow
  ['\u00f0\u0178', '\u{1F4A1}'],      // emoji prefix (bulb)
  ['\u00e2\u20ac', '\u2014'],
  ['\u00c3\u00a9', 'e'],              // accented e (Pokemon)
  ['\u00c3\u00a8', 'e']               // accented e, grave
];


let touched = 0;
for (const file of process.argv.slice(2)) {
  let text = fs.readFileSync(file, 'utf8');
  const before = text;
  for (const [from, to] of REPAIRS) text = text.split(from).join(to);
  if (text !== before) {
    fs.writeFileSync(file, text);
    touched += 1;
    console.log('repaired ' + file);
  }
}
console.log('files repaired: ' + touched);
