// Proxy health verdicts. A proxy is a transport, so an HTTP error status from
// the origin is still a working tunnel — but 429 (exit rate-limited) and 5xx
// (gateway broke) are not usable and used to be counted `ok` because the old
// check only required `status < 500`.
import { jest } from '@jest/globals';

jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));
jest.unstable_mockModule('node:dns/promises', () => ({
  default: { lookup: async () => [{ address: '93.184.216.34', family: 4 }] }
}));

let nextStatus = 200;
let nextThrows = false;
jest.unstable_mockModule('got-scraping', () => ({
  gotScraping: async () => {
    if (nextThrows) throw new Error('ECONNRESET');
    return { statusCode: nextStatus, body: 'ok' };
  }
}));

const { testProxy } = await import('../../helpers/proxy-health.js');

const proxy = { id: 7, host: 'proxy.example.com', port: 8080 };

beforeEach(() => { nextStatus = 200; nextThrows = false; });

test('a 200 through the tunnel is healthy', async () => {
  const r = await testProxy(proxy);
  expect(r.summary).toBe('healthy');
  expect(r.okCount).toBe(r.total);
});

test('a 403 from the origin still means the tunnel works', async () => {
  nextStatus = 403;
  const r = await testProxy(proxy);
  expect(r.summary).toBe('healthy');
});

test('429 is not a healthy proxy', async () => {
  nextStatus = 429;
  const r = await testProxy(proxy);
  expect(r.summary).toBe('dead');
  expect(r.results[0].error).toBe('HTTP 429');
});

test('503 is not a healthy proxy', async () => {
  nextStatus = 503;
  const r = await testProxy(proxy);
  expect(r.summary).toBe('dead');
});

test('a transport throw is dead', async () => {
  nextThrows = true;
  const r = await testProxy(proxy);
  expect(r.summary).toBe('dead');
});

test('a loopback literal proxy is refused', async () => {
  const r = await testProxy({ id: 1, host: '127.0.0.1', port: 8080 });
  expect(r.summary).toBe('blocked');
  expect(r.error).toMatch(/private/);
});

test('an IPv4-mapped IPv6 loopback is refused', async () => {
  const r = await testProxy({ id: 2, host: '::ffff:127.0.0.1', port: 8080 });
  expect(r.summary).toBe('blocked');
  expect(r.error).toMatch(/private/);
});

test('an invalid port is rejected', async () => {
  const r = await testProxy({ id: 3, host: 'proxy.example.com', port: 70000 });
  expect(r.summary).toBe('blocked');
  expect(r.error).toMatch(/invalid port/);
});
