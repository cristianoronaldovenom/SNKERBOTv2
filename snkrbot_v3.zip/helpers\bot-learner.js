// Bot-bypass ML learner — Bayesian MAP + ε-greedy bandit per site.
//
// Problem: Different checkout sites respond differently to different
// behavioral profiles. Chrome 131 on Windows might be flagged by Site A's
// WAF but pass Site B's. Quick checkout (tight timing) might beat Site C's
// inventory race but get flagged by Site D's behavioral analyzer.
//
// Without data, you pick randomly. With this learner, each run teaches the
// system which combination works best for each site, and the bandit
// automatically shifts toward configurations that succeed more often while
// occasionally exploring alternatives to catch changes in WAF behavior.
//
// Algorithm: Bayesian MAP estimate (Beta-Binomial prior) + ε-greedy
//
// Win rate estimate: uses a Beta(α, β) prior to regularize estimates when
// data is sparse. With prior α=2, β=2 (equivalent to 2 imagined wins and
// 2 imagined losses), the MAP estimate is:
//
//   score(arm) = (real_wins + 2) / (real_pulls + 4)
//
// This means an untried arm starts at 50% and moves quickly as data arrives.
// An arm with 3/3 successes scores (3+2)/(3+4) = 71.4% and beats untried arms.
//
// Exploration: 5% of the time, pick a random arm instead of the best known
// one. This covers WAF updates (a profile that stopped working) without
// wasting pulls on systematic exploration of every arm before exploiting.
//
// Why NOT pure UCB1: UCB1's exploration bonus (√(ln N / n)) is infinite for
// untried arms, forcing the algorithm to try every arm before exploiting good
// ones. For a sneaker bot each "exploration" costs real proxy/captcha/time —
// so we want a bias toward exploitation and only light exploration.
//
// Arms (6 per site, one bandit per site_id):
//   chrome131-quick   chrome131-normal
//   chrome124-quick   chrome124-normal
//   chrome120-quick   chrome120-normal
//
// Reward:
//   1.0  — checkout succeeded (the arm combination worked)
//   0.0  — failed at a bot-detection stage (WAF flagged us — punish the arm)
//   0.5  — failed for unrelated reasons (OOS, decline, session expiry, sibling)
//          Partial credit: the arm wasn't the cause of failure.
//   skip — preflight_fail, household_cap, drop_wait (no signal at all)
//
// Persistence: bandit state is stored as a JSON blob in the `settings` table
// under key `_bot_learner_state`. Learning survives restarts and accumulates
// across days/weeks. State is persisted after every recorded outcome
// (debounced 5s to avoid DB round-trips on rapid-fire attempts).

import db from '../db/index.js';
import logger from './logger.js';

// ── Constants ─────────────────────────────────────────────────────────────────

const STATE_KEY = '_bot_learner_state';
const PERSIST_DEBOUNCE_MS = 5_000;   // min ms between DB writes

// Prior pseudo-counts: equivalent to having seen 2 wins and 2 losses before
// any real data. Gives untried arms a starting score of 0.50. Arms with real
// data quickly pull away from this prior.
const PRIOR_WINS   = 2;
const PRIOR_LOSSES = 2;

// Epsilon: probability of random exploration instead of exploiting best arm.
// 5% = one in twenty runs tries a random arm. High enough to detect WAF
// changes, low enough to not waste runs systematically.
const EPSILON = 0.05;

// Arms: all combinations of TLS profile and timing mode.
const ARMS = [
  'chrome131-quick', 'chrome131-normal',
  'chrome124-quick', 'chrome124-normal',
  'chrome120-quick', 'chrome120-normal'
];

// Stages that indicate bot detection (WAF blocked us, not our product logic)
const BOT_STAGE_PATTERNS = [
  'bot_block', 'challenge', 'cloudflare', 'imperva', 'datadome',
  'perimeterx', 'kasada', 'akamai', 'turnstile', 'recaptcha',
  'hcaptcha', 'queue', 'waiting_room', 'blocked', 'detection'
];

// Stages that are clearly NOT bot detection (don't penalize the arm)
const NON_BOT_STAGE_PATTERNS = [
  'oos', 'out_of_stock', 'decline', 'payment_decline', 'session_expired',
  'session_retry', 'sibling_won', 'restock_wait', 'household_cap'
];

// Skip these outcomes entirely — no useful signal for the bandit
const SKIP_STAGE_PATTERNS = [
  'preflight_fail', 'household_cap', 'drop_wait', 'sibling_won', 'stop_loss'
];

// ── Bandit state ─────────────────────────────────────────────────────────────
// state.sites[siteId][arm] = { wins: number, losses: number }
// "wins" and "losses" are real observations, not including the prior.
// The prior is added at score-computation time so it doesn't pollute the data.

let state = { sites: {}, meta: { lastUpdatedAt: null, totalRuns: 0 } };
let stateLoaded = false;
let persistTimer = null;

// ── State helpers ─────────────────────────────────────────────────────────────

const getSiteState = (siteId) => {
  const k = String(siteId);
  if (!state.sites[k]) {
    state.sites[k] = {};
    for (const arm of ARMS) state.sites[k][arm] = { wins: 0, losses: 0 };
  }
  // Ensure all arms exist (handles arms added after initial state creation)
  for (const arm of ARMS) {
    if (!state.sites[k][arm]) state.sites[k][arm] = { wins: 0, losses: 0 };
  }
  return state.sites[k];
};

// MAP estimate with Beta prior: (wins + PRIOR_WINS) / (pulls + PRIOR_WINS + PRIOR_LOSSES)
const mapScore = (entry) => {
  const pulls = entry.wins + entry.losses;
  return (entry.wins + PRIOR_WINS) / (pulls + PRIOR_WINS + PRIOR_LOSSES);
};

// ── Persistence ───────────────────────────────────────────────────────────────

const loadState = async () => {
  if (stateLoaded) return;
  stateLoaded = true;
  try {
    const row = await db('settings').where({ key: STATE_KEY }).first();
    if (row?.value) {
      const parsed = JSON.parse(row.value);
      if (parsed?.sites) {
        state = parsed;
        const totalObs = Object.values(state.sites).reduce(
          (s, site) => s + Object.values(site).reduce((a, arm) => a + (arm.wins || 0) + (arm.losses || 0), 0), 0
        );
        logger.info(`[BotLearner] Loaded bandit state — ${Object.keys(state.sites).length} sites, ${totalObs} recorded observations`);
        return;
      }
    }
    // No saved state — try to seed from historical task_runs
    await seedFromHistory();
  } catch (err) {
    logger.warn(`[BotLearner] Failed to load saved state: ${err.message} — starting fresh`);
  }
};

const persistState = () => {
  if (persistTimer) return;
  persistTimer = setTimeout(async () => {
    persistTimer = null;
    try {
      state.meta.lastUpdatedAt = new Date().toISOString();
      const json = JSON.stringify(state);
      const existing = await db('settings').where({ key: STATE_KEY }).first();
      if (existing) {
        await db('settings').where({ key: STATE_KEY }).update({ value: json, updated_at: new Date() });
      } else {
        await db('settings').insert({ key: STATE_KEY, value: json });
      }
      logger.debug('[BotLearner] State persisted to DB');
    } catch (err) {
      logger.warn(`[BotLearner] Failed to persist state: ${err.message}`);
    }
  }, PERSIST_DEBOUNCE_MS);
};

// ── Historical seeding ────────────────────────────────────────────────────────
// On first start, pre-warm the bandit from existing task_runs data so previous
// runs count as learning (don't start from scratch after a restart).

const resolveArmFromRun = (run) => {
  let prefix = 'chrome131'; // default
  const label = (run.profile_label || '').toLowerCase();
  if (label.includes('124')) prefix = 'chrome124';
  else if (label.includes('120')) prefix = 'chrome120';
  const mode = run.quick_mode ? 'quick' : 'normal';
  return `${prefix}-${mode}`;
};

const classifyReward = (run) => {
  if (run.status === 'success') return 1.0;
  const stage = (run.stage_failed || '').toLowerCase();
  if (SKIP_STAGE_PATTERNS.some(p => stage.includes(p))) return null;
  if (BOT_STAGE_PATTERNS.some(p => stage.includes(p))) return 0.0;
  if (NON_BOT_STAGE_PATTERNS.some(p => stage.includes(p))) return 0.5;
  // Unknown: treat as a partial bot-detection signal
  return 0.3;
};

const seedFromHistory = async () => {
  try {
    const runs = await db('task_runs')
      .join('tasks', 'tasks.id', 'task_runs.task_id')
      .select(
        'task_runs.status', 'task_runs.stage_failed',
        'task_runs.profile_label', 'tasks.site_id', 'tasks.quick_mode'
      )
      .whereNotNull('tasks.site_id')
      .orderBy('task_runs.finished_at', 'desc')
      .limit(2000); // cap to last 2000 runs so stale data doesn't dominate

    let seeded = 0;
    for (const run of runs) {
      const reward = classifyReward(run);
      if (reward === null) continue;
      const arm = resolveArmFromRun(run);
      const site = getSiteState(run.site_id);
      if (site[arm]) {
        // Convert fractional reward to win/loss increments
        site[arm].wins   += reward;
        site[arm].losses += (1 - reward);
        seeded++;
      }
    }
    state.meta.totalRuns = seeded;
    logger.info(`[BotLearner] Seeded bandit from ${seeded} historical runs across ${Object.keys(state.sites).length} sites`);
    if (seeded > 0) persistState();
  } catch (err) {
    logger.warn(`[BotLearner] Historical seeding failed: ${err.message}`);
  }
};

// ── Public API ────────────────────────────────────────────────────────────────

// Get the recommended arm (profile + timing mode) for a given site.
//
// Returns:
//   { profile, quickMode, arm, confidence, totalPulls, ranked }
//
// confidence levels:
//   'exploring' — less than 3 real observations total for this site
//   'low'       — 3-14 real observations
//   'high'      — 15+ real observations
//
// The recommendation is the arm with the highest MAP score, 95% of the time.
// 5% of the time a random arm is returned to maintain exploration.
export const getBotLearnerRecommendation = async (siteId) => {
  await loadState();
  const site = getSiteState(siteId);

  const scored = ARMS.map((arm) => ({
    arm,
    score: mapScore(site[arm]),
    wins: site[arm].wins,
    losses: site[arm].losses,
    pulls: site[arm].wins + site[arm].losses,
    winRate: (site[arm].wins + site[arm].losses) > 0
      ? site[arm].wins / (site[arm].wins + site[arm].losses)
      : null
  })).sort((a, b) => b.score - a.score);

  const totalPulls = scored.reduce((s, a) => s + a.pulls, 0);

  // ε-greedy: explore with probability EPSILON
  let chosen;
  if (Math.random() < EPSILON) {
    chosen = scored[Math.floor(Math.random() * scored.length)];
    logger.debug(`[BotLearner] Site ${siteId} — exploring: randomly picked "${chosen.arm}"`);
  } else {
    chosen = scored[0];
  }

  const confidence = totalPulls < 3 ? 'exploring' : totalPulls < 15 ? 'low' : 'high';
  const [profile, mode] = chosen.arm.split('-');

  logger.debug(
    `[BotLearner] Site ${siteId} recommendation: "${chosen.arm}" ` +
    `(mapScore=${chosen.score.toFixed(3)}, winRate=${chosen.winRate !== null ? (chosen.winRate * 100).toFixed(0) + '%' : 'none'}, ` +
    `pulls=${chosen.pulls}, confidence=${confidence})`
  );

  return {
    profile,
    quickMode: mode === 'quick',
    arm: chosen.arm,
    confidence,
    totalPulls,
    ranked: scored
  };
};

// Record the outcome of a run. Call after every task attempt.
// siteId: integer
// arm: the arm string from getBotLearnerRecommendation (e.g. 'chrome131-normal')
// result: { ok: bool, stage: string, failureType: string }
export const recordBotLearnerOutcome = async (siteId, arm, result) => {
  await loadState();
  if (!ARMS.includes(arm)) {
    logger.debug(`[BotLearner] Unknown arm "${arm}" — skipping`);
    return;
  }

  const site = getSiteState(siteId);

  // Compute reward
  let reward;
  if (result.ok) {
    reward = 1.0;
  } else {
    const stage = (result.stage || result.failureType || '').toLowerCase();
    if (SKIP_STAGE_PATTERNS.some(p => stage.includes(p))) {
      logger.debug(`[BotLearner] Non-informative outcome "${stage}" — skipping`);
      return;
    }
    if (BOT_STAGE_PATTERNS.some(p => stage.includes(p))) reward = 0.0;
    else if (NON_BOT_STAGE_PATTERNS.some(p => stage.includes(p))) reward = 0.5;
    else reward = 0.3;
  }

  // Update win/loss counters using fractional increments (soft reward)
  site[arm].wins   += reward;
  site[arm].losses += (1 - reward);
  state.meta.totalRuns++;

  const totalPulls = site[arm].wins + site[arm].losses;
  logger.info(
    `[BotLearner] Site ${siteId} arm "${arm}" — reward=${reward.toFixed(1)} → ` +
    `mapScore=${mapScore(site[arm]).toFixed(3)} (${totalPulls.toFixed(1)} effective pulls)`
  );

  persistState();
};

// ── Diagnostics ───────────────────────────────────────────────────────────────

export const getBotLearnerStats = async () => {
  await loadState();
  const report = [];

  for (const [siteIdStr, siteData] of Object.entries(state.sites)) {
    const siteId = parseInt(siteIdStr, 10);
    const totalPulls = Object.values(siteData).reduce((s, e) => s + (e.wins || 0) + (e.losses || 0), 0);

    const arms = ARMS.map((arm) => {
      const e = siteData[arm] || { wins: 0, losses: 0 };
      const pulls = e.wins + e.losses;
      return {
        arm,
        wins: parseFloat(e.wins.toFixed(2)),
        losses: parseFloat(e.losses.toFixed(2)),
        pulls: parseFloat(pulls.toFixed(1)),
        winRate: pulls > 0 ? parseFloat((e.wins / pulls * 100).toFixed(1)) : null,
        mapScore: parseFloat(mapScore(e).toFixed(3))
      };
    }).sort((a, b) => b.mapScore - a.mapScore);

    const best = arms[0];
    const confidence = totalPulls < 3 ? 'exploring' : totalPulls < 15 ? 'low' : 'high';

    report.push({
      siteId,
      totalPulls: parseFloat(totalPulls.toFixed(1)),
      confidence,
      bestArm: best.arm,
      bestMapScore: best.mapScore,
      arms
    });
  }

  return {
    totalSites: report.length,
    totalRuns: state.meta.totalRuns,
    lastUpdatedAt: state.meta.lastUpdatedAt,
    epsilon: EPSILON,
    prior: { wins: PRIOR_WINS, losses: PRIOR_LOSSES },
    sites: report.sort((a, b) => b.totalPulls - a.totalPulls)
  };
};

// Reset all learned state (e.g. after switching VPS/proxies, making old data stale).
export const resetBotLearner = async () => {
  state = { sites: {}, meta: { lastUpdatedAt: null, totalRuns: 0 } };
  stateLoaded = true;
  try { await db('settings').where({ key: STATE_KEY }).delete(); } catch (_) {}
  logger.info('[BotLearner] State reset — will reseed from task_runs on next request');
};

// For tests only
export const __resetInMemory = () => {
  state = { sites: {}, meta: { lastUpdatedAt: null, totalRuns: 0 } };
  stateLoaded = true;
};
