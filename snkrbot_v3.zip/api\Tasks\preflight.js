import db from '../../db/index.js';
import { preflightTask } from '../../helpers/preflight.js';

export const runPreflight = async (req, res, next) => {
  try {
    const taskId = parseInt(req.params.id);
    const task = await db('tasks').where({ id: taskId, is_deleted: false }).first();
    if (!task) return res.status(404).json({ success: false, message: 'Task not found', data: {} });
    const result = await preflightTask(task);
    return res.json({ success: true, message: result.summary, data: result });
  } catch (err) { next(err); }
};
