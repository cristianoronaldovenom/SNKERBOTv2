import { tryRequestFirstAddToCart } from '../../helpers/browser-request-atc.js';
import { navigateCartUnlessReady } from '../../helpers/site-checkout-fastpath.js';
import logger from '../../helpers/logger.js';
import { solveCaptcha, solveHCaptcha } from '../../helpers/captcha.js';
import { getCachedToken } from '../../helpers/captcha-cache.js';
import { consumeToken, depositToken, ensureStockpiling } from '../../helpers/token-stockpile.js';
import { storePageInTaskCache } from '../../helpers/task-cache.js';
import { humanType, humanTypeInFrames, humanSelect, humanClick } from '../../helpers/human-type.js';
import { detectAndSolveAkamai } from '../../helpers/akamai.js';
import { waitForImpervaToResolve } from '../../helpers/session-warmer.js';
import {
  takeFailureScreenshot,
  detectBotBlockOnPage,
  detectThreeDSecure,
  retryWithBackoff,
  hasCaptchaApiKey,
  guardedGoto,
  postClickGuard,
  preOrderGuard
} from '../../helpers/checkout-guards.js';
import {
  formatPostal,
  stripPhone,
  dismissAutocomplete,
  verifyFieldValue,
  requireCardIframe,
  verifyCartHasItem,
  FillReport,
  assertCriticalFields,
  dismissAddressSuggestion,
  detectCardType
} from '../../helpers/autofill-utils.js';
import { captureOrderSuccess } from '../../helpers/order-capture.js';
import { notify } from '../../helpers/notifier.js';
import { waitForAnySelector, classifySiteError, sleep as runtimeSleep } from '../../helpers/site-runtime.js';
import { assertActionButtonIntent } from '../../helpers/checkout-controls.js';
import { detectQueuePage, waitForQueueToPass } from '../../helpers/checkout-guards.js';
import { runStageWithRecovery } from '../../helpers/stage-retry.js';

const BASE_URL = 'https://www.pokemoncenter.com';
const LOCALE = 'en-ca';
const CHECKOUT_URL = `${BASE_URL}/${LOCALE}/checkout`;
const CART_URL = `${BASE_URL}/${LOCALE}/cart`;

const TIMEOUT = 15000;
const PLACE_ORDER_TIMEOUT = 60000;
const POLL_BASE_MS = 1800;
const POLL_JITTER_MS = 700;
const POLL_MAX_MS = 5000;
const FAST_BURST_ATTEMPTS = 5;
const MAX_MONITOR_ATTEMPTS = 200;

const sleep = runtimeSleep;

// Checkout markup can change without changing the underlying flow. Keep a
// small set of semantic fallbacks so ordinary checkout reliability does not
// depend on one exact CSS class. This does not bypass queues or challenges.
const CHECKOUT_BUTTON_SELECTORS = [
  '.checkout-btn',
  'a.checkout-btn',
  'button.checkout-btn',
  '[data-action="checkout"]',
  'button[name="checkout"]',
  'a[href*="/checkout"]'
];

const SHIPPING_SUBMIT_SELECTORS = [
  'button.submit-shipping',
  'button[name*="shipping" i][type="submit"]',
  'button[data-action*="shipping" i]',
  'input[type="submit"][name*="shipping" i]'
];

const PAYMENT_SUBMIT_SELECTORS = [
  'button.submit-payment',
  'button[value="submit-payment"]',
  'button[name*="payment" i][type="submit"]',
  'button[data-action*="payment" i]',
  'input[type="submit"][name*="payment" i]'
];

const PLACE_ORDER_SELECTORS = [
  'button.place-order',
  'button.submit-order',
  'button[name*="place" i][type="submit"]',
  'button[data-action*="place-order" i]',
  'input[type="submit"][value*="place order" i]'
];

const firstExistingSelector = async (page, selectors, timeout = 3000) =>
  waitForAnySelector(page, selectors, { timeout, requireEnabled: false });

const clickTextFallback = async (page, labels) => {
  return page.evaluate((wanted) => {
    const norm = (v) => String(v || '').replace(/\s+/g, ' ').trim().toLowerCase();
    const wantedNorm = wanted.map(norm);
    const els = Array.from(document.querySelectorAll('button, a, input[type="submit"]'));
    for (const el of els) {
      const disabled = el.disabled || el.getAttribute('aria-disabled') === 'true';
      if (disabled) continue;
      const text = norm(el.innerText || el.value || el.getAttribute('aria-label'));
      if (!text) continue;
      if (wantedNorm.some((label) => text === label || text.includes(label))) {
        el.click();
        return text;
      }
    }
    return null;
  }, labels);
};

const computePollDelay = (attempt) => {
  const jitter = Math.floor((Math.random() - 0.5) * 2 * POLL_JITTER_MS);
  if (attempt < FAST_BURST_ATTEMPTS) {
    return Math.max(900, POLL_BASE_MS + jitter);
  }
  const backoff = Math.min(POLL_MAX_MS, POLL_BASE_MS + (attempt - FAST_BURST_ATTEMPTS) * 150);
  return Math.max(1200, backoff + jitter);
};

const ATC_SELECTORS = [
  'button.add-to-cart:not([disabled])',
  'button[data-action="add-to-cart"]:not([disabled])',
  'button[name="add-to-cart"]:not([disabled])',
  'button[id*="add-to-cart" i]:not([disabled])',
  'button.add-to-bag:not([disabled])'
].join(', ');

const SOLD_OUT_SELECTORS = [
  '.product-availability .not-available',
  '.product-availability.unavailable',
  '.sold-out-message',
  '[data-availability="sold-out"]',
  '.out-of-stock'
].join(', ');

const runPokemonCenter = async ({ page, task, reportStage = null }) => {
  const startedAt = Date.now();
  logger.info(`[PokemonCenter] Starting task ${task.id}: ${task.url}`);

  storePageInTaskCache({ taskId: task.id, page });

  const stages = [
    { name: 'monitorAndAtc', fn: monitorAndAtc },
    { name: 'navigateToCheckout', fn: navigateToCheckout },
    { name: 'fillShipping', fn: fillShipping },
    { name: 'fillPayment', fn: fillPayment },
    { name: 'placeOrder', fn: (args) => placeOrder({ ...args, startedAt }) }
  ];

  for (const stage of stages) {
    try {
      await reportStage?.(stage.name, 'running');
      await guardedStage(page, task, stage.name);
      const stageAttempts = stage.name === 'placeOrder' ? 1 : (stage.name === 'monitorAndAtc' ? 1 : 2);
      await runStageWithRecovery(() => stage.fn({ page, task }), {
        taskId: task.id, stage: stage.name, attempts: stageAttempts, baseMs: 350
      });
      await reportStage?.(stage.name, 'completed');
    } catch (err) {
      await takeFailureScreenshot(page, task.id, stage.name);
      if (/cart is empty|out of stock|sold out/i.test(err.message || '')) err.failureType = 'oos';
      else if (/session|cookie|cart.*expired|invalid.*session/i.test(err.message || '')) err.failureType = 'session_expired';
      else if (/queue timeout/i.test(err.message || '')) err.failureType = 'queue';
      else if (/3d secure|verification/i.test(err.message || '')) err.failureType = 'human_required';
      logger.error(`[PokemonCenter] Task ${task.id} failed at stage "${stage.name}": ${err.message}`);
      throw err;
    }
  }
};

const guardedStage = async (page, task, stageName) => {
  const block = await detectBotBlockOnPage(page);
  if (block.blocked) {
    logger.warn(`[PokemonCenter] Task ${task.id} — bot-block detected before ${stageName} (vendor: ${block.vendor}). Attempting Imperva resolve…`);
    await waitForImpervaToResolve(page, { timeout: 25000 }).catch(() => {});
    const after = await detectBotBlockOnPage(page);
    if (after.blocked) {
      throw new Error(`Site blocked bot at "${stageName}" (vendor: ${after.vendor}). HTML snippet: ${after.htmlSnippet?.slice(0, 200)}`);
    }
  }
  await tryAutoCaptcha({ page, task, where: stageName });
};

const readProductState = async (page) => page.evaluate(() => {
  const visible = (el) => {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    const st = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && st.display !== 'none' && st.visibility !== 'hidden';
  };
  const atc = Array.from(document.querySelectorAll('button, input[type=submit], [role=button]')).find((el) =>
    visible(el) && /(add to cart|add to bag)/i.test(String(el.innerText || el.value || el.getAttribute('aria-label') || '')) &&
    !el.disabled && el.getAttribute('aria-disabled') !== 'true'
  );
  const soldOut = Array.from(document.querySelectorAll('.product-availability, .sold-out-message, [data-availability], .out-of-stock'))
    .some((el) => visible(el) && /(sold out|out of stock|unavailable|not available)/i.test(el.textContent || ''));
  return { atcReady: !!atc, soldOut };
});

const waitForProductReady = async (page, timeout = 12000) => {
  try {
    await page.waitForFunction(() => {
      const visible = (el) => {
        if (!el) return false;
        const r = el.getBoundingClientRect();
        const st = getComputedStyle(el);
        return r.width > 0 && r.height > 0 && st.display !== 'none' && st.visibility !== 'hidden';
      };
      return Array.from(document.querySelectorAll('button, input[type=submit], [role=button]')).some((el) =>
        visible(el) && /(add to cart|add to bag)/i.test(String(el.innerText || el.value || el.getAttribute('aria-label') || '')) &&
        !el.disabled && el.getAttribute('aria-disabled') !== 'true'
      );
    }, { timeout });
  } catch (_) {}
  return readProductState(page);
};

const monitorAndAtc = async ({ page, task }) => {
  logger.info(`[PokemonCenter] Monitoring product for task ${task.id}`);

  // Only pay for a full PDP navigation when we are not already sitting on the
  // product (or after a failed attempt). Re-navigating on every poll costs a
  // document load + Imperva round-trip per ~2s, which dominates the poll budget
  // and throws away the warm Akamai session we just earned.
  const pdpHost = (() => { try { return new URL(task.url).hostname; } catch (_) { return 'www.pokemoncenter.com'; } })();
  let onPdp = false;

  for (let attempt = 0; attempt < MAX_MONITOR_ATTEMPTS; attempt++) {
    try {
      if (!onPdp) {
        await guardedGoto(page, task.url, { taskId: task.id, stage: 'pdp_load', waitUntil: 'domcontentloaded', timeout: 30000 });
        onPdp = true;
      }

      const impResult = await waitForImpervaToResolve(page, { timeout: 25000 });
      if (!impResult.resolved) {
        logger.warn(`[PokemonCenter] Task ${task.id} — Imperva still challenging after navigation (bodyLen=${impResult.bodyLen})`);
        try {
          const html = await page.content();
          const ua = await page.evaluate(() => navigator.userAgent);
          const cookies = await page.cookies();
          const sessionCookies = new Map([[pdpHost, cookies.map(c => `${c.name}=${c.value}`).join('; ')]]);
          const newAbck = await detectAndSolveAkamai({ html, pageUrl: task.url, ua, sessionCookies });
          if (newAbck) {
            await page.setCookie({ name: '_abck', value: newAbck, domain: `.${pdpHost.replace(/^www\./, '')}`, path: '/' });
            logger.info(`[PokemonCenter] Task ${task.id} — _abck refreshed via Akamai BMP, retrying navigation`);
            await page.reload({ waitUntil: 'domcontentloaded', timeout: 30000 });
            await waitForImpervaToResolve(page, { timeout: 15000 });
          }
        } catch (akErr) {
          logger.warn(`[PokemonCenter] Akamai sensor preflight failed: ${akErr.message}`);
        }
      }

      if (task.keywords) {
        await selectVariantByKeyword({ page, task });
      }

      if (task.size) {
        await selectSize({ page, task });
      }

      const state = await waitForProductReady(page, 2500);

      if (state.soldOut || !state.atcReady) {
        const delay = computePollDelay(attempt);
        logger.info(`[PokemonCenter] Task ${task.id} — product not available, retrying in ${delay}ms (attempt ${attempt + 1}/${MAX_MONITOR_ATTEMPTS})`);
        await sleep(delay);
        continue;
      }

      await addToCart({ page, task });
      return;
    } catch (err) {
      // addToCart can throw AFTER the cart actually mutated (the confirmation
      // selector timed out). Re-entering the loop then re-adds the same item, so
      // check the cart first and finish if it is already populated.
      const cartCheck = await verifyCartHasItem(page, { timeout: 2500 }).catch(() => ({ empty: false }));
      if (!cartCheck.empty) {
        logger.info(`[PokemonCenter] Task ${task.id} — ATC already applied (cart populated), continuing`);
        return;
      }
      logger.warn(`[PokemonCenter] Task ${task.id} monitor error: ${err.message}`);
      onPdp = false;
      await sleep(computePollDelay(attempt));
    }
  }

  throw new Error(`[PokemonCenter] Task ${task.id} timed out waiting for product to be available`);
};

const selectVariantByKeyword = async ({ page, task }) => {
  const keywordList = task.keywords
    .split(',')
    .map((k) => k.trim().toLowerCase())
    .filter(Boolean);

  logger.info(`[PokemonCenter] Looking for variant matching keywords [${keywordList.join(', ')}] for task ${task.id}`);

  const matched = await page.evaluate((keywords) => {
    const variantSelectors = [
      '.product-variants .variant-link',
      '.variations a',
      '.product-option-value',
      '.set-select option',
      '.variant-pill',
      '.product-detail .attribute .swatchanchor',
      '.variant-selection a',
      '.product-detail select option'
    ];

    for (const sel of variantSelectors) {
      const elements = Array.from(document.querySelectorAll(sel));
      for (const el of elements) {
        const label = (el.textContent || el.value || el.dataset.attrValue || '').toLowerCase().trim();
        const matchesAll = keywords.every((kw) => label.includes(kw));
        if (matchesAll && !el.classList.contains('unselectable') && !el.disabled) {
          if (el.tagName === 'OPTION') {
            el.closest('select').value = el.value;
            el.closest('select').dispatchEvent(new Event('change', { bubbles: true }));
          } else {
            el.click();
          }
          return label;
        }
      }
    }
    return null;
  }, keywordList);

  if (matched) {
    logger.info(`[PokemonCenter] Variant matched: "${matched}" for task ${task.id}`);
    await waitForProductReady(page, 4000);
  } else {
    logger.warn(`[PokemonCenter] No variant matched keywords [${keywordList.join(', ')}] for task ${task.id} — proceeding without variant selection`);
  }
};

const selectSize = async ({ page, task }) => {
  logger.info(`[PokemonCenter] Selecting size "${task.size}" for task ${task.id}`);

  try {
    await page.waitForSelector('.size-attribute .size-btn, .attribute-selector .swatchanchor', {
      timeout: TIMEOUT
    });

    const sizeSelected = await page.evaluate((targetSize) => {
      const sizeButtons = document.querySelectorAll(
        '.size-attribute .size-btn, .attribute-selector .swatchanchor'
      );
      for (const btn of sizeButtons) {
        const label = btn.textContent.trim().toUpperCase();
        if (label === targetSize.toUpperCase() && !btn.classList.contains('unselectable')) {
          btn.click();
          return true;
        }
      }
      return false;
    }, task.size);

    if (!sizeSelected) {
      throw new Error(`Size "${task.size}" not available`);
    }

    await waitForProductReady(page, 2500);
    logger.info(`[PokemonCenter] Size "${task.size}" selected for task ${task.id}`);
  } catch (err) {
    throw new Error(`[PokemonCenter] Size selection failed for task ${task.id}: ${err.message}`);
  }
};

const setQuantity = async (page, quantity) => {
  if (!quantity || quantity <= 1) return;
  const selectors = ['select.quantity-select', 'select[name="quantity"]', 'input[name="quantity"]', 'select.qty-selector'];
  for (const sel of selectors) {
    const el = await page.$(sel).catch(() => null);
    if (!el) continue;
    const tag = await el.evaluate((n) => n.tagName.toLowerCase());
    if (tag === 'select') {
      await page.select(sel, String(quantity)).catch(() => {});
    } else {
      await el.click({ clickCount: 3 }).catch(() => {});
      await page.keyboard.press('Backspace').catch(() => {});
      await humanType(page, sel, String(quantity));
    }
    await page.waitForFunction((selector, expected) => {
      const el = document.querySelector(selector);
      if (!el) return true;
      return String(el.value || '') === String(expected);
    }, { timeout: 2500 }, sel, quantity).catch(() => {});
    logger.info(`[PokemonCenter] Quantity set to ${quantity} via ${sel}`);
    return;
  }
  logger.warn('[PokemonCenter] Quantity selector not found — proceeding with default qty');
};

const addToCart = async ({ page, task }) => {
  logger.info(`[PokemonCenter] Adding to cart for task ${task.id}`);

  await setQuantity(page, task.quantity);

  await retryWithBackoff(async () => {
    await page.waitForSelector(ATC_SELECTORS, { timeout: TIMEOUT });
if (!(await tryRequestFirstAddToCart(page, ATC_SELECTORS))) {
      await humanClick(page, ATC_SELECTORS);
    }
    await page.waitForSelector(
      '.minicart-quantity, .cart-icon-quantity, .add-to-cart-messages, .added-to-cart, [data-cart-count]',
      { timeout: TIMEOUT }
    );
  }, { attempts: 3, baseMs: 1500, label: `addToCart task ${task.id}` });

  logger.info(`[PokemonCenter] Added to cart for task ${task.id}`);

  const cartCheck = await verifyCartHasItem(page, { timeout: 6000 });
  if (cartCheck.empty) {
    logger.warn(`[PokemonCenter] Task ${task.id} — cart appears empty after ATC (count=${cartCheck.count}); product may be OOS or session dropped`);
    const err = new Error('Cart is empty after add-to-cart — product may be out of stock');
    err.failureType = 'oos';
    throw err;
  }
};

// SFCC guest-checkout button selectors — PC uses the same DWFRM names as Topps/Demandware
const GUEST_CHECKOUT_SELECTORS = [
  'button.guest-continue',
  'button[name="dwfrm_login_unregistered"]',
  'a.guest-checkout',
  'button[data-action="guest"]',
  'button.btn-block.guest-checkout',
  'a.checkout-as-guest',
  'button.checkout-as-guest',
];

const findGuestButton = async (page, timeoutMs = 5000) =>
  await firstExistingSelector(page, GUEST_CHECKOUT_SELECTORS, timeoutMs);

const navigateToCheckout = async ({ page, task }) => {
  logger.info(`[PokemonCenter] Navigating to checkout for task ${task.id}`);

  await navigateCartUnlessReady({ page, cartUrl: CART_URL, navigate: guardedGoto, taskId: task.id, stage: 'cart_load', waitUntil: 'domcontentloaded' });

  let checkoutSelector = await firstExistingSelector(page, CHECKOUT_BUTTON_SELECTORS);
  if (!checkoutSelector) {
    await page.waitForSelector('a[href*="/checkout"], button', { timeout: TIMEOUT });
    checkoutSelector = await firstExistingSelector(page, CHECKOUT_BUTTON_SELECTORS);
  }

  let checkoutClicked = false;
  if (checkoutSelector) {
    await humanClick(page, checkoutSelector).catch(() => {});
    checkoutClicked = true;
  } else {
    checkoutClicked = Boolean(await clickTextFallback(page, ['checkout', 'proceed to checkout']));
  }

  if (!checkoutClicked) {
    await guardedGoto(page, CHECKOUT_URL, { taskId: task.id, stage: 'checkout_direct', waitUntil: 'domcontentloaded', timeout: 30000 });
  } else {
    await page.waitForNavigation({ waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
    await postClickGuard(page, { taskId: task.id, stage: 'cart_to_checkout' });
  }

  await waitForCheckoutSurface(page, TIMEOUT);

  // Handle login/guest wall — SFCC shows this before the shipping form when the
  // session has no stored account. Without clicking "Continue as Guest" the bot
  // stalls on data-checkout-stage="login" and times out waiting for "shipping".
  const guestSel = await findGuestButton(page, 5000);
  if (guestSel) {
    logger.info(`[PokemonCenter] Task ${task.id} — guest checkout wall detected, clicking "${guestSel}"`);
    await humanClick(page, guestSel);
    await waitForCheckoutSurface(page, 8000).catch(() => {});
    await postClickGuard(page, { taskId: task.id, stage: 'guest_checkout' });
    // PC may show an email-entry step between guest click and shipping form
    const emailGuestSel = 'input[name="dwfrm_login_email"], input[name="email"][id*="guest"]';
    const emailEl = await page.$(emailGuestSel).catch(() => null);
    if (emailEl) {
      const guestEmail = task.notification_email_address || task.shippingAddress?.email || '';
      if (guestEmail) {
        await humanType(page, emailGuestSel, guestEmail);
        logger.info(`[PokemonCenter] Task ${task.id} — filled guest email`);
        const continueGuestBtn = await page.$('button[name="dwfrm_login_unregistered"], button.guest-continue').catch(() => null);
        if (continueGuestBtn) {
          await humanClick(page, 'button[name="dwfrm_login_unregistered"], button.guest-continue');
          await waitForCheckoutSurface(page, 8000).catch(() => {});
          await postClickGuard(page, { taskId: task.id, stage: 'guest_email_continue' });
        }
      }
    }
  }

  logger.info(`[PokemonCenter] On checkout page for task ${task.id}`);
};

const fillField = async (page, report, name, selector, value, opts = {}) => {
  const wantsTab = opts.tabAfter !== false;
  const typeOpts = opts.dismissAutocomplete ? { tabAfter: false } : { tabAfter: wantsTab };

  const filled = await humanType(page, selector, value, typeOpts);
  if (!filled) {
    report.record(name, false, 'selector not found');
    return false;
  }

  if (opts.dismissAutocomplete) {
    await dismissAutocomplete(page);
    if (wantsTab) {
      await sleep(80);
      await page.keyboard.press('Tab').catch(() => {});
    }
  }

  if (opts.verify !== false && value) {
    const v = await verifyFieldValue(page, selector, value, opts.fieldHint || name);
    if (!v.ok) {
      logger.warn(`[Autofill] ${name} mismatch (got "${v.actual}" want "${v.expected}") — retrying once`);
      await humanType(page, selector, value, typeOpts);
      if (opts.dismissAutocomplete) {
        await dismissAutocomplete(page);
        if (wantsTab) { await sleep(80); await page.keyboard.press('Tab').catch(() => {}); }
      }
      const v2 = await verifyFieldValue(page, selector, value, opts.fieldHint || name);
      report.record(name, v2.ok, v2.ok ? '' : `got "${v2.actual}"`);
      return v2.ok;
    }
  }
  report.record(name, true);
  return true;
};

const fillShipping = async ({ page, task }) => {
  logger.info(`[PokemonCenter] Filling shipping for task ${task.id}`);

  await waitForCheckoutStage(page, 'shipping');

  const address = task.shippingAddress;
  if (!address) throw new Error('No shipping address attached to task');

  const report = new FillReport(task.id, 'shipping');
  const postal = formatPostal(address.zip, address.country);
  const phone  = stripPhone(address.phone);

  await fillField(page, report, 'firstName', 'input[name="firstName"], input[id*="firstName"]', address.first_name);
  await fillField(page, report, 'lastName',  'input[name="lastName"], input[id*="lastName"]',   address.last_name);
  await fillField(page, report, 'address1',  'input[name="address1"], input[id*="address1"]',   address.address1, { dismissAutocomplete: true });

  if (address.address2) {
    await fillField(page, report, 'address2', 'input[name="address2"], input[id*="address2"]', address.address2);
  }

  await fillField(page, report, 'city', 'input[name="city"], input[id*="city"]', address.city, { dismissAutocomplete: true });

  const stateOk = await humanSelect(page, 'select[name="stateCode"], select[name="dwfrm_shipping_shippingAddress_addressFields_states_stateCode"]', address.state);
  report.record('state', stateOk, stateOk ? '' : 'select failed');

  if (address.country) {
    const countryOk = await humanSelect(page, 'select[name="country"], select[name="dwfrm_shipping_shippingAddress_addressFields_country"]', address.country).catch(() => false);
    if (countryOk) report.record('country', true);
  }

  await fillField(page, report, 'postalCode', 'input[name="postalCode"], input[id*="postalCode"]', postal, { dismissAutocomplete: true, fieldHint: 'postal' });
  await fillField(page, report, 'phone',      'input[name="phone"], input[id*="phone"]',           phone, { fieldHint: 'phone' });
  await fillField(page, report, 'email',      'input[name="email"], input#email',                  task.notification_email_address || address.email);

  report.log();
  if (report.summary().failed.length > 0) {
    await takeFailureScreenshot(page, task.id, 'fillShipping-mismatch');
  }
  // Never submit a half-filled shipping form — abort loud instead of sailing on
  // to payment with a missing address/postal.
  // 'state'/province is filled & recorded above but intentionally NOT critical:
  // a <select> value-format mismatch (e.g. "Ontario" vs option value "ON") would
  // otherwise FALSE-abort an order whose load-bearing delivery fields are all fine.
  assertCriticalFields(report, ['firstName', 'lastName', 'address1', 'city', 'postalCode', 'phone', 'email']);

  await selectShippingMethod({ page });

  logger.info(`[PokemonCenter] Submitting shipping for task ${task.id}`);
  const shippingSubmit = await firstExistingSelector(page, SHIPPING_SUBMIT_SELECTORS);
  if (shippingSubmit) {
    await humanClick(page, shippingSubmit);
  } else if (!(await clickTextFallback(page, ['continue', 'continue to payment', 'continue to shipping']))) {
    throw new Error(`[PokemonCenter] Shipping submit control not found for task ${task.id}`);
  }
  await waitForCheckoutStage(page, 'payment', 15000).catch(() => {});
  // Keep the address the user entered if PC pops a "verify/suggested address" modal.
  await dismissAddressSuggestion(page);
  await postClickGuard(page, { taskId: task.id, stage: 'submit_shipping' });
  await waitForCheckoutStage(page, 'payment');
};

const selectShippingMethod = async ({ page }) => {
  await page.waitForSelector('.shipping-method-list', { timeout: TIMEOUT }).catch(() => {});

  const methodSelected = await page.evaluate(() => {
    const methods = document.querySelectorAll('input[name="shippingMethodID"]');
    if (methods.length > 0) {
      methods[0].click();
      return true;
    }
    return false;
  });

  if (methodSelected) {
    logger.info('[PokemonCenter] Shipping method selected');
    // No fixed post-selection sleep: the subsequent submit/stage wait is the
    // authoritative readiness signal and is faster on healthy responses.
  }
};

const fillPayment = async ({ page, task }) => {
  logger.info(`[PokemonCenter] Filling payment for task ${task.id}`);

  await waitForCheckoutStage(page, 'payment');

  const card = task.paymentProfile;
  if (!card) throw new Error('No payment profile attached to task');

  const billing = task.billingAddress || task.shippingAddress;
  if (!billing) throw new Error('No billing address attached to task');

  await requireCardIframe(page, { timeout: 15000 });

  const report = new FillReport(task.id, 'payment');

  const cardNumberSelector = 'input[name="cardNumber"], input[id*="cardNumber"], input[data-cse="encryptedCardNumber"], input[name="dwfrm_billing_creditCardFields_cardNumber"], input[autocomplete="cc-number"]';
  const cleanedCard = card.card_number.replace(/\s/g, '');

  let cardFilled = false;
  for (let attempt = 1; attempt <= 3 && !cardFilled; attempt++) {
    cardFilled = await humanTypeInFrames(page, cardNumberSelector, cleanedCard, { tabAfter: true });
    if (!cardFilled) {
      logger.warn(`[PokemonCenter] Card field fill attempt ${attempt}/3 failed — backing off ${attempt * 800}ms`);
      await sleep(attempt * 800);
      await requireCardIframe(page, { timeout: 5000 }).catch(() => {});
    }
  }
  report.record('cardNumber', cardFilled, cardFilled ? '' : 'not found in main or iframes (3 attempts)');
  if (!cardFilled) {
    const frameUrls = page.frames().map(f => f.url()).filter(u => u && u !== 'about:blank');
    throw new Error(`Card number field not found after 3 attempts. Frames present: ${frameUrls.join(' | ') || 'none'}`);
  }

  const cardTypeEl = await page.$('select[id="cardType"], select[name="cardType"]');
  if (cardTypeEl) {
    const cardType = detectCardType(card.card_number);
    if (cardType) {
      const ok = await humanSelect(page, 'select[id="cardType"], select[name="cardType"]', cardType);
      report.record('cardType', ok);
    } else {
      // Unknown BIN: better to leave the select alone (site auto-detects) than to
      // mislabel it 'Visa' and trip a card-type-mismatch decline.
      logger.warn(`[PokemonCenter] Unrecognized card BIN — leaving card-type select for the site to auto-detect (task ${task.id})`);
    }
  }

  const holderOk = await humanTypeInFrames(
    page,
    'input[name="cardOwner"], input[name="dwfrm_billing_creditCardFields_cardOwner"], input[data-cse="holderName"], input[autocomplete="cc-name"]',
    card.card_holder_name,
    { tabAfter: true }
  );
  report.record('cardOwner', holderOk, holderOk ? '' : 'not found');

  const monthSel = 'select[name="expirationMonth"], select[name="dwfrm_billing_creditCardFields_expirationMonth"]';
  let monthOk = await humanSelect(page, monthSel, card.expiration_month);
  if (!monthOk) {
    const paddedMonth = String(parseInt(card.expiration_month, 10)).padStart(2, '0');
    monthOk = await humanSelect(page, monthSel, paddedMonth).catch(() => false);
  }
  if (!monthOk) {
    monthOk = await humanTypeInFrames(page, 'input[name="expirationMonth"], input[data-cse="encryptedExpiryMonth"]', card.expiration_month, { tabAfter: true });
  }
  report.record('expirationMonth', monthOk);

  const yearSel = 'select[name="expirationYear"], select[name="dwfrm_billing_creditCardFields_expirationYear"]';
  let yearOk = await humanSelect(page, yearSel, card.expiration_year);
  if (!yearOk) {
    yearOk = await humanTypeInFrames(page, 'input[name="expirationYear"], input[data-cse="encryptedExpiryYear"]', card.expiration_year, { tabAfter: true });
  }
  report.record('expirationYear', yearOk);

  const cvvOk = await humanTypeInFrames(
    page,
    'input[name="securityCode"], input[name="dwfrm_billing_creditCardFields_securityCode"], input[data-cse="encryptedSecurityCode"], input[autocomplete="cc-csc"]',
    card.cvv,
    { tabAfter: true }
  );
  report.record('cvv', cvvOk);

  await fillBillingAddress({ page, billing, report });

  report.log();
  if (report.summary().failed.length > 0) {
    await takeFailureScreenshot(page, task.id, 'fillPayment-mismatch');
  }
  // Don't submit payment unless the card actually went in. cardNumber already
  // throws above; this catches a missing holder/expiry/CVV.
  assertCriticalFields(report, ['cardOwner', 'expirationMonth', 'expirationYear', 'cvv']);

  if (task.coupon_code) {
    await applyCoupon({ page, task });
  }

  await tryAutoCaptcha({ page, task, where: 'fillPayment-end' });

  logger.info(`[PokemonCenter] Submitting payment for task ${task.id}`);
  const paymentSubmit = await firstExistingSelector(page, PAYMENT_SUBMIT_SELECTORS);
  if (paymentSubmit) {
    await humanClick(page, paymentSubmit);
  } else if (!(await clickTextFallback(page, ['continue', 'review order', 'continue to review']))) {
    throw new Error(`[PokemonCenter] Payment submit control not found for task ${task.id}`);
  }
  await waitForCheckoutStage(page, 'placeOrder', 20000).catch(() => {});
  await postClickGuard(page, { taskId: task.id, stage: 'submit_payment' });
  await waitForCheckoutStage(page, 'placeOrder', PLACE_ORDER_TIMEOUT);
};

const tryAutoCaptcha = async ({ page, task, where }) => {
  try {
    const hasKey = await hasCaptchaApiKey();
    if (!hasKey) return;
    await handleCaptcha({ page, task, where });
  } catch (err) {
    logger.warn(`[PokemonCenter] tryAutoCaptcha(${where}) error: ${err.message}`);
  }
};

const fillBillingAddress = async ({ page, billing, report }) => {
  const sameBillingCheck = await page.$(
    'input[name="matchingShippingAddress"], input[id*="sameAsBilling"], input[id*="billingAddressSameAsShipping"]'
  );
  if (sameBillingCheck) {
    const checked = await page.evaluate((el) => el.checked, sameBillingCheck);
    if (checked) {
      logger.info('[PokemonCenter] Billing = shipping (checkbox already checked)');
      if (report) report.record('billing', true, 'same as shipping');
      return;
    }
  }

  const postal = formatPostal(billing.zip, billing.country);
  const dummyReport = report || new FillReport(0, 'billing-internal');

  await fillField(page, dummyReport, 'billing_firstName', 'input[name="billing_firstName"], input[name="dwfrm_billing_billingAddress_addressFields_firstName"]', billing.first_name);
  await fillField(page, dummyReport, 'billing_lastName',  'input[name="billing_lastName"], input[name="dwfrm_billing_billingAddress_addressFields_lastName"]',   billing.last_name);
  await fillField(page, dummyReport, 'billing_address1',  'input[name="billing_address1"], input[name="dwfrm_billing_billingAddress_addressFields_address1"]',  billing.address1, { dismissAutocomplete: true });

  if (billing.address2) {
    await fillField(page, dummyReport, 'billing_address2', 'input[name="billing_address2"], input[name="dwfrm_billing_billingAddress_addressFields_address2"]', billing.address2);
  }

  await fillField(page, dummyReport, 'billing_city', 'input[name="billing_city"], input[name="dwfrm_billing_billingAddress_addressFields_city"]', billing.city, { dismissAutocomplete: true });

  const stateOk = await humanSelect(
    page,
    'select[name="billing_stateCode"], select[name="dwfrm_billing_billingAddress_addressFields_states_stateCode"]',
    billing.state
  ).catch(() => false);
  dummyReport.record('billing_state', stateOk);

  if (billing.country) {
    const countryOk = await humanSelect(
      page,
      'select[name="billing_country"], select[name="dwfrm_billing_billingAddress_addressFields_country"]',
      billing.country
    ).catch(() => false);
    if (countryOk) dummyReport.record('billing_country', true);
  }

  await fillField(page, dummyReport, 'billing_postalCode', 'input[name="billing_postalCode"], input[name="dwfrm_billing_billingAddress_addressFields_postalCode"]', postal, { dismissAutocomplete: true, fieldHint: 'postal' });

  if (billing.phone) {
    const billingPhone = stripPhone(billing.phone);
    await fillField(page, dummyReport, 'billing_phone', 'input[name="billing_phone"], input[name="dwfrm_billing_billingAddress_addressFields_phone"]', billingPhone, { fieldHint: 'phone' }).catch(() => {});
  }
};

const applyCoupon = async ({ page, task }) => {
  try {
    const filled = await humanType(page, 'input[name="couponCode"]', task.coupon_code, { tabAfter: false });
    if (!filled) return;
    await humanClick(page, 'button.promo-code-btn, button.promo-code-submit').catch(() => {});
    await sleep(2000);
    logger.info(`[PokemonCenter] Coupon "${task.coupon_code}" applied for task ${task.id}`);
  } catch (err) {
    logger.warn(`[PokemonCenter] Coupon failed for task ${task.id}: ${err.message}`);
  }
};

// Start (once per sitekey) a background captcha pre-solver for this site, so the
// next stage/attempt can consume an already-solved token. Idempotent, and it
// never blocks the checkout path — solveOnce runs off the critical path.
const STOCKPILE_ARMED = new Set();
const armStockpile = (where, type, siteKey, pageUrl) => {
  try {
    if (!type || !siteKey) return;
    const key = `${type}::${siteKey}`;
    if (STOCKPILE_ARMED.has(key)) return;
    STOCKPILE_ARMED.add(key);
    ensureStockpiling({
      type,
      siteKey,
      pageUrl,
      targetDepth: Math.max(1, Number(process.env.CAPTCHA_STOCKPILE_DEPTH || 2)),
      refillIntervalMs: Math.max(5000, Number(process.env.CAPTCHA_STOCKPILE_REFILL_MS || 30000)),
      solveOnce: async (t, key2, url) => (t === 'hcaptcha'
        ? solveHCaptcha({ siteKey: key2, pageUrl: url })
        : solveCaptcha({ siteKey: key2, pageUrl: url }))
    });
    logger.info(`[${where}] Captcha stockpile armed for ${key}`);
  } catch (err) {
    logger.warn(`[${where}] Captcha stockpile arming failed: ${err.message}`);
  }
};

const handleCaptcha = async ({ page, task, where = 'unknown' }) => {
  try {
    const captchaInfo = await page.evaluate(() => {
      const recaptchaEl = document.querySelector('.g-recaptcha, [data-sitekey]');
      const hcaptchaEl  = document.querySelector('.h-captcha, [data-hcaptcha-sitekey]');
      const iframeRC    = document.querySelector('iframe[src*="recaptcha"]');
      const iframeHC    = document.querySelector('iframe[src*="hcaptcha"]');

      if (hcaptchaEl || iframeHC) {
        const siteKey = hcaptchaEl?.dataset?.sitekey
          || hcaptchaEl?.dataset?.hcaptchaSitekey
          || iframeHC?.src?.match(/[?&]sitekey=([^&]+)/)?.[1] || null;
        return { type: 'hcaptcha', siteKey };
      }

      if (recaptchaEl || iframeRC) {
        const siteKey = recaptchaEl?.dataset?.sitekey
          || iframeRC?.src?.match(/[?&]k=([^&]+)/)?.[1]
          || document.querySelector('textarea[name="g-recaptcha-response"]')
              ?.closest('[data-sitekey]')?.dataset?.sitekey
          || null;
        return { type: 'recaptcha', siteKey };
      }

      return null;
    });

    if (!captchaInfo) {
      logger.info(`[PokemonCenter] No captcha found on page for task ${task.id}`);
      return;
    }

    if (!captchaInfo.siteKey) {
      logger.warn(`[PokemonCenter] Captcha type "${captchaInfo.type}" detected but no sitekey found — skipping`);
      return;
    }

    logger.info(`[PokemonCenter] ${captchaInfo.type} detected (sitekey: ${captchaInfo.siteKey.slice(0, 12)}…) for task ${task.id}`);

    // Arm a background pre-solver the first time this sitekey is seen, so later
    // stages/attempts get an already-solved token instead of paying solver
    // latency inside the drop window. Idempotent per sitekey.
    armStockpile('PokemonCenter', captchaInfo.type, captchaInfo.siteKey, page.url());

    // Cheapest win first: a token pre-solved by the background stockpile, then the
    // short-lived in-process cache, and only then a real (paid) solve. On a drop
    // the stockpile is normally warm, so this path costs no solver latency.
    let token = consumeToken(captchaInfo.type, captchaInfo.siteKey)
      || getCachedToken(captchaInfo.type, captchaInfo.siteKey, page.url());
    if (!token) {
      if (captchaInfo.type === 'hcaptcha') {
        token = await solveHCaptcha({ siteKey: captchaInfo.siteKey, pageUrl: page.url(), page });
      } else {
        token = await solveCaptcha({ siteKey: captchaInfo.siteKey, pageUrl: page.url(), page });
      }
      // Feed the stockpile so the next stage/attempt reuses this solve instead of
      // paying for another one. Stored in the stockpile ONLY: the read chain
      // above already prefers it, and duplicating the token into the cache let a
      // third read replay an already-consumed token.
      if (token) depositToken(captchaInfo.type, captchaInfo.siteKey, token);
    }

    await page.evaluate(({ token, type }) => {
      if (type === 'hcaptcha') {
        const responseEl =
          document.querySelector('[name="h-captcha-response"]') ||
          document.querySelector('textarea[name="h-captcha-response"]');
        if (responseEl) {
          responseEl.value = token;
          responseEl.dispatchEvent(new Event('input', { bubbles: true }));
        }
        if (typeof hcaptcha !== 'undefined') {
          try { hcaptcha.execute(); } catch (_) {}
        }
        const widgets = document.querySelectorAll('[data-hcaptcha-widget-id]');
        widgets.forEach(w => {
          const widgetId = w.dataset.hcaptchaWidgetId;
          try { hcaptcha.close(widgetId); } catch (_) {}
          const hiddenInput = document.createElement('input');
          hiddenInput.type = 'hidden';
          hiddenInput.name = 'h-captcha-response';
          hiddenInput.value = token;
          w.appendChild(hiddenInput);
        });
      } else {
        const responseEl =
          document.getElementById('g-recaptcha-response') ||
          document.querySelector('textarea[name="g-recaptcha-response"]');
        if (responseEl) {
          responseEl.style.display = 'block';
          responseEl.value = token;
          responseEl.dispatchEvent(new Event('input', { bubbles: true }));
        }
        if (typeof ___grecaptcha_cfg !== 'undefined') {
          Object.values(___grecaptcha_cfg.clients || {}).forEach((client) => {
            const traverse = (obj, depth = 0) => {
              if (depth > 6 || !obj || typeof obj !== 'object') return;
              if (typeof obj.callback === 'function') {
                try { obj.callback(token); } catch (_) {}
              }
              Object.values(obj).forEach(v => traverse(v, depth + 1));
            };
            traverse(client);
          });
        }
      }
    }, { token, type: captchaInfo.type });

    await sleep(1200);
    logger.info(`[PokemonCenter] Captcha token injected for task ${task.id}`);
  } catch (err) {
    logger.warn(`[PokemonCenter] Captcha handling failed for task ${task.id}: ${err.message}`);
  }
};

const placeOrder = async ({ page, task, startedAt }) => {
  logger.info(`[PokemonCenter] Placing order for task ${task.id}`);

  await waitForCheckoutStage(page, 'placeOrder', PLACE_ORDER_TIMEOUT);
  const placeOrderSelector = await firstExistingSelector(page, PLACE_ORDER_SELECTORS);
  if (!placeOrderSelector) {
    const found = await page.waitForFunction(
      () => Array.from(document.querySelectorAll('button, input[type="submit"]')).some((el) => {
        const text = String(el.innerText || el.value || el.getAttribute('aria-label') || '').trim().toLowerCase();
        return !el.disabled && /(place order|submit order)/i.test(text);
      }),
      { timeout: TIMEOUT }
    ).catch(() => false);
    if (!found) throw new Error(`[PokemonCenter] Place Order control not found for task ${task.id}`);
  }

  await sleep(500);
  await tryAutoCaptcha({ page, task, where: 'placeOrder-pre' });

  const queue = await detectQueuePage(page);
  if (queue.queued) {
    logger.info(`[PokemonCenter] Task ${task.id} entered ${queue.type} queue before order — waiting`);
    const passed = await waitForQueueToPass(page, { timeout: 1800000, taskId: task.id });
    if (!passed) throw classifySiteError(new Error(`Queue timeout before Place Order (${queue.type})`), 'queue', 'placeOrder');
  }

  const guardResult = await preOrderGuard(page, { taskId: task.id });
  if (guardResult.threeDSecure) {
    // The bot can't solve bank OTP/SMS. Clicking Place Order into a 3DS challenge
    // leaves an ambiguous "did it submit?" state (double-order risk). Instead, stop
    // and wake the user loudly so they can finish this one order by hand.
    logger.warn(`[PokemonCenter] Task ${task.id} — 3D Secure detected (${guardResult.threeDSecure.url}). NOT clicking Place Order; alerting for manual action.`);
    await takeFailureScreenshot(page, task.id, 'placeOrder-3ds').catch(() => {});
    await notify({
      taskId: task.id,
      success: false,
      message: '🔐 3D Secure / bank verification required before Place Order. The bot cannot solve OTP/SMS — please finish this order manually now.',
      stage: 'place_order_3ds',
      productUrl: task.url,
      siteId: task.site_id || 6
    }).catch(() => {});
    const err = new Error('3D Secure challenge requires manual verification — stopped before Place Order to avoid an ambiguous submit');
    err.failureType = 'human_required';
    throw err;
  }

  if (placeOrderSelector) {
    await assertActionButtonIntent(page, PLACE_ORDER_SELECTORS, { stage: 'place order', allow: /place order|submit order/i });
  await humanClick(page, placeOrderSelector);
  } else {
    const clicked = await clickTextFallback(page, ['place order', 'submit order']);
    if (!clicked) throw new Error(`[PokemonCenter] Could not click Place Order for task ${task.id}`);
  }

  await page.waitForSelector(
    '#checkout-main[data-checkout-stage="submitted"], [data-checkout-stage="submitted"], .order-confirmation, .order-thank-you-msg, .order-success, [data-order-id], [class*="order-confirm" i]',
    { timeout: PLACE_ORDER_TIMEOUT * 3 }
  );

  const orderNumber = await page
    .evaluate(() => {
      const el =
        document.querySelector('.order-number') ||
        document.querySelector('[data-order-id]') ||
        document.querySelector('.summary-order-number');
      return el ? el.textContent.trim() : null;
    })
    .catch(() => null);

  if (!orderNumber) {
    logger.warn(`[PokemonCenter] Task ${task.id} — confirmation page reached but no order number found. Saving screenshot for verification.`);
  }

  logger.info(`[PokemonCenter] Order placed successfully for task ${task.id}! Order: ${orderNumber || 'N/A'}`);

  await captureOrderSuccess({
    page,
    taskId: task.id,
    orderNumber,
    productUrl: task.url,
    durationMs: Date.now() - (startedAt || Date.now())
  }).catch((err) => logger.warn(`[PokemonCenter] Order capture failed: ${err.message}`));
};

const waitForCheckoutSurface = async (page, timeoutMs = TIMEOUT) => {
  await page.waitForFunction(
    () => Boolean(
      document.querySelector('.checkout-main, #checkout-main, [data-checkout-stage], form[action*="checkout" i], input[autocomplete="cc-number"]')
    ),
    { timeout: timeoutMs }
  );
};

const waitForCheckoutStage = async (page, stage, timeoutMs = TIMEOUT) => {
  await page.waitForFunction(
    (wantedStage) => {
      const roots = Array.from(document.querySelectorAll('.checkout-main, #checkout-main, [data-checkout-stage]'));
      const stageValue = roots.map((el) => el.getAttribute('data-checkout-stage') || el.dataset?.checkoutStage || '').find(Boolean);
      if (stageValue === wantedStage) return true;

      const body = (document.body?.innerText || '').toLowerCase();
      if (wantedStage === 'shipping') {
        return Boolean(document.querySelector('input[name*="firstName" i], input[name*="address1" i]')) && !/payment|place order/.test(body);
      }
      if (wantedStage === 'payment') {
        return Boolean(document.querySelector('input[autocomplete="cc-number"], input[data-cse="encryptedCardNumber"], input[name*="cardNumber" i]'));
      }
      if (wantedStage === 'placeOrder') {
        return Array.from(document.querySelectorAll('button, input[type="submit"]')).some((el) => {
          const text = String(el.innerText || el.value || el.getAttribute('aria-label') || '');
          return !el.disabled && /(place order|submit order)/i.test(text);
        });
      }
      return false;
    },
    { timeout: timeoutMs },
    stage
  );
};

export default runPokemonCenter;
