/**
 * Per-host circuit breaker.
 *
 * Why this exists: a basic bot keeps hammering a site that is hard-blocking it,
 * which burns proxies, gets the IP/fingerprint flagged harder, and wastes time.
 * A professional bot detects sustained failure, *stops* (opens the circuit),
 * waits a cooldown, then sends a single probe before resuming. This protects the
 * proxy pool and lets a temporarily-blocked host recover instead of being beaten
 * into a permanent ban.
 *
 * States:
 *   CLOSED     → normal operation; requests flow.
 *   OPEN       → too many consecutive failures; requests are short-circuited
 *                (rejected without hitting the network) until the cooldown ends.
 *   HALF_OPEN  → cooldown elapsed; allow ONE probe. Success → CLOSED, failure → OPEN.
 */

import logger from './logger.js';

const STATES = { CLOSED: 'CLOSED', OPEN: 'OPEN', HALF_OPEN: 'HALF_OPEN' };

const DEFAULTS = {
  failureThreshold: 5,      // consecutive failures before opening
  cooldownMs: 30_000,       // base time to stay open before probing
  maxCooldownMs: 5 * 60_000,// cap on exponential cooldown growth
  halfOpenMaxProbes: 1,     // probes allowed in HALF_OPEN
  // A probe is a single in-flight request. If its caller dies (throws past the
  // breaker in a way that skips recordFailure, or the request hangs forever)
  // NOTHING ever releases the probe slot and the host stays HALF_OPEN with
  // halfOpenProbes === 1, i.e. permanently "allowing" requests that are then
  // immediately refused. After this window the slot is reclaimed.
  halfOpenMaxProbeMs: 15_000,
};

const breakers = new Map(); // host → breaker state
const MAX_BREAKERS = 512;

const pruneBreakers = () => {
  if (breakers.size <= MAX_BREAKERS) return;
  const oldest = Array.from(breakers.entries())
    .sort((a, b) => (a[1].lastTouched || 0) - (b[1].lastTouched || 0))
    .slice(0, breakers.size - Math.floor(MAX_BREAKERS * 0.9));
  for (const [host] of oldest) breakers.delete(host);
};

const getBreaker = (host, opts = {}) => {
  let b = breakers.get(host);
  if (!b) {
    pruneBreakers();
    b = {
      host,
      state: STATES.CLOSED,
      consecutiveFailures: 0,
      openedAt: 0,
      openCount: 0,        // how many times it has opened (drives exponential cooldown)
      halfOpenProbes: 0,
      probeStartedAt: 0,   // when the in-flight HALF_OPEN probe was admitted
      lastTransition: Date.now(),
      config: { ...DEFAULTS, ...opts },
      lastTouched: Date.now(),
    };
    breakers.set(host, b);
  }
  b.lastTouched = Date.now();
  return b;
};

const currentCooldown = (b) => {
  // Exponential backoff on repeated opens: cooldown * 2^(openCount-1), capped.
  const factor = Math.pow(2, Math.max(0, b.openCount - 1));
  return Math.min(b.config.cooldownMs * factor, b.config.maxCooldownMs);
};

const transition = (b, next) => {
  if (b.state === next) return;
  logger.info(`[CircuitBreaker] ${b.host}: ${b.state} → ${next}`);
  b.state = next;
  b.lastTransition = Date.now();
};

/**
 * Should we allow a request to this host right now?
 * Returns { allowed, state, retryInMs }. When not allowed, the caller should
 * skip the network entirely and treat it as a (cheap) blocked result.
 */
export const canRequest = (host, opts = {}) => {
  const b = getBreaker(host, opts);

  if (b.state === STATES.OPEN) {
    const elapsed = Date.now() - b.openedAt;
    const cooldown = currentCooldown(b);
    if (elapsed >= cooldown) {
      transition(b, STATES.HALF_OPEN);
      b.halfOpenProbes = 0;
    } else {
      return { allowed: false, state: b.state, retryInMs: cooldown - elapsed };
    }
  }

  if (b.state === STATES.HALF_OPEN) {
    const probeStale = b.halfOpenProbes > 0
      && b.probeStartedAt > 0
      && (Date.now() - b.probeStartedAt) >= b.config.halfOpenMaxProbeMs;
    if (probeStale) {
      // The probe never reported back (caller threw past us, or the request
      // hung). Reclaim the slot instead of wedging the host in HALF_OPEN.
      logger.warn(`[CircuitBreaker] ${b.host}: HALF_OPEN probe exceeded ${b.config.halfOpenMaxProbeMs}ms — reclaiming slot`);
      b.halfOpenProbes = 0;
      b.probeStartedAt = 0;
    }
    if (b.halfOpenProbes >= b.config.halfOpenMaxProbes) {
      // A probe is already in flight; hold other requests back.
      return { allowed: false, state: b.state, retryInMs: 1_000 };
    }
    b.halfOpenProbes += 1;
    b.probeStartedAt = Date.now();
    return { allowed: true, state: b.state, retryInMs: 0 };
  }

  return { allowed: true, state: b.state, retryInMs: 0 };
};

/** Record a successful, unblocked request. Closes the circuit and resets counters. */
export const recordSuccess = (host) => {
  const b = getBreaker(host);
  b.consecutiveFailures = 0;
  b.halfOpenProbes = 0;
  b.probeStartedAt = 0;
  if (b.state !== STATES.CLOSED) {
    transition(b, STATES.CLOSED);
    b.openCount = 0; // full recovery resets exponential growth
  }
};

/**
 * Record a failure (block, timeout, network error). Opens the circuit once the
 * consecutive-failure threshold is crossed, or immediately re-opens on a failed
 * HALF_OPEN probe.
 */
export const recordFailure = (host, reason = '') => {
  const b = getBreaker(host);
  b.consecutiveFailures += 1;

  if (b.state === STATES.HALF_OPEN) {
    // The probe failed — back to OPEN with a longer cooldown.
    b.openCount += 1;
    b.openedAt = Date.now();
    transition(b, STATES.OPEN);
    logger.warn(`[CircuitBreaker] ${b.host}: probe failed (${reason}) — reopening for ${(currentCooldown(b) / 1000).toFixed(0)}s`);
    return;
  }

  if (b.state === STATES.CLOSED && b.consecutiveFailures >= b.config.failureThreshold) {
    b.openCount += 1;
    b.openedAt = Date.now();
    transition(b, STATES.OPEN);
    logger.warn(`[CircuitBreaker] ${b.host}: ${b.consecutiveFailures} consecutive failures (${reason}) — opening for ${(currentCooldown(b) / 1000).toFixed(0)}s`);
  }
};

export const getState = (host) => {
  const b = breakers.get(host);
  if (!b) return { state: STATES.CLOSED, consecutiveFailures: 0 };
  return {
    state: b.state,
    consecutiveFailures: b.consecutiveFailures,
    openCount: b.openCount,
    halfOpenProbes: b.halfOpenProbes,
    retryInMs: b.state === STATES.OPEN ? Math.max(0, currentCooldown(b) - (Date.now() - b.openedAt)) : 0,
  };
};

export const getAllStates = () => {
  const out = {};
  for (const [host] of breakers) out[host] = getState(host);
  return out;
};

/** Test/maintenance helper: wipe a host's breaker (or all). */
export const reset = (host) => { host ? breakers.delete(host) : breakers.clear(); };

export { STATES };
