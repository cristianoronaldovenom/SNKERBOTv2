// Regression test: hasCaptchaApiKey() must recognise EVERY paid provider in the
// cascade. It previously omitted capsolver_api_key, so a CapSolver-only install
// reported "no solver" and every adapter's tryAutoCaptcha() bailed out early —
// the drop then ran with captchas never solved despite a funded key.
import { jest } from '@jest/globals';

jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));

let rows = [];
// The mock MUST honour the whereIn key list, otherwise a provider that was
// dropped from the query still looks configured and the regression slips by.
jest.unstable_mockModule('../../db/index.js', () => ({
  default: () => ({
    whereIn: async (column, keys) => rows.filter((r) => keys.includes(r.key))
  })
}));

const { hasCaptchaApiKey } = await import('../../helpers/checkout-guards.js');

beforeEach(() => { rows = []; });

describe('hasCaptchaApiKey provider coverage', () => {
  test('is true for a CapSolver-only configuration', async () => {
    rows = [{ key: 'capsolver_api_key', value: 'CS-KEY' }];
    await expect(hasCaptchaApiKey()).resolves.toBe(true);
  });

  test('is true for each other paid provider', async () => {
    for (const key of ['captcha_api_key', 'capmonster_api_key', 'anticaptcha_api_key']) {
      rows = [{ key, value: 'KEY' }];
      await expect(hasCaptchaApiKey()).resolves.toBe(true);
    }
  });

  test('is true when only the harvester is enabled', async () => {
    rows = [{ key: 'harvester_enabled', value: 'true' }];
    await expect(hasCaptchaApiKey()).resolves.toBe(true);
  });

  test('is false when nothing is configured or keys are blank', async () => {
    await expect(hasCaptchaApiKey()).resolves.toBe(false);
    rows = [
      { key: 'captcha_api_key', value: '' },
      { key: 'capsolver_api_key', value: '' },
      { key: 'harvester_enabled', value: 'false' }
    ];
    await expect(hasCaptchaApiKey()).resolves.toBe(false);
  });
});
