// Residential exit selection quality, region fit and monthly IP quota.
//
// `proxy-pool.js` answers "is this proxy broken?" — transport failures and
// cooldowns. It has no notion of whether a proxy is *good*, which is the wrong
// question to stop at when every request through one is billable, per-IP-limited
// and watched by a WAF.
//
// Three separate mistakes this closes:
//
//   1. No quality signal. A gateway returning 429s on the first hit scores the
//      same as one that never gets challenged, so rotation picks effectively at
//      random and re-tries the worst exits.
//   2. No region fit. A residential exit in the wrong country against a
//      geo-pinned profile is a cheap, decisive tell — the timezone, locale and
//      Accept-Language all contradict the IP.
//   3. No IP quota. Real residential plans bill or throttle per distinct IP per
//      month, and nothing tracked that, so a rotate-happy task silently burned
//      the allowance.
//
// Scoring is a pure function of counters so ordering is deterministic and
// testable, and every term is explainable in a log line.
//
// Freshness: an unused proxy scores neutral (0), never a large bonus. Otherwise a
// brand-new proxy would always win, guaranteeing one-hit rotation and defeating
// the whole point of scoring.

const W = Object.freeze({
  clean: 1.0,      // weight per clean success
  block: 2.2,      // a block is worse than a win is good — its cost repeats
  transport: 1.6,
  latency: 1 / 200, // per ms, applied to the mean
  regionMatch: 1.25,
  regionMiss: 1.5
});

const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));

const rating = (entry) => {
  const e = entry || {};
  const clean = Math.max(0, Number(e.successes) || 0);
  const blocks = Math.max(0, Number(e.blocks) || 0);
  const transport = Math.max(0, Number(e.transportFailures) || 0);
  const latency = Math.max(0, Number(e.meanLatencyMs) || 0);
  return (clean * W.clean) - (blocks * W.block) - (transport * W.transport) - (latency * W.latency);
};

const regionVerdict = ({ proxyCountry = null, profileCountry = null } = {}) => {
  const a = String(proxyCountry || '').trim().toUpperCase();
  const b = String(profileCountry || '').trim().toUpperCase();
  if (!a || !b) return { delta: 0, state: 'unknown' };
  if (a === b) return { delta: W.regionMatch, state: 'match' };
  return { delta: -W.regionMiss, state: 'miss' };
};

// `monthlyIpCap` 0/absent means unlimited (no penalty applied).
export const quotaRemaining = ({ ipsUsedThisMonth = 0, monthlyIpCap = 0 } = {}) => {
  const cap = Math.max(0, Number(monthlyIpCap) || 0);
  if (!cap) return { remaining: Infinity, exhausted: false, spentRatio: 0 };
  const used = Math.max(0, Number(ipsUsedThisMonth) || 0);
  return {
    remaining: Math.max(0, cap - used),
    exhausted: used >= cap,
    spentRatio: clamp(used / cap, 0, 1)
  };
};

export const qualityScore = ({ entry = null, proxyCountry = null, profileCountry = null, quota = null } = {}) => {
  const reasons = [];
  let score = rating(entry);

  const region = regionVerdict({ proxyCountry, profileCountry });
  if (region.delta !== 0) {
    score += region.delta;
    reasons.push(`region_${region.state}`);
  }

  // Never let quality outweigh a spent quota: a perfect proxy you cannot use is
  // worth nothing this month.
  if (quota?.exhausted) {
    score -= 1000;
    reasons.push('quota_exhausted');
  } else if (quota && quota.spentRatio >= 0.9) {
    score -= 0.8;
    reasons.push('quota_low');
  }

  return { score, region: region.state, reasons };
};

// Rank candidates best-first. `candidates` is
// [{ id, countryCode, monthlyIpCap, ipsUsedThisMonth, entry }].
export const rankProxies = ({ candidates = [], profileCountry = null } = {}) => candidates
  .map((c) => {
    const quota = quotaRemaining({
      ipsUsedThisMonth: c.ipsUsedThisMonth,
      monthlyIpCap: c.monthlyIpCap
    });
    const graded = qualityScore({
      entry: c.entry,
      proxyCountry: c.countryCode,
      profileCountry,
      quota
    });
    return { ...c, quota, ...graded };
  })
  // Stable tiebreak on id so equal scores do not oscillate between calls.
  .sort((a, b) => (b.score - a.score) || String(a.id).localeCompare(String(b.id)));

export const pickBestProxy = (opts = {}) => {
  const ranked = rankProxies(opts);
  return ranked.find((c) => !c.quota.exhausted) || ranked[0] || null;
};

export const WEIGHTS = W;
