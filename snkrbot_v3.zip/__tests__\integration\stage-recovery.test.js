import { describe, test, expect } from '@jest/globals';
import { runStageWithRecovery } from '../../helpers/stage-retry.js';

describe('stage recovery', () => {
  test('retries a transient stage failure', async () => {
    let calls = 0;
    const result = await runStageWithRecovery(async () => {
      calls += 1;
      if (calls === 1) throw new Error('Navigation failed: timeout');
      return 'ok';
    }, { taskId: 1, stage: 'fillShipping', attempts: 2, baseMs: 1 });
    expect(result).toBe('ok');
    expect(calls).toBe(2);
  });

  test('does not retry terminal OOS failures', async () => {
    let calls = 0;
    await expect(runStageWithRecovery(async () => {
      calls += 1;
      const err = new Error('Cart is empty');
      err.failureType = 'oos';
      throw err;
    }, { taskId: 1, stage: 'navigateToCheckout', attempts: 3, baseMs: 1 })).rejects.toThrow('Cart is empty');
    expect(calls).toBe(1);
  });

  test('never retries place-order by default', async () => {
    let calls = 0;
    await expect(runStageWithRecovery(async () => {
      calls += 1;
      throw new Error('Navigation failed: timeout');
    }, { taskId: 1, stage: 'placeOrder', attempts: 3, baseMs: 1 })).rejects.toThrow('timeout');
    expect(calls).toBe(1);
  });
});
