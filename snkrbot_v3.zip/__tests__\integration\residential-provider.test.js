// Residential provider targeting (Decodo / Smartproxy).
//
// The regression this guards: Topps and Pokemon Center are US-only, the gateway was
// free to return an exit anywhere on earth, and nothing pinned the country. A
// US-only shop served from a foreign residential IP is an anomaly fingerprint
// patching cannot cancel.
//
// Two invariants matter beyond correctness: an unknown provider must return the
// username untouched (so other gateways do not regress), and targeting must be
// idempotent so re-applying cannot stack directives.
import { describe, expect, test } from '@jest/globals';
import {
  SUPPORTED, applyTargeting, countryForTimezone, detectProvider,
  policyForSite, providerConfig, targetingFor
} from '../../helpers/residential-provider.js';

const env = { RESIDENTIAL_PROVIDER: 'decodo' };
const proxy = (username = 'user1') => ({ host: 'gate.decodo.com', port: 7000, username, password: 'p' });

describe('provider detection', () => {
  test('explicit env wins', () => {
    expect(detectProvider({ env: { RESIDENTIAL_PROVIDER: 'decodo' } })).toBe('decodo');
  });

  test('the host is sniffed when nothing is set', () => {
    expect(detectProvider({ env: { RESIDENTIAL_PROXY_URL: 'http://u:p@gate.decodo.com:7000' } })).toBe('decodo');
    expect(detectProvider({ env: { RESIDENTIAL_PROXY_URL: 'http://u:p@gate.smartproxy.com:7000' } })).toBe('smartproxy');
  });

  test('anything else is unsupported', () => {
    expect(detectProvider({ env: {} })).toBeNull();
    expect(detectProvider({ env: { RESIDENTIAL_PROVIDER: 'brightdata' } })).toBeNull();
    expect(detectProvider({ env: { RESIDENTIAL_PROXY_URL: 'http://other.host:1' } })).toBeNull();
  });

  test('smartproxy is listed as supported (same platform)', () => {
    expect(SUPPORTED).toContain('smartproxy');
  });
});

describe('targeting policy', () => {
  test('US-only retailers force country us', () => {
    for (const siteId of [6, 7]) {
      const t = targetingFor({ siteId, env });
      expect(t.country).toBe('us');
      expect(t.reason).toBe('us_only_retailer');
      expect(policyForSite(siteId).timezone).toBe('America/New_York');
    }
  });

  test('other sites follow the profile country instead', () => {
    const t = targetingFor({ siteId: 2, profileTimezone: 'America/Toronto', env });
    expect(t.country).toBe('ca');
    expect(t.reason).toBe('profile_country');
  });

  test('an unmapped profile leaves country off rather than guessing', () => {
    const t = targetingFor({ siteId: 2, profileTimezone: 'Asia/Tokyo', env });
    expect(t.country).toBeNull();
    expect(t.reason).toBe('unmapped');
  });

  test('an unsupported provider short-circuits', () => {
    expect(targetingFor({ siteId: 6, env: {} })).toMatchObject({ provider: null, reason: 'no_provider' });
  });

  test('countryForTimezone maps the geo table and nothing else', () => {
    expect(countryForTimezone('America/Chicago')).toBe('us');
    expect(countryForTimezone('Europe/Berlin')).toBe('de');
    expect(countryForTimezone('Asia/Tokyo')).toBeNull();
    expect(countryForTimezone(null)).toBeNull();
  });
});

describe('username composition', () => {
  test('the documented Decodo shape is produced', () => {
    const out = applyTargeting(proxy(), { provider: 'decodo', country: 'us' });
    expect(out.applied).toBe(true);
    expect(out.proxy.username).toBe('user1-country-us');
  });

  test('session is always last, because targeting stops after it', () => {
    const out = applyTargeting(proxy(), { provider: 'decodo', country: 'us', session: 'abc123' });
    expect(out.proxy.username).toBe('user1-country-us-session-abc123');
  });

  test('city sits between country and session', () => {
    const out = applyTargeting(proxy(), { provider: 'decodo', country: 'us', city: 'newyork', session: 's1' });
    expect(out.proxy.username).toBe('user1-country-us-city-newyork-session-s1');
  });

  test('re-applying does not stack directives', () => {
    const once = applyTargeting(proxy(), { provider: 'decodo', country: 'us' });
    const twice = applyTargeting(once.proxy, { provider: 'decodo', country: 'us' });
    expect(twice.proxy.username).toBe('user1-country-us');
    expect(twice.proxy.username.match(/-country-/g)).toHaveLength(1);
  });

  test('changing country replaces the old one', () => {
    const ca = applyTargeting(proxy(), { provider: 'decodo', country: 'ca' });
    expect(applyTargeting(ca.proxy, { provider: 'decodo', country: 'us' }).proxy.username).toBe('user1-country-us');
  });

  test('the caller proxy object is copied, never mutated', () => {
    const p = proxy();
    const out = applyTargeting(p, { provider: 'decodo', country: 'us' });
    expect(p.username).toBe('user1');
    expect(out.proxy).not.toBe(p);
    expect(out.proxy.password).toBe('p');
  });

  test('smartproxy uses the same dialect', () => {
    expect(applyTargeting(proxy(), { provider: 'smartproxy', country: 'us' }).proxy.username).toBe('user1-country-us');
  });
});

describe('degradation', () => {
  test('an unsupported provider passes the proxy through untouched', () => {
    const p = proxy();
    const out = applyTargeting(p, { provider: null, country: 'us' });
    expect(out.proxy).toBe(p);
    expect(out.reason).toBe('unsupported_provider');
  });

  test('nothing to apply is a no-op', () => {
    const p = proxy();
    expect(applyTargeting(p, { provider: 'decodo' }).proxy).toBe(p);
  });

  test('a proxy without a username is left alone', () => {
    expect(applyTargeting({ host: 'h', port: 1, username: '' }, { provider: 'decodo', country: 'us' }).reason)
      .toBe('no_username');
    expect(applyTargeting(null, { provider: 'decodo', country: 'us' }).proxy).toBeNull();
  });

  test('an already-correct username reports already_targeted', () => {
    expect(applyTargeting(proxy('user1-country-us'), { provider: 'decodo', country: 'us' }).reason)
      .toBe('already_targeted');
  });
});

describe('config surface', () => {
  test('reports the detected provider and the published policies', () => {
    const cfg = providerConfig({ env });
    expect(cfg.detected).toBe('decodo');
    expect(cfg.policies.map((p) => p.siteId).sort()).toEqual([6, 7]);
  });
});
