// In-process rate limiter, dependency-free.
//
// `express-rate-limit` is not installed and adding a dependency means re-running
// the install for an offline-hostile payoff. This is a fixed-window counter, which
// is enough for the two things that actually matter here: slowing password
// guessing against a single-owner login, and stopping a burst of dashboard polls
// from starving a checkout.
//
// Deliberately NOT a defence against a distributed attacker — a fixed window and an
// in-process map are trivially evaded by many IPs, and reset on restart. It is a
// speed bump against the obvious attacks, and that is stated rather than implied.
//
// The key function is injectable so login can key on username+IP while general
// routes key on IP alone.

const buckets = new Map();
const MAX_BUCKETS = 5000;

const defaultKey = (req) => req.ip || req.socket?.remoteAddress || 'unknown';

const sweep = (now) => {
  if (buckets.size < MAX_BUCKETS) return;
  for (const [k, v] of buckets) if (v.resetAt <= now) buckets.delete(k);
  while (buckets.size >= MAX_BUCKETS) {
    const first = buckets.keys().next().value;
    if (first === undefined) break;
    buckets.delete(first);
  }
};

/**
 * @param {object} opts
 * @param {number} opts.windowMs  window length
 * @param {number} opts.max       allowed hits per window
 * @param {(req)=>string} [opts.key]  bucket key builder
 * @param {string} [opts.name]    label for logging
 */
export const rateLimit = ({ windowMs, max, key = defaultKey, name = 'default' } = {}) => {
  const windowSize = Math.max(1000, Number(windowMs) || 60_000);
  const limit = Math.max(1, Number(max) || 60);

  return (req, res, next) => {
    const now = Date.now();
    sweep(now);
    const bucketKey = `${name}|${key(req)}`;
    let entry = buckets.get(bucketKey);

    if (!entry || entry.resetAt <= now) {
      entry = { count: 0, resetAt: now + windowSize };
      buckets.set(bucketKey, entry);
    }
    entry.count += 1;

    const remaining = Math.max(0, limit - entry.count);
    res.setHeader('X-RateLimit-Limit', String(limit));
    res.setHeader('X-RateLimit-Remaining', String(remaining));
    res.setHeader('X-RateLimit-Reset', String(Math.ceil(entry.resetAt / 1000)));

    if (entry.count > limit) {
      // Retry-After is the header a well-behaved SPA reads to back off.
      res.setHeader('Retry-After', String(Math.max(1, Math.ceil((entry.resetAt - now) / 1000))));
      return res.status(429).json({
        success: false,
        message: `Too many requests — retry in ${Math.ceil((entry.resetAt - now) / 1000)}s`,
        data: {}
      });
    }
    return next();
  };
};

// Key a login attempt by username AND address: one attacker must not be able to
// lock the real owner out by burning the IP bucket alone.
export const loginKey = (req) => {
  const user = String(req.body?.username || req.body?.email || '').trim().toLowerCase();
  const addr = defaultKey(req);
  return user ? `${user}|${addr}` : addr;
};

export const resetRateLimits = () => buckets.clear();
export const rateLimitBuckets = () => buckets.size;
