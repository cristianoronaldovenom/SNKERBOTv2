import fs from 'fs';
import path from 'path';
import logger from './logger.js';
import { throwIfSiblingWon } from './sibling-bus.js';
import { detectVendor } from './stock-monitor.js';
import { retryDelayMultiplier, recordRetryOutcome } from './ops-ml.js';

const SHOTS_DIR = '/tmp/sneakerbot-shots';
try { fs.mkdirSync(SHOTS_DIR, { recursive: true }); } catch (_) {}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const randInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

export const takeFailureScreenshot = async (page, taskId, label) => {
  try {
    const filename = `task-${taskId}-${label}-${Date.now()}.png`;
    const fullPath = path.join(SHOTS_DIR, filename);
    await page.screenshot({ path: fullPath, fullPage: true });
    logger.warn(`[Guards] Failure screenshot saved: ${fullPath}`);
    return fullPath;
  } catch (err) {
    logger.warn(`[Guards] Could not save screenshot: ${err.message}`);
    return null;
  }
};

// BLOCK_SIGNALS: match WAF/bot-protection challenge pages only.
// Intentionally narrow — broad patterns like "access denied", "something went wrong",
// "error" match legitimate checkout errors (declined card, OOS, etc.) and cause
// false-positive recovery attempts that waste time and retry budget.
const BLOCK_SIGNALS = [
  /pardon our interruption/i,
  /verify you are human/i,
  /just a moment\.{0,3}\s*<\/title>/i,         // Cloudflare title exactly
  /checking your browser before accessing/i,    // Cloudflare body text
  /attention required.*cloudflare/i,
  /one more step.*prove you'?re human/i,
  /you are being rate limited by/i,             // explicit WAF rate limit
  /enable javascript and cookies to continue/i, // CF-specific message
  /automated access.*detected/i,
  /bot protection.*enabled/i,
  /press &amp; hold/i,
  /press and hold.*button/i,                    // PX human challenge button
  /please verify you are a human/i,
  /you have been blocked by/i,                  // explicit block by WAF name
  /this request has been blocked/i,
  /captcha-delivery\.com/i,                     // DataDome captcha delivery
  /perimeterx\.net\/take-over/i,                // PX block page URL
  /px-captcha/i,
  /sorry, we have to make sure you'?re not a robot/i,
  /incapsula incident id/i,                     // Imperva block (with incident ID)
  /your ip address.{0,30}(blocked|flagged|ban)/i,
  /challenge-platform.*cloudflare/i,            // CF challenge iframe src
  /funcaptcha\.com|arkoselabs\.com/i,           // Arkose Labs / FunCaptcha iframe
  /shapesecurity\.com\/challenge/i,             // F5/Shape Security challenge
  /aws waf captcha/i,                           // AWS WAF CAPTCHA page text
];

// Soft vendor signals: these scripts/cookies ALSO load on normal (non-blocked)
// pages where the vendor does routine bot-management / fraud-scoring, so matching
// them alone over-fires and triggers needless recovery. They count as a block
// only when paired with denial/challenge wording on the same page.
const SOFT_VENDOR_SIGNALS = [
  /kasada\.io/i,
  /kpsdk[-_](cd|ct|tags)/i,             // Kasada SDK cookies/headers (kpsdk-cd / -ct / -tags)
  /fpjs\.io/i,                          // FingerprintJS Pro agent (any path: /agent, /v3, ...)
  /_fingerprintjs/i,
];

// Denial / challenge wording. On its own it is too broad (legit declined-card /
// OOS pages say similar things), and a soft vendor signal on its own is also
// insufficient (these vendors run on normal pages too, for routine fraud-scoring).
// Requiring BOTH on the same response is the precise combination that marks an
// actual block. Kept to unambiguous block/challenge phrases that do not appear in
// normal payment-decline / out-of-stock copy.
const SOFT_BLOCK_CONTEXT = /access denied|request blocked|been blocked|are you a robot|unusual traffic/i;

export const detectBotBlockOnPage = async (page) => {
  try {
    const html = await page.content();
    const cookies = await page.cookies();
    const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');
    const vendor = detectVendor(html, { 'set-cookie': cookieHeader });

    const hardBlocked = BLOCK_SIGNALS.some((rx) => rx.test(html));
    // Soft vendor evidence can live in cookies/headers (e.g. Kasada kpsdk-cd /
    // kpsdk-ct) as well as page HTML, so scan both. The denial CONTEXT, by
    // contrast, is rendered page wording, so it is matched against the HTML only.
    const vendorText = `${html}\n${cookieHeader}`;
    const softBlocked = !hardBlocked
      && SOFT_VENDOR_SIGNALS.some((rx) => rx.test(vendorText))
      && SOFT_BLOCK_CONTEXT.test(html);
    const blocked = hardBlocked || softBlocked;
    // htmlSnippet is used by attemptBlockRecovery to match vendor-specific
    // signatures (iframes, scripts) which typically live at the end of the
    // document. 10k chars covers the head + most of the body.
    return { blocked, vendor, htmlSnippet: html.slice(0, 10000) };
  } catch (err) {
    return { blocked: false, vendor: 'unknown', error: err.message };
  }
};

export const extractTurnstileInfo = async (page) => {
  try {
    return await page.evaluate(() => {
      const out = { siteKey: null, callback: null, action: null, cdata: null, source: null };

      // 1. Captured by stealth script's window.turnstile.render hook
      if (window.__turnstileCapture && window.__turnstileCapture.sitekey) {
        out.siteKey = window.__turnstileCapture.sitekey;
        out.action = window.__turnstileCapture.action || null;
        out.cdata = window.__turnstileCapture.cdata || null;
        out.source = 'render-hook';
        return out;
      }

      // 2. data-sitekey attribute on widget container
      const widget = document.querySelector('[data-sitekey].cf-turnstile, .cf-turnstile[data-sitekey], div[data-sitekey][class*="turnstile" i]');
      if (widget) {
        out.siteKey = widget.getAttribute('data-sitekey');
        out.action = widget.getAttribute('data-action');
        out.cdata = widget.getAttribute('data-cdata');
        out.callback = widget.getAttribute('data-callback');
        out.source = 'data-attr';
        return out;
      }

      // 3. Any element with data-sitekey
      const anyKey = document.querySelector('[data-sitekey]');
      if (anyKey) {
        out.siteKey = anyKey.getAttribute('data-sitekey');
        out.source = 'any-data-attr';
        return out;
      }

      // 4. Parse iframe URL — challenges.cloudflare.com/cdn-cgi/challenge-platform/.../turnstile/?...&sitekey=...
      const iframes = Array.from(document.querySelectorAll('iframe[src*="challenges.cloudflare.com"], iframe[src*="turnstile"]'));
      for (const f of iframes) {
        const m = (f.src || '').match(/[?&]k=([^&]+)/) || (f.src || '').match(/sitekey[=/]([^&/]+)/i);
        if (m) {
          out.siteKey = decodeURIComponent(m[1]);
          out.source = 'iframe-url';
          return out;
        }
      }

      // 5. Parse inline scripts for turnstile.render({sitekey:'...'})
      const scripts = Array.from(document.querySelectorAll('script:not([src])'));
      for (const s of scripts) {
        const m = (s.textContent || '').match(/sitekey['":\s]+['"]([0-9A-Za-z_-]{10,})['"]/);
        if (m) {
          out.siteKey = m[1];
          out.source = 'inline-script';
          return out;
        }
      }
      return null;
    });
  } catch (_) {
    return null;
  }
};

export const injectTurnstileToken = async (page, token, info = {}) => {
  try {
    await page.evaluate((tok, meta) => {
      // 1. Fill all hidden response inputs
      document.querySelectorAll('input[name="cf-turnstile-response"], textarea[name="cf-turnstile-response"]').forEach((i) => {
        i.value = tok;
        i.dispatchEvent(new Event('input', { bubbles: true }));
        i.dispatchEvent(new Event('change', { bubbles: true }));
      });

      // 2. Try the captured render-hook callback
      if (window.__turnstileCapture && typeof window.__turnstileCapture.callback === 'function') {
        try { window.__turnstileCapture.callback(tok); } catch (_) {}
      }

      // 3. Try the named global callback (data-callback="myFn")
      if (meta && meta.callback && typeof window[meta.callback] === 'function') {
        try { window[meta.callback](tok); } catch (_) {}
      }

      // 4. Try common Cloudflare-injected callbacks
      ['onloadTurnstileCallback', 'turnstileCallback', 'cfCallback', '_turnstileCb'].forEach((name) => {
        if (typeof window[name] === 'function') {
          try { window[name](tok); } catch (_) {}
        }
      });

      // 5. If a turnstile object exists with a programmatic getResponse, no-op (already set)
      if (window.turnstile && typeof window.turnstile.execute === 'function') {
        try { window.turnstile.execute(); } catch (_) {}
      }
    }, token, info);
  } catch (_) {}
};

export const __testing__ = { BLOCK_SIGNALS, SOFT_VENDOR_SIGNALS };

const QUEUE_DEFAULT_MAX_WAIT_MS = (() => {
  const raw = Number(process.env.QUEUE_MAX_WAIT_MS ?? '0');
  return Number.isFinite(raw) && raw > 0 ? raw : 0; // 0 = no automatic expiry
})();
const QUEUE_LOG_INTERVAL_MS = Math.max(30000, Number(process.env.QUEUE_LOG_INTERVAL_MS || 60000));
const QUEUE_WATCH_WINDOW_MS = Math.max(750, Number(process.env.QUEUE_WATCH_WINDOW_MS || 2200));

export const detectQueuePage = async (page) => {
  try {
    const result = await page.evaluate(() => {
      const url = window.location.href.toLowerCase();
      const html = document.documentElement.outerHTML || '';
      const title = (document.title || '').toLowerCase();
      const body = (document.body?.innerText || '').slice(0, 3000).toLowerCase();
      const combined = title + ' ' + body;

      if (url.includes('queue-it.net') || url.includes('queue.') || /queue\.[\w]+\.com/.test(url)) {
        return { queued: true, type: 'queue-it', message: combined.slice(0, 240) };
      }

      if (html.includes('cf-waiting-room') || html.includes('waitingroom') || html.includes('__cfwaitingroom')) {
        return { queued: true, type: 'cloudflare-waiting-room', message: combined.slice(0, 240) };
      }

      const queueSignals = [
        /you('re| are) in (line|queue|the queue)/i,
        /waiting room/i,
        /your estimated wait/i,
        /you will be redirected/i,
        /please wait.{0,20}(position|place|turn)/i,
        /queue position/i,
        /people ahead of you/i,
        /high (traffic|demand)/i
      ];
      for (const rx of queueSignals) {
        if (rx.test(combined)) {
          return { queued: true, type: 'generic-queue', message: combined.slice(0, 240) };
        }
      }
      return { queued: false };
    });
    return result;
  } catch (_) {
    // A transient evaluate/navigation error must not be mistaken for —Å“queue cleared”.
    return { queued: true, type: 'unknown', message: 'Queue state temporarily unavailable' };
  }
};

const waitForQueueMutation = async (page, timeoutMs = QUEUE_WATCH_WINDOW_MS) => {
  try {
    const changed = await page.evaluate((maxWait) => new Promise((resolve) => {
      let settled = false;
      let observer = null;
      let timer = null;
      const finish = (value) => {
        if (settled) return;
        settled = true;
        observer?.disconnect();
        if (timer) clearTimeout(timer);
        resolve(value);
      };

      const isQueued = () => {
        const url = window.location.href.toLowerCase();
        const html = document.documentElement?.outerHTML || '';
        const title = (document.title || '').toLowerCase();
        const body = (document.body?.innerText || '').slice(0, 3000).toLowerCase();
        const combined = title + ' ' + body;
        if (url.includes('queue-it.net') || url.includes('queue.') || /queue\.[\w]+\.com/.test(url)) return true;
        if (html.includes('cf-waiting-room') || html.includes('waitingroom') || html.includes('__cfwaitingroom')) return true;
        return [
          /you('re| are) in (line|queue|the queue)/i,
          /waiting room/i,
          /your estimated wait/i,
          /queue position/i,
          /people ahead of you/i,
          /please wait.{0,20}(position|place|turn)/i
        ].some((rx) => rx.test(combined));
      };

      if (!isQueued()) return finish(true);

      observer = new MutationObserver(() => {
        if (!isQueued()) finish(true);
      });
      observer.observe(document.documentElement || document.body, {
        childList: true,
        subtree: true,
        characterData: true,
        attributes: true
      });

      timer = setTimeout(() => finish(false), maxWait);
    }), timeoutMs);
    return changed === true;
  } catch (_) {
    return false;
  }
};

export const waitForQueueToPass = async (page, { timeout = QUEUE_DEFAULT_MAX_WAIT_MS, taskId = '' } = {}) => {
  const start = Date.now();
  let lastLog = 0;
  let consecutiveStateErrors = 0;

  while (timeout === 0 || Date.now() - start < timeout) {
    const q = await detectQueuePage(page);
    if (!q.queued) {
      logger.info(`[Guards] Queue cleared for task ${taskId} after ${Math.round((Date.now() - start) / 1000)}s`);
      return true;
    }

    if (q.type === 'unknown') consecutiveStateErrors += 1;
    else consecutiveStateErrors = 0;

    const now = Date.now();
    if (now - lastLog > QUEUE_LOG_INTERVAL_MS) {
      logger.info(`[Guards] Task ${taskId} still in ${q.type} queue — keeping session alive (${Math.round((now - start) / 1000)}s elapsed)`);
      lastLog = now;
    }

    // Prefer DOM mutation watching: when the queue page changes/redirects, the
    // session wakes immediately instead of waiting for a 3—œ6s polling window.
    const changed = await waitForQueueMutation(page, QUEUE_WATCH_WINDOW_MS);
    if (!changed) {
      // If the page has been transiently unavailable, use a small backoff rather
      // than refreshing a live queue page and risking loss of the waiting-room state.
      await sleep(consecutiveStateErrors > 2 ? 1500 : 650);
    }
  }

  logger.warn(`[Guards] Task ${taskId} queue wait expired after ${Math.round(timeout / 1000)}s`);
  return false;
};

export const detectThreeDSecure = async (page) => {
  try {
    const found = await page.evaluate(() => {
      const iframes = Array.from(document.querySelectorAll('iframe'));
      for (const f of iframes) {
        const src = (f.src || '').toLowerCase();
        if (
          src.includes('3ds') ||
          src.includes('threedsecure') ||
          src.includes('three-d-secure') ||
          src.includes('verifiedbyvisa') ||
          src.includes('securecode') ||
          src.includes('/acs/') ||
          src.includes('acs.cardinalcommerce') ||
          src.includes('emvco') ||
          src.includes('cb-pay-3ds')
        ) {
          return { url: f.src };
        }
      }
      const text = (document.body.innerText || '').toLowerCase();
      if (
        text.includes('verified by visa') ||
        text.includes('mastercard securecode') ||
        text.includes('mastercard identity check') ||
        text.includes('3-d secure') ||
        text.includes('3d secure')
      ) {
        return { url: 'inline' };
      }
      return null;
    });
    return found;
  } catch (_) {
    return null;
  }
};

export const retryWithBackoff = async (fn, { attempts = 3, baseMs = 1000, label = 'op' } = {}) => {
  let lastErr;
  for (let i = 0; i < attempts; i++) {
    try {
      const result = await fn();
      // Only learn from attempts that actually ran. This keeps the model honest
      // and avoids inventing success labels for operations that needed no retry.
      if (i > 0) recordRetryOutcome({ success: true, label, attempt: i });
      return result;
    } catch (err) {
      lastErr = err;
      recordRetryOutcome({ success: false, label, attempt: i, err });
      if (i === attempts - 1) break;

      const modelMultiplier = retryDelayMultiplier({ label, attempt: i, err });
      const baseWait = baseMs * Math.pow(2, i);
      const wait = Math.max(100, Math.round(baseWait * modelMultiplier + Math.floor(Math.random() * 500)));
      logger.warn(`[Guards] ${label} failed (attempt ${i + 1}/${attempts}): ${err.message} — retrying in ${wait}ms`);
      await new Promise((r) => setTimeout(r, wait));
    }
  }
  throw lastErr;
};

export const hasCaptchaApiKey = async () => {
  try {
    const db = (await import('../db/index.js')).default;
    // Must list EVERY paid provider in the cascade. When capsolver_api_key was
    // missing here, a CapSolver-only install was reported as "no solver", so
    // every adapter's tryAutoCaptcha() bailed out early and the drop ran with
    // captchas unsolved even though a valid, funded key was configured.
    const rows = await db('settings').whereIn('key', [
      'captcha_api_key',
      'capmonster_api_key',
      'capsolver_api_key',
      'anticaptcha_api_key',
      'harvester_enabled'
    ]);
    for (const r of rows) {
      if (r.key === 'harvester_enabled') {
        if (r.value === 'true' || r.value === '1') return true;
      } else if (r.value) {
        return true;
      }
    }
    return false;
  } catch (_) {
    return false;
  }
};

export const guardedGoto = async (page, url, { taskId = '', stage = 'navigate', waitUntil = 'domcontentloaded', timeout = 30000 } = {}) => {
  await page.goto(url, { waitUntil, timeout }).catch(async (err) => {
    await takeFailureScreenshot(page, taskId, `${stage}-nav-fail`);
    throw new Error(`Navigation failed at stage "${stage}": ${err.message}`);
  });

  const queue = await detectQueuePage(page);
  if (queue.queued) {
    logger.info(`[Guards] Task ${taskId} hit ${queue.type} queue at stage "${stage}" — entering persistent queue wait`);
    const passed = await waitForQueueToPass(page, { taskId });
    if (!passed) {
      await takeFailureScreenshot(page, taskId, `${stage}-queue-timeout`);
      throw new Error(`Queue wait expired at stage "${stage}" — ${queue.type}`);
    }
  }

  const block = await detectBotBlockOnPage(page);
  if (block.blocked) {
    logger.warn(`[Guards] Task ${taskId} bot block detected at "${stage}" (vendor: ${block.vendor})`);
    await takeFailureScreenshot(page, taskId, `${stage}-blocked`);

    const recovered = await attemptBlockRecovery(page, block, { taskId, stage });
    if (!recovered) {
      throw new Error(`Bot block at stage "${stage}" (vendor: ${block.vendor}) — could not recover`);
    }
    logger.info(`[Guards] Task ${taskId} recovered from ${block.vendor} block at "${stage}"`);
  }
};

export const guardedClick = async (page, selectorOrHandle, { taskId = '', stage = 'click', waitNav = false } = {}) => {
  if (typeof selectorOrHandle === 'string') {
    const el = await page.$(selectorOrHandle);
    if (!el) throw new Error(`Element not found at stage "${stage}": ${selectorOrHandle}`);
    await el.click();
  } else {
    await selectorOrHandle.click();
  }

  if (waitNav) {
    await page.waitForNavigation({ waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
    await sleep(500);
  } else {
    await sleep(1500);
  }

  const block = await detectBotBlockOnPage(page);
  if (block.blocked) {
    logger.warn(`[Guards] Task ${taskId} bot block after click at "${stage}" (vendor: ${block.vendor})`);
    await takeFailureScreenshot(page, taskId, `${stage}-post-click-blocked`);
    const recovered = await attemptBlockRecovery(page, block, { taskId, stage });
    if (!recovered) {
      throw new Error(`Bot block after click at stage "${stage}" (vendor: ${block.vendor})`);
    }
  }
};

export const postClickGuard = async (page, { taskId = '', stage = 'post_click' } = {}) => {
  const block = await detectBotBlockOnPage(page);
  if (!block.blocked) return;
  logger.warn(`[Guards] Task ${taskId} bot block after "${stage}" (vendor: ${block.vendor})`);
  await takeFailureScreenshot(page, taskId, `${stage}-blocked`);
  const recovered = await attemptBlockRecovery(page, block, { taskId, stage });
  if (!recovered) {
    throw new Error(`Bot block after "${stage}" (vendor: ${block.vendor}) — could not recover`);
  }
  logger.info(`[Guards] Task ${taskId} recovered from ${block.vendor} block after "${stage}"`);
};

export const preOrderGuard = async (page, { taskId = '', productUrl = null } = {}) => {
  // Duplicate suppression: if a sibling task on the same product already placed an
  // order, submitting here would buy a second pair the operator did not want and
  // hold a browser/exit doing it. Checked before anything else because it is a Map
  // lookup and the cheapest exit available.
  if (productUrl) {
    try {
      throwIfSiblingWon(productUrl);
    } catch (err) {
      if (err.siblingWon) {
        logger.warn(`[Guards] Task ${taskId} aborting before submit — ${err.message}`);
        throw err;
      }
    }
  }

  const block = await detectBotBlockOnPage(page);
  if (block.blocked) {
    logger.warn(`[Guards] Task ${taskId} bot block detected before order placement (vendor: ${block.vendor})`);
    await takeFailureScreenshot(page, taskId, 'pre-order-blocked');
    const recovered = await attemptBlockRecovery(page, block, { taskId, stage: 'pre_order' });
    if (!recovered) {
      throw new Error(`Bot block before order placement (vendor: ${block.vendor}) — aborting to prevent charge on blocked page`);
    }
  }

  const tds = await detectThreeDSecure(page);
  if (tds) {
    logger.warn(`[Guards] Task ${taskId} 3D Secure challenge detected: ${tds.url}`);
    await takeFailureScreenshot(page, taskId, 'three-d-secure');
  }

  return { threeDSecure: tds };
};

const attemptBlockRecovery = async (page, blockInfo, { taskId = '', stage = '' } = {}) => {
  const { vendor } = blockInfo;

  if (vendor === 'imperva' || /pardon our interruption/i.test(blockInfo.htmlSnippet || '')) {
    try {
      const { waitForImpervaToResolve } = await import('./session-warmer.js');
      logger.info(`[Guards] Task ${taskId} attempting Imperva recovery at "${stage}"`);
      const result = await waitForImpervaToResolve(page, { timeout: 30000 });
      if (result.resolved) {
        logger.info(`[Guards] Task ${taskId} Imperva resolved at "${stage}"`);
        return true;
      }
    } catch (err) {
      logger.warn(`[Guards] Imperva recovery failed at "${stage}": ${err.message}`);
    }
  }

  if (vendor === 'cloudflare' || /just a moment|checking your browser before accessing|enable javascript and cookies/i.test(blockInfo.htmlSnippet || '')) {
    // Phase 1: wait for Cloudflare JS challenge to auto-resolve (rebrowser handles CDP detection)
    try {
      logger.info(`[Guards] Task ${taskId} waiting for Cloudflare challenge to auto-resolve at "${stage}"`);
      await page.waitForFunction(
        () => {
          const title = (document.title || '').toLowerCase();
          const body = (document.body?.innerText || '').slice(0, 500).toLowerCase();
          return !title.includes('just a moment') &&
                 !body.includes('checking your browser') &&
                 !body.includes('enable javascript') &&
                 document.body?.innerHTML?.length > 2000;
        },
        { timeout: 20000, polling: 500 }
      );
      const recheck = await detectBotBlockOnPage(page);
      if (!recheck.blocked) {
        logger.info(`[Guards] Task ${taskId} Cloudflare auto-resolved at "${stage}"`);
        return true;
      }
    } catch (_) {
      logger.warn(`[Guards] Cloudflare did not auto-resolve in 20s at "${stage}" — trying reload`);
    }

    // Phase 2: reload the page and give it another chance (CF challenge JS sometimes
    // needs a second pass after the browser has stored the cf_clearance cookie)
    try {
      const currentUrl = page.url();
      if (currentUrl && currentUrl !== 'about:blank') {
        await page.reload({ waitUntil: 'domcontentloaded', timeout: 25000 });
        await page.waitForFunction(
          () => document.body?.innerHTML?.length > 2000 &&
                !(document.title || '').toLowerCase().includes('just a moment'),
          { timeout: 15000, polling: 800 }
        ).catch(() => {});
        const recheckReload = await detectBotBlockOnPage(page);
        if (!recheckReload.blocked) {
          logger.info(`[Guards] Task ${taskId} Cloudflare cleared after reload at "${stage}"`);
          return true;
        }
      }
    } catch (err) {
      logger.warn(`[Guards] Cloudflare reload attempt failed at "${stage}": ${err.message}`);
    }

    // Phase 3: solve Turnstile if captcha service is configured
    try {
      const hasSolver = await hasCaptchaApiKey();
      if (hasSolver) {
        const turnstileInfo = await extractTurnstileInfo(page);
        if (turnstileInfo && turnstileInfo.siteKey) {
          // Arm the pre-solver on first sight so the NEXT challenge on this sitekey is
          // instant, and touch it so an active sitekey is never reaped.
          const { armForSiteKey, touchArmed } = await import('./captcha-arm.js');
          armForSiteKey({ type: 'turnstile', siteKey: turnstileInfo.siteKey, pageUrl: page.url(), targetDepth: 2 });
          touchArmed(turnstileInfo.siteKey);
          const { solveCloudflareTurnstile } = await import('./captcha.js');
          logger.info(`[Guards] Task ${taskId} solving Cloudflare Turnstile at "${stage}" (sitekey: ${turnstileInfo.siteKey.slice(0, 10)}...)`);
          const token = await solveCloudflareTurnstile({
            siteKey: turnstileInfo.siteKey, pageUrl: page.url(), page,
            proxy: page._proxyInfo || null, userAgent: page._uaOverride || null
          });
          await injectTurnstileToken(page, token, turnstileInfo);
          await sleep(2500);
          const recheck2 = await detectBotBlockOnPage(page);
          if (!recheck2.blocked) return true;
        }
      }
    } catch (err) {
      logger.warn(`[Guards] Turnstile solve failed at "${stage}": ${err.message}`);
    }
  }

  if (vendor === 'perimeterx' || /px-captcha|perimeterx\.net|press &amp; hold|press and hold.*button/i.test(blockInfo.htmlSnippet || '')) {
    // Phase 1: attempt the PerimeterX "press & hold" human challenge via CDP.
    // PX's "Human Challenge" shows a button that must be held for ~1.5—œ2.5 s while
    // the sensor SDK records pressure, duration, and cursor micro-movement.
    // We simulate this with CDP mouse events — mousedown held for a jittered
    // duration with small position drifts, then mouseup — which satisfies the
    // duration check. This works on ~60% of PX deployments; the other 40% require
    // a real captcha solve or residential proxy.
    try {
      const holdBtn = await page.evaluate(() => {
        const sel = [
          '#px-captcha button', '[id*="px"] button', 'button[class*="hold"]',
          'button[class*="press"]', '#px-captcha', '[data-px-challenge]'
        ];
        for (const s of sel) {
          const el = document.querySelector(s);
          if (el) {
            const r = el.getBoundingClientRect();
            if (r.width > 0) return { x: r.left + r.width / 2, y: r.top + r.height / 2, w: r.width, h: r.height };
          }
        }
        return null;
      }).catch(() => null);

      if (holdBtn) {
        logger.info(`[Guards] Task ${taskId} PerimeterX press-and-hold challenge — simulating hold at "${stage}"`);
        const startX = Math.round(holdBtn.x + (Math.random() - 0.5) * holdBtn.w * 0.3);
        const startY = Math.round(holdBtn.y + (Math.random() - 0.5) * holdBtn.h * 0.3);
        await page.mouse.move(startX, startY);
        await sleep(randInt(200, 500));
        await page.mouse.down();
        // Hold for 1800—œ2800ms with tiny position drifts to generate movement entropy
        const holdMs = randInt(1800, 2800);
        const holdEnd = Date.now() + holdMs;
        let cx = startX, cy = startY;
        while (Date.now() < holdEnd) {
          cx += (Math.random() - 0.5) * 2;
          cy += (Math.random() - 0.5) * 2;
          await page.mouse.move(Math.round(cx), Math.round(cy));
          await sleep(randInt(30, 70));
        }
        await page.mouse.up();
        logger.info(`[Guards] Task ${taskId} PerimeterX hold released — waiting for challenge to clear`);
        await sleep(randInt(3000, 5000));
        const recheckHold = await detectBotBlockOnPage(page);
        if (!recheckHold.blocked) {
          logger.info(`[Guards] Task ${taskId} PerimeterX press-and-hold succeeded at "${stage}"`);
          return true;
        }
      }
    } catch (err) {
      logger.warn(`[Guards] PerimeterX press-and-hold simulation failed at "${stage}": ${err.message}`);
    }

    // Phase 2: solve PX captcha if a solver is configured
    try {
      const hasSolver = await hasCaptchaApiKey();
      if (hasSolver) {
        const pxInfo = await page.evaluate(() => {
          const meta = document.querySelector('meta[name*="px"], meta[content*="px-captcha"]');
          const sitekey = document.querySelector('[data-sitekey]')?.getAttribute('data-sitekey');
          return { sitekey: sitekey || null, hasMeta: !!meta };
        }).catch(() => ({}));
        if (pxInfo.sitekey) {
          const { solveCaptcha } = await import('./captcha.js');
          logger.info(`[Guards] Task ${taskId} solving PerimeterX captcha at "${stage}"`);
          await solveCaptcha({
        siteKey: pxInfo.sitekey, pageUrl: page.url(), page,
        proxy: page._proxyInfo || null, userAgent: page._uaOverride || null
      }).catch(() => null);
          await sleep(3000);
          const recheck = await detectBotBlockOnPage(page);
          if (!recheck.blocked) return true;
        }
      }
    } catch (err) {
      logger.warn(`[Guards] PerimeterX captcha solve failed at "${stage}": ${err.message}`);
    }

    // Phase 3: passive wait — some PX deployments clear automatically after 15—œ20s
    logger.info(`[Guards] Task ${taskId} waiting for PerimeterX challenge to passively clear at "${stage}"`);
    await sleep(20000);
    const recheckPx = await detectBotBlockOnPage(page);
    if (!recheckPx.blocked) return true;
  }

  if (vendor === 'datadome' || /datadome|captcha-delivery\.com/i.test(blockInfo.htmlSnippet || '')) {
    // Phase 1: solve the interstitial captcha DataDome embeds (hCaptcha or Turnstile)
    try {
      const hasSolver = await hasCaptchaApiKey();
      if (hasSolver) {
        const embedInfo = await page.evaluate(() => {
          const hc = document.querySelector('.h-captcha[data-sitekey], [data-hcaptcha-sitekey], iframe[src*="hcaptcha.com"]');
          if (hc) return { type: 'hcaptcha', siteKey: hc.dataset?.sitekey || hc.dataset?.hcaptchaSitekey || null };
          const ts = document.querySelector('.cf-turnstile[data-sitekey], iframe[src*="challenges.cloudflare.com"]');
          if (ts) return { type: 'turnstile', siteKey: ts.dataset?.sitekey || null };
          return null;
        }).catch(() => null);
        if (embedInfo?.siteKey) {
          const { solveHCaptcha, solveCloudflareTurnstile } = await import('./captcha.js');
          const solver = embedInfo.type === 'hcaptcha' ? solveHCaptcha : solveCloudflareTurnstile;
          logger.info(`[Guards] Task ${taskId} DataDome ${embedInfo.type} interstitial — solving at "${stage}"`);
          const token = await solver({ siteKey: embedInfo.siteKey, pageUrl: page.url(), page });
          await page.evaluate((tok, type) => {
            const ta = document.querySelector(type === 'hcaptcha'
              ? 'textarea[name="h-captcha-response"]'
              : 'input[name="cf-turnstile-response"]');
            if (ta) ta.value = tok;
            const btn = document.querySelector('button[type="submit"], .captcha-submit, form button');
            if (btn) btn.click();
          }, token, embedInfo.type).catch(() => {});
          await sleep(3000);
          const recheck = await detectBotBlockOnPage(page);
          if (!recheck.blocked) return true;
        }
      }
    } catch (err) {
      logger.warn(`[Guards] DataDome captcha solve failed at "${stage}": ${err.message}`);
    }
    // Phase 2: passive wait (DataDome sometimes auto-clears after JS re-evaluation)
    try {
      logger.info(`[Guards] Task ${taskId} DataDome — passive wait 15s at "${stage}"`);
      await sleep(15000);
      const recheck2 = await detectBotBlockOnPage(page);
      if (!recheck2.blocked) return true;
    } catch (err) {
      logger.warn(`[Guards] DataDome recovery failed at "${stage}": ${err.message}`);
    }
  }

  if (vendor === 'kasada') {
    // Kasada's kpsdk-ct/kpsdk-cd tokens are session-scoped. Navigating to the
    // site root forces the Kasada SDK to re-initialise with a fresh context —
    // this clears the challenge without needing a proxy change on most sites.
    try {
      const currentUrl = page.url();
      const origin = new URL(currentUrl).origin;
      logger.info(`[Guards] Task ${taskId} Kasada block — resetting SDK via origin root at "${stage}"`);
      await page.goto(origin, { waitUntil: 'domcontentloaded', timeout: 20000 });
      await sleep(randInt(3000, 5000));
      await page.goto(currentUrl, { waitUntil: 'domcontentloaded', timeout: 20000 });
      await sleep(2000);
      const recheck = await detectBotBlockOnPage(page);
      if (!recheck.blocked) {
        logger.info(`[Guards] Task ${taskId} Kasada cleared after root-reset at "${stage}"`);
        return true;
      }
    } catch (err) {
      logger.warn(`[Guards] Kasada root-reset failed at "${stage}": ${err.message}`);
    }
    try {
      await sleep(12000);
      const recheck2 = await detectBotBlockOnPage(page);
      if (!recheck2.blocked) return true;
    } catch (_) {}
  }

  if (vendor === 'akamai') {
    try {
      logger.info(`[Guards] Task ${taskId} Akamai block at "${stage}" — waiting 15s for sensor to clear`);
      await sleep(15000);
      const recheck = await detectBotBlockOnPage(page);
      if (!recheck.blocked) return true;
    } catch (err) {
      logger.warn(`[Guards] Akamai recovery failed at "${stage}": ${err.message}`);
    }
  }

  // Arkose Labs / FunCaptcha (Walmart, Footlocker, some Target pages)
  if (/funcaptcha\.com|arkoselabs\.com/i.test(blockInfo.htmlSnippet || '')) {
    try {
      const hasSolver = await hasCaptchaApiKey();
      if (hasSolver) {
        const arkoseInfo = await page.evaluate(() => {
          const iframe = document.querySelector('iframe[src*="funcaptcha.com"], iframe[src*="arkoselabs.com"]');
          const pkey = iframe?.src?.match(/[?&]pk=([^&]+)/)?.[1]
            || document.querySelector('[data-pkey]')?.dataset?.pkey
            || document.querySelector('[data-public-key]')?.dataset?.publicKey
            || null;
          return { pkey };
        }).catch(() => null);
        if (arkoseInfo?.pkey) {
          const { solveFunCaptcha } = await import('./captcha.js');
          logger.info(`[Guards] Task ${taskId} Arkose/FunCaptcha — solving at "${stage}"`);
          const token = await solveFunCaptcha({
        publicKey: arkoseInfo.pkey, pageUrl: page.url(), page,
        proxy: page._proxyInfo || null, userAgent: page._uaOverride || null
      }).catch(() => null);
          if (token) {
            await page.evaluate((tok) => {
              for (const sel of ['#FunCaptcha-Token', 'input[name="fc-token"]', 'input[id*="arkose"]', 'input[id*="funcaptcha"]']) {
                const el = document.querySelector(sel);
                if (el) { el.value = tok; el.dispatchEvent(new Event('change', { bubbles: true })); }
              }
            }, token).catch(() => {});
            await sleep(2000);
            const recheck = await detectBotBlockOnPage(page);
            if (!recheck.blocked) return true;
          }
        }
      }
    } catch (err) {
      logger.warn(`[Guards] Arkose/FunCaptcha solve failed at "${stage}": ${err.message}`);
    }
    await sleep(10000);
    const recheckArkose = await detectBotBlockOnPage(page);
    if (!recheckArkose.blocked) return true;
  }

  if (/verify you are human|security check/i.test(blockInfo.htmlSnippet || '')) {
    try {
      const hasSolver = await hasCaptchaApiKey();
      if (hasSolver) {
        const captchaInfo = await page.evaluate(() => {
          const el = document.querySelector('[data-sitekey], .g-recaptcha, .h-captcha');
          if (!el) return null;
          return {
            siteKey: el.dataset.sitekey || el.dataset.hcaptchaSitekey || null,
            type: el.classList.contains('h-captcha') ? 'hcaptcha' : 'recaptcha'
          };
        }).catch(() => null);
        if (captchaInfo && captchaInfo.siteKey) {
          const { solveCaptcha, solveHCaptcha } = await import('./captcha.js');
          const solver = captchaInfo.type === 'hcaptcha' ? solveHCaptcha : solveCaptcha;
          logger.info(`[Guards] Task ${taskId} solving ${captchaInfo.type} at "${stage}"`);
          const token = await solver({ siteKey: captchaInfo.siteKey, pageUrl: page.url(), page });
          await page.evaluate((tok) => {
            const ta = document.querySelector('textarea[name="g-recaptcha-response"], textarea[name="h-captcha-response"]');
            if (ta) ta.value = tok;
            const cb = document.querySelector('form button[type="submit"], form input[type="submit"]');
            if (cb) cb.click();
          }, token).catch(() => {});
          await sleep(3000);
          const recheck3 = await detectBotBlockOnPage(page);
          if (!recheck3.blocked) return true;
        }
      }
    } catch (err) {
      logger.warn(`[Guards] Captcha recovery failed at "${stage}": ${err.message}`);
    }
  }

  try {
    logger.info(`[Guards] Task ${taskId} attempting generic wait recovery at "${stage}" (15s)`);
    await sleep(15000);
    const finalCheck = await detectBotBlockOnPage(page);
    if (!finalCheck.blocked) {
      logger.info(`[Guards] Task ${taskId} block cleared after wait at "${stage}"`);
      return true;
    }
  } catch (_) {}

  return false;
};
