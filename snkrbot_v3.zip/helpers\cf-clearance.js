// Cloudflare clearance cookie persistence helper.
//
// Why this exists:
// When a user solves a Cloudflare Turnstile / JS challenge, Cloudflare sets
// a `cf_clearance` cookie. That single cookie is worth its weight in gold —
// it bypasses the entire challenge for ~30 minutes per IP+UA combination.
// Pro bots aggressively cache this cookie across runs so a single human
// solve covers dozens of attempts.
//
// Now that each task has a persistent userDataDir, Chromium itself preserves
// cookies between launches. This helper provides explicit capture/inject so
// the orchestrator can also save clearance cookies to a separate, easier-to-
// inspect JSON file and inject them on cold-start before the very first
// navigation (when userDataDir cookies haven't been loaded yet).
import path from 'node:path';
import fs from 'node:fs/promises';
import logger from './logger.js';
import { normalizeCookiesForPage } from './cookie-pool.js';

const CF_COOKIE_NAMES = ['cf_clearance', '__cf_bm', 'cf_chl_2', '_cfuvid'];

const cfPath = (taskId) => path.resolve(process.cwd(), 'profiles', `task-${taskId}`, '_cf_clearance.json');

// Capture every Cloudflare-related cookie currently in the page context.
// Returns the list that was saved (empty array if none found).
export const captureCloudflareCookies = async ({ page, taskId }) => {
  try {
    const cookies = await page.cookies();
    const cf = cookies.filter((c) => CF_COOKIE_NAMES.some((n) => c.name === n));
    if (cf.length === 0) return [];
    await fs.mkdir(path.dirname(cfPath(taskId)), { recursive: true });
    await fs.writeFile(cfPath(taskId), JSON.stringify({ savedAt: Date.now(), cookies: cf }, null, 2), 'utf8');
    logger.info(`[CF-Clearance] Task ${taskId} captured ${cf.length} CF cookie(s): ${cf.map((c) => c.name).join(', ')}`);
    return cf;
  } catch (err) {
    logger.warn(`[CF-Clearance] Capture failed for task ${taskId}: ${err.message}`);
    return [];
  }
};

// Inject saved Cloudflare cookies BEFORE the first navigation. Cookies older
// than the supplied TTL (default 25min, just under CF's typical 30min window)
// are skipped to avoid presenting expired tokens that could downscore us.
export const restoreCloudflareCookies = async ({ page, taskId, maxAgeMs = 25 * 60 * 1000 }) => {
  try {
    const raw = await fs.readFile(cfPath(taskId), 'utf8').catch(() => null);
    if (!raw) return 0;
    const { savedAt, cookies } = JSON.parse(raw);
    const age = Date.now() - savedAt;
    if (age > maxAgeMs) {
      logger.info(`[CF-Clearance] Task ${taskId} saved CF cookies are stale (${Math.round(age/1000)}s old) — skipping`);
      return 0;
    }
    if (!Array.isArray(cookies) || cookies.length === 0) return 0;
    // Normalize before injection: a stored cookie without a domain/path throws
    // in CDP and would otherwise cost us the whole clearance set against an
    // already-challenged page.
    const normalized = normalizeCookiesForPage(page.url(), cookies);
    if (normalized.length === 0) return 0;
    await page.setCookie(...normalized);
    logger.info(`[CF-Clearance] Task ${taskId} restored ${normalized.length} CF cookie(s) (age ${Math.round(age/1000)}s): ${normalized.map((c) => c.name).join(', ')}`);
    return normalized.length;
  } catch (err) {
    logger.warn(`[CF-Clearance] Restore failed for task ${taskId}: ${err.message}`);
    return 0;
  }
};
