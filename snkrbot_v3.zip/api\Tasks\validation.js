import Joi from 'joi';

export const createTaskSchema = {
  body: Joi.object({
    url: Joi.string().uri().max(2048).required(),
    site_id: Joi.number().integer().required(),
    billing_address_id: Joi.number().integer().optional(),
    shipping_address_id: Joi.number().integer().optional(),
    payment_profile_id: Joi.number().integer().optional(),
    monitor_proxy_id: Joi.number().integer().allow(null).optional(),
    checkout_proxy_id: Joi.number().integer().allow(null).optional(),
    monitor_proxy_mode: Joi.string().valid('auto', 'assigned', 'residential_env', 'direct').optional(),
    checkout_proxy_mode: Joi.string().valid('auto', 'assigned', 'residential_env', 'direct').optional(),
    proxy_id: Joi.number().integer().allow(null).optional(),
    notification_email_address: Joi.string().email().allow('').optional(),
    auto_solve_captchas: Joi.boolean().optional(),
    size: Joi.string().max(20).allow('').optional(),
    style: Joi.string().max(50).allow('').optional(),
    coupon_code: Joi.string().max(100).allow('').optional(),
    keywords: Joi.string().max(500).allow('').optional(),
    start_at: Joi.date().iso().allow(null, '').optional(),
    max_retries: Joi.number().integer().min(0).max(10).optional(),
    quick_mode: Joi.boolean().optional(),
    quantity: Joi.number().integer().min(1).max(10).optional(),
    household_limit: Joi.number().integer().min(1).max(100).allow(null).optional()
  })
};

export const updateTaskSchema = {
  body: Joi.object({
    url: Joi.string().uri().max(2048).optional(),
    site_id: Joi.number().integer().optional(),
    billing_address_id: Joi.number().integer().optional(),
    shipping_address_id: Joi.number().integer().optional(),
    payment_profile_id: Joi.number().integer().optional(),
    monitor_proxy_id: Joi.number().integer().allow(null).optional(),
    checkout_proxy_id: Joi.number().integer().allow(null).optional(),
    monitor_proxy_mode: Joi.string().valid('auto', 'assigned', 'residential_env', 'direct').optional(),
    checkout_proxy_mode: Joi.string().valid('auto', 'assigned', 'residential_env', 'direct').optional(),
    proxy_id: Joi.number().integer().allow(null).optional(),
    notification_email_address: Joi.string().email().allow('').optional(),
    auto_solve_captchas: Joi.boolean().optional(),
    size: Joi.string().max(20).allow('').optional(),
    style: Joi.string().max(50).allow('').optional(),
    coupon_code: Joi.string().max(100).allow('').optional(),
    keywords: Joi.string().max(500).allow('').optional(),
    start_at: Joi.date().iso().allow(null, '').optional(),
    max_retries: Joi.number().integer().min(0).max(10).optional(),
    quick_mode: Joi.boolean().optional(),
    quantity: Joi.number().integer().min(1).max(10).optional(),
    household_limit: Joi.number().integer().min(1).max(100).allow(null).optional()
  })
};
