import { gotScraping } from 'got-scraping';
import dns from 'node:dns/promises';
import net from 'node:net';
import logger from './logger.js';

const HEALTH_TARGETS = [
  'https://example.com/',
  'https://www.google.com/generate_204'
];

// SSRF guard: refuse to dial proxies that resolve to private/loopback/link-local
// ranges. Without this, an attacker who can create proxy rows could pivot the
// server into the internal network.
const isPrivateIPv4 = (ip) => {
  const p = ip.split('.').map(Number);
  if (p.length !== 4 || p.some((n) => Number.isNaN(n))) return true;
  return (
    p[0] === 10 ||
    p[0] === 127 ||
    (p[0] === 169 && p[1] === 254) ||
    (p[0] === 172 && p[1] >= 16 && p[1] <= 31) ||
    (p[0] === 192 && p[1] === 168) ||
    (p[0] === 100 && p[1] >= 64 && p[1] <= 127) || // CGNAT
    p[0] === 0 || p[0] >= 224
  );
};

const isPrivateIPv6 = (ip) => /^(::1|fc|fd|fe80)/i.test(ip);

// An IPv4-mapped address (::ffff:127.0.0.1) slips past the v6 regex above and
// would have been treated as public, so `net.isIP`/the prefix test alone is not
// enough for a proxy that reports a dual-stack literal.
const isMappedPrivate = (ip) => {
  const m = /^::ffff:(\d+\.\d+\.\d+\.\d+)$/i.exec(ip);
  return m ? isPrivateIPv4(m[1]) : false;
};

const assertPublicHost = async (host) => {
  // Block obvious local hostnames first.
  if (/^(localhost|.*\.local|.*\.internal)$/i.test(host)) {
    throw new Error(`refusing to test proxy at private hostname: ${host}`);
  }
  let addrs = [];
  if (net.isIP(host)) {
    addrs = [{ address: host, family: net.isIP(host) }];
  } else {
    addrs = await dns.lookup(host, { all: true });
  }
  for (const a of addrs) {
    const bad = a.family === 6
      ? (isPrivateIPv6(a.address) || isMappedPrivate(a.address))
      : isPrivateIPv4(a.address);
    if (bad) throw new Error(`refusing to test proxy resolving to private address ${a.address}`);
  }
};

const buildProxyUrl = (proxy) => {
  const auth = proxy.username ? `${encodeURIComponent(proxy.username)}:${encodeURIComponent(proxy.password || '')}@` : '';
  return `http://${auth}${proxy.host}:${proxy.port}`;
};

export const testProxy = async (proxy, { timeout = 12000 } = {}) => {
  try {
    await assertPublicHost(proxy.host);
  } catch (err) {
    logger.warn(`[ProxyHealth] blocked: ${err.message}`);
    return { proxyId: proxy.id, host: proxy.host, port: proxy.port, summary: 'blocked', okCount: 0, total: 0, avgLatency: 0, results: [], error: err.message };
  }
  const port = parseInt(proxy.port, 10);
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    return { proxyId: proxy.id, host: proxy.host, port: proxy.port, summary: 'blocked', okCount: 0, total: 0, avgLatency: 0, results: [], error: 'invalid port' };
  }
  const proxyUrl = buildProxyUrl(proxy);
  const results = await Promise.all(HEALTH_TARGETS.map(async (target) => {
    const t0 = Date.now();
    try {
      const res = await gotScraping({
        url: target,
        proxyUrl,
        timeout: { request: timeout },
        retry: { limit: 0 },
        method: 'GET',
        throwHttpErrors: false
      });
      const ms = Date.now() - t0;
      // 429 means the exit IP is rate-limited and 5xx means the gateway failed;
      // neither is a usable proxy. A 4xx from the ORIGIN (403 Cloudflare,
      // challenge pages) still proves the tunnel itself carries traffic, so the
      // bar is "< 500, except 429".
      const status = res.statusCode;
      const usable = status >= 200 && status < 500 && status !== 429;
      return {
        target, status, latencyMs: ms,
        ok: usable,
        error: usable ? null : `HTTP ${status}`
      };
    } catch (err) {
      return { target, status: 0, latencyMs: Date.now() - t0, ok: false, error: err.message?.slice(0, 200) || String(err) };
    }
  }));
  const okCount = results.filter((r) => r.ok).length;
  const avgLatency = Math.round(results.reduce((s, r) => s + r.latencyMs, 0) / results.length);
  const summary = okCount === results.length
    ? 'healthy'
    : okCount > 0 ? 'partial' : 'dead';
  logger.info(`[ProxyHealth] ${proxy.host}:${proxy.port} → ${summary} (${okCount}/${results.length} ok, avg ${avgLatency}ms)`);
  return { proxyId: proxy.id, host: proxy.host, port: proxy.port, summary, okCount, total: results.length, avgLatency, results };
};

export const testAllProxies = async (proxies) => {
  // Limited parallelism so we don't open 20 sockets at once.
  const concurrency = 4;
  const out = [];
  for (let i = 0; i < proxies.length; i += concurrency) {
    const batch = proxies.slice(i, i + concurrency);
    const r = await Promise.all(batch.map((p) => testProxy(p).catch((e) => ({ proxyId: p.id, summary: 'error', error: e.message }))));
    out.push(...r);
  }
  return out;
};
