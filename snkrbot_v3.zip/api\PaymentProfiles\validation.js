import Joi from 'joi';

export const createPaymentProfileSchema = {
  body: Joi.object({
    label: Joi.string().max(100).required(),
    card_number: Joi.string().creditCard().required(),
    card_holder_name: Joi.string().max(200).required(),
    expiration_month: Joi.string().pattern(/^(0[1-9]|1[0-2])$/).required(),
    expiration_year: Joi.string().pattern(/^\d{4}$/).required(),
    cvv: Joi.string().pattern(/^\d{3,4}$/).required()
  })
};

export const updatePaymentProfileSchema = {
  body: Joi.object({
    label: Joi.string().max(100).optional(),
    card_number: Joi.string().creditCard().optional(),
    card_holder_name: Joi.string().max(200).optional(),
    expiration_month: Joi.string().pattern(/^(0[1-9]|1[0-2])$/).optional(),
    expiration_year: Joi.string().pattern(/^\d{4}$/).optional(),
    cvv: Joi.string().pattern(/^\d{3,4}$/).optional()
  })
};
