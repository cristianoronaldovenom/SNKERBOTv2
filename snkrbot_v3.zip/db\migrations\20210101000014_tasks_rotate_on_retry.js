export const up = (knex) =>
  knex.schema.alterTable('tasks', (table) => {
    table.boolean('rotate_on_retry').nullable();
  });

export const down = (knex) =>
  knex.schema.alterTable('tasks', (table) => {
    table.dropColumn('rotate_on_retry');
  });
