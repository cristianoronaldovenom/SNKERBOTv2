import { Router } from 'express';
import * as controller from './controller.js';

const router = Router();

router.get('/', controller.findAll);
router.get('/:id', controller.findOne);
router.get('/task/:taskId', controller.findByTask);
router.delete('/:id', controller.remove);

export default router;
