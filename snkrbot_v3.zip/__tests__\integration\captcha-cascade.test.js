// Captcha cascade behaviour tests: type-aware ordering, Turnstile racing, and
// provider health cooldown. These assert *which provider gets called first*,
// which is the whole point of the ranking — a regression here costs drop window
// rather than correctness, so it has to be pinned down.
import { jest } from '@jest/globals';

jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));

jest.unstable_mockModule('../../helpers/captcha-harvester.js', () => ({
  createHarvesterChallenge: jest.fn(),
  solveInPage: jest.fn()
}));

let settings = {};
const firstMock = jest.fn(async function () {
  const key = this.__key;
  return key in settings ? { key, value: settings[key] } : undefined;
});
const db = jest.fn(() => ({
  where: (criteria) => ({ __key: criteria.key, first: firstMock })
}));
jest.unstable_mockModule('../../db/index.js', () => ({ default: db }));

const postMock = jest.fn();
const getMock = jest.fn();
jest.unstable_mockModule('axios', () => ({ default: { post: postMock, get: getMock } }));

const { solveCloudflareTurnstile, solveCaptcha, __resetCaptureState } =
  await import('../../helpers/captcha.js');

beforeEach(() => {
  settings = {};
  postMock.mockReset();
  getMock.mockReset();
  __resetCaptureState();
  jest.useFakeTimers();
});

afterEach(() => { jest.useRealTimers(); });

// Drive fake timers while a solve promise is pending. The first poll is 1.2s,
// so 6s covers it plus a couple of backoff steps. Handlers are attached eagerly
// (before the timers advance) so a provider failing mid-advance is not reported
// as an unhandled rejection, which jest can surface as a second failure.
const settle = async (promise) => {
  const pending = promise.then(
    (value) => ({ ok: true, value }),
    (error) => ({ ok: false, error })
  );
  await jest.advanceTimersByTimeAsync(6000);
  const result = await pending;
  if (!result.ok) throw result.error;
  return result.value;
};

// Which provider name owns a createTask URL.
const providerOfCreate = (url) => {
  if (url.includes('capsolver')) return 'capsolver';
  if (url.includes('capmonster')) return 'capmonster';
  if (url.includes('2captcha')) return '2captcha';
  if (url.includes('anti-captcha')) return 'anticaptcha';
  return null;
};

// 2Captcha polls over GET, the others POST. Route both verbs through one table
// so a test never has to remember which verb a provider uses.
const wire = (routes) => {
  const route = (url) => {
    const hit = routes(url);
    if (hit === undefined) throw new Error(`unexpected request ${url}`);
    return hit;
  };
  postMock.mockImplementation(async (url) => route(url));
  getMock.mockImplementation(async (url) => route(url));
};

describe('captcha provider ordering', () => {
  test('Turnstile prefers CapSolver over 2Captcha when both are configured', async () => {
    settings = { captcha_api_key: '2C-KEY', capsolver_api_key: 'CS-KEY' };
    wire((url) => {
      if (url === 'https://api.capsolver.com/createTask') {
        return { data: { errorId: 0, taskId: 'cs-1' } };
      }
      if (url === 'https://api.capsolver.com/getTaskResult') {
        return { data: { errorId: 0, status: 'ready', solution: { token: 'TS_TOKEN' } } };
      }
      if (url === 'https://2captcha.com/in.php') {
        return { data: { status: 1, request: '2c-1' } };
      }
      throw new Error(`unexpected POST ${url}`);
    });

    const token = await settle(solveCloudflareTurnstile({ siteKey: 'S', pageUrl: 'https://x.test/p' }));
    expect(token).toBe('TS_TOKEN');

    // CapSolver must occupy the FIRST submit slot — that is the ranking working.
    // With declaration order (2Captcha first) this assertion fails.
    const creates = postMock.mock.calls.map(([u]) => providerOfCreate(u)).filter(Boolean);
    expect(creates[0]).toBe('capsolver');
  });

  test('reCAPTCHA ranks 2Captcha above CapSolver and sequences it', async () => {
    settings = { captcha_api_key: '2C-KEY', capsolver_api_key: 'CS-KEY' };
    wire((url) => {
      if (url === 'https://2captcha.com/in.php') return { data: { status: 1, request: '2c-1' } };
      if (url === 'https://2captcha.com/res.php') return { data: { status: 1, request: 'RC_TOKEN' } };
      throw new Error(`unexpected POST ${url}`);
    });

    const token = await settle(solveCaptcha({ siteKey: 'K', pageUrl: 'https://x.test/p' }));
    expect(token).toBe('RC_TOKEN');
    // 2Captcha is first, and because reCAPTCHA sequences, CapSolver never runs.
    expect(postMock.mock.calls[0][0]).toBe('https://2captcha.com/in.php');
    expect(postMock.mock.calls.some(([u]) => u.includes('capsolver'))).toBe(false);
  });

  test('Turnstile races both providers concurrently and takes the first success', async () => {
    settings = { captcha_api_key: '2C-KEY', capsolver_api_key: 'CS-KEY' };
    // CapSolver dies on createTask while 2Captcha succeeds: the race must
    // resolve with the surviving token rather than reject.
    wire((url) => {
      if (url === 'https://2captcha.com/in.php') return { data: { status: 1, request: '2c-1' } };
      if (url === 'https://2captcha.com/res.php') return { data: { status: 1, request: 'RACE_WINNER' } };
      if (url === 'https://api.capsolver.com/createTask') return { data: { errorId: 1, errorDescription: 'boom' } };
      throw new Error(`unexpected POST ${url}`);
    });

    const token = await settle(solveCloudflareTurnstile({ siteKey: 'S', pageUrl: 'https://x.test/p' }));
    expect(token).toBe('RACE_WINNER');
    const creates = postMock.mock.calls.map(([u]) => providerOfCreate(u));
    expect(creates).toContain('capsolver');
    expect(creates).toContain('2captcha');
  });

  test('a provider that failed three times is skipped while in cooldown', async () => {
    settings = { captcha_api_key: '2C-KEY', capsolver_api_key: 'CS-KEY' };

    // Trip BOTH providers three times so CapSolver racks up its strikes.
    for (let i = 0; i < 3; i++) {
      wire((url) => {
        if (url.includes('2captcha')) return { data: { status: 0, request: 'ERROR' } };
        if (url.includes('capsolver')) return { data: { errorId: 1, errorDescription: 'dead' } };
        throw new Error(`unexpected ${url}`);
      });
      await expect(
        settle(solveCaptcha({ siteKey: 'K', pageUrl: 'https://x.test/p' }))
      ).rejects.toThrow(/All captcha providers failed/);
    }

    // CapSolver is now cooling down: 2Captcha succeeds and CapSolver is never
    // touched again on this attempt.
    postMock.mockClear();
    getMock.mockClear();
    wire((url) => {
      if (url === 'https://2captcha.com/in.php') return { data: { status: 1, request: '2c-9' } };
      if (url === 'https://2captcha.com/res.php') return { data: { status: 1, request: 'HEALTHY' } };
      throw new Error(`unexpected POST ${url}`);
    });
    const token = await settle(solveCaptcha({ siteKey: 'K', pageUrl: 'https://x.test/p' }));
    expect(token).toBe('HEALTHY');
    expect(postMock.mock.calls.some(([u]) => u.includes('capsolver'))).toBe(false);
  });
});
