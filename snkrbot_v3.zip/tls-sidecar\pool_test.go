package main

// Tests for the pooling / jar / decompression layer. These cover the parts that
// only show up under load on a long-lived process: pool eviction, jar growth,
// DNS-cache growth, and the decode paths. Nothing here dials the network —
// NewHttpClient only builds a transport, it does not connect.

import (
	"bytes"
	"compress/flate"
	"compress/gzip"
	"compress/zlib"
	"io"
	"net"
	"strings"
	"testing"
	"time"

	"github.com/andybalholm/brotli"
	fhttp "github.com/bogdanfinn/fhttp"
	"github.com/bogdanfinn/tls-client/profiles"
)

func resetPool() {
	clientPoolMu.Lock()
	for k, e := range clientPool {
		e.client.CloseIdleConnections()
		delete(clientPool, k)
	}
	clientPoolMu.Unlock()
}

func resetCookies() {
	cookieStoreMu.Lock()
	cookieStore = make(map[string]map[string]map[string]string)
	cookieLastUsed = make(map[string]time.Time)
	cookieStoreMu.Unlock()
}

// ── pool ────────────────────────────────────────────────────────────────────

func TestPoolKeyIsCaseInsensitiveAndProxyScoped(t *testing.T) {
	if poolKey("Chrome131", "http://p:1") != poolKey("chrome131", "http://p:1") {
		t.Fatal("profile case must not split the pool")
	}
	if poolKey("chrome131", "http://a:1") == poolKey("chrome131", "http://b:1") {
		t.Fatal("different proxies must not share a client")
	}
	if poolKey("chrome131", "") == poolKey("chrome131", "http://b:1") {
		t.Fatal("direct and proxied must not share a client")
	}
}

func TestGetClientReusesAndFlagsFreshness(t *testing.T) {
	resetPool()
	defer resetPool()

	first, fresh, err := getClient("chrome131", "")
	if err != nil {
		t.Fatalf("first getClient: %v", err)
	}
	if !fresh {
		t.Fatal("first build must report fresh=true")
	}
	second, fresh2, err := getClient("chrome131", "")
	if err != nil {
		t.Fatalf("second getClient: %v", err)
	}
	if fresh2 {
		t.Fatal("pooled client must report fresh=false so the caller can retry")
	}
	if first != second {
		t.Fatal("expected the pooled client to be reused")
	}
}

func TestEvictClientForcesRebuild(t *testing.T) {
	resetPool()
	defer resetPool()

	first, _, err := getClient("chrome131", "")
	if err != nil {
		t.Fatalf("getClient: %v", err)
	}
	evictClient("chrome131", "")
	if got := len(clientPool); got != 0 {
		t.Fatalf("pool should be empty after evict, got %d", got)
	}
	second, fresh, err := getClient("chrome131", "")
	if err != nil {
		t.Fatalf("getClient after evict: %v", err)
	}
	if !fresh {
		t.Fatal("a rebuilt client must report fresh=true")
	}
	if first == second {
		t.Fatal("expected a brand new client after eviction")
	}
}

func TestEvictUnknownKeyIsSafe(t *testing.T) {
	resetPool()
	evictClient("chrome131", "http://never-used:1")
}

func TestPoolIsHardCapped(t *testing.T) {
	resetPool()
	defer resetPool()

	for i := 0; i < maxPooledClients+8; i++ {
		proxy := "http://p" + itoa(i) + ".local:8080"
		if _, _, err := getClient("chrome131", proxy); err != nil {
			t.Fatalf("getClient %d: %v", i, err)
		}
		if n := len(clientPool); n > maxPooledClients {
			t.Fatalf("pool grew past cap: %d > %d", n, maxPooledClients)
		}
	}
}

// ── cookie jar ──────────────────────────────────────────────────────────────

func cookieResp(pairs ...string) *fhttp.Response {
	h := make(fhttp.Header, len(pairs))
	for _, p := range pairs {
		h.Add("Set-Cookie", p)
	}
	return &fhttp.Response{Header: h}
}

func TestAbsorbThenRenderCookies(t *testing.T) {
	resetCookies()
	absorbCookies("s1", "shop.example", cookieResp("a=1; Path=/", "b=2; Path=/"))

	got := cookieHeaderFor("s1", "shop.example")
	if !strings.Contains(got, "a=1") || !strings.Contains(got, "b=2") {
		t.Fatalf("expected both cookies, got %q", got)
	}
	if other := cookieHeaderFor("s1", "elsewhere.example"); other != "" {
		t.Fatalf("cookies must not leak to another host, got %q", other)
	}
	if other := cookieHeaderFor("s2", "shop.example"); other != "" {
		t.Fatalf("cookies must not leak to another session, got %q", other)
	}
}

func TestAbsorbCookieDeletion(t *testing.T) {
	resetCookies()
	absorbCookies("s1", "shop.example", cookieResp("sid=abc; Path=/"))
	if cookieHeaderFor("s1", "shop.example") == "" {
		t.Fatal("cookie should be stored first")
	}
	absorbCookies("s1", "shop.example", cookieResp("sid=; Max-Age=0; Path=/"))
	if got := cookieHeaderFor("s1", "shop.example"); got != "" {
		t.Fatalf("Max-Age=0 should delete the cookie, got %q", got)
	}
}

// The sweep must run even when a response carries no cookies at all; otherwise
// idle sessions never age out and the jar is an unbounded leak.
func TestAbsorbWithoutCookiesStillTouchesSession(t *testing.T) {
	resetCookies()
	absorbCookies("idle", "shop.example", cookieResp())
	if _, ok := cookieLastUsed["idle"]; !ok {
		t.Fatal("session should be tracked even with no Set-Cookie")
	}
}

func TestSweepDropsExpiredSessions(t *testing.T) {
	resetCookies()
	absorbCookies("old", "shop.example", cookieResp("a=1"))
	cookieStoreMu.Lock()
	cookieLastUsed["old"] = time.Now().Add(-2 * cookieSessionTTL)
	cookieStoreMu.Unlock()

	// The TTL sweep is rate-limited, so force one to run rather than
	// assuming every call sweeps.
	cookieStoreMu.Lock()
	cookieSweepAt = time.Time{}
	cookieStoreMu.Unlock()

	absorbCookies("new", "shop.example", cookieResp())

	cookieStoreMu.Lock()
	_, stillThere := cookieStore["old"]
	cookieStoreMu.Unlock()
	if stillThere {
		t.Fatal("expired session should have been swept")
	}
}

func TestSweepEnforcesSessionCeiling(t *testing.T) {
	resetCookies()
	base := time.Now()
	cookieStoreMu.Lock()
	for i := 0; i < maxCookieSessions+50; i++ {
		s := "s" + itoa(i)
		cookieStore[s] = map[string]map[string]string{"h": {"k": "v"}}
		cookieLastUsed[s] = base.Add(time.Duration(i) * time.Millisecond)
	}
	sweepCookieStoreLocked(base.Add(time.Second))
	n := len(cookieLastUsed)
	nStore := len(cookieStore)
	cookieStoreMu.Unlock()

	if n > maxCookieSessions {
		t.Fatalf("jar exceeded ceiling: %d > %d", n, maxCookieSessions)
	}
	if nStore != n {
		t.Fatalf("cookieStore (%d) and cookieLastUsed (%d) drifted apart", nStore, n)
	}
}

// The sweep must stay rate-limited: calling absorbCookies repeatedly in quick
// succession must not run it more than once per interval.
// The sweep must stay rate-limited: calling absorbCookies repeatedly in quick
// succession must not run it more than once per interval.
func TestSweepIsRateLimited(t *testing.T) {
	resetCookies()
	defer func() {
		cookieStoreMu.Lock()
		cookieSweepAt = time.Time{}
		cookieStoreMu.Unlock()
	}()

	absorbCookies("s1", "h", cookieResp())
	cookieStoreMu.Lock()
	first := cookieSweepAt
	cookieStoreMu.Unlock()
	if first.IsZero() {
		t.Fatal("first absorb should have run a sweep and stamped the time")
	}

	// A second absorb within the interval must NOT advance the stamp.
	time.Sleep(2 * time.Millisecond)
	absorbCookies("s2", "h", cookieResp())
	cookieStoreMu.Lock()
	same := cookieSweepAt.Equal(first)
	cookieStoreMu.Unlock()
	if !same {
		t.Fatal("sweep ran again inside the throttle interval")
	}

	// And advancing past the interval must allow it again.
	cookieStoreMu.Lock()
	cookieSweepAt = first.Add(-cookieSweepInterval)
	cookieStoreMu.Unlock()
	absorbCookies("s3", "h", cookieResp())
	cookieStoreMu.Lock()
	advanced := cookieSweepAt.After(first)
	cookieStoreMu.Unlock()
	if !advanced {
		t.Fatal("sweep did not run again after the interval elapsed")
	}
}

func TestEmptySessionIsNoop(t *testing.T) {
	resetCookies()
	absorbCookies("", "h", cookieResp("a=1"))
	if got := cookieHeaderFor("", "h"); got != "" {
		t.Fatalf("empty session should render nothing, got %q", got)
	}
}

// ── hostOf ──────────────────────────────────────────────────────────────────

func TestHostOf(t *testing.T) {
	cases := map[string]string{
		"https://Shop.Example.com/a/b?q=1": "shop.example.com",
		"http://shop.example.com:8443/":    "shop.example.com",
	}
	for in, want := range cases {
		if got := hostOf(in); got != want {
			t.Errorf("hostOf(%q) = %q, want %q", in, got, want)
		}
	}
	if got := hostOf("://bad"); got != "" {
		t.Errorf("hostOf(invalid) = %q, want empty", got)
	}
}

// ── decodeBody ──────────────────────────────────────────────────────────────

func encodeAs(t *testing.T, enc string, payload []byte) []byte {
	t.Helper()
	var buf bytes.Buffer
	var w io.WriteCloser
	switch enc {
	case "gzip":
		w = gzip.NewWriter(&buf)
	case "deflate":
		w = zlib.NewWriter(&buf)
	case "rawflate":
		w, _ = flate.NewWriter(&buf, flate.DefaultCompression)
	case "br":
		w = brotli.NewWriter(&buf)
	default:
		t.Fatalf("unknown encoder %s", enc)
	}
	if _, err := w.Write(payload); err != nil {
		t.Fatalf("encode: %v", err)
	}
	if err := w.Close(); err != nil {
		t.Fatalf("close: %v", err)
	}
	return buf.Bytes()
}

func TestDecodeBodyRoundTripsEveryEncoding(t *testing.T) {
	payload := []byte(strings.Repeat("<html>in stock</html>", 200))
	for _, enc := range []string{"gzip", "deflate", "rawflate", "br"} {
		header := enc
		if enc == "rawflate" {
			header = "deflate"
		}
		body := encodeAs(t, enc, payload)
		resp := &fhttp.Response{
			Header: fhttp.Header{"Content-Encoding": {header}},
			Body:   io.NopCloser(bytes.NewReader(body)),
		}
		got, err := decodeBody(resp)
		if err != nil {
			t.Fatalf("%s: decode: %v", enc, err)
		}
		if !bytes.Equal(got, payload) {
			t.Fatalf("%s: round-trip mismatch (%d bytes)", enc, len(got))
		}
	}
}

func TestDecodeBodyIdentityPassesThrough(t *testing.T) {
	payload := []byte("plain")
	resp := &fhttp.Response{Header: fhttp.Header{}, Body: io.NopCloser(bytes.NewReader(payload))}
	got, err := decodeBody(resp)
	if err != nil {
		t.Fatalf("decode: %v", err)
	}
	if !bytes.Equal(got, payload) {
		t.Fatal("identity body must be returned untouched")
	}
}

// A caller that trusts a stale Content-Length truncates a decoded body.
func TestDecodeBodyDropsStaleLengthHeaders(t *testing.T) {
	payload := []byte(strings.Repeat("x", 4096))
	body := encodeAs(t, "gzip", payload)
	resp := &fhttp.Response{
		Header: fhttp.Header{
			"Content-Encoding": {"gzip"},
			"Content-Length":   {itoa(len(body))},
		},
		Body: io.NopCloser(bytes.NewReader(body)),
	}
	if _, err := decodeBody(resp); err != nil {
		t.Fatalf("decode: %v", err)
	}
	if got := resp.Header.Get("Content-Encoding"); got != "" {
		t.Fatalf("Content-Encoding should be dropped, got %q", got)
	}
	if got := resp.Header.Get("Content-Length"); got != "" {
		t.Fatalf("stale Content-Length should be dropped, got %q", got)
	}
}

func TestDecodeBodyMalformedGzipFallsBackToRaw(t *testing.T) {
	raw := []byte("not really gzip")
	resp := &fhttp.Response{
		Header: fhttp.Header{"Content-Encoding": {"gzip"}},
		Body:   io.NopCloser(bytes.NewReader(raw)),
	}
	got, err := decodeBody(resp)
	if err != nil {
		t.Fatalf("expected graceful fallback, got error %v", err)
	}
	if !bytes.Equal(got, raw) {
		t.Fatal("expected raw bytes back")
	}
}

func TestDecodeBodyUnknownEncodingPassesThrough(t *testing.T) {
	raw := []byte("zstd-ish")
	resp := &fhttp.Response{
		Header: fhttp.Header{"Content-Encoding": {"zstd"}},
		Body:   io.NopCloser(bytes.NewReader(raw)),
	}
	got, _ := decodeBody(resp)
	if !bytes.Equal(got, raw) {
		t.Fatal("unknown encoding should pass through untouched")
	}
}

// ── DNS cache ───────────────────────────────────────────────────────────────

func TestDNSCacheIsCapped(t *testing.T) {
	dnsCacheMu.Lock()
	dnsCache = make(map[string]dnsEntry)
	now := time.Now()
	for i := 0; i < maxDNSCache; i++ {
		dnsCache["host"+itoa(i)+".example"] = dnsEntry{expires: now.Add(dnsCacheTTL)}
	}
	dnsCacheMu.Unlock()
	defer func() {
		dnsCacheMu.Lock()
		dnsCache = make(map[string]dnsEntry)
		dnsCacheMu.Unlock()
	}()

	// Every existing verdict is still fresh, so this must hard-evict rather
	// than simply pruning expired entries.
	if _, err := lookupCached("localhost"); err != nil {
		t.Fatalf("lookupCached: %v", err)
	}
	dnsCacheMu.Lock()
	n := len(dnsCache)
	dnsCacheMu.Unlock()
	if n > maxDNSCache {
		t.Fatalf("dns cache exceeded cap: %d > %d", n, maxDNSCache)
	}
}

func TestDNSVerdictExpires(t *testing.T) {
	defer func() {
		dnsCacheMu.Lock()
		dnsCache = make(map[string]dnsEntry)
		dnsCacheMu.Unlock()
	}()
	dnsCacheMu.Lock()
	dnsCache = map[string]dnsEntry{"h.example": {private: true, expires: time.Now().Add(-time.Second)}}
	dnsCacheMu.Unlock()
	if _, ok := dnsVerdict("h.example"); ok {
		t.Fatal("expired verdict must not be served")
	}
	dnsCacheMu.Lock()
	dnsCache = map[string]dnsEntry{"h.example": {private: true, expires: time.Now().Add(time.Minute)}}
	dnsCacheMu.Unlock()
	if v, ok := dnsVerdict("H.Example"); !ok || !v.private {
		t.Fatal("fresh verdict should be served case-insensitively")
	}
}

// ── misc guards ─────────────────────────────────────────────────────────────

func TestIPIsPrivate(t *testing.T) {
	priv := []string{"127.0.0.1", "10.1.2.3", "192.168.1.1", "172.16.0.1", "169.254.169.254", "::1", "fd00:ec2::254"}
	for _, s := range priv {
		if !ipIsPrivate(net.ParseIP(s)) {
			t.Errorf("%s should be private", s)
		}
	}
	for _, s := range []string{"1.1.1.1", "8.8.8.8", "104.16.0.1"} {
		if ipIsPrivate(net.ParseIP(s)) {
			t.Errorf("%s should be public", s)
		}
	}
}

func profileName(p profiles.ClientProfile) string {
	return p.GetClientHelloStr()
}

func TestResolveProfileMapsAndDefaults(t *testing.T) {
	if got := profileName(resolveProfile("")); got != profileName(profiles.Chrome_131) {
		t.Fatalf("empty profile should default to Chrome_131, got %q", got)
	}
	if got := profileName(resolveProfile("chrome131")); got != profileName(profiles.Chrome_131) {
		t.Fatalf("chrome131 mismatch: %q", got)
	}
	if got := profileName(resolveProfile("CHROME120")); got != profileName(profiles.Chrome_120) {
		t.Fatalf("profile names should be case-insensitive, got %q", got)
	}
	if got := profileName(resolveProfile("nonsense")); got != profileName(profiles.Chrome_131) {
		t.Fatalf("unknown profile should fall back to Chrome_131, got %q", got)
	}
	// A browser-name remap must be observable: the firefox profile is a
	// genuinely different ClientHello, unlike chrome131 vs its PSK variant
	// (both of which report the same "Chrome" ClientHelloID name).
	if profileName(resolveProfile("firefox120")) == profileName(resolveProfile("chrome131")) {
		t.Fatal("firefox120 should resolve to a different ClientHello than chrome131")
	}
}

func itoa(n int) string {
	if n == 0 {
		return "0"
	}
	var b []byte
	for n > 0 {
		b = append([]byte{byte('0' + n%10)}, b...)
		n /= 10
	}
	return string(b)
}
