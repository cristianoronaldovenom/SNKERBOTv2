export const up = async (knex) => {
  await knex.schema.alterTable('tasks', (table) => {
    table.index(['site_id', 'is_deleted', 'disabled_at'], 'tasks_site_active_idx');
  });
  await knex.schema.alterTable('logs', (table) => {
    table.index(['level', 'created_at'], 'logs_level_created_idx');
    table.index(['created_at'], 'logs_created_idx');
  });
};

export const down = async (knex) => {
  await knex.schema.alterTable('logs', (table) => {
    table.dropIndex('logs_level_created_idx');
    table.dropIndex('logs_created_idx');
  });
  await knex.schema.alterTable('tasks', (table) => {
    table.dropIndex('tasks_site_active_idx');
  });
};
