export const up = async (knex) => {
  const addIfMissing = async (key, value) => {
    const exists = await knex('settings').where({ key }).first();
    if (!exists) await knex('settings').insert({ key, value });
  };

  await addIfMissing('max_armed_tasks_per_host', '100');

  // Only upgrade the previous shipped defaults; preserve user-customized values.
  await knex('settings').where({ key: 'max_armed_tasks', value: '30' }).update({ value: '1000' });
  await knex('settings').where({ key: 'max_concurrent_per_host', value: '5' }).update({ value: '100' });
  await knex('settings').where({ key: 'max_concurrent_runs', value: '16' }).update({ value: '24' });
};

export const down = async (knex) => {
  await knex('settings').where({ key: 'max_armed_tasks_per_host' }).del();
};
