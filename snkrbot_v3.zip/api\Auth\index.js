import { Router } from 'express';
import crypto from 'crypto';
import db from '../../db/index.js';
import { hashPassword, verifyPassword, isFirstRun } from '../../helpers/auth.js';
import { sendApprovalRequestEmail, sendApprovalResultEmail } from '../../helpers/email.js';
import logger from '../../helpers/logger.js';

const router = Router();

const getOwner = () => db('users').where({ role: 'owner' }).first();

const approvalPage = (title, color, message, extra = '') => `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>SneakerBot — ${title}</title>
  <link rel="stylesheet" href="/css/style.css"/>
  <style>
    .auth-wrap { display:flex; align-items:center; justify-content:center; min-height:100vh; }
    .auth-card { background:var(--surface); border:1px solid var(--border); border-radius:12px; padding:40px 48px; width:100%; max-width:480px; text-align:center; }
    .auth-card h2 { font-size:1.4rem; margin-bottom:12px; color:${color}; }
    .auth-card p  { color:var(--text-mute); margin-bottom:24px; }
    .auth-card a  { color:var(--neon); text-decoration:none; font-weight:600; }
    .auth-card a:hover { text-decoration:underline; }
  </style>
</head>
<body>
  <div class="auth-wrap">
    <div class="auth-card">
      <div class="logo" style="font-size:1.8rem;margin-bottom:24px;">&#9889; SneakerBot</div>
      <h2>${title}</h2>
      <p>${message}</p>
      ${extra}
      <a href="/">← Back to dashboard</a>
    </div>
  </div>
</body>
</html>`;

// GET /setup — first-time owner creation page
router.get('/setup', async (req, res) => {
  if (req.session?.userId) return res.redirect('/');
  const first = await isFirstRun().catch(() => false);
  if (!first) return res.redirect('/login');
  res.sendFile('setup.html', { root: 'public' });
});

// POST /auth/setup — create owner account
router.post('/auth/setup', async (req, res) => {
  try {
    if (req.session?.userId) return res.redirect('/');
    const first = await isFirstRun();
    if (!first) return res.status(403).json({ success: false, message: 'Setup already complete — log in instead.', data: {} });

    const { username, email, password } = req.body;
    if (!username?.trim() || !email?.trim() || !password) {
      return res.status(400).json({ success: false, message: 'All fields are required.', data: {} });
    }
    if (password.length < 8) {
      return res.status(400).json({ success: false, message: 'Password must be at least 8 characters.', data: {} });
    }

    const password_hash = await hashPassword(password);
    const [user] = await db('users')
      .insert({ username: username.trim(), email: email.trim().toLowerCase(), password_hash, role: 'owner' })
      .returning('*');

    req.session.userId   = user.id;
    req.session.username = user.username;
    req.session.role     = user.role;
    logger.info(`[Auth] Owner account created: ${user.username} (${user.email})`);
    req.session.save((saveErr) => {
      if (saveErr) logger.warn(`[Auth] Session save warning (non-fatal): ${saveErr.message}`);
      return res.json({ success: true, message: 'Owner account created.', data: { id: user.id, username: user.username, role: user.role } });
    });
  } catch (err) {
    if (err.message?.includes('unique')) {
      return res.status(409).json({ success: false, message: 'Email or username already taken.', data: {} });
    }
    logger.error(`[Auth] Setup error: ${err.message}`);
    return res.status(500).json({ success: false, message: 'Server error.', data: {} });
  }
});

// GET /login
router.get('/login', (req, res) => {
  if (req.session?.userId) return res.redirect('/');
  res.sendFile('login.html', { root: 'public' });
});

// POST /auth/login
router.post('/auth/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username?.trim() || !password) {
      return res.status(400).json({ success: false, message: 'Username and password are required.', data: {} });
    }
    const lower = username.trim().toLowerCase();
    const user = await db('users')
      .whereRaw('lower(username) = ?', [lower])
      .orWhereRaw('lower(email) = ?', [lower])
      .first();

    if (!user || !(await verifyPassword(password, user.password_hash))) {
      return res.status(401).json({ success: false, message: 'Invalid username or password.', data: {} });
    }

    req.session.userId   = user.id;
    req.session.username = user.username;
    req.session.role     = user.role;
    logger.info(`[Auth] Login: ${user.username}`);
    req.session.save((saveErr) => {
      if (saveErr) logger.warn(`[Auth] Session save warning (non-fatal): ${saveErr.message}`);
      return res.json({ success: true, message: 'Logged in.', data: { id: user.id, username: user.username, role: user.role } });
    });
  } catch (err) {
    logger.error(`[Auth] Login error: ${err.message}`);
    return res.status(500).json({ success: false, message: 'Server error.', data: {} });
  }
});

// GET /logout
router.get('/logout', (req, res) => {
  const name = req.session?.username;
  req.session.destroy(() => {
    res.clearCookie('sneakerbot.sid');
    if (name) logger.info(`[Auth] Logout: ${name}`);
    res.redirect('/login');
  });
});

// GET /register
router.get('/register', (req, res) => {
  if (req.session?.userId) return res.redirect('/');
  res.sendFile('register.html', { root: 'public' });
});

// POST /auth/register — send approval request to owner
router.post('/auth/register', async (req, res) => {
  try {
    if (req.session?.userId) return res.redirect('/');

    const { username, email, password } = req.body;
    if (!username?.trim() || !email?.trim() || !password) {
      return res.status(400).json({ success: false, message: 'All fields are required.', data: {} });
    }
    if (password.length < 8) {
      return res.status(400).json({ success: false, message: 'Password must be at least 8 characters.', data: {} });
    }

    const uname = username.trim();
    const mail  = email.trim().toLowerCase();

    const existing = await db('users').whereRaw('lower(email)=?', [mail]).orWhereRaw('lower(username)=?', [uname.toLowerCase()]).first();
    if (existing) {
      return res.status(409).json({ success: false, message: 'Email or username already taken.', data: {} });
    }
    const pending = await db('pending_registrations').whereRaw('lower(email)=?', [mail]).orWhereRaw('lower(username)=?', [uname.toLowerCase()]).first();
    if (pending) {
      return res.status(409).json({ success: false, message: 'A request for this email/username is already pending approval.', data: {} });
    }

    const password_hash = await hashPassword(password);
    const token = crypto.randomBytes(48).toString('hex');
    await db('pending_registrations').insert({ email: mail, username: uname, password_hash, token });

    const owner = await getOwner();
    if (owner) {
      const base = process.env.PUBLIC_URL || process.env.APP_URL || `http://localhost:${process.env.PORT || 3000}`;
      await sendApprovalRequestEmail({
        ownerEmail:  owner.email,
        newUsername: uname,
        newEmail:    mail,
        approveUrl:  `${base}/auth/approve/${token}`,
        declineUrl:  `${base}/auth/decline/${token}`
      }).catch((e) => logger.warn(`[Auth] Approval email error: ${e.message}`));
    } else {
      logger.warn('[Auth] No owner found — approval email not sent');
    }

    logger.info(`[Auth] New registration request: ${uname} (${mail})`);
    return res.json({ success: true, message: 'Request sent! The owner will review it and email you.', data: {} });
  } catch (err) {
    logger.error(`[Auth] Register error: ${err.message}`);
    return res.status(500).json({ success: false, message: 'Server error.', data: {} });
  }
});

// GET /auth/approve/:token
router.get('/auth/approve/:token', async (req, res) => {
  try {
    const pending = await db('pending_registrations').where({ token: req.params.token }).first();
    if (!pending) {
      return res.status(404).send(approvalPage('Invalid Link', 'var(--red)', 'This link is invalid or has already been used.'));
    }

    const [user] = await db('users').insert({
      email:         pending.email,
      username:      pending.username,
      password_hash: pending.password_hash,
      role:          'user'
    }).returning('*');

    await db('pending_registrations').where({ token: req.params.token }).delete();

    await sendApprovalResultEmail({ to: pending.email, username: pending.username, approved: true })
      .catch((e) => logger.warn(`[Auth] Approval result email error: ${e.message}`));

    logger.info(`[Auth] Approved: ${user.username} (${user.email})`);
    return res.send(approvalPage(
      '✅ Account Approved',
      'var(--neon)',
      `<strong>${user.username}</strong> (${user.email}) has been approved and can now log in.`,
      `<p style="margin-bottom:16px"><a href="/login" style="color:var(--neon)">Go to login →</a></p>`
    ));
  } catch (err) {
    logger.error(`[Auth] Approve error: ${err.message}`);
    return res.status(500).send('Server error');
  }
});

// GET /auth/decline/:token
router.get('/auth/decline/:token', async (req, res) => {
  try {
    const pending = await db('pending_registrations').where({ token: req.params.token }).first();
    if (!pending) {
      return res.status(404).send(approvalPage('Invalid Link', 'var(--red)', 'This link is invalid or has already been used.'));
    }

    await db('pending_registrations').where({ token: req.params.token }).delete();

    await sendApprovalResultEmail({ to: pending.email, username: pending.username, approved: false })
      .catch((e) => logger.warn(`[Auth] Decline email error: ${e.message}`));

    logger.info(`[Auth] Declined: ${pending.username} (${pending.email})`);
    return res.send(approvalPage(
      '❌ Request Declined',
      'var(--magenta)',
      `The registration request from <strong>${pending.username}</strong> (${pending.email}) has been declined and they have been notified.`
    ));
  } catch (err) {
    logger.error(`[Auth] Decline error: ${err.message}`);
    return res.status(500).send('Server error');
  }
});

// GET /admin — serve the admin page (owner only, redirect others)
router.get('/admin', (req, res) => {
  if (!req.session?.userId) return res.redirect('/login');
  if (req.session?.role !== 'owner') return res.redirect('/');
  res.sendFile('admin.html', { root: 'public' });
});

// GET /auth/admin/pending — list pending registration requests (owner only)
router.get('/auth/admin/pending', async (req, res) => {
  if (!req.session?.userId || req.session?.role !== 'owner') {
    return res.status(403).json({ success: false, message: 'Forbidden', data: {} });
  }
  try {
    const rows = await db('pending_registrations').select('token', 'username', 'email', 'created_at').orderBy('created_at', 'desc');
    return res.json({ success: true, message: '', data: rows });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message, data: {} });
  }
});

// GET /auth/admin/users — list all active users (owner only)
router.get('/auth/admin/users', async (req, res) => {
  if (!req.session?.userId || req.session?.role !== 'owner') {
    return res.status(403).json({ success: false, message: 'Forbidden', data: {} });
  }
  try {
    const rows = await db('users').select('id', 'username', 'email', 'role', 'created_at').orderBy('created_at', 'asc');
    return res.json({ success: true, message: '', data: rows });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message, data: {} });
  }
});

// POST /auth/admin/approve/:token — approve a pending registration (owner only)
router.post('/auth/admin/approve/:token', async (req, res) => {
  if (!req.session?.userId || req.session?.role !== 'owner') {
    return res.status(403).json({ success: false, message: 'Forbidden', data: {} });
  }
  try {
    const pending = await db('pending_registrations').where({ token: req.params.token }).first();
    if (!pending) return res.status(404).json({ success: false, message: 'Request not found or already handled.', data: {} });

    const [user] = await db('users').insert({
      email: pending.email, username: pending.username,
      password_hash: pending.password_hash, role: 'user'
    }).returning('*');
    await db('pending_registrations').where({ token: req.params.token }).delete();
    await sendApprovalResultEmail({ to: pending.email, username: pending.username, approved: true })
      .catch((e) => logger.warn(`[Auth] Approval result email error: ${e.message}`));

    logger.info(`[Auth] Admin approved: ${user.username} (${user.email})`);
    return res.json({ success: true, message: `${user.username} approved.`, data: {} });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message, data: {} });
  }
});

// POST /auth/admin/decline/:token — decline a pending registration (owner only)
router.post('/auth/admin/decline/:token', async (req, res) => {
  if (!req.session?.userId || req.session?.role !== 'owner') {
    return res.status(403).json({ success: false, message: 'Forbidden', data: {} });
  }
  try {
    const pending = await db('pending_registrations').where({ token: req.params.token }).first();
    if (!pending) return res.status(404).json({ success: false, message: 'Request not found or already handled.', data: {} });

    await db('pending_registrations').where({ token: req.params.token }).delete();
    await sendApprovalResultEmail({ to: pending.email, username: pending.username, approved: false })
      .catch((e) => logger.warn(`[Auth] Decline result email error: ${e.message}`));

    logger.info(`[Auth] Admin declined: ${pending.username} (${pending.email})`);
    return res.json({ success: true, message: `${pending.username} declined.`, data: {} });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message, data: {} });
  }
});

// DELETE /auth/admin/users/:id — remove an active user (owner only, can't remove self or other owners)
router.delete('/auth/admin/users/:id', async (req, res) => {
  if (!req.session?.userId || req.session?.role !== 'owner') {
    return res.status(403).json({ success: false, message: 'Forbidden', data: {} });
  }
  const targetId = parseInt(req.params.id, 10);
  if (targetId === req.session.userId) {
    return res.status(400).json({ success: false, message: 'You cannot remove your own account.', data: {} });
  }
  try {
    const user = await db('users').where({ id: targetId }).first();
    if (!user) return res.status(404).json({ success: false, message: 'User not found.', data: {} });
    if (user.role === 'owner') return res.status(400).json({ success: false, message: 'Cannot remove another owner.', data: {} });
    await db('users').where({ id: targetId }).delete();
    logger.info(`[Auth] Admin removed user: ${user.username} (${user.email})`);
    return res.json({ success: true, message: `${user.username} removed.`, data: {} });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message, data: {} });
  }
});

// GET /auth/me
router.get('/auth/me', (req, res) => {
  if (!req.session?.userId) {
    return res.status(401).json({ success: false, message: 'Not authenticated', data: {} });
  }
  return res.json({ success: true, message: 'Authenticated', data: {
    id:       req.session.userId,
    username: req.session.username,
    role:     req.session.role
  }});
});

export default router;
