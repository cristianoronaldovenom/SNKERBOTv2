// Show the offending spans without PowerShell mangling the literals.
import fs from 'node:fs';
const text = fs.readFileSync(process.argv[2], 'utf8');
const hits = text.match(/.{0,25}(?:\u00c3[\u00a2\u00a9\u00a8\u00a0]|\u00e2\u20ac|\u00f0\u0178).{0,25}/g) || [];
console.log(hits.length ? hits.slice(0, 8).map((h) => h.replace(/\r?\n/g, ' | ')).join('\n') : 'clean');
