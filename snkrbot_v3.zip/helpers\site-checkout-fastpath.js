// Site-wide checkout fast-path helpers.
// These helpers optimize navigation/readiness without inventing undocumented
// retailer APIs. Each adapter supplies its own known cart/checkout URL.

const SURFACE_RE = /(?:\/cart(?:\/|$)|\/basket(?:\/|$)|\/bag(?:\/|$)|\/checkout(?:\/|$))/i;

const safeUrl = (page) => page.url?.() || '';

export const currentCheckoutSurface = async (page) => {
  const url = safeUrl(page);
  if (/(?:\/checkout)(?:\/|$)/i.test(url)) return 'checkout';
  if (/(?:\/cart|\/basket|\/bag)(?:\/|$)/i.test(url)) return 'cart';
  return null;
};

export const navigateCartUnlessReady = async ({ page, cartUrl, navigate, taskId, stage = 'cart_load', waitUntil = 'domcontentloaded' }) => {
  const surface = await currentCheckoutSurface(page);
  if (surface) return { surface, navigated: false };
  await navigate(page, cartUrl, { taskId, stage, waitUntil });
  return { surface: 'cart', navigated: true };
};

export const waitForCartAndCheckout = async ({
  page,
  checkoutSelectors = [],
  cartTimeout = 6000,
  selectorTimeout = 6000,
  verifyCart,
  waitForAnySelector,
}) => {
  const selectorPromise = checkoutSelectors.length
    ? waitForAnySelector(page, checkoutSelectors, { timeout: selectorTimeout }).catch(() => null)
    : Promise.resolve(null);
  const cartPromise = verifyCart ? verifyCart(page, { timeout: cartTimeout }).catch(() => ({ empty: false, count: -1 })) : Promise.resolve(null);
  const [checkoutSelector, cart] = await Promise.all([selectorPromise, cartPromise]);
  return { checkoutSelector, cart };
};

export const tuneSitePage = async (page, profile = {}) => {
  // Keep navigation latency bounded while preserving a slower safety window
  // when an individual retailer responds slowly.
  if (profile.navigationTimeoutMs) {
    page.setDefaultNavigationTimeout(profile.navigationTimeoutMs);
  }
  if (profile.requestInterception === false) return;
  return true;
};

export const FASTPATH_VERSION = 2;
export const hasSurfaceUrl = (url = '') => SURFACE_RE.test(String(url));
