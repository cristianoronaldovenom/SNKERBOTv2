// Burst confirmation tests.
//
// The regression this guards: the poll optimizations (304s, coalesced responses) serve
// from cache, so a change landing mid-cycle is invisible until the next tick — fine
// on a quiet monitor, costly during a seconds-long restock. A detected change must
// therefore force fast re-confirmation, then settle back so the rate is not
// permanently inflated.
import { beforeEach, describe, expect, test } from '@jest/globals';
import {
  burstConfig, burstConfirmations, burstDelay, clearBurst, inBurst, noteChange, __resetBursts
} from '../../helpers/poll-burst.js';

beforeEach(() => __resetBursts());

describe('window', () => {
  test('no change means no burst', () => {
    expect(inBurst('t1')).toBe(false);
    expect(burstDelay('t1')).toBeNull();
  });

  test('a change opens a burst', () => {
    noteChange('t1');
    expect(inBurst('t1')).toBe(true);
  });

  test('confirmations accumulate so repeat changes extend the burst', () => {
    noteChange('t2');
    noteChange('t2');
    expect(burstConfirmations('t2')).toBe(2);
  });

  test('clearing stops it', () => {
    noteChange('t3');
    clearBurst('t3');
    expect(inBurst('t3')).toBe(false);
  });

  test('a null task id is ignored', () => {
    expect(() => noteChange(null)).not.toThrow();
  });
});

describe('delay', () => {
  test('a burst delay is short', () => {
    noteChange('t4');
    const d = burstDelay('t4');
    expect(d).toBeGreaterThan(0);
    expect(d).toBeLessThan(3000);
  });

  test('it never lengthens a caller base, only shortens it', () => {
    noteChange('t5');
    expect(burstDelay('t5', { baseMs: 20_000 })).toBeLessThanOrEqual(20_000);
    // A very small base wins over the burst delay.
    expect(burstDelay('t5', { baseMs: 300 })).toBeLessThanOrEqual(300);
  });

  test('the cadence is not a metronome', () => {
    noteChange('t6');
    const samples = new Set();
    for (let i = 0; i < 12; i++) samples.add(burstDelay('t6'));
    expect(samples.size).toBeGreaterThan(1);
  });

  test('config is sane: the window outlives any drop window', () => {
    expect(burstConfig().windowMs).toBeGreaterThanOrEqual(5000);
    expect(burstConfig().baseMs).toBeLessThanOrEqual(burstConfig().windowMs);
  });
});
