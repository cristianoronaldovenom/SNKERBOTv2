import { jest } from '@jest/globals';

jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));

jest.unstable_mockModule('../../helpers/captcha-harvester.js', () => ({
  createHarvesterChallenge: jest.fn(),
  solveInPage: jest.fn()
}));

let settings = {};
const firstMock = jest.fn(async function () {
  const key = this.__key;
  return key in settings ? { key, value: settings[key] } : undefined;
});
const db = jest.fn(() => ({
  where: (criteria) => ({ __key: criteria.key, first: firstMock })
}));
jest.unstable_mockModule('../../db/index.js', () => ({ default: db }));

const postMock = jest.fn();
const getMock = jest.fn();
jest.unstable_mockModule('axios', () => ({
  default: { post: postMock, get: getMock }
}));

const { solveCloudflareTurnstile, solveCaptcha, solveFunCaptcha, solveHCaptcha } =
  await import('../../helpers/captcha.js');

beforeEach(() => {
  settings = {};
  postMock.mockReset();
  getMock.mockReset();
  firstMock.mockClear();
  jest.useFakeTimers();
});

afterEach(() => {
  jest.useRealTimers();
});

// The provider poll loop sleeps POLL_INTERVAL_MS (5s) before the first result
// check, so drive fake timers forward while the solve promise is pending.
const settle = async (promise) => {
  await jest.advanceTimersByTimeAsync(6000);
  return promise;
};

// Route CapSolver createTask/getTaskResult; every other host throws so a leak
// out of the CapSolver path would surface loudly instead of silently passing.
const wireCapsolver = (solution) => {
  postMock.mockImplementation(async (url, body) => {
    if (url === 'https://api.capsolver.com/createTask') {
      return { data: { errorId: 0, taskId: 'cs-task-1', __sent: body } };
    }
    if (url === 'https://api.capsolver.com/getTaskResult') {
      return { data: { errorId: 0, status: 'ready', solution } };
    }
    throw new Error(`unexpected POST ${url}`);
  });
};

describe('CapSolver provider', () => {
  test('is reachable in the cascade and solves Turnstile', async () => {
    settings = { capsolver_api_key: 'CS-KEY' };
    wireCapsolver({ token: 'TURNSTILE_TOKEN' });

    const token = await settle(solveCloudflareTurnstile({
      siteKey: '0xSITE', pageUrl: 'https://shop.example.com/checkout'
    }));

    expect(token).toBe('TURNSTILE_TOKEN');
    const create = postMock.mock.calls.find(
      ([u]) => u === 'https://api.capsolver.com/createTask'
    );
    expect(create[1].clientKey).toBe('CS-KEY');
    expect(create[1].task).toEqual({
      type: 'AntiTurnstileTaskProxyLess',
      websiteURL: 'https://shop.example.com/checkout',
      websiteKey: '0xSITE'
    });
  });

  test('solves reCAPTCHA and returns gRecaptchaResponse', async () => {
    settings = { capsolver_api_key: 'CS-KEY' };
    wireCapsolver({ gRecaptchaResponse: 'RECAP_TOKEN' });

    const token = await settle(solveCaptcha({ siteKey: '6Lc', pageUrl: 'https://x.test/p' }));

    expect(token).toBe('RECAP_TOKEN');
    const create = postMock.mock.calls.find(
      ([u]) => u === 'https://api.capsolver.com/createTask'
    );
    expect(create[1].task.type).toBe('ReCaptchaV2TaskProxyLess');
    expect(create[1].task.websiteKey).toBe('6Lc');
  });

  test('solves hCaptcha', async () => {
    settings = { capsolver_api_key: 'CS-KEY' };
    wireCapsolver({ token: 'HC_TOKEN' });

    const token = await settle(solveHCaptcha({ siteKey: 'HK', pageUrl: 'https://x.test/p' }));

    expect(token).toBe('HC_TOKEN');
    const create = postMock.mock.calls.find(
      ([u]) => u === 'https://api.capsolver.com/createTask'
    );
    expect(create[1].task.type).toBe('HCaptchaTaskProxyLess');
  });

  test('FunCaptcha uses websitePublicKey (not websiteKey)', async () => {
    settings = { capsolver_api_key: 'CS-KEY' };
    wireCapsolver({ token: 'FC_TOKEN' });

    const token = await settle(solveFunCaptcha({ publicKey: 'PUB', pageUrl: 'https://x.test/p' }));

    expect(token).toBe('FC_TOKEN');
    const create = postMock.mock.calls.find(
      ([u]) => u === 'https://api.capsolver.com/createTask'
    );
    expect(create[1].task.type).toBe('FunCaptchaTaskProxyLess');
    expect(create[1].task.websitePublicKey).toBe('PUB');
    expect(create[1].task.websiteKey).toBeUndefined();
  });

  test('is skipped silently when no capsolver_api_key is set', async () => {
    settings = {}; // no providers configured at all
    postMock.mockImplementation(async () => { throw new Error('should not be called'); });

    await expect(
      solveCloudflareTurnstile({ siteKey: 'S', pageUrl: 'https://x.test/p' })
    ).rejects.toThrow(/No captcha providers configured/);
    // error message advertises the new key
    await expect(
      solveCloudflareTurnstile({ siteKey: 'S', pageUrl: 'https://x.test/p' })
    ).rejects.toThrow(/capsolver_api_key/);
    expect(postMock).not.toHaveBeenCalled();
  });

  test('runs as fallback after an earlier paid provider fails', async () => {
    // 2Captcha configured but its submit fails → cascade should reach CapSolver.
    settings = { captcha_api_key: '2C-KEY', capsolver_api_key: 'CS-KEY' };
    postMock.mockImplementation(async (url) => {
      if (url === 'https://2captcha.com/in.php') {
        return { data: { status: 0, request: 'ERROR_KEY_DOES_NOT_EXIST' } };
      }
      if (url === 'https://api.capsolver.com/createTask') {
        return { data: { errorId: 0, taskId: 'cs-task-1' } };
      }
      if (url === 'https://api.capsolver.com/getTaskResult') {
        return { data: { errorId: 0, status: 'ready', solution: { token: 'FALLBACK_TOKEN' } } };
      }
      throw new Error(`unexpected POST ${url}`);
    });

    const token = await settle(
      solveCloudflareTurnstile({ siteKey: 'S', pageUrl: 'https://x.test/p' })
    );
    expect(token).toBe('FALLBACK_TOKEN');
    expect(
      postMock.mock.calls.some(([u]) => u === 'https://api.capsolver.com/createTask')
    ).toBe(true);
  });
});
