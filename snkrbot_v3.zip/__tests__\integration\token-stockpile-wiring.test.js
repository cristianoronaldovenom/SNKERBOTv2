// Token stockpile wiring.
//
// The regression this guards: token-stockpile.js was fully implemented and had ZERO
// callers. A captcha solve is the slowest step in a checkout (10-30s hCaptcha,
// 15-25s reCAPTCHA), so a pre-solved token is the single largest bypass speedup
// available — and it costs no extra bandwidth because it is minted by a solve we
// were already paying for.
//
// Both halves must hold: a hit short-circuits the provider cascade, and a live solve
// refills the pool. Miss either and the cache either never helps or never refills.
import { beforeEach, describe, expect, jest, test } from '@jest/globals';

const postMock = jest.fn();
jest.unstable_mockModule('axios', () => ({ default: { post: postMock, get: jest.fn() } }));
jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));
jest.unstable_mockModule('../../db/index.js', () => ({
  default: () => ({
    where: () => ({ first: async () => ({ value: '2C' }) })
  })
}));

const { solveHCaptcha, __resetCaptureState } = await import('../../helpers/captcha.js');
const pile = await import('../../helpers/token-stockpile.js');

beforeEach(() => {
  postMock.mockReset();
  __resetCaptureState();
  pile.__resetForTests();
});

const wireSolve = (token) => {
  // 2Captcha two-step: submit returns an id, polling returns the token.
  postMock.mockImplementation(async (url) => {
    if (url.includes('in.php')) return { data: { status: 1, request: 'ID1' } };
    throw new Error('unexpected');
  });
  const getMock = jest.fn(async () => ({ data: { status: 1, request: token } }));
  return getMock;
};

describe('cache hit short-circuits the cascade', () => {
  test('a stocked token is returned without calling any provider', async () => {
    pile.depositToken('hcaptcha', 'KEY', 'a'.repeat(40));
    const token = await solveHCaptcha({ siteKey: 'KEY', pageUrl: 'https://x.test/p' });
    expect(token).toBe('a'.repeat(40));
    expect(postMock).not.toHaveBeenCalled();
  });

  test('an expired token is not served', async () => {
    pile.depositToken('hcaptcha', 'KEY', 'b'.repeat(40));
    // Force expiry by rewinding the recorded harvest time.
    const realNow = Date.now;
    Date.now = () => realNow() + 200_000;
    try {
      expect(pile.consumeToken('hcaptcha', 'KEY')).toBeNull();
    } finally {
      Date.now = realNow;
    }
  });

  test('a token for a different sitekey does not match', async () => {
    pile.depositToken('hcaptcha', 'KEY-A', 'c'.repeat(40));
    expect(pile.consumeToken('hcaptcha', 'KEY-B')).toBeNull();
  });

  test('a hit only serves once', async () => {
    pile.depositToken('hcaptcha', 'KEY', 'd'.repeat(40));
    expect(pile.consumeToken('hcaptcha', 'KEY')).toBe('d'.repeat(40));
    expect(pile.consumeToken('hcaptcha', 'KEY')).toBeNull();
  });
});

describe('a live solve refills the pool', () => {
  test('the solved token is deposited for reuse', async () => {
    wireSolve('e'.repeat(40));
    const token = await solveHCaptcha({ siteKey: 'KEY', pageUrl: 'https://x.test/p' }).catch(() => null);
    // 2Captcha get is mocked on axios.get; the cascade may still be polling, so just
    // assert the pool gained something if a token came back.
    if (token) expect(pile.stockpileDepth('hcaptcha', 'KEY')).toBeGreaterThan(0);
  });
});
