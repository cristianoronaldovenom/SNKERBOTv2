// Residential session concurrency.
//
// The monthly BYTE budget already existed, but bytes say nothing about how many
// sticky residential sessions are open at once. Firing every armed task at a drop
// passed the byte check and then opened one upstream session per task, which is
// exactly what makes a good residential gateway slow. The cap must bite, and it
// must release reliably — a lost token permanently shrinks capacity.
import { afterEach, describe, expect, test } from '@jest/globals';
import {
  acquireResidentialSession, activeResidentialSessions, maxResidentialSessions,
  __resetResidentialSessions
} from '../../helpers/residential-budget.js';

afterEach(() => __resetResidentialSessions());

const fill = async (n, role = 'checkout') => {
  const tokens = [];
  for (let i = 0; i < n; i += 1) tokens.push(await acquireResidentialSession(role));
  return tokens;
};

describe('residential session cap', () => {
  test('the cap is at least one and defaults to a small number', () => {
    expect(maxResidentialSessions()).toBeGreaterThanOrEqual(1);
    // A sensible default: enough parallelism to matter, few enough to stay fast.
    expect(maxResidentialSessions()).toBeLessThanOrEqual(8);
  });

  test('sessions are counted per role', async () => {
    await fill(2);
    expect(activeResidentialSessions('checkout')).toBe(2);
    expect(activeResidentialSessions('monitor')).toBe(0);
    expect(activeResidentialSessions()).toBe(2);
  });

  test('release frees exactly one slot and is idempotent', async () => {
    const [a, b] = await fill(2);
    a();
    expect(activeResidentialSessions('checkout')).toBe(1);
    a(); // second call must not double-free
    expect(activeResidentialSessions('checkout')).toBe(1);
    b();
    expect(activeResidentialSessions('checkout')).toBe(0);
  });

  test('the counter never goes negative below zero', async () => {
    const [a] = await fill(1);
    a(); a(); a();
    expect(activeResidentialSessions('checkout')).toBe(0);
  });

  test('a waiter is woken when a slot frees, and gets the freed slot', async () => {
    const tokens = await fill(maxResidentialSessions());
    const before = Date.now();
    const waiting = acquireResidentialSession('checkout');
    // Still blocked while the pool is full.
    expect(activeResidentialSessions('checkout')).toBe(maxResidentialSessions());

    tokens[0]();
    const token = await waiting;
    // It must resolve on the RELEASE, not on the fallback timeout — otherwise the
    // wake-up path could be broken and the test would still pass, just slowly.
    expect(Date.now() - before).toBeLessThan(1000);
    // The freed slot was handed over rather than dropped.
    expect(activeResidentialSessions('checkout')).toBe(maxResidentialSessions());
    token();
  });

  test('overflow beyond the cap is admitted after the bounded wait', async () => {
    const tokens = await fill(maxResidentialSessions());
    const before = Date.now();
    // No release: the waiter must time out and proceed anyway, never hang.
    const token = await acquireResidentialSession('checkout');
    const waited = Date.now() - before;
    expect(waited).toBeGreaterThanOrEqual(200);
    expect(waited).toBeLessThan(10_000);
    expect(typeof token).toBe('function');
    expect(activeResidentialSessions('checkout')).toBeGreaterThan(maxResidentialSessions());
    tokens.forEach((t) => t());
    token();
  });

  test('a timed-out waiter does not get counted twice when woken late', async () => {
    const tokens = await fill(maxResidentialSessions());
    const token = await acquireResidentialSession('checkout'); // times out
    const afterTimeout = activeResidentialSessions('checkout');
    // Freeing a slot must not additionally wake the already-settled waiter.
    tokens[0]();
    expect(activeResidentialSessions('checkout')).toBe(afterTimeout - 1);
    token();
  });
});
