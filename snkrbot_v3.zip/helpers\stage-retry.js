import logger from './logger.js';
import { shouldAbandonProxy } from './proxy-pool.js';

const TERMINAL_TYPES = new Set([
  'oos',
  'decline',
  'human_required',
  'queue',
  'household_cap',
  'sibling_won',
  'stop_loss',
  'preflight_fail',
]);

const isTransientMessage = (message = '') => {
  const text = String(message).toLowerCase();
  return /timeout|timed out|navigation failed|net::|econnreset|socket hang up|eai_again|enotfound|target closed|session.*expired|cart.*expired|detached|element.*not found|not ready|readiness/i.test(text);
};

/**
 * Retry a single checkout stage only when the failure is plausibly transient.
 * This deliberately does not retry the final order-submit stage.
 *
 * `proxyId` enables the liveness check: if the exit running this stage has gone
 * dead, the retry is skipped and `needsProxyRotation` is set, because retrying the
 * same dead IP just burns another timeout. A merely slow exit still retries —
 * rotating costs an IP, so it is only worth it when the exit is actually failing.
 */
export const runStageWithRecovery = async (
  fn,
  {
    taskId = '',
    stage = 'stage',
    attempts = 2,
    baseMs = 350,
    allowSessionRefresh = true,
    retryPlaceOrder = false,
    proxyId = null,
  } = {}
) => {
  const max = Math.max(1, Math.min(3, Number(attempts) || 1));
  let lastErr;

  for (let attempt = 1; attempt <= max; attempt += 1) {
    try {
      return await fn({ attempt });
    } catch (err) {
      lastErr = err;
      const failureType = String(err?.failureType || '').toLowerCase();
      const isFinalOrder = /place.?order|confirm.?order|submit.?order/i.test(stage);
      const terminal = TERMINAL_TYPES.has(failureType);
      const retryable = !terminal &&
        (!isFinalOrder || retryPlaceOrder) &&
        (isTransientMessage(err?.message) || failureType === 'session_expired');

      if (!retryable || attempt >= max) throw err;

      // A dead exit will not recover inside a 350ms backoff. Fail fast and tell
      // the caller to rotate instead of spending another timeout on it.
      if (proxyId && shouldAbandonProxy(proxyId)) {
        logger.warn(`[StageRetry] Task ${taskId} stage "${stage}" — exit ${proxyId} looks dead; requesting rotation`);
        err.needsProxyRotation = true;
        throw err;
      }

      const backoff = Math.min(3000, baseMs * (2 ** (attempt - 1)));
      const jitter = Math.floor(Math.random() * 150);
      const waitMs = backoff + jitter;

      if (failureType === 'session_expired' && allowSessionRefresh) {
        logger.info(`[StageRetry] Task ${taskId} stage "${stage}" — session expired; retrying stage in ${waitMs}ms with fresh state`);
      } else {
        logger.info(`[StageRetry] Task ${taskId} stage "${stage}" — transient failure; retry ${attempt + 1}/${max} in ${waitMs}ms`);
      }
      await new Promise((resolve) => setTimeout(resolve, waitMs));
    }
  }

  throw lastErr;
};
