import { Router } from 'express';
import { validate } from 'express-validation';
import * as controller from './controller.js';
import * as health from './health.js';
import { createProxySchema, updateProxySchema } from './validation.js';

const router = Router();

router.get('/', controller.findAll);
router.get('/meta', controller.findMeta);
router.get('/:id', controller.findOne);
router.post('/', validate(createProxySchema, {}, {}), controller.create);
router.patch('/:id', validate(updateProxySchema, {}, {}), controller.update);
router.delete('/:id', controller.remove);
router.post('/:id/health', health.checkOne);
router.post('/health/all', health.checkAll);

export default router;
