// Behavioral ML randomization — defeats machine-learning bot classifiers.
//
// WAFs like Akamai, PerimeterX, and Cloudflare Bot Management now run ML
// classifiers on behavioral telemetry: inter-keypress timing, mouse velocity
// curves, dwell time on elements, scroll patterns, and session-level features
// like "time between page load and first interaction."
//
// Simple bots are caught because their timing distributions are uniform or
// constant. Real humans have:
//   - Typing fatigue: slowing down after sustained typing sessions
//   - Reading pauses: dwelling on text before clicking (proportional to length)
//   - Micro-tremors: ±1–3px jitter on mouse positions
//   - Variable inter-field delays: pausing between form fields to visually check
//   - Hesitation before high-stakes actions (clicking "Place Order" takes longer)
//   - Acceleration/deceleration on mouse that trails off after the click

const randInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
const randFloat = (min, max) => min + Math.random() * (max - min);

// ── Typing fatigue model ─────────────────────────────────────────────────────
// Real users slow down 15–30% after typing for extended periods. The fatigue
// builds up over the first ~3 minutes of a session and levels out. We model
// this as a multiplier on the base keypress delay.
//
// Usage: get the multiplier once per field and apply it to humanDelay().
export const typingFatigueMultiplier = (sessionStartMs) => {
  const elapsed = Date.now() - sessionStartMs;
  const minutes = elapsed / 60_000;
  if (minutes < 0.5) return 1.0;          // fresh — normal speed
  if (minutes < 2.0) {
    // Linear ramp: 1.0 → 1.25 over the first 2 minutes
    const t = (minutes - 0.5) / 1.5;
    return 1.0 + 0.25 * t;
  }
  if (minutes < 5.0) {
    // Slight additional creep: 1.25 → 1.35
    const t = (minutes - 2.0) / 3.0;
    return 1.25 + 0.10 * t;
  }
  return 1.35;                             // plateau — never more than 35% slow
};

// ── Reading pause ────────────────────────────────────────────────────────────
// Before clicking a button or link, real users visually confirm what they're
// about to do. The dwell time scales with the number of visible words near the
// target — a long form section takes longer to "read" before committing.
//
// Returns milliseconds to wait before interacting with an element.
export const readingPauseMs = async (page, selector) => {
  try {
    const wordCount = await page.evaluate((sel) => {
      const el = document.querySelector(sel);
      if (!el) return 5;
      // Count words in the element + its immediate siblings (label, nearby text)
      const container = el.closest('form, section, .step, .checkout-form') || el.parentElement;
      const text = container?.innerText || el.innerText || '';
      return text.trim().split(/\s+/).filter(Boolean).length;
    }, selector).catch(() => 5);
    // 50ms base + ~10ms per word, capped at 1200ms, with ±20% jitter
    const base = Math.min(1200, 50 + wordCount * 10);
    const jitter = base * (0.8 + Math.random() * 0.4);
    return Math.round(jitter);
  } catch (_) {
    return randInt(180, 450);
  }
};

// ── Micro-tremors ────────────────────────────────────────────────────────────
// Human hands have involuntary micro-jitter (physiological tremor: ~8–12Hz,
// ±1–3px amplitude). Bots that move to exact pixel coordinates are trivially
// detected by WAFs that inspect mouse path entropy. Apply this to every
// intermediate point in a Bezier path.
//
// Returns {dx, dy} pixel offsets to add to a mouse coordinate.
export const microTremor = () => ({
  dx: randFloat(-2.5, 2.5),
  dy: randFloat(-2.0, 2.0)
});

// ── Hesitation before high-stakes clicks ─────────────────────────────────────
// "Place Order" and "Complete Payment" buttons get a longer pre-click pause
// because users mentally review their decision. Checkout navigation buttons
// (Continue to Shipping) get a medium pause. Plain form fields get almost none.
//
// importance: 'critical' (submit/pay) | 'navigate' (continue/proceed) | 'form' (field)
export const hesitationMs = (importance = 'form') => {
  switch (importance) {
    case 'critical':
      // Place Order: 800ms–2.5s — the user is double-checking the total
      return randInt(800, 2500);
    case 'navigate':
      // Continue to Shipping/Payment: 300ms–900ms
      return randInt(300, 900);
    case 'form':
    default:
      // Clicking into a text field: 40ms–180ms
      return randInt(40, 180);
  }
};

// ── Inter-field pause ─────────────────────────────────────────────────────────
// After filling a field and pressing Tab (or clicking the next field), real
// users briefly look at what they typed before moving on. This is especially
// pronounced after address and card fields (users double-check numbers).
//
// fieldType: 'card' | 'address' | 'text' | 'select'
export const interFieldPauseMs = (fieldType = 'text') => {
  switch (fieldType) {
    case 'card':
      // Card number / CVV — users stare at these
      return randInt(350, 900);
    case 'address':
      // Street address — medium verification glance
      return randInt(200, 550);
    case 'select':
      // Dropdown — quicker since value is constrained
      return randInt(80, 220);
    case 'text':
    default:
      return randInt(60, 200);
  }
};

// ── Session entropy score ─────────────────────────────────────────────────────
// Returns a synthetic "human-likeness" score (0–1) based on how varied the
// timing has been so far. Used for diagnostic logging; not fed into the
// live classifier (WAF can't see this).
export const sessionEntropyScore = (timings) => {
  if (!timings || timings.length < 3) return 0.5;
  const mean = timings.reduce((a, b) => a + b, 0) / timings.length;
  const variance = timings.reduce((s, t) => s + (t - mean) ** 2, 0) / timings.length;
  const cv = Math.sqrt(variance) / (mean || 1); // coefficient of variation
  // Humans: CV typically 0.2–0.7. Bots: CV < 0.05 (too uniform) or > 1.5 (too random).
  return Math.min(1, Math.max(0, (cv - 0.05) / 0.65));
};

// ── Gaze time on element ──────────────────────────────────────────────────────
// Before interacting with a large interactive element (a prominent CTA button,
// a section header, a product image), real users dwell momentarily. The pause
// scales with the element's visual footprint.
//
// Usage: await sleep(gazeTimeMs(box)) before humanClick.
export const gazeTimeMs = (boundingBox) => {
  if (!boundingBox) return randInt(50, 150);
  const area = (boundingBox.width || 0) * (boundingBox.height || 0);
  // Small elements (< 2000px²): ~50ms. Large CTAs (> 20000px²): ~250ms.
  const base = Math.min(300, 50 + area / 100);
  return Math.round(base * (0.7 + Math.random() * 0.6));
};

// ── Random idle micro-pause ───────────────────────────────────────────────────
// Injected between form steps to simulate the user glancing away, reading
// instructions, or hesitating. Occasional longer pauses (simulating
// "distraction") are especially important — classifiers look for sessions
// that never pause longer than 500ms.
export const idlePauseMs = () => {
  const r = Math.random();
  if (r < 0.60) return randInt(80, 350);          // 60% — quick glance
  if (r < 0.85) return randInt(350, 900);         // 25% — brief read
  if (r < 0.96) return randInt(900, 2200);        // 11% — longer hesitation
  return randInt(2200, 5000);                      //  4% — distracted pause
};
