// Per-retailer performance profiles. These tune the orchestration layer around
// each adapter without changing checkout semantics or final-order safeguards.
// Values are intentionally conservative: the fast path is shorter, while every
// profile keeps a slower fallback available through the shared runtime waits.

const DEFAULT_PROFILE = Object.freeze({
  warmPath: '/',
  warmMode: 'light',
  warmScroll: false,
  quickWarmPauseMs: [120, 260],
  normalWarmPauseMs: [600, 1200],
  navigationTimeoutMs: 30000,
  fastReadinessMs: 2500,
  cartVerifyMs: 5000,
  checkoutSurfaceMs: 8000,
});

const PROFILES = Object.freeze({
  1: Object.freeze({ // Footsites
    ...DEFAULT_PROFILE,
    warmMode: 'light',
    quickWarmPauseMs: [100, 220],
    fastReadinessMs: 2200,
    cartVerifyMs: 4500,
    checkoutSurfaceMs: 7000,
  }),
  2: Object.freeze({ // Shopify
    ...DEFAULT_PROFILE,
    warmMode: 'light',
    warmScroll: false,
    quickWarmPauseMs: [80, 180],
    fastReadinessMs: 1800,
    cartVerifyMs: 4000,
    checkoutSurfaceMs: 6500,
  }),
  3: Object.freeze({ // Demandware / SFCC
    ...DEFAULT_PROFILE,
    warmMode: 'light',
    quickWarmPauseMs: [100, 220],
    fastReadinessMs: 2200,
    cartVerifyMs: 4500,
    checkoutSurfaceMs: 7000,
  }),
  4: Object.freeze({ // Nike
    ...DEFAULT_PROFILE,
    warmMode: 'light',
    quickWarmPauseMs: [100, 220],
    fastReadinessMs: 2200,
    cartVerifyMs: 4500,
    checkoutSurfaceMs: 7000,
  }),
  5: Object.freeze({ // Supreme NY
    ...DEFAULT_PROFILE,
    warmMode: 'minimal',
    quickWarmPauseMs: [80, 160],
    fastReadinessMs: 1800,
    cartVerifyMs: 4000,
    checkoutSurfaceMs: 6500,
  }),
  6: Object.freeze({ // Pokémon Center
    ...DEFAULT_PROFILE,
    warmPath: '/en-ca/',
    warmMode: 'full',
    warmScroll: false,
    quickWarmPauseMs: [250, 500],
    normalWarmPauseMs: [900, 1500],
    fastReadinessMs: 2200,
    cartVerifyMs: 5000,
    checkoutSurfaceMs: 8000,
  }),
  7: Object.freeze({ // Topps
    ...DEFAULT_PROFILE,
    warmMode: 'light',
    quickWarmPauseMs: [100, 220],
    fastReadinessMs: 2200,
    cartVerifyMs: 4500,
    checkoutSurfaceMs: 7000,
  }),
  8: Object.freeze({ // Walmart
    ...DEFAULT_PROFILE,
    warmMode: 'light',
    quickWarmPauseMs: [100, 220],
    fastReadinessMs: 2200,
    cartVerifyMs: 4500,
    checkoutSurfaceMs: 7000,
  }),
  9: Object.freeze({ // Best Buy
    ...DEFAULT_PROFILE,
    warmMode: 'light',
    quickWarmPauseMs: [100, 220],
    fastReadinessMs: 2000,
    cartVerifyMs: 4500,
    checkoutSurfaceMs: 7000,
  }),
  10: Object.freeze({ // Target
    ...DEFAULT_PROFILE,
    warmMode: 'light',
    warmScroll: false,
    quickWarmPauseMs: [80, 180],
    fastReadinessMs: 2000,
    cartVerifyMs: 4500,
    checkoutSurfaceMs: 7000,
  }),
  11: Object.freeze({ // GameStop
    ...DEFAULT_PROFILE,
    warmMode: 'light',
    quickWarmPauseMs: [100, 220],
    fastReadinessMs: 2200,
    cartVerifyMs: 4500,
    checkoutSurfaceMs: 7000,
  }),
  12: Object.freeze({ // Amazon
    ...DEFAULT_PROFILE,
    warmMode: 'minimal',
    warmScroll: false,
    quickWarmPauseMs: [80, 160],
    fastReadinessMs: 2200,
    cartVerifyMs: 5000,
    checkoutSurfaceMs: 8000,
    // Amazon checkout depends on a pre-authenticated persistent browser profile;
    // the optimizer therefore avoids extra homepage interaction during warm-up.
    preserveAuthenticatedSession: true,
  }),
});

const normalizeId = (siteId) => {
  const n = Number(siteId);
  return Number.isFinite(n) ? n : 0;
};

export const getSitePerformanceProfile = (siteId) => ({
  ...DEFAULT_PROFILE,
  ...(PROFILES[normalizeId(siteId)] || {}),
  siteId: normalizeId(siteId),
});

export const allSitePerformanceProfiles = () => Object.fromEntries(
  Object.entries(PROFILES).map(([id, profile]) => [id, { ...profile, siteId: Number(id) }])
);
