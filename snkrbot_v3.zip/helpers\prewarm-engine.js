// Prewarm / pre-position speed engine.
//
// Goal: cut the time between the stock monitor confirming stock and the browser
// checkout actually starting, by doing the slow COLD work (Chrome launch +
// session warm) AHEAD of the drop.
//
// Design — PARK-THEN-ADOPT (forced by a hard constraint, not a preference):
//   launchBrowser() opens a persistent per-task Chrome profile dir
//   (profiles/task-<id>) that Chrome locks EXCLUSIVELY. So you cannot have an
//   idle prewarm browser AND a separate cold checkout browser for the same task
//   — they would collide on that lock. Therefore the parked browser IS the
//   checkout browser: the monitor loop launches + warms it while it polls, and
//   runOnce ADOPTS it (skipping launch + warm) the instant stock hits.
//
// Safety contract (mirrors cart-reserver / request-checkout):
//   * Gated OFF by default (setting `prewarm_enabled`). When it was never on,
//     nothing is ever parked and adoptPrewarm() is an instant no-op → today's
//     behavior, byte-for-byte.
//   * Never throws. Any failure falls back to the cold checkout path.
//   * A parked browser holds NO run-queue slot while idle (only runOnce calls
//     acquireSlot), so it can never starve real checkouts.
//   * adoptPrewarm() ALWAYS releases the per-task profile lock before returning
//     null (it awaits browser.close() on any stale/mismatched/unhealthy
//     context), so the cold fallback's launchBrowser() can never deadlock.
import db from '../db/index.js';
import logger from './logger.js';
import { launchBrowser, getNewPage } from './cluster.js';
import { getSitePerformanceProfile } from './site-performance.js';
import { enableResourceBlocker } from './resource-blocker.js';
import { injectCookies, harvestCookies } from './cookie-pool.js';
import { warmInPlace } from './session-warmer.js';
import { getMemorySnapshot, isMemoryPressure, recommendedPrewarmCap, armParkingStorm } from './memory-guard.js';
import { VERDICT, assessBrowser } from './rss-watchdog.js';

const truthy = (v) => v === true || v === 'true' || v === '1' || v === 1;

// Feature gate. Defaults to false (disabled) on any read error. Cache briefly
// because the monitor scheduler checks this on every restored/started task.
let prewarmCache = { value: false, expiresAt: 0 };
const PREWARM_SETTING_TTL_MS = 5000;
export const prewarmEnabled = async () => {
  const now = Date.now();
  if (prewarmCache.expiresAt > now) return prewarmCache.value;
  try {
    const r = await db('settings').where({ key: 'prewarm_enabled' }).first();
    prewarmCache.value = truthy(r?.value);
  } catch (_) {
    prewarmCache.value = false;
  }
  prewarmCache.expiresAt = now + PREWARM_SETTING_TTL_MS;
  return prewarmCache.value;
};

const PREWARM_TTL_MS = 8.5 * 60 * 1000;      // discard if last successful warm is older than this
const REWARM_EVERY_MS = 6.5 * 60 * 1000;   // re-warm before the warm session drifts
const REWARM_JITTER_MS = 30 * 1000;        // jitter the re-warm so it isn't a fixed, detectable beat
const DEFAULT_MAX_PARKED = 3;              // memory-guard reduces this automatically on smaller/loaded hosts
let maxParkedCache = { value: DEFAULT_MAX_PARKED, expiresAt: 0 };

// Effective parked-browser cap.
//
// NOTE: this was previously *called* (in park()) but never defined, so every
// park() threw `maxParked is not defined` and was swallowed by the outer catch —
// i.e. prewarm silently never worked. Keep this a pure policy number read from
// the `prewarm_max_parked` setting; host memory pressure is enforced separately
// inside park() via isMemoryPressure(), so a loaded host cannot silently rewrite
// the operator's configured cap.
const maxParked = async () => {
  const now = Date.now();
  if (maxParkedCache.expiresAt > now) return maxParkedCache.value;
  let cap = DEFAULT_MAX_PARKED;
  try {
    const r = await db('settings').where({ key: 'prewarm_max_parked' }).first();
    const parsed = Number.parseInt(r?.value, 10);
    if (Number.isFinite(parsed)) cap = Math.max(0, Math.min(10, parsed));
  } catch (_) { /* keep the safe default */ }
  maxParkedCache = { value: cap, expiresAt: now + PREWARM_SETTING_TTL_MS };
  return cap;
};

// taskId -> shared prewarm pool entry. Multiple tasks on the same host/proxy
// can lease pages from one Chromium process instead of one browser per task.
// This preserves prewarm latency while removing the largest avoidable RAM cost.
const registry = new Map();
const pools = new Map(); // poolKey -> pool entry
const taskIdsForPool = (entry) => entry?.taskIds || new Set();

const proxyKey = (proxy) => proxy
  ? `${proxy.host}:${proxy.port}:${proxy.username || ''}:${proxy.password || ''}`
  : 'direct';
const poolKeyFor = (task, proxy) => {
  const host = hostOf(task?.url);
  return `${host || 'unknown'}|${proxyKey(proxy)}|${task?.site_id || ''}`;
};

const hostOf = (url) => { try { return new URL(url).hostname; } catch (_) { return null; } };
const originOf = (url) => { const u = new URL(url); return `${u.protocol}//${u.hostname}`; };

// Close a parked browser exactly once and stop its refresh timer.
const closeEntryBrowser = async (entry) => {
  if (!entry || entry.closed) return;
  entry.closed = true;
  if (entry.refreshTimer) { clearTimeout(entry.refreshTimer); entry.refreshTimer = null; }
  if (entry.browser) await entry.browser.close().catch(() => {});
};

// Keep the shared warmed session fresh. A pool browser is deliberately kept
// alive only while tasks are waiting/using it; this avoids 100 independent
// refresh timers and browser processes for 100 armed monitors.
const scheduleRewarm = (poolKey, entry) => {
  if (!entry || entry.refreshTimer) return;
  const delay = Math.max(1000, REWARM_EVERY_MS + Math.floor(Math.random() * REWARM_JITTER_MS) - REWARM_JITTER_MS / 2);
  entry.refreshTimer = setTimeout(async () => {
    entry.refreshTimer = null;
    const current = pools.get(poolKey);
    if (!current || current.disposed || current.browser?.isConnected?.() === false) return;
    if (Date.now() - current.lastWarmedAt > PREWARM_TTL_MS) {
      await closePool(poolKey);
      return;
    }
    if (current.page && current.browser?.isConnected?.() !== false) {
      if (await isMemoryPressure(0.88)) {
        logger.warn(`[Prewarm] Memory pressure during shared re-warm — closing pool ${poolKey}`);
        await closePool(poolKey);
        return;
      }
      const warmPromise = warmInPlace(current.page, `${originOf(current.warmUrl)}${current.warmPath}`).catch(() => false);
      current.warmInFlight = warmPromise;
      await warmPromise;
      await harvestCookies(current.page, current.warmUrl).catch(() => {});
      current.warmInFlight = null;
      current.lastWarmedAt = Date.now();
    }
    if (pools.has(poolKey)) scheduleRewarm(poolKey, entry);
  }, delay);
  entry.refreshTimer.unref?.();
};

const closePool = async (poolKey) => {
  const entry = pools.get(poolKey);
  if (!entry || entry.disposed) return;
  entry.disposed = true;
  if (entry.refreshTimer) { clearTimeout(entry.refreshTimer); entry.refreshTimer = null; }
  for (const taskId of entry.taskIds || []) registry.delete(taskId);
  entry.taskIds?.clear?.();
  if (entry.contexts) {
    await Promise.all(Array.from(entry.contexts).map((ctx) => ctx.close?.().catch?.(() => {}) || Promise.resolve()));
    entry.contexts.clear();
  }
  if (entry.browser) await entry.browser.close().catch(() => {});
  pools.delete(poolKey);
};

const maybeCloseIdlePool = async (entry) => {
  if (!entry || entry.disposed) return;
  if ((entry.taskIds?.size || 0) === 0 && (entry.activeUses || 0) === 0) {
    await closePool(entry.poolKey);
  }
};

// Pre-position a warmed browser for a task. Fire-and-forget from the monitor.
// Never throws; returns a small status object.
export const park = async ({ task, proxy = null } = {}) => {
  try {
    if (!task?.id || !task?.url) return { parked: false, reason: 'no task' };
    const taskId = task.id;
    if (registry.has(taskId)) return { parked: false, reason: 'already parked' };

    // Pressure (below) is a binary gate; this lowers the numeric cap first so a
    // small or partly-loaded host parks fewer browsers instead of all-or-nothing.
    const cap = await recommendedPrewarmCap(await maxParked());
    if (cap <= 0) return { parked: false, reason: 'memory_pressure' };

    const poolKey = poolKeyFor(task, proxy);
    let entry = pools.get(poolKey);
    if (entry) {
      entry.taskIds.add(taskId);
      registry.set(taskId, entry);
      return { parked: true, shared: true, reused: true };
    }

    if (pools.size >= cap) {
      logger.info(`[Prewarm] Skip task ${taskId} — shared pool cap ${pools.size}/${cap} reached`);
      return { parked: false, reason: 'cap' };
    }
    if (await isMemoryPressure(0.84)) return { parked: false, reason: 'memory_pressure' };

    // We are about to add a browser: make the next few hundred ms of capability
    // checks re-read real memory instead of a snapshot taken before it existed,
    // otherwise a parallel burst each sees the pre-park headroom and over-parks.
    armParkingStorm();

    let resolveReady;
    const ready = new Promise((r) => { resolveReady = r; });
    entry = {
      poolKey, browser: null, page: null, proxyId: proxy?.id ?? null, proxy,
      host: hostOf(task.url), warmUrl: task.url, warmPath: `${getSitePerformanceProfile(task.site_id).warmPath}`,
      createdAt: Date.now(), lastWarmedAt: Date.now(), refreshTimer: null, warmInFlight: null,
      disposed: false, closed: false, activeUses: 0, contexts: new Set(), taskIds: new Set(),
      ready, readySettled: false
    };
    pools.set(poolKey, entry);
    registry.set(taskId, entry);
    entry.taskIds.add(taskId);

    try {
      entry.browser = await launchBrowser({ proxy, taskId: null, siteId: task.site_id });
      entry.page = await getNewPage({ browser: entry.browser, proxy, role: 'checkout', siteId: task.site_id });
      await enableResourceBlocker(entry.page, { mode: task.quick_mode ? 'checkout' : 'monitor', siteId: task.site_id });
      const hadPool = await injectCookies(entry.page, task.url).catch(() => false);
      if (!hadPool) {
        await warmInPlace(entry.page, `${originOf(task.url)}${entry.warmPath}`).catch(() => {});
      }
      await harvestCookies(entry.page, task.url).catch(() => {});
      entry.lastWarmedAt = Date.now();
    } catch (err) {
      await closePool(poolKey);
      resolveReady(false);
      logger.warn(`[Prewarm] Shared pool warm failed for task ${taskId}: ${err.message}`);
      return { parked: false, reason: err.message };
    }

    if (entry.disposed || entry.browser?.isConnected?.() === false) {
      await closePool(poolKey);
      resolveReady(false);
      return { parked: false, reason: 'disposed during park' };
    }

    scheduleRewarm(poolKey, entry);
    entry.readySettled = true;
    resolveReady(true);
    logger.info(`[Prewarm] Shared pool warmed ${entry.host} — one browser can serve ${entry.taskIds.size} task(s)`);
    return { parked: true, shared: true, reused: false };
  } catch (err) {
    logger.warn(`[Prewarm] park() unexpected error: ${err.message}`);
    return { parked: false, reason: err.message };
  }
};

// Claim the parked browser for checkout. Returns { browser, page } on a healthy,
// proxy-matched, fresh context; otherwise disposes any leftover context (freeing
// the profile lock) and returns null so the caller cold-launches cleanly.
//
// Always safe to call — an instant no-op (null) when nothing is parked.
export const adoptPrewarm = async (taskId, { proxyId = null, url = null, siteId = null, quickMode = true } = {}) => {
  try {
    const entry = registry.get(taskId);
    if (!entry) return null;

    let timeoutTimer;
    const settled = await Promise.race([
      entry.ready.then(() => true, () => false),
      new Promise((r) => { timeoutTimer = setTimeout(() => r(false), 15000); }),
    ]);
    clearTimeout(timeoutTimer);

    const cur = registry.get(taskId);
    if (!cur || !settled || cur.disposed || !cur.browser || cur.browser.isConnected?.() === false) {
      if (cur) { cur.taskIds.delete(taskId); registry.delete(taskId); await maybeCloseIdlePool(cur); }
      return null;
    }
    if (proxyId != null && (cur.proxyId ?? null) !== proxyId) {
      cur.taskIds.delete(taskId); registry.delete(taskId); await maybeCloseIdlePool(cur);
      return null;
    }

    if (cur.warmInFlight) { try { await cur.warmInFlight; } catch (_) {} }
    if (Date.now() - cur.lastWarmedAt > PREWARM_TTL_MS) {
      cur.taskIds.delete(taskId); registry.delete(taskId); await maybeCloseIdlePool(cur);
      return null;
    }

    const context = await cur.browser.createBrowserContext();
    const page = await getNewPage({
      browser: cur.browser, context, proxy: cur.proxy, role: 'checkout', taskId, siteId: siteId || undefined
    });
    await enableResourceBlocker(page, { mode: quickMode ? 'checkout' : 'monitor', siteId: siteId || undefined });
    await injectCookies(page, url || cur.warmUrl).catch(() => false);
    cur.contexts.add(context);
    cur.activeUses += 1;
    cur.taskIds.delete(taskId);
    registry.delete(taskId);

    let released = false;
    const release = async () => {
      if (released) return;
      released = true;
      cur.activeUses = Math.max(0, cur.activeUses - 1);
      cur.contexts.delete(context);
      try { await context.close(); } catch (_) {}
      await maybeCloseIdlePool(cur);
    };

    logger.info(`[Prewarm] Task ${taskId} ⚡ adopted shared warmed browser/page (pool ${cur.poolKey})`);
    return { browser: cur.browser, page, context, sharedPrewarm: true, release };
  } catch (err) {
    logger.warn(`[Prewarm] adoptPrewarm error for task ${taskId}: ${err.message}`);
    const e = registry.get(taskId);
    if (e) { e.taskIds.delete(taskId); registry.delete(taskId); await maybeCloseIdlePool(e).catch(() => {}); }
    return null;
  }
};

// Tear down a parked browser (monitor stop, TTL sweep). Never throws.
export const disposePrewarm = async (taskId) => {
  const entry = registry.get(taskId);
  if (!entry) return;
  registry.delete(taskId);
  entry.taskIds.delete(taskId);
  await maybeCloseIdlePool(entry);
};

export const disposeAll = async () => {
  const keys = Array.from(pools.keys());
  await Promise.all(keys.map((key) => closePool(key).catch(() => {})));
  registry.clear();
};

export const isParked = (taskId) => registry.has(taskId);
export const parkedCount = () => pools.size;

// Cheap RSS of a browser plus its renderers, from the browser process node.
// Returns 0 when the platform will not tell us (Windows has no /proc), which the
// watchdog treats as "no measurement" rather than "healthy".
const residentBytes = (browser) => {
  const proc = browser?.process?.();
  if (!proc) return 0;
  try {
    if (typeof proc.memoryUsage === 'function') return proc.memoryUsage();
  } catch (_) { /* racing shutdown */ }
  const reported = Number(proc.memoryUsageRaw);
  return Number.isFinite(reported) ? reported : 0;
};

/**
 * Sweep parked browsers and close the ones the watchdog condemns.
 *
 * Parked prewarm browsers are the highest-leak surface we have: they live for
 * minutes holding a warmed SPA, with nothing to recycle them when a heavy PDP
 * slowly grows their heap. Admission only ran before launch, so without this a
 * single parked tab can eat the host before its checkout ever adopts it.
 *
 * Never throws. Returns a short report for telemetry.
 */
export const sweepParkedByRss = async ({ hostLimitBytes = 0 } = {}) => {
  const verdicts = [];
  for (const [poolKey, entry] of pools) {
    if (!entry || entry.disposed) continue;
    try {
      // A pool with an active checkout is in use; leave it alone this pass.
      if ((entry.activeUses || 0) > 0) continue;
      const verdict = assessBrowser({
        rssBytes: residentBytes(entry.browser),
        pageCount: entry.contexts?.size || 0,
        hostLimitBytes,
        parked: true,
        ageMs: Date.now() - (entry.createdAt || Date.now())
      });
      if (verdict.verdict === VERDICT.KEEP) continue;
      verdicts.push({ poolKey, verdict: verdict.verdict, reasons: verdict.reasons, rssMb: verdict.rssMb });
      // Both non-KEEP verdicts close the pool. Its warm state is already spent at
      // this heap size, and the next monitor tick re-parks a fresh browser.
      logger.info(`[Prewarm] ${verdict.verdict} parked browser on ${entry.host || 'unknown'} (${verdict.rssMb}MB, ${verdict.reasons.join('+')})`);
      await closePool(poolKey).catch(() => {});
    } catch (err) {
      logger.warn(`[Prewarm] RSS sweep failed for ${poolKey}: ${err.message}`);
    }
  }
  return verdicts;
};

export const __test__ = {
  registry,
  pools,
  PREWARM_TTL_MS,
  DEFAULT_MAX_PARKED,
  // Reset the short-lived settings caches. Tests mutate the settings table
  // directly and would otherwise observe a stale cached value for up to 5s.
  resetCaches: () => {
    prewarmCache = { value: false, expiresAt: 0 };
    maxParkedCache = { value: DEFAULT_MAX_PARKED, expiresAt: 0 };
  }
};
