// Captcha provider cascade — 2Captcha → CapMonster → CapSolver → AntiCaptcha
// auto-failover.
//
// Why this exists: pro bots NEVER rely on a single captcha vendor during a
// drop. 2Captcha gets DDoSed at every major sneaker release; CapMonster's
// solver pool dries up; AntiCaptcha rate-limits by API key. Stellar/Hidden/
// Valor all ship multi-provider cascades that try the cheapest/fastest first
// and fall through to the next on failure or timeout.
//
// Order of preference is TYPE-AWARE, not fixed: each provider carries a rank
// per challenge type (2Captcha is strongest at reCAPTCHA, CapSolver at
// Turnstile, CapMonster at hCaptcha/FunCaptcha) and the cascade sorts on that,
// on live health (a provider that just failed three times cools down for two
// minutes), and on recent strikes. There is no universal cheapest-first order,
// because the cheapest provider is not cheapest when it needs 25s to answer a
// Turnstile that decides the drop.
//
// Turnstile additionally RACES the top two providers head-to-head and takes the
// first token back - see solveWithCascade.
import axios from 'axios';
import logger from './logger.js';
import db from '../db/index.js';
import { createHarvesterChallenge, solveInPage } from './captcha-harvester.js';
import { consumeToken, depositToken } from './token-stockpile.js';
import {
  solverProxy, taskTypeFor, uaParam, twocaptchaProxyParams, taskProxyParams, capsolverProxyParams
} from './captcha-proxy.js';

const POLL_INTERVAL_MS = 5000;
// First poll is far tighter than the steady-state interval. Solvers usually
// finish a Turnstile in 1-3s and hCaptcha in 5-15s; sitting on a 5s timer before
// the first check wastes most of a short drop window. Polls then back off
// geometrically toward POLL_INTERVAL_MS so we stay inside provider rate limits.
const FIRST_POLL_MS = 1200;
const MAX_ATTEMPTS = 24;
// Global solve budget across ALL providers in the cascade. Pro bots cap total
// solve time because a 6-minute cascade burns the entire drop window — better
// to fail fast and let the retry loop pick a fresh identity than to wait for
// a third stale provider. Default 45s total, configurable via setting.
const DEFAULT_TOTAL_BUDGET_MS = 45_000;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Poll delay for attempt N: 1.2s, 2.4s, 4.8s, capped at POLL_INTERVAL_MS,
// plus Ã‚Â±15% jitter so several concurrent tasks don't hammer a provider in
// lockstep (their rate limiter treats a synchronised burst as abuse).
const pollDelay = (attempt) => {
  const base = Math.min(POLL_INTERVAL_MS, FIRST_POLL_MS * Math.pow(2, attempt));
  const jitter = base * 0.15 * (Math.random() * 2 - 1);
  return Math.max(500, Math.round(base + jitter));
};

const getKey = async (settingKey) => {
  const setting = await db('settings').where({ key: settingKey }).first();
  return setting?.value || null;
};

// ---------- Provider: 2Captcha ----------
const twocaptcha = {
  name: '2captcha',
  settingKey: 'captcha_api_key',
  // How good this provider is per challenge type, lower = tried earlier.
  // Turnstile is 2Captcha's weak spot (slow human pool); reCAPTCHA is its
  // strength. A fixed provider order wastes drop-window seconds on the wrong
  // vendor, so the cascade sorts by this instead.
  rank: { recaptcha: 1, hcaptcha: 2, turnstile: 3, funcaptcha: 2 },
  async solve({ apiKey, type, siteKey, pageUrl, deadline, signal, proxy, userAgent }) {
    const methodMap = { recaptcha: 'userrecaptcha', hcaptcha: 'hcaptcha', turnstile: 'turnstile', funcaptcha: 'funcaptcha' };
    const method = methodMap[type];
    if (!method) throw new Error(`2captcha: unsupported type ${type}`);

    // 2Captcha keeps the SAME method for proxied solves — the proxy arrives as
    // extra params. Unlike the other three vendors there is no separate task
    // name, so a proxied solve must not switch the method.
    const params = {
      key: apiKey, method, pageurl: pageUrl, json: 1,
      ...twocaptchaProxyParams(proxy),
      ...uaParam(userAgent)
    };
    if (type === 'recaptcha') params.googlekey = siteKey;
    else if (type === 'funcaptcha') params.publickey = siteKey;
    else params.sitekey = siteKey;

    const { data: submit } = await axios.post('https://2captcha.com/in.php', null, { params, timeout: 15_000, signal });
    if (submit.status !== 1) throw new Error(`2captcha submit: ${submit.request}`);

    for (let attempt = 0; Date.now() < deadline; attempt++) {
      await sleep(Math.min(pollDelay(attempt), Math.max(200, deadline - Date.now())));
      if (signal?.aborted) throw new Error('2captcha: aborted');
      if (Date.now() >= deadline) break;
      const { data } = await axios.get(`https://2captcha.com/res.php`, {
        params: { key: apiKey, action: 'get', id: submit.request, json: 1 }, timeout: 15_000, signal
      });
      if (data.status === 1) return data.request;
      if (data.request !== 'CAPCHA_NOT_READY') throw new Error(`2captcha: ${data.request}`);
    }
    throw new Error('2captcha: budget exhausted');
  }
};

// ---------- Provider: CapMonster ----------
const capmonster = {
  name: 'capmonster',
  settingKey: 'capmonster_api_key',
  rank: { recaptcha: 2, hcaptcha: 1, turnstile: 2, funcaptcha: 1 },
  async solve({ apiKey, type, siteKey, pageUrl, deadline, signal, proxy, userAgent }) {
    // Proxied and proxyless are DIFFERENT task types here (no *ProxyLess suffix
    // vs suffixed), so the proxy decision has to be made before the type is
    // chosen — sending proxy params with a proxyless type is silently ignored.
    const proxied = Boolean(solverProxy(proxy));
    const baseMap = { recaptcha: 'NoCaptchaTask', hcaptcha: 'HCaptchaTask', turnstile: 'TurnstileTask', funcaptcha: 'FunCaptchaTask' };
    const base = baseMap[type];
    if (!base) throw new Error(`capmonster: unsupported type ${type}`);
    const taskType = taskTypeFor(base, { proxied });

    const taskPayload = type === 'funcaptcha'
      ? { type: taskType, websiteURL: pageUrl, websitePublicKey: siteKey }
      : { type: taskType, websiteURL: pageUrl, websiteKey: siteKey };
    Object.assign(taskPayload, taskProxyParams(proxy), uaParam(userAgent));
    const { data: create } = await axios.post('https://api.capmonster.cloud/createTask', {
      clientKey: apiKey, task: taskPayload
    }, { timeout: 15_000, signal });
    if (create.errorId !== 0) throw new Error(`capmonster create: ${create.errorDescription || create.errorCode}`);

    for (let attempt = 0; Date.now() < deadline; attempt++) {
      await sleep(Math.min(pollDelay(attempt), Math.max(200, deadline - Date.now())));
      if (signal?.aborted) throw new Error('capmonster: aborted');
      if (Date.now() >= deadline) break;
      const { data } = await axios.post('https://api.capmonster.cloud/getTaskResult', {
        clientKey: apiKey, taskId: create.taskId
      }, { timeout: 15_000, signal });
      if (data.errorId !== 0) throw new Error(`capmonster poll: ${data.errorDescription}`);
      if (data.status === 'ready') {
        return data.solution.gRecaptchaResponse || data.solution.token || data.solution.solution;
      }
    }
    throw new Error('capmonster: budget exhausted');
  }
};

// ---------- Provider: AntiCaptcha ----------
const anticaptcha = {
  name: 'anticaptcha',
  settingKey: 'anticaptcha_api_key',
  rank: { recaptcha: 3, hcaptcha: 3, turnstile: 3, funcaptcha: 3 },
  async solve({ apiKey, type, siteKey, pageUrl, deadline, signal, proxy, userAgent }) {
    const proxied = Boolean(solverProxy(proxy));
    const baseMap = { recaptcha: 'RecaptchaV2Task', hcaptcha: 'HCaptchaTask', turnstile: 'TurnstileTask', funcaptcha: 'FunCaptchaTask' };
    const base = baseMap[type];
    if (!base) throw new Error(`anticaptcha: unsupported type ${type}`);
    const taskType = taskTypeFor(base, { proxied });

    const taskPayload = type === 'funcaptcha'
      ? { type: taskType, websiteURL: pageUrl, websitePublicKey: siteKey }
      : { type: taskType, websiteURL: pageUrl, websiteKey: siteKey };
    Object.assign(taskPayload, taskProxyParams(proxy), uaParam(userAgent));
    const { data: create } = await axios.post('https://api.anti-captcha.com/createTask', {
      clientKey: apiKey, task: taskPayload
    }, { timeout: 15_000, signal });
    if (create.errorId !== 0) throw new Error(`anticaptcha create: ${create.errorDescription}`);

    for (let attempt = 0; Date.now() < deadline; attempt++) {
      await sleep(Math.min(pollDelay(attempt), Math.max(200, deadline - Date.now())));
      if (signal?.aborted) throw new Error('anticaptcha: aborted');
      if (Date.now() >= deadline) break;
      const { data } = await axios.post('https://api.anti-captcha.com/getTaskResult', {
        clientKey: apiKey, taskId: create.taskId
      }, { timeout: 15_000, signal });
      if (data.errorId !== 0) throw new Error(`anticaptcha poll: ${data.errorDescription}`);
      if (data.status === 'ready') {
        return data.solution.gRecaptchaResponse || data.solution.token || data.solution.solution;
      }
    }
    throw new Error('anticaptcha: budget exhausted');
  }
};

// ---------- Provider: CapSolver ----------
// CapSolver (api.capsolver.com) uses the same createTask/getTaskResult shape as
// CapMonster/AntiCaptcha (all descend from the anti-captcha API spec), but its
// task-type names differ: reCAPTCHA/hCaptcha use *TaskProxyLess and Turnstile
// uses AntiTurnstileTaskProxyLess. It's one of the cheapest/fastest at
// Turnstile + DataDome, which is why we slot it into the paid cascade.
const capsolver = {
  name: 'capsolver',
  settingKey: 'capsolver_api_key',
  // Best-in-class at Turnstile and DataDome — rank it first for Turnstile so
  // the cascade does not burn its budget on a slow provider first.
  rank: { recaptcha: 2, hcaptcha: 2, turnstile: 1, funcaptcha: 2 },
  async solve({ apiKey, type, siteKey, pageUrl, deadline, signal, proxy, userAgent }) {
    const proxied = Boolean(solverProxy(proxy));
    const baseMap = { recaptcha: 'ReCaptchaV2Task', hcaptcha: 'HCaptchaTask', turnstile: 'AntiTurnstileTask', funcaptcha: 'FunCaptchaTask' };
    const base = baseMap[type];
    if (!base) throw new Error(`capsolver: unsupported type ${type}`);
    const taskType = taskTypeFor(base, { proxied });

    const taskPayload = type === 'funcaptcha'
      ? { type: taskType, websiteURL: pageUrl, websitePublicKey: siteKey }
      : { type: taskType, websiteURL: pageUrl, websiteKey: siteKey };
    Object.assign(taskPayload, capsolverProxyParams(proxy), uaParam(userAgent));
    const { data: create } = await axios.post('https://api.capsolver.com/createTask', {
      clientKey: apiKey, task: taskPayload
    }, { timeout: 15_000, signal });
    if (create.errorId !== 0) throw new Error(`capsolver create: ${create.errorDescription || create.errorCode}`);

    for (let attempt = 0; Date.now() < deadline; attempt++) {
      await sleep(Math.min(pollDelay(attempt), Math.max(200, deadline - Date.now())));
      if (signal?.aborted) throw new Error('capsolver: aborted');
      if (Date.now() >= deadline) break;
      const { data } = await axios.post('https://api.capsolver.com/getTaskResult', {
        clientKey: apiKey, taskId: create.taskId
      }, { timeout: 15_000, signal });
      if (data.errorId !== 0) throw new Error(`capsolver poll: ${data.errorDescription || data.errorCode}`);
      if (data.status === 'ready') {
        return data.solution.gRecaptchaResponse || data.solution.token || data.solution.solution;
      }
    }
    throw new Error('capsolver: budget exhausted');
  }
};

// ---------- Provider: Manual Harvester ----------
// Two solve modes:
//   'in_page' (DEFAULT, recommended) — pause the bot's already-open puppeteer
//     page (which is on the real target domain) and poll for the captcha
//     widget's hidden response field to be filled by the human. Tokens minted
//     this way ARE accepted by the site because they're bound to the correct
//     hostname. Requires headful Chrome and the page handle threaded through.
//   'tab' — push challenge to /v1/harvester/pending; UI at /harvester.html
//     renders the widget with the sitekey. WARNING: most modern sitekeys are
//     hostname-bound and will REJECT tokens solved on localhost:3000.
//     Useful only for sitekeys that aren't strictly bound (rare).
//
// Position controlled by setting `harvester_position`:
//   'first' = preferred / free (paid providers tried only as fallback)
//   'last'  = fallback only (paid providers tried first)
const harvester = {
  name: 'harvester',
  settingKey: '__harvester__',
  async solve({ type, siteKey, pageUrl, deadline, page, mode }) {
    if (mode === 'in_page' && page) {
      return solveInPage({ page, type, deadline });
    }
    return createHarvesterChallenge({ type, siteKey, pageUrl, deadline });
  }
};

const PAID_PROVIDERS = [twocaptcha, capmonster, capsolver, anticaptcha];

// Cap how long the harvester can hold the global budget when it's NOT the
// last provider — otherwise harvester_position=first would drain the entire
// 90s budget before paid providers ever get tried.
const DEFAULT_HARVESTER_MAX_WAIT_MS = 30_000;
// Per-provider health, so a provider that is timing out or rate-limiting right
// now sinks in the order instead of being retried first every single time.
//   strikes — consecutive failures; reset on success
//   cooldownUntil — epoch ms; hard skip window after repeated failures
const providerHealth = new Map();
const STRIKE_COOLDOWN_MS = 120_000;

const healthOf = (p) => providerHealth.get(p.name) || { strikes: 0, cooldownUntil: 0 };

const recordSuccess = (p) => providerHealth.set(p.name, { strikes: 0, cooldownUntil: 0 });

const recordFailure = (p) => {
  const h = healthOf(p);
  const strikes = h.strikes + 1;
  // Two blips are noise; the third means a real provider problem worth routing
  // around for a couple of minutes rather than hammering.
  providerHealth.set(p.name, {
    strikes,
    cooldownUntil: strikes >= 3 ? Date.now() + STRIKE_COOLDOWN_MS : h.cooldownUntil
  });
};

// Order providers for a challenge type: healthy before tripped, then best-typed
// rank, then fewest recent strikes. Array.sort is stable, so equally-ranked
// providers keep declaration order.
const orderProviders = (type, providers) => {
  const now = Date.now();
  return [...providers].sort((a, b) => {
    const ah = healthOf(a);
    const bh = healthOf(b);
    if ((ah.cooldownUntil > now) !== (bh.cooldownUntil > now)) {
      return (ah.cooldownUntil > now ? 1 : 0) - (bh.cooldownUntil > now ? 1 : 0);
    }
    const ar = a.rank?.[type] ?? 9;
    const br = b.rank?.[type] ?? 9;
    if (ar !== br) return ar - br;
    return ah.strikes - bh.strikes;
  });
};



// Two cascade modes:
//
//  1. RACE - for Turnstile with two capable providers, submit to both at once
//     and take the first token. Turnstile latency varies from 1s to 25s on
//     the same sitekey and it is what gates Topps/DataDome checkouts, so the
//     duplicate solve is cheaper than waiting out a slow provider in sequence.
//  2. SEQUENTIAL - ranked order, first success wins. Used elsewhere, where a
//     wasted second solve is real money and the top provider almost always wins.
//
// All attempts share one GLOBAL deadline: once it expires no further provider
// is tried, so a 4-provider failure cannot eat six minutes of the drop.
export const solveWithCascade = async ({ type, siteKey, pageUrl, page, proxy = null, userAgent = null }) => {
  // Consumption point for the stockpile. A pre-solved token turns a 10-30s
  // hCaptcha or 15-25s reCAPTCHA into an instant return, which is the single
  // largest bypass speedup available and costs no extra bandwidth. Only fresh
  // tokens are served (consumeToken sweeps on TTL), and a miss falls through to
  // live solving exactly as before.
  const stocked = consumeToken(type, siteKey);
  if (stocked) {
    logger.info(`[Captcha] Served pre-solved ${type} token for ${siteKey.slice(0, 10)}... (stockpile hit)`);
    return stocked;
  }

  const budgetSetting = await getKey('captcha_total_budget_ms');
  const totalBudget = parseInt(budgetSetting) || DEFAULT_TOTAL_BUDGET_MS;
  const globalDeadline = Date.now() + totalBudget;
  const errors = [];

  // Harvester position setting.
  // 'first' = harvester tried before paid providers (free solves preferred).
  // 'last'  = harvester is the final fallback after paid providers fail.
  // 'off' or unset = harvester not in cascade (default — opt-in).
  const harvesterEnabled = await getKey('harvester_enabled');
  const harvesterPosition = (await getKey('harvester_position')) || 'last';
  const harvesterMode = (await getKey('harvester_mode')) || 'in_page';
  const harvesterMaxWaitSetting = await getKey('harvester_max_wait_ms');
  const harvesterMaxWait = parseInt(harvesterMaxWaitSetting) || DEFAULT_HARVESTER_MAX_WAIT_MS;
  const harvesterOn = harvesterEnabled === 'true' || harvesterEnabled === '1';
  const harvesterFirst = harvesterOn && harvesterPosition === 'first';

  // Resolve keys up front so an unconfigured provider never occupies a race
  // slot, and so ordering is computed over real candidates only.
  const ready = [];
  for (const provider of orderProviders(type, PAID_PROVIDERS)) {
    const apiKey = await getKey(provider.settingKey);
    if (apiKey) ready.push({ provider, apiKey });
  }

  const attempt = async ({ provider, apiKey }, { deadline, label, signal }) => {
    const t0 = Date.now();
    try {
      logger.info(`[Captcha] ${label} ${provider.name} for ${type} (${Math.max(0, deadline - Date.now())}ms remaining${provider === harvester ? `, mode=${harvesterMode}` : ''})`);
      // Harvester takes no API key - it is always configured when enabled.
      const token = await provider.solve({
        apiKey: apiKey ?? '__harvester__',
        type,
        siteKey,
        pageUrl,
        deadline,
        page,
        mode: harvesterMode,
        signal,
        proxy,
        userAgent
      });
      logger.info(`[Captcha] ${provider.name} solved ${type} in ${Date.now() - t0}ms`);
      if (provider !== harvester) recordSuccess(provider);
      // Also deposit into the stockpile. It only ever holds tokens THIS process
      // minted for THIS sitekey, so a hit is always the right challenge, and the
      // next solve for the same sitekey returns instantly.
      if (provider !== harvester) depositToken(type, siteKey, token);
      return token;
    } catch (err) {
      logger.warn(`[Captcha] ${provider.name} failed ${type} after ${Date.now() - t0}ms: ${err.message}`);
      // An aborted loser is not a provider fault — its cooldown strikes should
      // reflect real outages, not the race being won by someone else.
      if (provider !== harvester && !signal?.aborted) recordFailure(provider);
      errors.push(`${provider.name}: ${err.message}`);
      throw err;
    }
  };

  // Harvester-first is a human, so it runs alone and bounds its own wait;
  // paid providers still get whatever budget is left if it fails.
  if (harvesterFirst) {
    const deadline = Math.min(globalDeadline, Date.now() + harvesterMaxWait);
    try {
      return await attempt({ provider: harvester }, { deadline, label: 'Trying' });
    } catch (_) { /* fall through to paid providers */ }
  }

  // Head-to-head race for Turnstile: two capable providers, first token wins.
  //
  // Promise.allSettled was WRONG here: it only resolves once *both* settle, so a
  // 28s loser held the winning token hostage and the fast racer bought nothing.
  // Now the first token returns immediately and the loser is aborted (its
  // in-flight HTTP call is cancelled via AbortSignal), which also stops the
  // orphaned poll loop from spending the rest of the global budget.
  const racers = type === 'turnstile' ? ready.slice(0, 2) : [];
  if (racers.length === 2) {
    logger.info(`[Captcha] Racing ${racers.map((r) => r.provider.name).join(' vs ')} for ${type}`);
    const controllers = racers.map(() => new AbortController());
    let settled = false;
    try {
      const win = await new Promise((resolve, reject) => {
        let failures = 0;
        racers.forEach((racer, i) => {
          attempt(racer, { deadline: globalDeadline, label: 'Racing', signal: controllers[i].signal })
            .then((token) => {
              if (settled) return;
              settled = true;
              // Cancel the loser so it stops burning budget/proxy sockets.
              controllers.forEach((c, j) => { if (j !== i) c.abort(); });
              resolve(token);
            })
            .catch(() => {
              failures += 1;
              if (!settled && failures === racers.length) {
                settled = true;
                reject(new Error('race lost'));
              }
            });
        });
      });
      if (win) return win;
    } catch (_) { /* both racers failed — fall through to the rest of the list */ }
    ready.splice(0, 2);
  }

  for (const entry of ready) {
    if (Date.now() >= globalDeadline) {
      errors.push(`${entry.provider.name}: skipped (global ${totalBudget}ms budget exhausted)`);
      continue;
    }
    try {
      return await attempt(entry, { deadline: globalDeadline, label: 'Trying' });
    } catch (_) { /* next provider */ }
  }

  if (harvesterOn && !harvesterFirst) {
    if (Date.now() >= globalDeadline) {
      errors.push(`harvester: skipped (global ${totalBudget}ms budget exhausted)`);
    } else {
      try {
        return await attempt({ provider: harvester }, { deadline: globalDeadline, label: 'Trying' });
      } catch (_) { /* fall through to throw */ }
    }
  }
  if (errors.length === 0) {
    throw new Error('No captcha providers configured. Add at least one API key in Settings (captcha_api_key for 2Captcha, capmonster_api_key, capsolver_api_key, or anticaptcha_api_key).');
  }
  throw new Error(`All captcha providers failed within ${totalBudget}ms budget: ${errors.join(' | ')}`);
};

// A proxied solve is strictly better when the caller has an exit: the token is
// minted on the same IP that will submit it. `proxy` stays optional so callers
// without one still get the old proxyless behaviour rather than an error.
export const solveCaptcha = ({ siteKey, pageUrl, page, proxy = null, userAgent = null }) =>
  solveWithCascade({ type: 'recaptcha', siteKey, pageUrl, page, proxy, userAgent });

export const solveHCaptcha = ({ siteKey, pageUrl, page, proxy = null, userAgent = null }) =>
  solveWithCascade({ type: 'hcaptcha', siteKey, pageUrl, page, proxy, userAgent });

export const solveCloudflareTurnstile = ({ siteKey, pageUrl, page, proxy = null, userAgent = null }) =>
  solveWithCascade({ type: 'turnstile', siteKey, pageUrl, page, proxy, userAgent });

export const solveFunCaptcha = ({ publicKey, pageUrl, page, proxy = null, userAgent = null }) =>
  solveWithCascade({ type: 'funcaptcha', siteKey: publicKey, pageUrl, page, proxy, userAgent });

// Test helper — provider health is module state and leaks between cases.
export const __resetCaptureState = () => providerHealth.clear();
