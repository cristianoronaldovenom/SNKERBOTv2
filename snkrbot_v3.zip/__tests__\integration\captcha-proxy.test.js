// Captcha solver proxy wiring tests.
//
// The regression this guards: every provider was called with a *Proxyless task
// type and no UA, so tokens were minted from the solver's datacenter IP with the
// solver's fingerprint and then submitted from our residential exit — an IP and
// fingerprint mismatch on exactly the challenges where it matters most.
//
// Two things must hold: proxied and proxyless task names differ per vendor (get
// the name wrong and the proxy params are silently ignored, not rejected), and
// proxy params must be absent — never empty-string — when there is no proxy.
import { describe, expect, test } from '@jest/globals';
import {
  capsolverProxyParams, solverProxy, taskProxyParams, taskTypeFor,
  twocaptchaProxyParams, uaParam
} from '../../helpers/captcha-proxy.js';

const proxy = {
  host: 'gate.provider.net', port: 8000, username: 'user1', password: 'p@ss:word',
  proxy_type: 'residential'
};

describe('solverProxy', () => {
  test('normalises a residential proxy', () => {
    expect(solverProxy(proxy)).toEqual({
      host: 'gate.provider.net', port: 8000, username: 'user1', password: 'p@ss:word', type: 'http'
    });
  });

  test('a missing host or port means no proxy', () => {
    expect(solverProxy(null)).toBeNull();
    expect(solverProxy({})).toBeNull();
    expect(solverProxy({ host: 'h' })).toBeNull();
  });

  test('an unknown proxy type falls back to http rather than being passed through', () => {
    expect(solverProxy({ ...proxy, proxy_type: 'quantum' }).type).toBe('http');
    expect(solverProxy({ ...proxy, proxy_type: 'socks5' }).type).toBe('socks5');
  });

  test('datacenter type is accepted (still a valid http proxy)', () => {
    expect(solverProxy({ ...proxy, proxy_type: 'datacenter' }).type).toBe('http');
  });
});

describe('proxy params', () => {
  test('2captcha uses lowercase query keys', () => {
    expect(twocaptchaProxyParams(proxy)).toEqual({
      proxy: 'gate.provider.net:8000', proxytype: 'http', proxyuser: 'user1', proxypass: 'p@ss:word'
    });
  });

  test('task-spec providers use split address/port keys', () => {
    expect(taskProxyParams(proxy)).toEqual({
      proxyType: 'http', proxyAddress: 'gate.provider.net', proxyPort: 8000,
      proxyLogin: 'user1', proxyPassword: 'p@ss:word'
    });
  });

  test('capsolver takes one URL and percent-encodes the credentials', () => {
    const out = capsolverProxyParams(proxy);
    expect(out.proxyType).toBe('http');
    expect(out.proxy).toBe('http://user1:p%40ss%3Aword@gate.provider.net:8000');
  });

  test('credentials are omitted when the proxy has none', () => {
    const bare = { host: 'h', port: 1 };
    expect(twocaptchaProxyParams(bare)).toEqual({ proxy: 'h:1', proxytype: 'http' });
    expect(taskProxyParams(bare)).toEqual({ proxyType: 'http', proxyAddress: 'h', proxyPort: 1 });
    expect(capsolverProxyParams(bare).proxy).toBe('http://h:1');
  });

  test('no proxy yields an empty set, so nothing is sent', () => {
    expect(twocaptchaProxyParams(null)).toEqual({});
    expect(taskProxyParams(null)).toEqual({});
    expect(capsolverProxyParams(null)).toEqual({});
  });
});

describe('task type names', () => {
  test('proxyless appends the suffix, proxied does not', () => {
    expect(taskTypeFor('TurnstileTask', { proxied: false })).toBe('TurnstileTaskProxyLess');
    expect(taskTypeFor('TurnstileTask', { proxied: true })).toBe('TurnstileTask');
  });

  test('the proxied name is a prefix of the proxyless one', () => {
    // Guards against a typo in one half leaving the pair unusable.
    const proxied = taskTypeFor('HCaptchaTask', { proxied: true });
    expect(taskTypeFor('HCaptchaTask', { proxied: false }).startsWith(proxied)).toBe(true);
  });
});

describe('user agent', () => {
  test('a UA is forwarded so the solving browser matches ours', () => {
    expect(uaParam('Mozilla/5.0 (Windows NT 10.0) Chrome/131.0.0.0')).toEqual({
      userAgent: 'Mozilla/5.0 (Windows NT 10.0) Chrome/131.0.0.0'
    });
  });

  test('no UA sends no field, rather than an empty one that overrides a default', () => {
    expect(uaParam(null)).toEqual({});
    expect(uaParam('')).toEqual({});
  });
});
