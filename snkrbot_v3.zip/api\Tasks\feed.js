import { Router } from 'express';
import db from '../../db/index.js';
import { getAllMonitors } from '../../helpers/monitor-store.js';

const router = Router();

router.get('/', async (_req, res, next) => {
  try {
    const rows = await db('task_runs')
      .select('task_id', 'status', 'stage_failed', 'duration_ms', 'started_at', 'finished_at')
      .orderBy('started_at', 'desc')
      .limit(40)
      .catch(() => []);

    const monitors = Object.values(getAllMonitors() || {}).map((m) => ({
      taskId: Number(m?.taskId ?? m?.id ?? 0),
      siteId: m?.siteId ?? null,
      status: m?.status ?? m?.state ?? 'checking',
      message: m?.message ?? m?.lastMessage ?? '',
      lastCheckedAt: m?.lastCheckedAt ?? m?.updatedAt ?? null,
    }));

    res.json({ success: true, message: 'Live automation feed', data: { monitors, recentRuns: rows } });
  } catch (err) {
    next(err);
  }
});

export default router;
