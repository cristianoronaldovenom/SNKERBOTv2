export const up = async (knex) => {
  await knex.schema.createTableIfNotExists('user_sessions', (t) => {
    t.string('sid').primary();
    t.jsonb('sess').notNullable();
    t.timestamp('expire', { precision: 6 }).notNullable().index();
  });
};

export const down = async (knex) => {
  await knex.schema.dropTableIfExists('user_sessions');
};
