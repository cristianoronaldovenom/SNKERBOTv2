// Dependency-free semantic recovery for checkout DOM drift.
// Used only after a site's explicit selectors are unavailable. The goal is to
// recover from harmless markup changes (renamed classes/IDs, extra wrappers,
// React rerenders) without guessing through an ambiguous final-order control.

const TOKEN_RE = /[a-z0-9]+/gi;
const normalize = (s) => String(s || '').replace(/\s+/g, ' ').trim().toLowerCase();

const TOKEN_GROUPS = [
  ['email', ['email', 'e-mail']],
  ['first_name', ['firstname', 'first-name', 'givenname', 'given-name', 'first']],
  ['last_name', ['lastname', 'last-name', 'surname', 'familyname', 'family-name', 'last']],
  ['address1', ['address', 'address1', 'address-line1', 'address-line-1', 'street', 'shippingaddress', 'billingaddress']],
  ['address2', ['address2', 'address-line2', 'address-line-2', 'apt', 'unit', 'suite', 'apartment']],
  ['city', ['city', 'town']],
  ['state', ['state', 'province', 'region', 'territory']],
  ['postal', ['postal', 'postcode', 'zipcode', 'zip-code', 'zip']],
  ['country', ['country', 'country-code']],
  ['phone', ['phone', 'telephone', 'mobile', 'tel']],
  ['card_number', ['cardnumber', 'card-number', 'cc-number', 'creditcardnumber', 'encryptedcardnumber']],
  ['card_name', ['cardholder', 'card-holder', 'cardowner', 'card-owner', 'nameoncard', 'name-on-card', 'cardname']],
  ['cvv', ['cvv', 'cvc', 'securitycode', 'security-code', 'cardverification']],
  ['exp_month', ['expmonth', 'expiry-month', 'expirationmonth', 'cc-exp-month']],
  ['exp_year', ['expyear', 'expiry-year', 'expirationyear', 'cc-exp-year']],
  ['quantity', ['quantity', 'qty']],
  ['add_to_cart', ['addtocart', 'add-to-cart', 'addtobag', 'add-to-bag']],
  ['checkout', ['checkout', 'proceedtocheckout', 'cartcheckout']],
  ['guest', ['guest', 'continueasguest', 'guestcheckout']],
  ['continue', ['continue', 'next', 'proceed', 'shipping-submit', 'payment-submit']],
  ['place_order', ['placeorder', 'place-order', 'submitorder', 'completeorder', 'submit-order', 'complete-order']],
];

const flattenHints = (selectors = []) => {
  const raw = selectors.flatMap((s) => String(s || '').match(TOKEN_RE) || []).map(normalize);
  const text = normalize(selectors.join(' '));
  return { raw, text };
};

const groupFor = (hints) => {
  const matches = [];
  for (const [group, aliases] of TOKEN_GROUPS) {
    const hit = aliases.some((alias) => hints.text.includes(alias) || hints.raw.some((t) => t === alias || t.includes(alias)));
    if (hit) matches.push(group);
  }
  return [...new Set(matches)];
};

const escapeCss = (value) => String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"');

const uniqueSelectorFor = (el) => {
  if (el.id) return `#${escapeCss(el.id)}`;

  for (const attr of ['data-testid', 'data-test', 'data-qa', 'name', 'autocomplete']) {
    const value = el.getAttribute?.(attr);
    if (!value) continue;
    const selector = `${el.tagName.toLowerCase()}[${attr}="${escapeCss(value)}"]`;
    try {
      if (document.querySelectorAll(selector).length === 1) return selector;
    } catch (_) {}
  }

  const parts = [];
  let node = el;
  for (let depth = 0; node && node.nodeType === 1 && depth < 8; node = node.parentElement, depth += 1) {
    let part = node.tagName.toLowerCase();
    const cls = typeof node.className === 'string'
      ? node.className.split(/\s+/).filter(Boolean).slice(0, 2)
      : [];
    if (cls.length) part += cls.map((c) => `.${escapeCss(c)}`).join('');
    if (node.parentElement) {
      const siblings = Array.from(node.parentElement.children).filter((x) => x.tagName === node.tagName);
      if (siblings.length > 1) part += `:nth-of-type(${siblings.indexOf(node) + 1})`;
    }
    parts.unshift(part);
    const candidate = parts.join(' > ');
    try {
      if (document.querySelectorAll(candidate).length === 1) return candidate;
    } catch (_) {}
  }
  return null;
};

const visible = (el) => {
  if (!el) return false;
  const r = el.getBoundingClientRect();
  const s = getComputedStyle(el);
  return r.width > 0 && r.height > 0 && s.display !== 'none' && s.visibility !== 'hidden';
};

const labelsFor = (el) => {
  const out = [];
  const aria = el.getAttribute?.('aria-label');
  if (aria) out.push(aria);
  const placeholder = el.getAttribute?.('placeholder');
  if (placeholder) out.push(placeholder);
  const name = el.getAttribute?.('name');
  if (name) out.push(name);
  const id = el.getAttribute?.('id');
  if (id) out.push(id);
  const autocomplete = el.getAttribute?.('autocomplete');
  if (autocomplete) out.push(autocomplete);
  const test = el.getAttribute?.('data-testid') || el.getAttribute?.('data-test') || el.getAttribute?.('data-qa');
  if (test) out.push(test);
  if (id) {
    const label = document.querySelector(`label[for="${escapeCss(id)}"]`);
    if (label) out.push(label.textContent || '');
  }
  const wrapping = el.closest?.('label');
  if (wrapping) out.push(wrapping.textContent || '');
  const parentText = el.parentElement?.innerText;
  if (parentText && parentText.length < 160) out.push(parentText);
  return normalize(out.join(' '));
};

const actionTextFor = (el) => normalize([
  el.innerText,
  el.value,
  el.getAttribute?.('aria-label'),
  el.getAttribute?.('data-testid'),
  el.getAttribute?.('data-test'),
  el.getAttribute?.('name'),
].filter(Boolean).join(' '));

const badAction = /\b(cancel|delete|remove|edit|back|close|clear|reset|sign ?out|logout|unsubscribe)\b/i;

export const semanticSelector = async (page, selectorList, { kind = 'auto', minScore = 7 } = {}) => {
  const selectors = [...new Set((selectorList || []).filter(Boolean).map(String))];
  if (!selectors.length) return null;
  const hintData = flattenHints(selectors);
  const groups = groupFor(hintData);
  const hintedActions = new Set(groups.filter((g) => ['add_to_cart', 'checkout', 'guest', 'continue', 'place_order'].includes(g)));
  const hintedFields = new Set(groups.filter((g) => !hintedActions.has(g) && g !== 'quantity'));
  const mode = kind === 'auto'
    ? (hintedActions.size ? 'action' : 'field')
    : kind;

  return page.evaluate(({ groups: wantedGroups, hintedActions: actionGroups, hintedFields: fieldGroups, mode, minScore, selectors }) => {
    const TOKEN_GROUPS_LOCAL = [["email",["email","e-mail"]],["first_name",["firstname","first-name","givenname","given-name","first"]],["last_name",["lastname","last-name","surname","familyname","family-name","last"]],["address1",["address1","address-line1","address-line-1","street","shippingaddress","billingaddress"]],["address2",["address2","address-line2","address-line-2","apt","unit","suite","apartment"]],["city",["city","town"]],["state",["state","province","region","territory"]],["postal",["postal","postcode","zipcode","zip-code","zip"]],["country",["country","country-code"]],["phone",["phone","telephone","mobile","tel"]],["card_number",["cardnumber","card-number","cc-number","creditcardnumber","encryptedcardnumber"]],["card_name",["cardholder","card-holder","nameoncard","name-on-card","cardname"]],["cvv",["cvv","cvc","securitycode","security-code","cardverification"]],["exp_month",["expmonth","expiry-month","expirationmonth","cc-exp-month"]],["exp_year",["expyear","expiry-year","expirationyear","cc-exp-year"]],["quantity",["quantity","qty"]],["add_to_cart",["addtocart","add-to-cart","addtobag","add-to-bag"]],["checkout",["checkout","proceedtocheckout","cartcheckout"]],["guest",["guest","continueasguest","guestcheckout"]],["continue",["continue","next","proceed","shipping-submit","payment-submit"]],["place_order",["placeorder","place-order","submitorder","completeorder","submit-order","complete-order"]]];
    const normalizeLocal = (s) => String(s || '').replace(/\s+/g, ' ').trim().toLowerCase();
    const groupHit = (text, aliases) => aliases.some((alias) => text.includes(alias));
    const visibleLocal = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.display !== 'none' && s.visibility !== 'hidden';
    };
    const textOf = (el) => normalizeLocal([
      el.getAttribute?.('aria-label'),
      el.getAttribute?.('placeholder'),
      el.getAttribute?.('name'),
      el.getAttribute?.('id'),
      el.getAttribute?.('autocomplete'),
      el.getAttribute?.('data-testid'),
      el.getAttribute?.('data-test'),
      el.getAttribute?.('data-qa'),
      el.innerText,
      el.value,
      el.closest?.('label')?.innerText,
    ].filter(Boolean).join(' '));
    const actionText = (el) => normalizeLocal([
      el.innerText,
      el.value,
      el.getAttribute?.('aria-label'),
      el.getAttribute?.('data-testid'),
      el.getAttribute?.('data-test'),
      el.getAttribute?.('name'),
    ].filter(Boolean).join(' '));
    const candidates = mode === 'action'
      ? Array.from(document.querySelectorAll('button, a[role="button"], [role="button"], input[type="button"], input[type="submit"]')).filter((el) => visibleLocal(el) && !el.disabled && el.getAttribute('aria-disabled') !== 'true')
      : Array.from(document.querySelectorAll('input, textarea, select')).filter((el) => visibleLocal(el) && !el.disabled);

    const scored = candidates.map((el) => {
      const text = textOf(el);
      let score = 0;
      const groupsToUse = mode === 'action' ? actionGroups : fieldGroups;
      for (const [group, aliases] of TOKEN_GROUPS_LOCAL) {
        if (!groupsToUse.includes(group)) continue;
        if (groupHit(text, aliases)) score += 5;
      }
      const tag = el.tagName.toLowerCase();
      if (mode === 'field') {
        if (tag === 'input' || tag === 'select' || tag === 'textarea') score += 2;
        const ac = normalizeLocal(el.getAttribute('autocomplete') || '');
        if (ac && groupsToUse.some((g) => ac.includes(g.replace('_', '-')))) score += 3;
      } else {
        const action = actionText(el);
        if (actionGroups.includes('place_order')) {
          if (/\b(place|submit|complete)\b.*\b(order|purchase)\b/i.test(action)) score += 7;
          else score -= 8;
        }
        if (actionGroups.includes('add_to_cart') && /add\s*(to|into)?\s*(cart|bag)|buy now/i.test(action)) score += 6;
        if (actionGroups.includes('checkout') && /checkout|proceed to checkout|go to checkout/i.test(action)) score += 6;
        if (actionGroups.includes('guest') && /continue as guest|guest checkout/i.test(action)) score += 6;
        if (actionGroups.includes('continue') && /^(continue|next|proceed|review|delivery|payment)$/i.test(action.trim())) score += 5;
        if (/\b(cancel|delete|remove|edit|back|close|clear|reset|logout)\b/i.test(action)) score -= 12;
      }
      return { el, score, text };
    }).sort((a, b) => b.score - a.score);

    const top = scored[0];
    if (!top || top.score < minScore) return null;

    const el = top.el;
    if (el.id) return `#${CSS.escape(el.id)}`;
    for (const attr of ['data-testid', 'data-test', 'data-qa', 'name', 'autocomplete']) {
      const value = el.getAttribute(attr);
      if (!value) continue;
      const sel = `${el.tagName.toLowerCase()}[${attr}="${CSS.escape(value)}"]`;
      try { if (document.querySelectorAll(sel).length === 1) return sel; } catch (_) {}
    }
    const parts = [];
    let node = el;
    for (let depth = 0; node && node.nodeType === 1 && depth < 8; node = node.parentElement, depth += 1) {
      let part = node.tagName.toLowerCase();
      if (typeof node.className === 'string') {
        const classes = node.className.split(/\s+/).filter(Boolean).slice(0, 2);
        if (classes.length) part += classes.map((c) => `.${CSS.escape(c)}`).join('');
      }
      if (node.parentElement) {
        const siblings = Array.from(node.parentElement.children).filter((x) => x.tagName === node.tagName);
        if (siblings.length > 1) part += `:nth-of-type(${siblings.indexOf(node) + 1})`;
      }
      parts.unshift(part);
      const candidate = parts.join(' > ');
      try { if (document.querySelectorAll(candidate).length === 1) return candidate; } catch (_) {}
    }
    return null;
  }, { groups, hintedActions: [...hintedActions], hintedFields: [...hintedFields], mode, minScore, selectors });
};
