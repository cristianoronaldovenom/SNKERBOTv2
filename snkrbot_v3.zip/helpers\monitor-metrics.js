/**
 * Per-host stock-monitoring metrics.
 *
 * Why this exists: you cannot improve reliability you cannot see. A professional
 * bot exposes, per site: how many checks ran, how many succeeded, how many were
 * blocked, how many errored, the success rate, and latency percentiles. This is
 * what lets you tell "Pokémon Center is hard-blocking from this IP" apart from
 * "my parser is wrong" — without it you are guessing.
 *
 * Cheap, in-memory, ring-buffered latency samples (last 100 per host).
 */

const LAT_WINDOW = 100;
const MAX_HOSTS = 256;

const hosts = new Map(); // host → metric record

const blank = (host) => ({
  host,
  checks: 0,
  inStock: 0,
  outOfStock: 0,
  blocked: 0,
  errors: 0,
  apiHits: 0,        // resolved via JSON API fast-path
  htmlHits: 0,       // resolved via HTML fallback
  lastResult: null,  // 'instock' | 'outofstock' | 'blocked' | 'error'
  lastCheckedAt: 0,
  lastError: null,
  latencies: [],     // ring buffer of ms
  latencyIndex: 0,
});

const get = (host) => {
  let m = hosts.get(host);
  if (!m) {
    // Long-lived hosts must not grow the map forever if a user churns through
    // product URLs. Drop the least-recently-checked entries on insert.
    if (hosts.size >= MAX_HOSTS) {
      let oldestHost = null;
      let oldestAt = Infinity;
      for (const [h, rec] of hosts) {
        const at = rec.lastCheckedAt || 0;
        if (at < oldestAt) { oldestAt = at; oldestHost = h; }
      }
      if (oldestHost) hosts.delete(oldestHost);
    }
    m = blank(host);
    hosts.set(host, m);
  }
  return m;
};

const pushLatency = (m, ms) => {
  if (m.latencies.length < LAT_WINDOW) {
    m.latencies.push(ms);
    m.latencyIndex = m.latencies.length % LAT_WINDOW;
    return;
  }
  m.latencies[m.latencyIndex] = ms;
  m.latencyIndex = (m.latencyIndex + 1) % LAT_WINDOW;
};

/**
 * Record a completed check.
 * @param {string} host
 * @param {{ outcome:'instock'|'outofstock'|'blocked'|'error', latencyMs?:number, source?:'api'|'html', error?:string }} info
 */
export const record = (host, { outcome, latencyMs, source, error } = {}) => {
  const m = get(host);
  m.checks += 1;
  m.lastResult = outcome;
  m.lastCheckedAt = Date.now();
  if (typeof latencyMs === 'number') pushLatency(m, latencyMs);
  if (source === 'api') m.apiHits += 1;
  else if (source === 'html') m.htmlHits += 1;

  switch (outcome) {
    case 'instock': m.inStock += 1; break;
    case 'outofstock': m.outOfStock += 1; break;
    case 'blocked': m.blocked += 1; break;
    case 'error': m.errors += 1; m.lastError = error || 'unknown'; break;
    default: break;
  }
};

const percentile = (sorted, p) => {
  if (!sorted.length) return null;
  const idx = Math.min(sorted.length - 1, Math.floor((p / 100) * sorted.length));
  return sorted[idx];
};

const summarize = (m) => {
  const sorted = [...m.latencies].sort((a, b) => a - b);
  const successful = m.checks - m.blocked - m.errors;
  return {
    host: m.host,
    checks: m.checks,
    inStock: m.inStock,
    outOfStock: m.outOfStock,
    blocked: m.blocked,
    errors: m.errors,
    apiHits: m.apiHits,
    htmlHits: m.htmlHits,
    successRate: m.checks ? +(successful / m.checks).toFixed(3) : null,
    blockRate: m.checks ? +(m.blocked / m.checks).toFixed(3) : null,
    apiResolveRate: m.checks ? +(m.apiHits / m.checks).toFixed(3) : null,
    latency: {
      p50: percentile(sorted, 50),
      p95: percentile(sorted, 95),
      max: sorted.length ? sorted[sorted.length - 1] : null,
    },
    lastResult: m.lastResult,
    lastCheckedAt: m.lastCheckedAt,
    lastError: m.lastError,
  };
};

export const getMetrics = (host) => {
  const m = hosts.get(host);
  return m ? summarize(m) : null;
};

export const getAllMetrics = () => {
  const out = {};
  for (const [host, m] of hosts) out[host] = summarize(m);
  return out;
};

export const reset = (host) => { host ? hosts.delete(host) : hosts.clear(); };
