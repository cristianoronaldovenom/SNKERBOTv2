// Partial (Range) HTML fetch.
//
// The regression this guards: every HTML consumer is head-only — the block scan reads
// the first 4000 bytes, parsers read title/price/size nodes from the top — yet the
// whole page was fetched and cached. On a real PDP that is up to 2 MB of residential
// bandwidth parsed into nothing.
//
// The risk is a truncated head that misses its nodes, so the transport must report a
// 206 as `partial` and NOT report it when the server ignored the Range.
import { beforeEach, describe, expect, jest, test } from '@jest/globals';

const gotMock = jest.fn();
jest.unstable_mockModule('got-scraping', () => ({ gotScraping: gotMock }));
jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));

const mod = await import('../../helpers/stock-monitor.js');

const reply = (statusCode, body) => ({ statusCode, body, headers: {} });

beforeEach(() => { gotMock.mockReset(); });

// The transport caches per URL and skips Range once a validator exists, so each case
// needs its own URL or cases contaminate each other.
let seq = 0;
const drive = async () => {
  const url = `https://shop.example.com/products/probe-${++seq}`;
  await mod.checkStock(url, {}).catch(() => null);
  return gotMock;
};

describe('range request', () => {
  test('a first fetch asks for a head slice', async () => {
    gotMock.mockResolvedValue(reply(206, '<html><title>X</title>'));
    await drive();
    const headers = gotMock.mock.calls.map((c) => c[0].headers || {}).find((h) => h.Range);
    expect(headers?.Range).toMatch(/^bytes=0-\d+$/);
  });

  test('the requested slice is bounded', async () => {
    gotMock.mockResolvedValue(reply(206, '<html></html>'));
    await drive();
    const headers = gotMock.mock.calls.map((c) => c[0].headers || {}).find((h) => h.Range);
    const end = Number(headers.Range.split('-')[1]);
    expect(end).toBeGreaterThan(1024);
    expect(end).toBeLessThan(4 * 1024 * 1024);
  });

  test('a server that ignores Range still works (200, no error)', async () => {
    gotMock.mockResolvedValue(reply(200, '<html><title>X</title><body>ok</body></html>'));
    await expect(drive()).resolves.toBeDefined();
  });

  test('partial fetch can be disabled by env', async () => {
    process.env.MONITOR_PARTIAL_FETCH = 'false';
    try {
      gotMock.mockResolvedValue(reply(200, '<html></html>'));
      await drive();
      const withRange = gotMock.mock.calls.filter((c) => c[0].headers?.Range);
      expect(withRange).toHaveLength(0);
    } finally {
      delete process.env.MONITOR_PARTIAL_FETCH;
    }
  });
});

describe('partial response state', () => {
  test('a parser miss on a partial body refetches in full and does not throw', async () => {
    // First response is a truncated head with no usable nodes, second is complete.
    gotMock
      .mockResolvedValueOnce(reply(206, '<html><head></head><body>'))
      .mockResolvedValueOnce(reply(200, '<html><title>Real</title><body>ok</body></html>'));

    const result = await mod.checkStock(`https://shop.example.com/products/r-${++seq}`, {})
      .catch((err) => ({ threw: err.message }));

    // The original bug: `response` was undefined in scope, so this threw a
    // ReferenceError instead of performing the retry.
    expect(result).not.toMatchObject({ threw: expect.stringContaining('response is not defined') });
    expect(result).toBeDefined();
  });

  test('the full refetch is a second HTML request that skips the Range header', async () => {
    // The API fast path runs first and must fail (non-JSON) so the HTML path is used.
    // The head must be genuinely empty of product nodes so the parser returns null.
    gotMock.mockImplementation(async (opts) => {
      const dest = opts?.headers?.['Sec-Fetch-Dest'];
      if (dest === 'empty') return reply(200, 'not json');
      if (opts.headers?.Range) return reply(206, '<html><head><title></title></head><body></body></html>');
      return reply(200, '<html><title>Real</title><body>ok</body></html>');
    });

    await mod.checkStock(`https://shop.example.com/products/f-${++seq}`, {}).catch(() => null);

    const html = gotMock.mock.calls.filter((c) => c[0]?.headers?.['Sec-Fetch-Dest'] === 'document');
    expect(html.length).toBeGreaterThanOrEqual(2);
    expect(html[0][0].headers?.Range).toBeDefined();
    expect(html[1][0].headers?.Range).toBeUndefined();
  });

  test('a 200 despite asking means complete, so no second HTML request', async () => {
    gotMock.mockResolvedValueOnce(reply(200, '<html><title>Whole page</title></html>'));
    await mod.checkStock(`https://shop.example.com/products/n-${++seq}`, {}).catch(() => null);
    const html = gotMock.mock.calls.filter((c) => c[0]?.headers?.['Sec-Fetch-Dest'] === 'document');
    expect(html).toHaveLength(1);
  });
});
