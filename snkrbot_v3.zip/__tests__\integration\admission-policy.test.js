// Pure-policy tests for the checkout admission layer.
//
// The headline regression is the duplicated `--disable-features`: the static arg
// list and the lightweight-mode block both emitted one, and because Chromium only
// honours the last occurrence the first list was discarded on every default
// launch (LIGHTWEIGHT_TASK_MODE defaults to true). That silently re-enabled
// site-per-process — one renderer per origin, the largest single RAM cost of a
// headless page — and dropped WebRTC mDNS hiding.
import { describe, expect, test } from '@jest/globals';
import {
  buildChromiumArgs, mergeDisableFeatures, recommendedRendererLimit,
  isLowRamHost, checkoutAdmission, recommendedHeapCapMb, GB
} from '../../helpers/admission.js';

const disableFeaturesArgs = (args) => args.filter((a) => a.startsWith('--disable-features'));

describe('renderer heap cap', () => {
  test('a cap is emitted as js-flags and stays within sane bounds', () => {
    const args = buildChromiumArgs({ heapCapMb: 384 });
    expect(args).toContain('--js-flags=--max-old-space-size=384');
    // A 4 MB semi-space keeps scavenges cheap on a small host.
    expect(args).toContain('--js-flags=--max-semi-space-size=4');
  });

  test('no cap means no js-flags at all', () => {
    expect(buildChromiumArgs({}).filter((a) => a.startsWith('--js-flags='))).toHaveLength(0);
    expect(buildChromiumArgs({ heapCapMb: 0 })).toEqual(buildChromiumArgs({}));
  });

  test('the cap scales with the host but is clamped to useful values', () => {
    expect(recommendedHeapCapMb({})).toBe(0);
    // 1 GB host → 256 MB; small enough to protect, large enough for a PDP.
    expect(recommendedHeapCapMb({ totalMemoryBytes: 1 * GB })).toBe(256);
    // Never below 128 MB even on a tiny box (below that V8 thrashes).
    expect(recommendedHeapCapMb({ totalMemoryBytes: 0.25 * GB })).toBe(128);
    // Never above 768 MB: past that the cap stops protecting the host.
    expect(recommendedHeapCapMb({ totalMemoryBytes: 64 * GB })).toBe(768);
  });
});

describe('chromium launch args', () => {

  test.each([
    ['plain', {}],
    ['lightweight', { lightweight: true }],
    ['low ram', { lowRam: true }],
    ['both', { lightweight: true, lowRam: true }]
  ])('%s launch emits --disable-features exactly once', (_label, opts) => {
    const args = buildChromiumArgs(opts);
    expect(disableFeaturesArgs(args)).toHaveLength(1);
  });

  test('site isolation and webrtc mdns hiding are always disabled', () => {
    // Only the last --disable-features wins, so these must survive every mode.
    for (const opts of [{}, { lightweight: true }, { lowRam: true }]) {
      const list = disableFeaturesArgs(buildChromiumArgs(opts))[0];
      expect(list).toContain('site-per-process');
      expect(list).toContain('IsolateOrigins');
      expect(list).toContain('WebRtcHideLocalIpsWithMdns');
    }
  });

  test('low-ram adds the cache/telemetry features a plain launch omits', () => {
    const plain = disableFeaturesArgs(buildChromiumArgs({}))[0];
    const low = disableFeaturesArgs(buildChromiumArgs({ lowRam: true }))[0];
    expect(plain).not.toContain('OptimizationHints');
    expect(low).toContain('OptimizationHints');
  });

  test('duplicate features from a caller are collapsed, not repeated', () => {
    const args = mergeDisableFeatures([
      '--disable-features=a,b',
      '--disable-features=b,c',
      '--no-sandbox'
    ]);
    expect(args).toEqual(['--no-sandbox', '--disable-features=a,b,c']);
  });

  test('proxy credentials and the credential bypass list are wired', () => {
    const args = buildChromiumArgs({ proxy: { host: 'gw.example', port: 8000, username: 'u' } });
    expect(args).toContain('--proxy-server=gw.example:8000');
    // Without the loopback bypass an authenticated proxy can break local CDP.
    expect(args).toContain('--proxy-bypass-list=<-loopback>');
  });

  test('extraArgs are merged and feature flags inside them deduped', () => {
    const args = buildChromiumArgs({ extraArgs: ['--disable-dev-shm-usage', '--disable-features=site-per-process'] });
    expect(args).toContain('--disable-dev-shm-usage');
    expect(disableFeaturesArgs(args)).toHaveLength(1);
    expect(disableFeaturesArgs(args)[0].match(/site-per-process/g)).toHaveLength(1);
  });

  test('a renderer limit is only emitted when one is supplied', () => {
    expect(buildChromiumArgs({}).some((a) => a.includes('renderer-process-limit'))).toBe(false);
    expect(buildChromiumArgs({ rendererLimit: 2 })).toContain('--renderer-process-limit=2');
  });
});

describe('host sizing', () => {
  test.each([
    [1 * GB, 2], [2 * GB, 2], [4 * GB, 3], [8 * GB, 5], [32 * GB, 0]
  ])('%i bytes yields renderer limit %i', (bytes, expected) => {
    expect(recommendedRendererLimit({ totalMemoryBytes: bytes })).toBe(expected);
  });

  test('an unknown host keeps Chromium defaults', () => {
    expect(recommendedRendererLimit({ totalMemoryBytes: 0 })).toBe(0);
  });

  test('low-RAM detection is bounded and off for unknown hosts', () => {
    expect(isLowRamHost({ limitBytes: 1 * GB })).toBe(true);
    expect(isLowRamHost({ limitBytes: 16 * GB })).toBe(false);
    expect(isLowRamHost(null)).toBe(false);
    expect(isLowRamHost({ limitBytes: 0 })).toBe(false);
  });
});

describe('admission verdict', () => {
  const roomy = { limitBytes: 16 * GB, currentBytes: 4 * GB };
  const tight = { limitBytes: 2 * GB, currentBytes: 2 * GB };
  const residential = { proxy_type: 'residential' };

  test('a roomy host admits and needs no wait', () => {
    const v = checkoutAdmission({ memory: roomy, proxy: residential });
    expect(v.admit).toBe(true);
    expect(v.waitForProxy).toBe(false);
    expect(v.isResidential).toBe(true);
  });

  test('saturated memory rejects even when the proxy has capacity', () => {
    const v = checkoutAdmission({ memory: tight, proxy: residential, activeResidential: 0, maxResidential: 4 });
    expect(v.admit).toBe(false);
    expect(v.reasons).toContain('memory_saturated');
    // Waiting for a gateway slot cannot create RAM, so there is nothing to wait for.
    expect(v.waitForProxy).toBe(false);
  });

  test('a full residential pool waits instead of rejecting', () => {
    const v = checkoutAdmission({ memory: roomy, proxy: residential, activeResidential: 4, maxResidential: 4 });
    expect(v.reasons).toContain('residential_sessions_full');
    // Headroom exists, so this is a "wait your turn", not a hard no.
    expect(v.admit).toBe(false);
    expect(v.waitForProxy).toBe(true);
  });

  test('a non-residential proxy is not subject to the session cap', () => {
    const v = checkoutAdmission({
      memory: roomy, proxy: { proxy_type: 'datacenter' }, activeResidential: 99, maxResidential: 4
    });
    expect(v.admit).toBe(true);
    expect(v.isResidential).toBe(false);
  });

  test('a missing snapshot is tolerated', () => {
    expect(checkoutAdmission({ memory: null, proxy: null }).admit).toBe(true);
  });
});
