// Session secret policy.
//
// The regression this guards: a known fallback secret was accepted silently in
// production. Anyone who read the source could forge a signed cookie for any userId.
// Compose requires the variable, but launching outside it (bare `node app.js`, a
// PaaS, a one-off container) did not — so the fallback was reachable in prod.
//
// Production without a secret must now refuse to boot; development must stay
// frictionless; and an explicit escape hatch exists for throwaway deployments.
import { describe, expect, test, jest } from '@jest/globals';

// The secret is resolved at module load, so each case needs a fresh module with its
// own environment.
const loadAuth = async (env) => {
  const saved = { ...process.env };
  for (const k of ['SESSION_SECRET', 'NODE_ENV', 'ALLOW_INSECURE_SESSION_SECRET']) delete process.env[k];
  Object.assign(process.env, env);
  jest.resetModules();
  try {
    return await import('../../helpers/auth.js');
  } finally {
    for (const k of ['SESSION_SECRET', 'NODE_ENV', 'ALLOW_INSECURE_SESSION_SECRET']) delete process.env[k];
    Object.assign(process.env, saved);
  }
};

const bootError = async (env) => {
  try {
    await loadAuth(env);
    return null;
  } catch (err) {
    return err.message;
  }
};

describe('production requires a secret', () => {
  test('production without SESSION_SECRET refuses to boot', async () => {
    const msg = await bootError({ NODE_ENV: 'production' });
    expect(msg).toMatch(/SESSION_SECRET is required in production/);
    expect(msg).toMatch(/ALLOW_INSECURE_SESSION_SECRET/);
  });

  test('production with a real secret boots', async () => {
    expect(await bootError({ NODE_ENV: 'production', SESSION_SECRET: 'a'.repeat(64) })).toBeNull();
  });

  test('the escape hatch allows the fallback in production', async () => {
    expect(await bootError({ NODE_ENV: 'production', ALLOW_INSECURE_SESSION_SECRET: '1' })).toBeNull();
  });

  test('an empty string counts as unset, not as a blank secret', async () => {
    expect(await bootError({ NODE_ENV: 'production', SESSION_SECRET: '   ' })).toMatch(/required in production/);
  });
});

describe('development stays permissive', () => {
  test('development without a secret boots', async () => {
    expect(await bootError({ NODE_ENV: 'development' })).toBeNull();
  });

  test('an unset NODE_ENV is treated as non-production', async () => {
    expect(await bootError({})).toBeNull();
  });
});

describe('placeholder detection', () => {
  test('the documented placeholder in production warns but boots', async () => {
    const warn = jest.spyOn(console, 'warn').mockImplementation(() => {});
    try {
      const msg = await bootError({ NODE_ENV: 'production', SESSION_SECRET: 'sneakerbot-change-me-set-SESSION_SECRET' });
      expect(msg).toBeNull();
      expect(warn.mock.calls.flat().join(' ')).toMatch(/placeholder/);
    } finally {
      warn.mockRestore();
    }
  });
});
