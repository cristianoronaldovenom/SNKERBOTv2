// Rate limiter tests.
//
// The regression this guards: login had NO limit at all, and bcrypt at cost 12 means
// each attempt burns real CPU. An unauthenticated attacker could both guess
// passwords and pin the box. The API was equally unbounded.
//
// The login key is deliberately username+IP so one attacker cannot lock the owner
// out; that is asserted explicitly rather than left implicit.
import { beforeEach, describe, expect, test } from '@jest/globals';
import { loginKey, rateLimit, rateLimitBuckets, resetRateLimits } from '../../helpers/rate-limit.js';

beforeEach(() => resetRateLimits());

const mockReq = (over = {}) => ({ ip: '1.2.3.4', body: {}, ...over });
const mockRes = () => {
  const headers = {};
  const res = {
    statusCode: 200,
    payload: null,
    setHeader: (k, v) => { headers[k] = v; },
    status(code) { res.statusCode = code; return res; },
    json(body) { res.payload = body; return res; },
    headers
  };
  return res;
};

const run = (mw, req) => {
  const res = mockRes();
  let nexted = false;
  mw(req, res, () => { nexted = true; });
  return { nexted, res };
};

describe('windows and limits', () => {
  test('allows up to max then returns 429', () => {
    const mw = rateLimit({ name: 't1', windowMs: 60_000, max: 3 });
    for (let i = 0; i < 3; i++) expect(run(mw, mockReq()).nexted).toBe(true);

    const blocked = run(mw, mockReq());
    expect(blocked.nexted).toBe(false);
    expect(blocked.res.statusCode).toBe(429);
    expect(blocked.res.payload.success).toBe(false);
  });

  test('429 carries Retry-After so clients back off', () => {
    const mw = rateLimit({ name: 't2', windowMs: 60_000, max: 1 });
    run(mw, mockReq());
    const { res } = run(mw, mockReq());
    expect(Number(res.headers['Retry-After'])).toBeGreaterThan(0);
  });

  test('rate-limit headers are always exposed', () => {
    const mw = rateLimit({ name: 't3', windowMs: 60_000, max: 5 });
    const { res } = run(mw, mockReq());
    expect(res.headers['X-RateLimit-Limit']).toBe('5');
    expect(res.headers['X-RateLimit-Remaining']).toBe('4');
  });

  test('separate names do not share buckets', () => {
    const a = rateLimit({ name: 'a', windowMs: 60_000, max: 1 });
    const b = rateLimit({ name: 'b', windowMs: 60_000, max: 1 });
    run(a, mockReq());
    expect(run(a, mockReq()).nexted).toBe(false);
    expect(run(b, mockReq()).nexted).toBe(true);
  });

  test('separate clients do not share buckets', () => {
    const mw = rateLimit({ name: 'c', windowMs: 60_000, max: 1 });
    run(mw, mockReq({ ip: '9.9.9.9' }));
    expect(run(mw, mockReq({ ip: '8.8.8.8' })).nexted).toBe(true);
  });

  test('the window expires and traffic resumes', async () => {
    // Minimum window is clamped to 1s, so wait past it.
    const mw = rateLimit({ name: 'd', windowMs: 1000, max: 1 });
    run(mw, mockReq());
    expect(run(mw, mockReq()).nexted).toBe(false);
    await new Promise((r) => setTimeout(r, 1100));
    expect(run(mw, mockReq()).nexted).toBe(true);
  });

  test('a sub-second window is clamped up rather than creating a hot loop', () => {
    const mw = rateLimit({ name: 'e', windowMs: 10, max: 1 });
    run(mw, mockReq());
    expect(run(mw, mockReq()).nexted).toBe(false);
  });
});

describe('login key', () => {
  test('keys on username AND address', () => {
    expect(loginKey(mockReq({ body: { username: 'Owner' }, ip: '1.1.1.1' }))).toBe('owner|1.1.1.1');
  });

  test('one attacker on a different IP cannot lock the owner out', () => {
    const mw = rateLimit({ name: 'login', windowMs: 60_000, max: 1, key: loginKey });
    // Attacker exhausts owner|attacker-ip.
    run(mw, mockReq({ body: { username: 'owner' }, ip: '6.6.6.6' }));
    expect(run(mw, mockReq({ body: { username: 'owner' }, ip: '6.6.6.6' })).nexted).toBe(false);
    // The owner from their own address still gets through.
    expect(run(mw, mockReq({ body: { username: 'owner' }, ip: '1.1.1.1' })).nexted).toBe(true);
  });

  test('falls back to the address when no username is supplied', () => {
    expect(loginKey(mockReq({ body: {}, ip: '2.2.2.2' }))).toBe('2.2.2.2');
  });

  test('username casing does not create a second bucket', () => {
    expect(loginKey(mockReq({ body: { username: 'OWNER' } }))).toBe(loginKey(mockReq({ body: { username: 'owner' } })));
  });
});

describe('bookkeeping', () => {
  test('a missing ip still yields a usable key', () => {
    const mw = rateLimit({ name: 'f', windowMs: 60_000, max: 1 });
    expect(run(mw, { body: {}, socket: { remoteAddress: '7.7.7.7' } }).nexted).toBe(true);
  });

  test('buckets are created and resettable', () => {
    run(rateLimit({ name: 'g', windowMs: 60_000, max: 1 }), mockReq());
    expect(rateLimitBuckets()).toBeGreaterThan(0);
    resetRateLimits();
    expect(rateLimitBuckets()).toBe(0);
  });
});
