// Lightweight pipeline timing instrumentation.
//
// StageTimer records named "marks" across a checkout run so we can see exactly
// where time goes (cold browser launch vs. session warm vs. adapter), prove that
// a speed optimization actually helped, and surface a per-site speed breakdown.
//
// It is intentionally dependency-free and pure (time is injectable) so it can be
// unit-tested without a real run, a browser, or the network.

export class StageTimer {
  constructor(startedAt = Date.now()) {
    this.t0 = startedAt;
    this.last = startedAt;
    this.stages = [];
  }

  // Record a stage boundary. `at` is injectable for deterministic tests.
  // atMs   = ms since the run started (cumulative)
  // deltaMs = ms spent since the previous mark (this stage's own cost)
  mark(name, at = Date.now()) {
    const atMs = at - this.t0;
    const deltaMs = at - this.last;
    this.last = at;
    this.stages.push({ name, atMs, deltaMs });
    return this;
  }

  summary(endAt = Date.now()) {
    return {
      totalMs: endAt - this.t0,
      stages: this.stages.slice(),
    };
  }
}

// Aggregate persisted timing rows into a per-site average stage breakdown.
// Pure: accepts rows of { site_id, timings } where `timings` is either a parsed
// object or a JSON string (Postgres jsonb can come back either way depending on
// the driver/mock). Rows without usable timing data are skipped.
export const aggregateStageTimings = (rows = []) => {
  const bySite = new Map();

  for (const row of rows) {
    let t = row.timings;
    if (typeof t === 'string') {
      try { t = JSON.parse(t); } catch (_) { t = null; }
    }
    if (!t || !Array.isArray(t.stages)) continue;

    const siteId = row.site_id ?? null;
    if (!bySite.has(siteId)) {
      bySite.set(siteId, { siteId, runs: 0, totalMsSum: 0, handoffSum: 0, handoffCount: 0, stageSums: new Map() });
    }
    const agg = bySite.get(siteId);
    agg.runs += 1;
    if (Number.isFinite(t.totalMs)) agg.totalMsSum += t.totalMs;
    if (Number.isFinite(t.handoffMs)) { agg.handoffSum += t.handoffMs; agg.handoffCount += 1; }

    for (const s of t.stages) {
      if (!s || !Number.isFinite(s.deltaMs)) continue;
      const cur = agg.stageSums.get(s.name) || { sum: 0, count: 0 };
      cur.sum += s.deltaMs;
      cur.count += 1;
      agg.stageSums.set(s.name, cur);
    }
  }

  return Array.from(bySite.values()).map((agg) => ({
    siteId: agg.siteId,
    runs: agg.runs,
    avgTotalMs: agg.runs ? Math.round(agg.totalMsSum / agg.runs) : 0,
    avgHandoffMs: agg.handoffCount ? Math.round(agg.handoffSum / agg.handoffCount) : null,
    stages: Array.from(agg.stageSums.entries()).map(([name, v]) => ({
      name,
      avgMs: v.count ? Math.round(v.sum / v.count) : 0,
      samples: v.count,
    })),
  }));
};
