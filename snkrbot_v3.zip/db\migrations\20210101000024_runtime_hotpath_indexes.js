export const up = async (knex) => {
  await knex.schema.alterTable('tasks', (t) => {
    t.index(['monitor_24_7', 'is_deleted', 'disabled_at'], 'tasks_monitor24_active_idx');
  });
  await knex.schema.alterTable('active_monitors', (t) => {
    t.index(['started_at'], 'active_monitors_started_idx');
  });
  await knex.schema.alterTable('task_runs', (t) => {
    t.index(['status', 'finished_at'], 'task_runs_status_finished_idx');
  });
  await knex.schema.alterTable('proxies', (t) => {
    t.index(['is_deleted', 'proxy_type'], 'proxies_active_type_idx');
  });
};

export const down = async (knex) => {
  await knex.schema.alterTable('proxies', (t) => t.dropIndex('proxies_active_type_idx'));
  await knex.schema.alterTable('task_runs', (t) => t.dropIndex('task_runs_status_finished_idx'));
  await knex.schema.alterTable('active_monitors', (t) => t.dropIndex('active_monitors_started_idx'));
  await knex.schema.alterTable('tasks', (t) => t.dropIndex('tasks_monitor24_active_idx'));
};
