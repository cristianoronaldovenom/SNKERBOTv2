import { navigateCartUnlessReady } from '../../helpers/site-checkout-fastpath.js';
import logger from '../../helpers/logger.js';
import { captureOrderSuccess } from '../../helpers/order-capture.js';
import { humanType, humanTypeInFrames, humanClick, humanSelect } from '../../helpers/human-type.js';
import {
  formatPostal, stripPhone, dismissAutocomplete, verifyFieldValue,
  requireCardIframe, verifyCartHasItem, FillReport, assertCriticalFields
} from '../../helpers/autofill-utils.js';
import {
  retryWithBackoff, guardedGoto, preOrderGuard, postClickGuard,
  takeFailureScreenshot
} from '../../helpers/checkout-guards.js';

import { waitForAnySelector } from '../../helpers/site-runtime.js';
import { assertActionButtonIntent } from '../../helpers/checkout-controls.js';

const TIMEOUT = 15000;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const findFirst = async (page, selectorList, timeout = TIMEOUT) => {
  const selector = await waitForAnySelector(page, selectorList, { timeout });
  if (!selector) return null;
  const el = await page.$(selector).catch(() => null);
  return el ? { el, selector } : null;
};

const clickFirst = async (page, selectorList, { stage = '' } = {}) => {
  const found = await findFirst(page, selectorList, TIMEOUT);
  if (!found) throw new Error(`Could not find clickable element at stage "${stage}" — tried [${selectorList.join(', ')}]`);
  await humanClick(page, found.selector);
  return found.selector;
};

const fillField = async (page, selectorList, value, { type = 'text', label = '', report = null } = {}) => {
  const name = label || 'unnamed';
  if (!value) { if (report) report.record(name, true, 'skipped (empty)'); return false; }
  const found = await findFirst(page, selectorList, 8000);
  if (!found) { if (report) report.record(name, false, 'selector not found'); return false; }
  const formatted = type === 'postal' ? formatPostal(value) : type === 'phone' ? stripPhone(value) : String(value);
  for (let attempt = 0; attempt < 2; attempt++) {
    await found.el.click({ clickCount: 3 }).catch(() => {});
    await page.keyboard.press('Backspace').catch(() => {});
    await humanType(page, found.selector, formatted);
    await dismissAutocomplete(page);
    await page.keyboard.press('Tab').catch(() => {});
    const v = await verifyFieldValue(page, found.selector, formatted, type);
    if (v.ok) { if (report) report.record(name, true); return true; }
    logger.warn(`[Shopify] ${name} did not stick on attempt ${attempt + 1} (got "${v.actual}", expected "${v.expected}"), retrying`);
  }
  if (report) report.record(name, false, 'verify failed after retry');
  return false;
};

const SELECTORS = {
  addToCart: [
    'button[name="add"]',
    'button[data-testid="add-to-cart"]',
    'button.product-form__submit',
    'button.btn-addtocart',
    'button[type="submit"][name="add"]',
    'button.add-to-cart',
    '#AddToCart',
    'button[id*="AddToCart"]'
  ],
  qtyInput: [
    'input[name="quantity"]',
    'select[name="quantity"]',
    'input.quantity__input',
    'input[data-quantity-input]'
  ],
  checkout: [
    '[name="checkout"]',
    'button[name="checkout"]',
    'input[name="checkout"]',
    'a[href*="/checkout"]',
    'button.cart__checkout-button',
    'button[data-testid="checkout-button"]'
  ],
  guestCheckout: [
    'button#GuestButton',
    'a#GuestButton',
    'button[data-testid="guest-checkout-button"]',
    'a[data-value="guest"]',
    'button.alternative-action__button',
    'a[href*="checkout/step"]',
    'button[name="checkout-guest"]'
  ],
  email: [
    'input#email', 'input[name="email"]', 'input#checkout_email',
    'input[autocomplete="email"]', 'input[type="email"]'
  ],
  firstName: [
    'input#shipping_first_name', 'input[name="shipping_address[first_name]"]',
    'input[name="firstName"]', 'input[autocomplete="given-name"]'
  ],
  lastName: [
    'input#shipping_last_name', 'input[name="shipping_address[last_name]"]',
    'input[name="lastName"]', 'input[autocomplete="family-name"]'
  ],
  address1: [
    'input#shipping_address1', 'input[name="shipping_address[address1]"]',
    'input[name="address1"]', 'input[autocomplete="address-line1"]'
  ],
  address2: [
    'input#shipping_address2', 'input[name="shipping_address[address2]"]',
    'input[name="address2"]', 'input[autocomplete="address-line2"]'
  ],
  city: [
    'input#shipping_city', 'input[name="shipping_address[city]"]',
    'input[name="city"]', 'input[autocomplete="address-level2"]'
  ],
  province: [
    'select#shipping_province', 'select[name="shipping_address[province]"]',
    'select[name="province"]', 'select[autocomplete="address-level1"]'
  ],
  postalCode: [
    'input#shipping_zip', 'input[name="shipping_address[zip]"]',
    'input[name="zip"]', 'input[autocomplete="postal-code"]'
  ],
  phone: [
    'input#shipping_phone', 'input[name="shipping_address[phone]"]',
    'input[name="phone"]', 'input[type="tel"]'
  ],
  continueToShipping: [
    'button#continue_button', 'button[data-trekkie-id="continue_to_shipping_button"]',
    'input[type="submit"][value*="Continue"]', 'button.step__footer__continue-btn'
  ],
  continueToPayment: [
    'button#continue_button', 'button[data-trekkie-id="continue_to_payment_button"]',
    'input[type="submit"][value*="Continue"]', 'button.step__footer__continue-btn'
  ],
  cardNumber: [
    'input[name="number"]', 'input#number', 'input[autocomplete="cc-number"]',
    'input[placeholder*="Card number"]', 'input[data-current-field="number"]'
  ],
  cardName: [
    'input[name="name"]', 'input#name', 'input[autocomplete="cc-name"]',
    'input[placeholder*="Name on card"]'
  ],
  expiry: [
    'input[name="expiry"]', 'input#expiry', 'input[autocomplete="cc-exp"]',
    'input[placeholder*="Expiration"]'
  ],
  cvv: [
    'input[name="verification_value"]', 'input#verification_value',
    'input[autocomplete="cc-csc"]', 'input[placeholder*="Security code"]'
  ],
  completeOrder: [
    'button#continue_button', 'button[data-trekkie-id="complete_order_button"]',
    'button.step__footer__continue-btn', 'input[type="submit"][value*="Pay now"]',
    'button[type="submit"]'
  ],
  orderConfirmation: [
    '.os-header__title', '.thank-you-page', '[data-step="thank_you"]',
    'h2.os-header__title', '.order-confirmation', '.main__header'
  ]
};

// Try Shopify's JSON ATC endpoint first — POST /cart/add.js with the variant
// ID skips PDP rendering entirely and beats DOM-driven bots by 1.5–3 seconds.
// Falls back to the visible "Add to Cart" button if anything goes wrong
// (variant not extractable, endpoint blocked, soft-launch protection, etc.)
// so this is a strict speedup with zero new failure modes.
const tryJsonAtc = async (page, task) => {
  try {
    // Variant ID extraction priority:
    //   1. ?variant=XXX in the product URL (most reliable — comes from monitor/manual entry)
    //   2. <select name="id"> first selected option (size selector after a click)
    //   3. ProductJson script tag (.product-json or window.meta.product.variants[0].id)
    let variantId = null;
    try {
      const u = new URL(task.url);
      variantId = u.searchParams.get('variant');
    } catch (_) {}
    if (!variantId) {
      variantId = await page.evaluate(() => {
        const sel = document.querySelector('select[name="id"]');
        if (sel && sel.value) return sel.value;
        const input = document.querySelector('input[name="id"][value]:not([value=""])');
        if (input) return input.value;
        const scriptEl = document.querySelector('script[type="application/json"][data-product-json], .product-json');
        if (scriptEl) {
          try {
            const json = JSON.parse(scriptEl.textContent || '{}');
            const v = json?.variants?.[0]?.id || json?.product?.variants?.[0]?.id;
            if (v) return String(v);
          } catch (_) {}
        }
        if (window.meta?.product?.variants?.[0]?.id) return String(window.meta.product.variants[0].id);
        return null;
      }).catch(() => null);
    }
    if (!variantId) return { ok: false, reason: 'no variantId' };

    const qty = task.quantity && task.quantity > 0 ? task.quantity : 1;
    const result = await page.evaluate(async (vid, q) => {
      try {
        const res = await fetch('/cart/add.js', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
          body: JSON.stringify({ id: Number(vid), quantity: q }),
          credentials: 'include'
        });
        const text = await res.text();
        return { status: res.status, body: text.slice(0, 500) };
      } catch (e) { return { status: 0, body: String(e.message) }; }
    }, variantId, qty);

    if (result.status === 200) return { ok: true, variantId };
    return { ok: false, reason: `status ${result.status}: ${result.body.slice(0, 120)}` };
  } catch (err) {
    return { ok: false, reason: err.message };
  }
};

const runShopify = async ({ page, task }) => {
  const startedAt = Date.now();
  logger.info(`[Shopify] Starting checkout for task ${task.id}: ${task.url}`);
  page.setDefaultNavigationTimeout(30000);

  const cartUrl = new URL('/cart', task.url).href;

  // RESERVATION FAST PATH: a cart spot was already secured over HTTP the instant
  // stock was detected. Inject that cart cookie so this browser shares the exact
  // same cart, skip PDP + ATC entirely, and go straight to checkout. If the cart
  // doesn't carry over, fall through to the normal PDP → ATC flow (no harm done).
  let reserved = false;
  if (task.reservation?.reserved && task.reservation.site === 'shopify' && task.reservation.cartCookies) {
    try {
      const origin = new URL(task.url).origin;
      const cookies = task.reservation.cartCookies.split('; ').filter(Boolean).map((pair) => {
        const i = pair.indexOf('=');
        return { name: pair.slice(0, i), value: pair.slice(i + 1), url: origin };
      });
      if (cookies.length) await page.setCookie(...cookies);
      await navigateCartUnlessReady({ page, cartUrl, navigate: guardedGoto, taskId: task.id, stage: 'cart_load' });
      const reservedCart = await verifyCartHasItem(page, { timeout: 6000 });
      if (!reservedCart.empty) {
        reserved = true;
        logger.info(`[Shopify] ⚡ Reservation honored — cart already holds ${reservedCart.count} item(s) (variant ${task.reservation.variantId}), skipping ATC`);
      } else {
        logger.warn('[Shopify] Reservation cookie did not carry the cart into the browser — falling back to PDP + ATC');
      }
    } catch (err) {
      logger.warn(`[Shopify] Reservation reuse failed (${err.message}) — falling back to PDP + ATC`);
    }
  }

  if (!reserved) {
    await guardedGoto(page, task.url, { taskId: task.id, stage: 'pdp_load' });
    await waitForAnySelector(page, SELECTORS.addToCart, { timeout: 8000 });

    if (task.quantity && task.quantity > 1) {
      const qtyFound = await findFirst(page, SELECTORS.qtyInput, 5000);
      if (qtyFound) {
        const tag = await qtyFound.el.evaluate((el) => el.tagName.toLowerCase());
        if (tag === 'select') {
          await page.select(qtyFound.selector, String(task.quantity)).catch(() => {});
        } else {
          await qtyFound.el.click({ clickCount: 3 }).catch(() => {});
          await page.keyboard.press('Backspace').catch(() => {});
          await humanType(page, qtyFound.selector, String(task.quantity));
        }
        logger.info(`[Shopify] Quantity set to ${task.quantity}`);
      }
    }

    // FAST PATH: try JSON ATC (~150ms) before falling back to UI click (~2s).
    const jsonAtc = await tryJsonAtc(page, task);
    if (jsonAtc.ok) {
      logger.info(`[Shopify] ⚡ Fast-path JSON ATC succeeded (variant ${jsonAtc.variantId}) — skipped PDP click`);
    } else {
      logger.info(`[Shopify] JSON ATC unavailable (${jsonAtc.reason}) — falling back to UI click`);
      await retryWithBackoff(async () => {
        await clickFirst(page, SELECTORS.addToCart, { stage: 'add_to_cart' });
      }, { attempts: 3, baseMs: 1000, label: 'Shopify ATC' });
      logger.info('[Shopify] Added to cart');
    }

    await navigateCartUnlessReady({ page, cartUrl, navigate: guardedGoto, taskId: task.id, stage: 'cart_load' });
    const cartState = await verifyCartHasItem(page, { timeout: 8000 });
    if (cartState.empty) {
      throw new Error('Cart is empty after ATC — item not added (likely OOS / size unavailable / session lost)');
    }
    logger.info(`[Shopify] Cart verified: ${cartState.count} item(s)`);
  }

  await clickFirst(page, SELECTORS.checkout, { stage: 'proceed_to_checkout' });
  await page.waitForNavigation({ waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
  await postClickGuard(page, { taskId: task.id, stage: 'proceed_to_checkout' });
  await waitForAnySelector(page, [...SELECTORS.guestCheckout, ...SELECTORS.email, ...SELECTORS.cardNumber], { timeout: 12000 });

  // Some Shopify stores redirect to an account login/guest wall before showing the
  // checkout form. Click "Continue as guest" if it appears — silently skip if not.
  const guestBtn = await findFirst(page, SELECTORS.guestCheckout, 3000);
  if (guestBtn) {
    logger.info(`[Shopify] Task ${task.id} — guest checkout wall, clicking "${guestBtn.selector}"`);
    await humanClick(page, guestBtn.selector);
    await waitForAnySelector(page, [...SELECTORS.email, ...SELECTORS.cardNumber], { timeout: 8000 });
    await postClickGuard(page, { taskId: task.id, stage: 'guest_checkout' });
  }

  const ship = task.shippingAddress;
  if (!ship) throw new Error('Shipping address missing at stage "fill_shipping"');

  const contactReport = new FillReport(task.id, 'Shopify Contact');
  await fillField(page, SELECTORS.email, task.notification_email_address || ship.email, { label: 'email', report: contactReport });
  contactReport.log();

  await fillField(page, SELECTORS.firstName, ship.first_name, { label: 'firstName', report: contactReport });
  await fillField(page, SELECTORS.lastName, ship.last_name, { label: 'lastName', report: contactReport });
  await fillField(page, SELECTORS.address1, ship.address1, { label: 'address1', report: contactReport });
  await fillField(page, SELECTORS.address2, ship.address2, { label: 'address2', report: contactReport });
  await fillField(page, SELECTORS.city, ship.city, { label: 'city', report: contactReport });
  await fillField(page, SELECTORS.postalCode, formatPostal(ship.zip), { label: 'postalCode', report: contactReport });
  await fillField(page, SELECTORS.phone, stripPhone(ship.phone), { label: 'phone', report: contactReport });

  const provSel = await findFirst(page, SELECTORS.province, 3000);
  if (provSel) await humanSelect(page, provSel.selector, ship.state).catch(() => {});

  const shipReport = new FillReport(task.id, 'Shopify Shipping');
  shipReport.fields = contactReport.fields;
  shipReport.log();
  assertCriticalFields(shipReport, ['email', 'firstName', 'lastName', 'address1', 'city', 'postalCode', 'phone']);

  const contShip = await findFirst(page, SELECTORS.continueToShipping, 5000);
  if (contShip) { await humanClick(page, contShip.selector); await waitForAnySelector(page, SELECTORS.continueToPayment, { timeout: 12000 }); await postClickGuard(page, { taskId: task.id, stage: 'continue_shipping' }); }

  const contPay = await findFirst(page, SELECTORS.continueToPayment, 5000);
  if (contPay) { await humanClick(page, contPay.selector); await waitForAnySelector(page, SELECTORS.completeOrder, { timeout: 12000 }); await postClickGuard(page, { taskId: task.id, stage: 'continue_payment' }); }

  const pay = task.paymentProfile;
  if (!pay) throw new Error('Payment profile missing at stage "fill_payment"');

  await requireCardIframe(page, { timeout: 15000 });

  const payReport = new FillReport(task.id, 'Shopify Payment');
  const cleanedCard = pay.card_number.replace(/\s/g, '');
  const cardFilled = await humanTypeInFrames(page, SELECTORS.cardNumber.join(', '), cleanedCard, { tabAfter: true });
  payReport.record('cardNumber', cardFilled, cardFilled ? '' : 'not found in main or iframes');

  await humanTypeInFrames(page, SELECTORS.cardName.join(', '), pay.card_holder_name, { tabAfter: true });

  const expStr = `${String(pay.expiration_month).padStart(2, '0')} / ${String(pay.expiration_year).slice(-2)}`;
  await humanTypeInFrames(page, SELECTORS.expiry.join(', '), expStr, { tabAfter: true });

  await humanTypeInFrames(page, SELECTORS.cvv.join(', '), pay.cvv, { tabAfter: true });
  payReport.log();
  assertCriticalFields(payReport, ['cardNumber']);

  await preOrderGuard(page, { taskId: task.id });
  await assertActionButtonIntent(page, SELECTORS.completeOrder, { stage: 'complete order', allow: /complete order|place order|pay now|submit order/i });
  await clickFirst(page, SELECTORS.completeOrder, { stage: 'complete_order' });

  const confirmed = await Promise.race([
    findFirst(page, SELECTORS.orderConfirmation, 60000),
    page.waitForFunction(() => /thank.you|order.*confirm|processing/i.test(document.title + ' ' + document.body?.innerText?.slice(0, 500)), { timeout: 60000 }).then(() => ({ url: true })).catch(() => null)
  ]);
  if (!confirmed) throw new Error('Order confirmation not detected at stage "confirm_order"');

  const orderNumber = await page.evaluate(() => {
    const el = document.querySelector('[data-checkout-payment-due-target], .order-number span, [class*="orderNumber" i], h2.os-header__heading + p');
    return el ? el.textContent.trim() : null;
  }).catch(() => null);

  logger.info(`[Shopify] ✅ Order placed for task ${task.id}! Order: ${orderNumber || 'N/A'}`);
  await captureOrderSuccess({ page, taskId: task.id, orderNumber, productUrl: task.url, durationMs: Date.now() - startedAt }).catch(() => {});
};

export default runShopify;
