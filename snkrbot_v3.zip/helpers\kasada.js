// Kasada (Bot Defender / kpsdk) — detection and HTTP-only token acquisition.
//
// Kasada is the hardest common WAF and, until now, this bot only *classified* it
// and then did nothing: stock-monitor returns 'kasada' from its vendor
// classifier and falls through to the generic bot-block branch. Every
// Kasada-protected drop was therefore a coin flip on a plain GET.
//
// Why it is hard: the page runs an obfuscated VM that emits a scored, time-boxed
// payload (x-kpsdk-ct) plus a clock-sync header (x-kpsdk-cd / x-kpsdk-v). Both
// are bound to the TLS session and to the IP, so a payload lifted from one
// connection is rejected on another. There is no public solver API for it the way
// there is for reCAPTCHA.
//
// So this is layered, cheapest first:
//   1. Replay a fresh triple we already hold for this host+exit.
//   2. Fork: re-request the challenge and harvest the payload from the response.
//   3. Report that a browser solve is needed. The token is genuinely computed by
//      the VM, so a real page is the only reliable answer — but this module must
//      not launch one (monitors call it on the HTTP hot path).
//
// State is keyed by host AND proxy: the same host on a different exit needs a
// different token, and replaying across exits reads as an attack.

import logger from './logger.js';
import { tlsRequest } from './tls-client.js';

const HDR_CT = 'x-kpsdk-ct';
const HDR_CD = 'x-kpsdk-cd';
const HDR_V = 'x-kpsdk-v';

// Kasada rejects a stale payload; reusing one past its window is worse than not
// sending it all. Conservative on purpose.
const TOKEN_TTL_MS = Math.max(30_000, Number(process.env.KASADA_TOKEN_TTL_MS || 120_000));
const MAX_ENTRIES = 512;

// host|proxy → { ct, cd, v, expiresAt }
const tokens = new Map();

const keyFor = (host, proxy) => `${host}|${proxy?.host || ''}:${proxy?.port || ''}`;

const trim = () => {
  if (tokens.size <= MAX_ENTRIES) return;
  const now = Date.now();
  for (const [k, v] of tokens) if (v.expiresAt <= now) tokens.delete(k);
  while (tokens.size > MAX_ENTRIES) {
    const first = tokens.keys().next().value;
    if (first === undefined) break;
    tokens.delete(first);
  }
};

// ── Detection ────────────────────────────────────────────────────────────────
//
// Kasada answers with 429/307 (sometimes 403) carrying a kpsdk payload, or sets
// kpsdk headers. Matched on the response envelope only — a page merely
// mentioning Kasada is not a challenge.
export const isKasadaChallenge = ({ status = 0, body = '', headers = {} } = {}) => {
  const headerStr = Object.keys(headers || {}).join('\n').toLowerCase();
  if (/x-kpsdk-(ct|cd|v)/.test(headerStr)) return true;
  if (status !== 429 && status !== 307 && status !== 403) return false;
  const head = String(body || '').slice(0, 4000);
  return /kpsdk/i.test(head) || /"ct"\s*:\s*"/.test(head) || /_kpsdk/i.test(head);
};

// ── Payload extraction ───────────────────────────────────────────────────────
//
// Three shapes are seen in the wild; all are regex work, because running the VM
// is the browser's job, not ours.
export const extractKasadaPayload = ({ body = '', headers = {} } = {}) => {
  const pick = (name) => {
    for (const [k, v] of Object.entries(headers || {})) {
      if (k.toLowerCase() === name) return Array.isArray(v) ? v[0] : v;
    }
    return null;
  };
  // Shape 1: already-parsed headers (a retry response echoing them back).
  const fromHeaders = { ct: pick(HDR_CT), cd: pick(HDR_CD), v: pick(HDR_V) };
  if (fromHeaders.ct) return fromHeaders;

  const text = String(body || '');
  // Shape 2: JSON envelope, e.g. {"ct":"...","cd":1699...,"v":"2"}
  const jsonCt = text.match(/"ct"\s*:\s*"([^"]{16,})"/);
  if (jsonCt) {
    return {
      ct: jsonCt[1],
      cd: (text.match(/"cd"\s*:\s*"?(\d{8,})"?/) || [])[1] || null,
      v: (text.match(/"v"\s*:\s*"([^"]{1,8})"/) || [])[1] || null
    };
  }
  // Shape 3: inline JSON.parse('...') with escaped quotes.
  const parsedCt = text.match(/["\\]{1,2}ct["\\]{1,2}\s*:\s*["\\]{1,2}([A-Za-z0-9+/=_-]{16,})/);
  if (parsedCt) return { ct: parsedCt[1], cd: null, v: null };

  return null;
};

// ── Replay ───────────────────────────────────────────────────────────────────
// Headers to attach. Empty object when nothing fresh is held.
export const kasadaHeaders = ({ host, proxy = null } = {}) => {
  if (!host) return {};
  const key = keyFor(host, proxy);
  const entry = tokens.get(key);
  if (!entry) return {};
  if (entry.expiresAt <= Date.now()) {
    tokens.delete(key);
    return {};
  }
  const out = { [HDR_CT]: entry.ct };
  if (entry.cd) out[HDR_CD] = entry.cd;
  if (entry.v) out[HDR_V] = entry.v;
  return out;
};

export const storeKasadaPayload = ({ host, proxy = null, payload }) => {
  if (!host || !payload?.ct) return false;
  tokens.set(keyFor(host, proxy), {
    ct: payload.ct,
    cd: payload.cd || null,
    v: payload.v || null,
    expiresAt: Date.now() + TOKEN_TTL_MS
  });
  trim();
  return true;
};

export const clearKasada = ({ host, proxy = null } = {}) => tokens.delete(keyFor(host, proxy));

// ── Fork ─────────────────────────────────────────────────────────────────────
//
// Re-request the page to shake loose a fresh payload. tlsRequest keeps the
// ClientHello pinned per host+proxy, which Kasada needs: a payload minted under a
// different JA3 from the one that will use it is rejected.
//
// Returns the payload or null. Never throws.
export const forkKasadaPayload = async ({ pageUrl, proxy = null, ua = null, referer = null } = {}) => {
  if (!pageUrl) return null;
  let host = '';
  try { host = new URL(pageUrl).hostname; } catch (_) { return null; }

  const headers = {
    Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    // The payload is normally issued to a same-site XHR, not a cold navigation.
    ...(referer ? { Referer: referer } : {}),
    ...(ua ? { 'User-Agent': ua } : {})
  };

  try {
    const res = await tlsRequest({
      url: pageUrl,
      headers,
      proxy: proxy ? `${proxy.host}:${proxy.port}` : null,
      timeoutMs: 12_000
    });
    if (!res?.ok) return null;

    const found = extractKasadaPayload({ body: res.body, headers: res.headers });
    if (!found?.ct) return null;

    storeKasadaPayload({ host, proxy, payload: found });
    logger.info(`[Kasada] Harvested fresh payload for ${host} via fork`);
    return found;
  } catch (err) {
    logger.warn(`[Kasada] Fork failed for ${host}: ${err.message}`);
    return null;
  }
};

// ── Solve ────────────────────────────────────────────────────────────────────
//
// Called when a page classifies as Kasada. Covers layers 1-2 and reports whether
// a browser is worth it. `needBrowser` is the signal to escalate to warmSession —
// unlike a generic block, retrying blind never clears a Kasada challenge.
export const solveKasada = async ({ pageUrl, proxy = null, ua = null, status = 0, body = '', headers = {} } = {}) => {
  let host = '';
  try { host = new URL(pageUrl).hostname; } catch (_) {
    return { retry: false, needBrowser: false, reason: 'bad_url' };
  }

  // Layer 1: a payload carried by this very response.
  const inline = extractKasadaPayload({ body, headers });
  if (inline?.ct) {
    storeKasadaPayload({ host, proxy, payload: inline });
    return { retry: true, needBrowser: false, reason: 'payload_in_response' };
  }

  // Layer 2: we may already hold one — let the caller replay, no fork needed.
  if (Object.keys(kasadaHeaders({ host, proxy })).length > 0) {
    return { retry: true, needBrowser: false, reason: 'cached_token' };
  }

  const forked = await forkKasadaPayload({ pageUrl, proxy, ua });
  if (forked) return { retry: true, needBrowser: false, reason: 'forked' };

  logger.info(`[Kasada] No HTTP-only payload for ${host} (status ${status}) — browser solve required`);
  return { retry: false, needBrowser: true, reason: 'browser_required' };
};

export const __resetKasada = () => tokens.clear();
export const kasadaState = () => Array.from(tokens.entries()).map(([key, v]) => ({
  key, expiresInMs: Math.max(0, v.expiresAt - Date.now())
}));
export const kasadaConfig = () => ({ tokenTtlMs: TOKEN_TTL_MS });
