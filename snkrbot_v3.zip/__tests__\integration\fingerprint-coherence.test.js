import { jest } from '@jest/globals';

jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));

const {
  validate, repair, isCoherent, deriveScreenMetrics, rendererFor, screenGeometry,
  platformOf, __internals
} = await import('../../helpers/fingerprint-coherence.js');
const { FINGERPRINT_PROFILES } = await import('../../helpers/fingerprint-store.js');

const windowsBase = () => ({
  ua: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
  chromeVer: '131', fullVer: '131.0.6778.204', platform: '"Windows"',
  platformVer: '"15.0.0"', arch: '"x86"', bitness: '"64"', model: '""', mobile: '?0',
  vendor: 'Google Inc.', cores: 8, mem: 8,
  gpu: 'Intel(R) UHD Graphics 620',
  webglVendor: 'Google Inc. (Intel)',
  webglRenderer: 'ANGLE (Intel, Intel(R) UHD Graphics 620 Direct3D11 vs_5_0 ps_5_0, D3D11)',
  screen: { width: 1920, height: 1080 }, viewport: { width: 1600, height: 900 }, dpr: 1,
  tz: 'America/Toronto', fontSeed: 7, canvasSeed: 11, audioSeed: 13
});

describe('validate', () => {
  test('a coherent profile reports nothing', () => {
    expect(validate(windowsBase())).toEqual([]);
    expect(isCoherent(windowsBase())).toBe(true);
  });

  test('UA platform contradicting the platform token is fatal', () => {
    const p = { ...windowsBase(), platform: '"macOS"' };
    expect(validate(p)).toEqual(expect.arrayContaining([
      expect.objectContaining({ field: 'ua', severity: 'fatal' })
    ]));
  });

  test('macOS profile with a D3D11 renderer is fatal', () => {
    const p = {
      ...windowsBase(), platform: '"macOS"', gpu: 'Apple M1',
      ua: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'
    };
    expect(validate(p)).toEqual(expect.arrayContaining([
      expect.objectContaining({ field: 'webglRenderer', severity: 'fatal' })
    ]));
  });

  test('viewport larger than the screen is fatal', () => {
    const p = { ...windowsBase(), screen: { width: 1280, height: 720 }, viewport: { width: 1600, height: 900 } };
    expect(validate(p)).toEqual(expect.arrayContaining([
      expect.objectContaining({ field: 'viewport', severity: 'fatal' })
    ]));
  });

  test('viewport with no room for browser chrome is fatal', () => {
    const p = { ...windowsBase(), viewport: { width: 1920, height: 1080 } };
    expect(validate(p)).toEqual(expect.arrayContaining([
      expect.objectContaining({ field: 'viewport', severity: 'fatal' })
    ]));
  });

  test('chromeVer missing from the UA is fatal', () => {
    const p = { ...windowsBase(), ua: windowsBase().ua.replace('Chrome/131.', 'Chrome/124.') };
    expect(validate(p)).toEqual(expect.arrayContaining([
      expect.objectContaining({ field: 'chromeVer', severity: 'fatal' })
    ]));
  });

  test('implausible cores/mem are only warnings', () => {
    const p = { ...windowsBase(), cores: 3, mem: 7 };
    expect(validate(p).every((i) => i.severity === 'warn')).toBe(true);
    expect(isCoherent(p)).toBe(true);
  });

  test('missing profile object is fatal', () => {
    expect(validate(null)[0].severity).toBe('fatal');
  });

describe('repair', () => {
  const fullyBroken = () => ({
    ...windowsBase(),
    platform: '"macOS"', cores: 3, mem: 7, gpu: 'Apple M1',
    webglRenderer: 'ANGLE (Intel, Intel(R) UHD Graphics 620 Direct3D11 vs_5_0 ps_5_0, D3D11)',
    ua: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
    screen: { width: 1280, height: 720 }, viewport: { width: 1600, height: 900 },
    dpr: 1, canvasSeed: 424242, audioSeed: 99
  });

  test('fixes a broken profile and preserves the seeds', () => {
    const { profile, changed } = repair(fullyBroken(), { seed: 5 });
    expect(isCoherent(profile)).toBe(true);
    expect(profile.canvasSeed).toBe(424242);
    expect(profile.audioSeed).toBe(99);
    expect(profile.webglRenderer).toMatch(/ANGLE \(Apple/);
    expect(profile.dpr).toBeGreaterThanOrEqual(1.5);
    expect(changed.length).toBeGreaterThan(0);
  });

  test('is a no-op on an already coherent profile', () => {
    const p = windowsBase();
    expect(repair(p).changed).toEqual([]);
    expect(repair(p).profile).toEqual(p);
  });

  test('does not mutate the input', () => {
    const p = fullyBroken();
    const snapshot = JSON.stringify(p);
    repair(p);
    expect(JSON.stringify(p)).toBe(snapshot);
  });

  test('keeps the viewport inside the screen for every seed', () => {
    for (let seed = 0; seed < 50; seed++) {
      const { profile } = repair({ ...windowsBase(), viewport: { width: 9999, height: 9999 } }, { seed });
      expect(profile.viewport.width).toBeLessThanOrEqual(profile.screen.width);
      expect(profile.viewport.height).toBeLessThanOrEqual(profile.screen.height);
    }
  });
});

describe('deriveScreenMetrics', () => {
  test('every derived pair fits inside its screen with chrome headroom', () => {
    for (const platform of ['Windows', 'macOS']) {
      for (let seed = 0; seed < 64; seed++) {
        const m = deriveScreenMetrics(platform, seed);
        expect(m.viewport.width).toBeLessThanOrEqual(m.screen.width);
        expect(m.viewport.height).toBeLessThanOrEqual(m.screen.height);
        const headroom = m.screen.height - m.viewport.height;
        expect(headroom).toBeGreaterThanOrEqual(40);
        expect(headroom).toBeLessThanOrEqual(400);
      }
    }
  });

  test('macOS derives a Retina dpr, Windows does not', () => {
    for (let seed = 0; seed < 40; seed++) {
      expect(deriveScreenMetrics('macOS', seed).dpr).toBeGreaterThanOrEqual(1.5);
      expect([1, 1.25]).toContain(deriveScreenMetrics('Windows', seed).dpr);
    }
  });
});

describe('rendererFor', () => {
  test('Windows renderers are D3D11 ANGLE strings', () => {
    expect(rendererFor('Windows', 'NVIDIA GeForce RTX 3060'))
      .toBe('ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0 ps_5_0, D3D11)');
  });

  test('AMD and Intel GPUs get their own vendor token', () => {
    expect(rendererFor('Windows', 'AMD Radeon RX 580')).toMatch(/^ANGLE \(AMD, /);
    expect(rendererFor('Windows', 'Intel(R) UHD Graphics 620')).toMatch(/^ANGLE \(Intel, /);
  });

  test('macOS renderers are Metal ANGLE strings', () => {
    expect(rendererFor('macOS', 'Apple M2 Pro')).toBe('ANGLE (Apple, Apple M2 Pro, Metal)');
  });
});

describe('screenGeometry', () => {
  test('chrome fits and outer never exceeds the panel', () => {
    const g = screenGeometry({ screen: { width: 1366, height: 768 }, viewport: { width: 1366, height: 657 }, dpr: 1 });
    expect(g.outerWidth).toBeLessThanOrEqual(g.screenWidth);
    expect(g.outerHeight).toBeLessThanOrEqual(g.screenHeight);
    expect(g.availHeight).toBeGreaterThanOrEqual(g.innerHeight);
  });
});

describe('platformOf', () => {
  test('reads quoted and unquoted tokens, rejects others', () => {
    expect(platformOf({ platform: '"macOS"' })).toBe('macOS');
    expect(platformOf({ platform: 'Windows' })).toBe('Windows');
    expect(platformOf({ platform: '"Linux"' })).toBeNull();
  });
});

describe('shipped tables', () => {
  test('every hardware entry pairs a plausible core/mem count', () => {
    for (const list of Object.values(__internals.PLATFORM_HARDWARE)) {
      for (const hw of list) {
        expect([2, 4, 6, 8, 10, 12, 16, 24]).toContain(hw.cores);
        expect([2, 4, 8, 16, 24, 32]).toContain(hw.mem);
      }
    }
  });

  test('every shipped profile stays coherent once its screen triad is derived', () => {
    expect(FINGERPRINT_PROFILES.length).toBeGreaterThan(0);
    FINGERPRINT_PROFILES.forEach((p, i) => {
      // generate() pairs the template with the derived triad exactly like this.
      const withGeometry = { ...p, ...deriveScreenMetrics(String(p.platform).replace(/"/g, ''), i) };
      expect(isCoherent(withGeometry)).toBe(true);
    });
  });
});

});
