import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (p) => fs.readFile(path.join(root, p), 'utf8');

const source = await read('sites/pokemoncenter/index.js');
const checkoutGuardsSource = await read('helpers/checkout-guards.js');
const packageLockText = await read('package-lock.json').catch(() => '');
const pkg = JSON.parse(await read('package.json'));

// Basic project integrity.
assert.equal(pkg.type, 'module', 'package.json must use ESM');
assert.match(pkg.scripts?.test ?? '', /run-tests\.mjs/, 'npm test must use the resilient test runner');

// Ensure the complete checkout pipeline still exists in the intended order.
const stages = ['monitorAndAtc', 'navigateToCheckout', 'fillShipping', 'fillPayment', 'placeOrder'];
let lastIndex = -1;
for (const stage of stages) {
  const idx = source.indexOf(`name: '${stage}'`);
  assert.ok(idx > lastIndex, `checkout stage missing/out of order: ${stage}`);
  lastIndex = idx;
}

// Every important transition must have a selector family AND a text fallback.
const controlFamilies = [
  ['CHECKOUT_BUTTON_SELECTORS', /checkout/i],
  ['SHIPPING_SUBMIT_SELECTORS', /shipping/i],
  ['PAYMENT_SUBMIT_SELECTORS', /payment/i],
  ['PLACE_ORDER_SELECTORS', /place-order|place order|submit-order|submit order/i]
];
for (const [name, semanticPattern] of controlFamilies) {
  const family = new RegExp(`const ${name} = \\[([\\s\\S]*?)\\];`).exec(source);
  assert.ok(family, `${name} definition missing`);
  assert.match(family[1], semanticPattern, `${name} has no semantic selector`);
}

for (const phrase of ['proceed to checkout', 'continue to payment', 'continue to review', 'place order', 'submit order']) {
  assert.match(source, new RegExp(phrase.replaceAll(' ', '\\s+'), 'i'), `missing button/text fallback: ${phrase}`);
}

// Guest checkout is a common silent-stall point; ensure both detection and click are present.
assert.match(source, /GUEST_CHECKOUT_SELECTORS/);
assert.match(source, /findGuestButton\(/);
assert.match(source, /guest_checkout/);

// Checkout must not click Place Order until critical fields and a pre-order guard have run.
const placeOrderSection = source.slice(source.indexOf('const placeOrder ='), source.indexOf('const waitForCheckoutSurface ='));
assert.match(placeOrderSection, /preOrderGuard\(/);
assert.match(placeOrderSection, /humanClick\(page, placeOrderSelector\)/);
assert.match(placeOrderSection, /place order|submit order/i);
assert.match(placeOrderSection, /order-confirmation|data-order-id|order-thank-you-msg/i);

// Shipping/payment submit paths must fail loudly when no actionable control exists.
const shippingSection = source.slice(source.indexOf('const fillShipping ='), source.indexOf('const fillPayment ='));
const paymentSection = source.slice(source.indexOf('const fillPayment ='), source.indexOf('const tryAutoCaptcha ='));
assert.match(shippingSection, /SHIPPING_SUBMIT_SELECTORS/);
assert.match(shippingSection, /submit_shipping|shipping submit|Shipping submit|clickTextFallback/);
assert.match(paymentSection, /PAYMENT_SUBMIT_SELECTORS/);
assert.match(paymentSection, /Payment submit control not found/);

// Guard against accidental placeholder/dead-control markers in the checkout file.
assert.doesNotMatch(source, /TODO:.*(checkout|place order|shipping|payment)/i);
assert.doesNotMatch(source, /FIXME:.*(checkout|place order|shipping|payment)/i);

console.log('PASS: Pokémon Center checkout smoke/audit checks');
console.log(`PASS: ${stages.length} checkout stages present in order`);
console.log('PASS: checkout, shipping, payment, Place Order, and guest fallbacks are wired');
console.log('PASS: Place Order requires pre-order guard and waits for confirmation');

// Best Buy should use the same staged/recovery architecture as Pokémon Center.
const bestbuySource = await read('sites/bestbuy/index.js');
const bestbuyStages = ['monitorAndAtc', 'navigateToCheckout', 'fillShipping', 'fillPayment', 'placeOrder'];
let bestbuyLast = -1;
for (const stage of bestbuyStages) {
  const idx = bestbuySource.indexOf(`name: '${stage}'`);
  assert.ok(idx > bestbuyLast, `Best Buy checkout stage missing/out of order: ${stage}`);
  bestbuyLast = idx;
}
assert.match(bestbuySource, /retryWithBackoff/);
assert.match(bestbuySource, /waitForCheckoutSurface/);
assert.match(bestbuySource, /preOrderGuard\(/);
assert.match(bestbuySource, /order-confirmation|confirmation|order-complete/i);
assert.match(bestbuySource, /guardResult\.threeDSecure/);
// The log line lives in the shared guard, not the Best Buy adapter.
assert.match(checkoutGuardsSource, /3D Secure challenge detected/);
assert.doesNotMatch(bestbuySource, /await sleep\((1000|1200|1500)\)/);
const opsMlSource = await read('helpers/ops-ml.js');
assert.match(opsMlSource, /online logistic regression/i);
assert.match(opsMlSource, /retryDelayMultiplier/);
assert.match(checkoutGuardsSource, /recordRetryOutcome/);
assert.match(checkoutGuardsSource, /retryDelayMultiplier/);
assert.doesNotMatch(packageLockText ?? '', /npm\.replit|replit\.com.*registry/i);
console.log('PASS: lightweight operational ML is wired only into retry timing and remains bounded');

console.log(`PASS: Best Buy uses ${bestbuyStages.length} staged checkout phases with bounded recovery`);
console.log('PASS: Best Buy fixed transition sleeps were replaced by readiness checks');

const dashboard = await read('public/js/app.js');
const dashboardHtml = await read('public/index.html');
const taskController = await read('api/Tasks/controller.js');
const taskMonitor = await read('api/Tasks/monitor.js');

// Dashboard controls must be wired to real backend actions and report failures.
assert.match(dashboard, /async function stopTask\(id\)[\s\S]*?post\(`\/tasks\/\$\{id\}\/stop`\)/);
assert.match(taskController, /import \{ endMonitorForTask \} from '\.\/monitor\.js';/);
assert.match(taskController, /export const stopTask[\s\S]*?endMonitorForTask\(req\.params\.id\)/);
assert.match(taskController, /export const remove[\s\S]*?endMonitorForTask\(req\.params\.id\)/);
assert.match(taskMonitor, /export const endMonitorForTask/);

// Editing a task with no relationships must clear stale selections from the prior edit.
const editStart = dashboard.indexOf('function editTask(task)');
const editEnd = dashboard.indexOf("document.getElementById('task-modal-title').textContent", editStart);
const editSection = dashboard.slice(editStart, editEnd);
assert.match(editSection, /task-shipping.*\.value = ''/s);
assert.match(editSection, /task-billing.*\.value = ''/s);
assert.match(editSection, /task-payment.*\.value = ''/s);
assert.match(editSection, /shipping_address_id != null/);
assert.match(editSection, /billing_address_id != null/);
assert.match(editSection, /payment_profile_id != null/);

// Delete actions must not show a success toast unless the API actually succeeded.
for (const fn of ['deleteTask', 'deleteAddress', 'deletePaymentProfile', 'deleteProxy']) {
  const start = dashboard.indexOf(`async function ${fn}`);
  assert.ok(start >= 0, `${fn} must exist`);
  const end = dashboard.indexOf('\n}', start) + 2;
  const block = dashboard.slice(start, end);
  assert.match(block, /res\?\.success/);
}

console.log('PASS: dashboard controls are wired and backend task stop/delete tears down monitors');
console.log('PASS: task edit clears stale relationship selections');
console.log('PASS: delete controls only report success after successful API responses');


// Performance wiring checks: these are static checks so `npm test` remains useful
// even when the heavyweight browser/Jest dependencies are not installed.
const monitorSource = await read('api/Tasks/monitor.js');
const businessHoursSource = await read('helpers/business-hours.js');
const stockSource = await read('helpers/stock-monitor.js');
const tlsSource = await read('helpers/tls-client.js');
const siteApiSource = await read('helpers/site-stock-apis.js');

assert.match(monitorSource, /POLL_SETTING_TTL_MS/);
assert.match(monitorSource, /resolveTaskProxy\(task, 'monitor'\)/);
assert.match(monitorSource, /getResidentialProxy\('monitor'\)/);
assert.match(monitorSource, /canStartResidentialSession\('monitor'\)/);
assert.match(monitorSource, /status: 'residential_fallback'/);
assert.doesNotMatch(monitorSource, /proxyById/);
assert.doesNotMatch(monitorSource, /saved\.indexOf\(task\)/);
assert.match(businessHoursSource, /ENABLED_TTL_MS/);
assert.match(stockSource, /jarPersistTimer/);
assert.match(siteApiSource, /autoCheckerCache/);
assert.match(tlsSource, /new http\.Agent\(\{ keepAlive: true/);
assert.match(tlsSource, /httpAgent: sidecarAgent/);
assert.match(dashboard, /const \[res, addrRes, payRes, proxyRes, proxyMetaRes\] = await Promise\.all/);
assert.match(dashboard, /task-monitor-proxy/);
assert.match(dashboard, /task-checkout-proxy/);

console.log('PASS: monitor hot path uses short-lived setting caches and parallel restore lookups');
console.log('PASS: cookie persistence snapshots, checker detection, and local TLS sidecar requests are optimized');
console.log('PASS: dashboard task loading fetches tasks/addresses/payments in parallel');

// Best Buy stock detection must only fire for online inventory, not store-only stock.
assert.match(siteApiSource, /Best Buy's in-store availability must NOT trigger an online checkout/);
assert.match(siteApiSource, /let inStock = online/);
const dropWatcherSource = await read('helpers/drop-watcher.js');
const bbDrop = dropWatcherSource.slice(dropWatcherSource.indexOf("'bestbuy.ca':"), dropWatcherSource.indexOf("'target.com':"));
assert.match(bbDrop, /isAvailableOnline/);
console.log('PASS: Best Buy stock hot path distinguishes online inventory from store-only inventory');

const startTaskSource = await read('scripts/start-task.js');
const requestModeSource = await read('helpers/request-checkout/index.js');
const prewarmSource = await read('helpers/prewarm-engine.js');
const queueSource = await read('helpers/run-queue.js');
const hotIndexMigration = await read('db/migrations/20210101000020_hotpath_indexes.js');
assert.match(startTaskSource, /const \[shippingAddress, billingAddress, paymentProfile, checkoutProxy\] = await Promise\.all/);
assert.match(startTaskSource, /resolveTaskProxy\(task, 'checkout'\)/);
assert.match(requestModeSource, /REQUEST_MODE_TTL_MS/);
assert.match(prewarmSource, /PREWARM_SETTING_TTL_MS/);
assert.match(queueSource, /LIMITS_CACHE_TTL_MS/);
assert.match(queueSource, /Promise\.all\(\[/);
assert.match(hotIndexMigration, /tasks_site_active_idx/);
assert.match(hotIndexMigration, /logs_level_created_idx/);
const guardSource = await read('helpers/checkout-guards.js');
assert.match(guardSource, /QUEUE_DEFAULT_MAX_WAIT_MS/);
assert.match(guardSource, /QUEUE_MAX_WAIT_MS/);
assert.match(guardSource, /MutationObserver/);
assert.match(guardSource, /persistent queue wait/);
console.log('PASS: queue waits persist by default and wake on DOM changes');

console.log('PASS: checkout relation loading, feature gates, queue settings, and DB hot paths are optimized');

const taskMigration = await read('db/migrations/20210101000021_tasks_24_7_monitor.js');
assert.match(taskMigration, /monitor_24_7/);
assert.match(monitorSource, /runPersistentMonitorSweep/);
assert.match(monitorSource, /monitor_24_7: true/);
assert.match(monitorSource, /monitor_24_7: false/);
assert.match(dashboard, /task-monitor-247/);
console.log('PASS: 24/7 monitoring is persisted, reconciled, and exposed in the dashboard');

// Current dashboard surface should expose every major runtime control.
assert.match(dashboardHtml, /data-tab="feed"/);
assert.match(dashboard, /task-monitor-247/);
assert.match(dashboard, /monitor-poll-input/);
assert.match(dashboard, /system-health-badge/);
assert.match(dashboard, /hydrateMonitorStates/);
// Assert the cache-buster shape, not a literal, so a version bump doesn't break
// this test — but a missing/empty buster still fails.
assert.match(dashboardHtml, /app\.js\?v=[0-9]{8}-[a-z0-9-]+/);
assert.match(dashboard, /Monitoring:.*monthlyBudgetMb/);
assert.match(dashboard, /Checkout:.*monthlyBudgetMb/);
assert.doesNotMatch(dashboard, /checks every 2 seconds/);
assert.match(monitorSource, /type: 'snapshot', monitors: current/);
assert.equal((monitorSource.match(/type: 'snapshot', monitors: current/g) || []).length, 1, 'global monitor stream should emit one initial snapshot');

const budgetSource = await read('helpers/residential-budget.js');
assert.match(budgetSource, /RESIDENTIAL_MONITOR_MONTHLY_BUDGET_MB/);
assert.match(budgetSource, /RESIDENTIAL_CHECKOUT_MONTHLY_BUDGET_MB/);
assert.match(budgetSource, /remainingResidentialBytes = \(role = null\)/);
console.log('PASS: monitoring and checkout have separate residential 1 GiB/month budgets by default');

const allSiteAdapters = ['amazon','bestbuy','demandware','footsites','gamestop','nike','pokemoncenter','shopify','supremenewyork','target','topps','walmart'];
const sitePerfSource = await read('helpers/site-performance.js');
for (const [id, name] of [[1,'Footsites'],[2,'Shopify'],[3,'Demandware'],[4,'Nike'],[5,'Supreme'],[6,'Pokemon Center'],[7,'Topps'],[8,'Walmart'],[9,'Best Buy'],[10,'Target'],[11,'GameStop'],[12,'Amazon']]) {
  assert.match(sitePerfSource, new RegExp(`${id}: Object\.freeze`), `${name}: site performance profile missing`);
}
assert.match(sitePerfSource, /warmPath/);
assert.match(sitePerfSource, /fastReadinessMs/);
console.log('PASS: every built-in retailer has a dedicated runtime performance profile');
const checkoutContracts = await read('helpers/site-checkout-contracts.js');
for (const f of allSiteAdapters) {
  const src2 = await read(`sites/${f}/index.js`);
  assert.match(src2, /const [A-Z0-9_]*SELECTORS|const SELECTORS|const SELECTOR/, `${f}: dedicated selector map missing`);
  assert.match(src2, /preOrderGuard\(/, `${f}: pre-order guard missing`);
  assert.match(src2, /order-confirmation|orderConfirmation|confirmation|thank.?you/i, `${f}: order confirmation detection missing`);
  assert.doesNotMatch(src2, /checkout adapter is not bundled|not bundled in this build/i, `${f}: placeholder adapter remains`);
  assert.match(checkoutContracts, new RegExp(`['\"]${f}['\"]\s*:`), `${f}: checkout contract missing`);
}
assert.match(await read('helpers/checkout-controls.js'), /assertActionButtonIntent/);
console.log('PASS: every built-in retailer has a dedicated checkout adapter, contract, and final-control guard');
console.log('PASS: dashboard surface, cache busting, monitor hydration, and global SSE snapshot are current');
const siteRuntime = await read('helpers/site-runtime.js');
assert(siteRuntime.includes("semantic-recovery.js"), 'site runtime uses semantic checkout recovery');
const semanticRecovery = await read('helpers/semantic-recovery.js');
assert(semanticRecovery.includes('place_order') && semanticRecovery.includes('add_to_cart'), 'semantic recovery covers critical checkout actions');
console.log('PASS: checkout selector drift has early semantic recovery and guarded action matching');


// Checkout performance regression checks
const humanTypeSource2 = await read('helpers/human-type.js');
assert(humanTypeSource2.includes('fastFillMainFrame'), 'fast verified main-frame fill missing');
assert(humanTypeSource2.includes('__checkoutFastUI'), 'fast checkout UI click path missing');
const startSource2 = await read('scripts/start-task.js');
assert(startSource2.includes('REQUEST_MODE_PROBE_HOTPATH'), 'hot-path request probe gate missing');
for (const f of ['amazon','demandware','footsites','gamestop','nike','shopify','supremenewyork','topps','walmart']) {
  const src2 = await read(`sites/${f}/index.js`);
  assert(src2.includes('waitForAnySelector'), `${f}: shared readiness wait missing`);
}


// Strong architecture contract: armed monitor capacity is distinct from heavyweight checkout slots.
const cpuPerf = await read('helpers/cpu-performance.js');
assert.match(cpuPerf, /recommendedCheckoutConcurrency/);
assert.match(cpuPerf, /CHECKOUT_CONCURRENCY_CAP/);
assert.match(cpuPerf, /Math\.min\(1000, configured\)/);
const queuePerf = await read('helpers/run-queue.js');
assert.match(queuePerf, /max_armed_tasks/);
assert.match(queuePerf, /priority/);
assert.match(queuePerf, /getArmedTaskCapacity/);
assert.match(queuePerf, /getArmedTaskHostCapacity/);
assert.match(queuePerf, /<= 100/);
assert.match(queuePerf, /DEFAULT_ARMED_TASKS = 1000/);
const monitorCapacity = await read('api/Tasks/monitor.js');
assert.match(monitorCapacity, /getArmedTaskCapacity/);
assert.match(monitorCapacity, /activeMonitorCount/);
assert.match(monitorCapacity, /armedReservationsByHost/);
assert.match(monitorCapacity, /restoredByHost/);
const lightweightPrewarmSource = await read('helpers/prewarm-engine.js');
assert.doesNotMatch(lightweightPrewarmSource, /return false;\n  }/);
const envSource = await read('.env.example');
assert.match(envSource, /LIGHTWEIGHT_TASK_MODE=true/);
assert.match(envSource, /TASK_MEMORY_BUDGET_MB=200/);
assert.match(envSource, /CHECKOUT_MEMORY_BUDGET_MB=500/);
assert.match(envSource, /CHECKOUT_CONCURRENCY_CAP=32/);
const startTaskPriority = await read('scripts/start-task.js');
assert.match(startTaskPriority, /priority: Number\(task\._priority \|\| 0\)/);
console.log('PASS: scalable armed monitor lane (1000 global / 100 per host) is separated from the adaptive checkout lane and hot hits get priority');


// Elite performance contract
const eliteCpuPerf = await read('helpers/cpu-performance.js');
assert.match(eliteCpuPerf, /CPU_PERFORMANCE_MODE \|\| 'max'/);
assert.match(eliteCpuPerf, /configured = 24/);
assert.match(eliteCpuPerf, /CHECKOUT_CONCURRENCY_CAP/);
const launcher = await read('launcher.mjs');
assert.match(launcher, /UV_THREADPOOL_SIZE/);
const netPerf = await read('helpers/network-performance.js');
assert.match(netPerf, /keepAliveMsecs/);
const clusterSrc = await read('helpers/cluster.js');
assert.match(clusterSrc, /setCacheEnabled\(true\)/);
assert.match((await read('helpers/resource-blocker.js')), /Network\.setBlockedURLs/);
console.log('PASS: elite CPU, connection-pool, launcher, and browser-cache optimizations are wired');

// Admission layer: `--disable-features` must be emitted exactly ONCE. It used to
// be duplicated (static list + lightweight block, which is on by default) and
// Chromium honours only the last one, silently dropping site-per-process and
// WebRTC mDNS hiding on every default launch.
const admissionSrc = await read('helpers/admission.js');
assert.match(admissionSrc, /mergeDisableFeatures/, 'feature flags must be merged, not concatenated');
assert.match(admissionSrc, /site-per-process/, 'site isolation must stay disabled for RAM');
assert.match(admissionSrc, /WebRtcHideLocalIpsWithMdns/, 'webrtc mDNS hiding must not be dropped');
assert.match(admissionSrc, /checkoutAdmission/, 'RAM and proxy admission must be decided together');
assert.doesNotMatch(clusterSrc, /--disable-features=/, 'cluster must not build feature flags inline');
assert.match(clusterSrc, /buildChromiumArgs/, 'launch args must come from the admission module');
// A 1 GB host used to be forced to 2 browsers by a fixed floor and then OOM'd.
const cpuPerfSrc = await read('helpers/cpu-performance.js');
assert.match(cpuPerfSrc, /lowRamHost/, 'the governor must have a low-RAM tier');
assert.match(cpuPerfSrc, /lowRamCeiling/, 'low-RAM hosts need a ceiling below ramCap');
const budgetSrc = await read('helpers/residential-budget.js');
assert.match(budgetSrc, /acquireResidentialSession/, 'residential sessions need a concurrency gate');
const taskSrc = await read('scripts/start-task.js');
assert.match(taskSrc, /residentialRelease\(\)/, 'the gateway slot must be released in finally');

// Anti-bot coherence contract
const coherenceSrc = await read('helpers/fingerprint-coherence.js');
assert.match(coherenceSrc, /export const validate/);
assert.match(coherenceSrc, /export const repair/);
assert.match(coherenceSrc, /export const deriveScreenMetrics/);
assert.match(coherenceSrc, /export const screenGeometry/);
const storeSrc = await read('helpers/fingerprint-store.js');
assert.match(storeSrc, /deriveScreenMetrics/, 'fingerprints must derive a coherent screen triad');
assert.match(storeSrc, /healIfIncoherent/, 'pinned fingerprints must self-heal on load');
assert.match(storeSrc, /CHROME_FINGERPRINT_MAJOR/, 'engine version must be configurable');
const clusterStealth = await read('helpers/cluster.js');
assert.doesNotMatch(clusterStealth, /const _sw = 1920, _sh = 1080;/, 'screen must not be hardcoded');
assert.match(clusterStealth, /screenGeometry/, 'cluster must use the shared geometry helper');
assert.match(clusterStealth, /pdfViewerEnabled/, 'pdfViewerEnabled must be spoofed');
assert.match(clusterStealth, /navigator\.permissions\.query,/, 'patched accessors must mask toString');
// WebGL vendor must follow the profile: a hardcoded 'Intel Inc.' contradicted
// every macOS/Apple profile and FingerprintJS Pro reports the pair directly.
assert.doesNotMatch(clusterStealth, /37445\) return 'Intel Inc\.'/, 'UNMASKED_VENDOR_WEBGL must not be hardcoded');
assert.match(clusterStealth, /_glVendor/, 'WebGL vendor must derive from the profile');
const geo = await read('helpers/geo-consistency.js');
assert.match(geo, /resolveTimezoneForExit/, 'exit timezone must be resolvable');
const dd = await read('helpers/datadome.js');
assert.doesNotMatch(dd, /'sec-ch-ua': '"Chromium";v="124"/, 'DataDome client hints must not be pinned to Chrome 124');
assert.match(dd, /clientHintFor/, 'DataDome client hints must follow the UA version');
// Client hints must come from one GREASE-correct implementation. The old
// hardcoded '"Not-A.Brand";v="99"' is Chrome-99 vintage and disagrees with a
// real Chrome 131, which emits e.g. "Not_A Brand";v="24".
const hintsSrc = await read('helpers/client-hints.js');
assert.match(hintsSrc, /GREASE_CHARS/, 'client hints must implement Chrome GREASE rotation');
assert.match(hintsSrc, /export const secChUa/, 'client hints must expose secChUa');
for (const [file, label] of [
  ['helpers/cluster.js', 'browser'],
  ['helpers/datadome.js', 'DataDome'],
  ['helpers/stock-monitor.js', 'stock monitor'],
  ['helpers/trainer.js', 'trainer']
]) {
  const src = await read(file);
  assert.match(src, /from '\.\/client-hints\.js'/, `${label} must use the shared client-hint builder`);
  assert.doesNotMatch(src, /Not-A\.Brand/, `${label} must not hardcode the legacy GREASE brand`);
}
const captchaSrc = await read('helpers/captcha.js');
assert.match(captchaSrc, /rank: \{/, 'captcha providers must carry per-type ranks');
assert.match(captchaSrc, /pollDelay/, 'captcha polling must back off instead of a fixed 5s interval');
assert.match(captchaSrc, /Racing/, 'Turnstile must race the top two providers');
const guardsSrc = await read('helpers/checkout-guards.js');
assert.match(guardsSrc, /'capsolver_api_key'/, 'hasCaptchaApiKey must recognise CapSolver');
const sidecar = await read('tls-sidecar/main.go');
assert.match(sidecar, /sec-ch-ua-arch/, 'sidecar header order must include arch');
assert.match(sidecar, /sec-ch-ua-full-version-list/, 'sidecar header order must include full version list');
console.log('PASS: anti-bot fingerprint coherence wiring (validation, self-heal, geometry, client hints, header order)');

// Payment lockout contract — a hard park that only an operator can clear.
const lockoutSrc = await read('helpers/payment-lockout.js');
assert.match(lockoutSrc, /PAYMENT_LOCKOUT_THRESHOLD = 5/, 'threshold must be five consecutive declines');
assert.match(lockoutSrc, /export const isPaymentLocked/, 'the gate must be importable by the runner');
assert.match(lockoutSrc, /export const clearPaymentLock/, 'the operator path must exist');
assert.match(lockoutSrc, /export const recordPaymentOutcome/, 'outcomes must be recorded through one helper');
const startTaskLock = await read('scripts/start-task.js');
// The gate must sit in runTaskLifecycle before any attempt can reach runOnce,
// otherwise a locked task still burns a proxy session and captcha credits to
// arrive at the same decline. runOnce is *defined* earlier, so compare against
// the retry loop that calls it.
const lockGateAt = startTaskLock.indexOf('isPaymentLocked(task)');
assert.ok(lockGateAt > 0, 'start-task must gate on the payment lock');
assert.ok(
  lockGateAt < startTaskLock.indexOf('for (let attempt = 0'),
  'the payment lock must be checked before the first checkout attempt'
);
assert.ok(
  startTaskLock.indexOf('runTaskLifecycle = async') < lockGateAt,
  'the gate must live in the lifecycle, not the per-attempt runner'
);
assert.match(startTaskLock, /stage: 'payment_locked'/);
assert.match(startTaskLock, /recordPaymentOutcome\(db, taskId, task, 'success'\)/);
assert.match(startTaskLock, /terminalDecline \? 'decline' : 'neutral'/, 'only a terminal decline may burn a strike');
const lockController = await read('api/Tasks/controller.js');
assert.match(lockController, /export const enablePayment/);
assert.match(lockController, /clearPaymentLock/, 'the endpoint must clear the lock');
const lockRoutes = await read('api/Tasks/index.js');
assert.match(lockRoutes, /:id\/enable-payment/, 'the operator route must be registered');
// A locked task must survive the reconciler, otherwise the sweep re-arms it and
// the dead card is retried on the next tick.
const monitorLock = await read('api/Tasks/monitor.js');
const noRestartSets = monitorLock.match(/NO_RESTART_STATUSES = new Set\(\[[^\]]*\]\)/g) || [];
assert.equal(noRestartSets.length, 2, 'both restart guards must exist');
for (const set of noRestartSets) {
  assert.match(set, /'payment_locked'/, 'payment_locked must be in every no-restart set');
}
const lockDashboard = await read('public/js/app.js');
assert.match(lockDashboard, /enablePayment/, 'the dashboard must offer a re-enable action');
assert.match(lockDashboard, /pay_disabled_at/, 'the badge must key off the lock column');
console.log('PASS: payment lockout parks a task after 5 declines and only an operator clears it');

