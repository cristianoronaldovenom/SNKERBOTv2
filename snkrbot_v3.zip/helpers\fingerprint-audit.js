// Fingerprint stability audit — the leaks a single snapshot cannot see.
//
// `fingerprint-coherence.js` checks ONE snapshot for contradictions (screen
// smaller than viewport, 32 GB on a 4-core laptop). Those are static lies.
//
// The other class of tell is DYNAMIC: a property that returns a different value
// each time it is read, or a surface that changes between two loads of the same
// identity. Real Chrome is bit-stable across a reload — canvas hash, WebGL
// vendor, audio sum, connection.rtt, `outerWidth` — so any drift between two
// samples of one profile is a machine-generated signal. Three separate live bugs
// found earlier in this repo (double-randomised connection.rtt, per-launch
// canvas noise, a webdriver value that changed type) were all this class and all
// invisible to a single-snapshot check.
//
// `SURFACE_PROBE` is the single source of truth for what gets sampled: the
// runtime evaluates it in the page, and this module compares N results. Pure and
// browser-free, so it is exercised directly by tests.

// Evaluated in the page. Must stay dependency-free and must not throw: every
// read is individually guarded so one blocked API cannot void the whole sample.
export const SURFACE_PROBE = `(() => {
  const g = (fn, d = null) => { try { const v = fn(); return v === undefined ? d : v; } catch (_) { return d; } };
  const gl = () => g(() => {
    const c = document.createElement('canvas');
    const ctx = c.getContext('webgl') || c.getContext('experimental-webgl');
    return ctx;
  });
  const ctx = gl();
  return {
    webdriverType: typeof navigator.webdriver,
    webdriverValue: g(() => navigator.webdriver),
    hardwareConcurrency: g(() => navigator.hardwareConcurrency),
    deviceMemory: g(() => navigator.deviceMemory),
    language: g(() => navigator.language),
    languages: g(() => navigator.languages.join(',')),
    platform: g(() => navigator.platform),
    connectionRtt: g(() => navigator.connection && navigator.connection.rtt),
    connectionDownlink: g(() => navigator.connection && navigator.connection.downlink),
    connectionType: g(() => navigator.connection && navigator.connection.type),
    screenWidth: g(() => screen.width),
    screenHeight: g(() => screen.height),
    availWidth: g(() => screen.availWidth),
    availTop: g(() => screen.availTop),
    availLeft: g(() => screen.availLeft),
    outerWidth: g(() => window.outerWidth),
    outerHeight: g(() => window.outerHeight),
    screenX: g(() => window.screenX),
    screenY: g(() => window.screenY),
    screenLeft: g(() => window.screenLeft),
    screenTop: g(() => window.screenTop),
    dpr: g(() => window.devicePixelRatio),
    hasFocus: g(() => document.hasFocus()),
    visibility: g(() => document.visibilityState),
    webglVendor: ctx ? g(() => ctx.getParameter(ctx.VENDOR)) : null,
    webglRenderer: ctx ? g(() => ctx.getParameter(ctx.RENDERER)) : null,
    plugins: g(() => navigator.plugins.length),
    mimeTypes: g(() => navigator.mimeTypes.length),
    brandCount: g(() => (navigator.userAgentData ? navigator.userAgentData.brands.length : null)),
    timezone: g(() => Intl.DateTimeFormat().resolvedOptions().timeZone),
    quota: g(() => navigator.storage ? 'present' : null)
  };
})()`;

// Fields legitimately expected to differ between two samples.
const VOLATILE = new Set([
  'quota',        // 'present' marker only, but be safe
]);

// Numeric fields that must stay put and where a change is unambiguous drift.
const STABLE_NUMERIC = new Set([
  'hardwareConcurrency', 'deviceMemory', 'screenWidth', 'screenHeight',
  'availWidth', 'availLeft', 'availTop', 'dpr', 'plugins', 'mimeTypes',
  'brandCount', 'screenX', 'screenY', 'screenLeft', 'screenTop',
  // Frozen by the stealth script precisely because real Chrome holds it steady.
  'connectionRtt', 'connectionDownlink'
]);

const sample = (value) => (value === null || value === undefined ? '<null>' : String(value));

// Compare N probe results for one identity. `samples` is an array of the objects
// SURFACE_PROBE returns. Fewer than two samples means nothing can be concluded.
export const compareSamples = (samples = []) => {
  const issues = [];
  const live = samples.filter((s) => s && typeof s === 'object');
  if (live.length < 2) return issues;

  const fields = new Set();
  for (const s of live) for (const k of Object.keys(s)) fields.add(k);

  for (const field of fields) {
    if (VOLATILE.has(field)) continue;
    const values = live.map((s) => s[field]);
    const distinct = new Set(values.map(sample));
    if (distinct.size <= 1) continue;
    issues.push({
      field,
      kind: STABLE_NUMERIC.has(field) ? 'unstable' : 'drift',
      severity: STABLE_NUMERIC.has(field) ? 'high' : 'medium',
      values: Array.from(distinct)
    });
  }
  return issues;
};

// Static plausibility checks on one sample. Deliberately tiny and only for
// invariants that hold for every real browser — coherence.js owns the rest, so
// this does not repeat it.
export const implausibilities = (s = {}) => {
  const issues = [];
  const push = (field, detail) => issues.push({ field, kind: 'implausible', severity: 'high', values: [detail] });

  if (s.webdriverType && s.webdriverType !== 'boolean') push('webdriverType', s.webdriverType);
  if (s.languages && !String(s.languages).startsWith(String(s.language))) {
    push('language', `${s.language} not first of ${s.languages}`);
  }
  if (s.visibility === 'visible' && s.hasFocus === false) push('hasFocus', 'visible but unfocused');
  const w = Number(s.screenWidth);
  const aw = Number(s.availWidth);
  if (Number.isFinite(w) && Number.isFinite(aw) && aw > w) push('availWidth', `${aw} > ${w}`);
  const ow = Number(s.outerWidth);
  if (Number.isFinite(ow) && Number.isFinite(w) && ow > w) push('outerWidth', `${ow} > ${w}`);
  return issues;
};

export const auditSamples = (samples = []) => {
  const first = Array.isArray(samples) ? samples.find((s) => s && typeof s === 'object') : null;
  const statics = first ? implausibilities(first) : [];
  const flagged = new Set(statics.map((i) => i.field));
  // A field already reported as implausible must not also be reported as drift:
  // "language is not first in languages" and "language changed between loads"
  // are two descriptions of one defect, and duplicates bury the signal.
  const drift = compareSamples(samples).filter((i) => !flagged.has(i.field));
  const issues = [...statics, ...drift];
  return {
    samples: Array.isArray(samples) ? samples.length : 0,
    issues,
    ok: issues.length === 0
  };
};
