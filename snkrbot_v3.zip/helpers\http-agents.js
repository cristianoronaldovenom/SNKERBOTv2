// Shared HTTP/HTTPS keep-alive pools for all HTTP clients.
// Applied once at boot to cut connection churn (fewer TLS handshakes → faster,
// cheaper residential bandwidth usage) and to enforce socket ceilings from env.
import axios from 'axios';
import { directHttpAgent, directHttpsAgent, socketTimeoutMs } from './network-performance.js';

let applied = false;

export const applyHttpClientPooling = () => {
  if (applied) return;
  axios.defaults.httpAgent = directHttpAgent;
  axios.defaults.httpsAgent = directHttpsAgent;
  // Respect any stricter per-call timeout; this only supplies a floor.
  if (!axios.defaults.timeout || axios.defaults.timeout > socketTimeoutMs) {
    axios.defaults.timeout = socketTimeoutMs;
  }
  applied = true;
};
