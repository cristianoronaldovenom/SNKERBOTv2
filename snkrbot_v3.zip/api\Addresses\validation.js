import Joi from 'joi';

export const createAddressSchema = {
  body: Joi.object({
    first_name: Joi.string().max(100).required(),
    last_name: Joi.string().max(100).required(),
    address1: Joi.string().max(255).required(),
    address2: Joi.string().max(255).allow('').optional(),
    city: Joi.string().max(100).required(),
    state: Joi.string().max(50).required(),
    zip: Joi.string().max(20).required(),
    country: Joi.string().max(100).optional(),
    phone: Joi.string().max(30).required(),
    email: Joi.string().email().required()
  })
};

export const updateAddressSchema = {
  body: Joi.object({
    first_name: Joi.string().max(100).optional(),
    last_name: Joi.string().max(100).optional(),
    address1: Joi.string().max(255).optional(),
    address2: Joi.string().max(255).allow('').optional(),
    city: Joi.string().max(100).optional(),
    state: Joi.string().max(50).optional(),
    zip: Joi.string().max(20).optional(),
    country: Joi.string().max(100).optional(),
    phone: Joi.string().max(30).optional(),
    email: Joi.string().email().optional()
  })
};
