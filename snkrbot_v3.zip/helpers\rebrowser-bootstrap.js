// MUST be imported BEFORE rebrowser-puppeteer-core anywhere in the process.
//
// Node ESM evaluates a module's static imports in left-to-right post-order
// before running the importer's own top-level statements. That means setting
// `process.env.REBROWSER_*` at the top of cluster.js (which still runs AFTER
// rebrowser-puppeteer-core's evaluation) is too late: rebrowser reads its
// env at module-init time and decides whether to apply the runtime patches.
//
// This bootstrap module has no other imports, so listing it as the FIRST
// import in cluster.js (before rebrowser-puppeteer-core) guarantees the env
// vars are set before rebrowser's top-level code runs.
process.env.REBROWSER_PATCHES_RUNTIME_FIX_MODE = process.env.REBROWSER_PATCHES_RUNTIME_FIX_MODE || 'addBinding';
process.env.REBROWSER_PATCHES_SOURCE_URL = process.env.REBROWSER_PATCHES_SOURCE_URL || 'app.js';
process.env.REBROWSER_PATCHES_UTILITY_WORLD_NAME = process.env.REBROWSER_PATCHES_UTILITY_WORLD_NAME || 'util';
// eslint-disable-next-line no-console
console.log(`[rebrowser-bootstrap] runtime fix mode: ${process.env.REBROWSER_PATCHES_RUNTIME_FIX_MODE}, sourceURL: ${process.env.REBROWSER_PATCHES_SOURCE_URL}, utility world: ${process.env.REBROWSER_PATCHES_UTILITY_WORLD_NAME}`);
