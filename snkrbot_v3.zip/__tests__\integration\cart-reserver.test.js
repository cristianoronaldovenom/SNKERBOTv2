import { jest } from '@jest/globals';

jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));

const tlsRequest = jest.fn();
jest.unstable_mockModule('../../helpers/tls-client.js', () => ({ tlsRequest }));

const getSessionCookies = jest.fn(() => '');
jest.unstable_mockModule('../../helpers/stock-monitor.js', () => ({ getSessionCookies }));

const extractApiUrl = jest.fn();
jest.unstable_mockModule('../../helpers/site-stock-apis.js', () => ({
  shopifyCheck: { extractApiUrl }
}));

const { reserveCart, __test__ } = await import('../../helpers/cart-reserver.js');

beforeEach(() => {
  tlsRequest.mockReset();
  getSessionCookies.mockReset();
  getSessionCookies.mockReturnValue('');
  extractApiUrl.mockReset();
});

describe('reserveCart — unsupported sites fall back cleanly', () => {
  test('non-Shopify site returns unsupported without touching the network', async () => {
    const res = await reserveCart({ task: { id: 1, site_id: 4, url: 'https://nike.com/x' } });
    expect(res.reserved).toBe(false);
    expect(res.site).toBe('unsupported');
    expect(tlsRequest).not.toHaveBeenCalled();
  });

  test('Topps (site_id 7) is unsupported — its checkout adapter is SFCC, not Shopify', async () => {
    const res = await reserveCart({ task: { id: 7, site_id: 7, url: 'https://www.topps.com/products/x' } });
    expect(res.reserved).toBe(false);
    expect(res.site).toBe('unsupported');
    expect(tlsRequest).not.toHaveBeenCalled();
  });

  test('missing url never throws', async () => {
    const res = await reserveCart({ task: { id: 2, site_id: 2 } });
    expect(res.reserved).toBe(false);
    expect(res.ok).toBe(false);
  });
});

describe('reserveCart — Shopify reservation', () => {
  test('variant from URL: POSTs /cart/add.js and captures the cart cookie', async () => {
    getSessionCookies.mockReturnValue('warm=1');
    tlsRequest.mockResolvedValueOnce({
      ok: true, status: 200,
      headers: { 'set-cookie': ['cart=abc123; path=/; HttpOnly', '_secure_session=zzz; path=/'] }
    });

    const res = await reserveCart({
      task: { id: 3, site_id: 2, url: 'https://shop.com/products/x?variant=999', quantity: 2 },
      proxy: { host: 'p', port: 1 }
    });

    expect(res.reserved).toBe(true);
    expect(res.site).toBe('shopify');
    expect(res.variantId).toBe('999');
    // Warm session cookie + fresh cart token handed to the browser together.
    expect(res.cartCookies).toBe('warm=1; cart=abc123; _secure_session=zzz');

    // The first request must be the add.js POST (variant came from the URL, so
    // no product-JSON resolve). The second is the /checkout pre-open handoff.
    expect(tlsRequest).toHaveBeenCalledTimes(2);
    const call = tlsRequest.mock.calls[0][0];
    expect(call.method).toBe('POST');
    expect(call.url).toBe('https://shop.com/cart/add.js');
    expect(call.headers.Cookie).toBe('warm=1'); // warm session cookies reused
    expect(JSON.parse(call.body)).toEqual({ id: 999, quantity: 2 });

    // Request-first checkout handoff reuses the merged cart cookie.
    const preopen = tlsRequest.mock.calls[1][0];
    expect(preopen.method ?? 'GET').toBe('GET');
    expect(preopen.url).toBe('https://shop.com/checkout');
    expect(preopen.headers.Cookie).toBe('warm=1; cart=abc123; _secure_session=zzz');
  });

  test('resolves variant from product JSON matching the requested size', async () => {
    extractApiUrl.mockReturnValue('https://shop.com/products/x.json');
    tlsRequest
      .mockResolvedValueOnce({ // product JSON fetch
        ok: true, status: 200,
        body: JSON.stringify({
          product: { variants: [
            { id: 111, title: 'US 9', available: false },
            { id: 222, title: 'US 10.5', available: true },
          ] }
        })
      })
      .mockResolvedValueOnce({ // add.js POST
        ok: true, status: 200, headers: { 'set-cookie': 'cart=tok; path=/' }
      });

    const res = await reserveCart({
      task: { id: 4, site_id: 2, url: 'https://shop.com/products/x', size: '10.5' }
    });

    expect(res.reserved).toBe(true);
    expect(res.variantId).toBe('222');
    expect(JSON.parse(tlsRequest.mock.calls[1][0].body)).toEqual({ id: 222, quantity: 1 });
  });

  test('a failed add (non-200) never blocks checkout', async () => {
    tlsRequest.mockResolvedValueOnce({ ok: true, status: 422, headers: {} });
    const res = await reserveCart({
      task: { id: 5, site_id: 2, url: 'https://shop.com/products/x?variant=5' }
    });
    expect(res.reserved).toBe(false);
    expect(res.ok).toBe(false);
    expect(res.error).toMatch(/422/);
  });

  test('no available variant resolved → not reserved, no add attempted', async () => {
    extractApiUrl.mockReturnValue('https://shop.com/products/x.json');
    tlsRequest.mockResolvedValueOnce({
      ok: true, status: 200,
      body: JSON.stringify({ product: { variants: [{ id: 1, title: 'US 9', available: false }] } })
    });
    const res = await reserveCart({
      task: { id: 6, site_id: 2, url: 'https://shop.com/products/x', size: '12' }
    });
    expect(res.reserved).toBe(false);
    expect(tlsRequest).toHaveBeenCalledTimes(1); // only the JSON lookup, no POST
  });
});

describe('pure helpers', () => {
  test('sizeMatches handles loose matches and empty size', () => {
    const { sizeMatches } = __test__;
    expect(sizeMatches('US 10.5', '10.5')).toBe(true);
    expect(sizeMatches('10.5', 'US 10.5')).toBe(true);
    expect(sizeMatches('US 9', '10.5')).toBe(false);
    expect(sizeMatches('anything', null)).toBe(true); // no size => match
    expect(sizeMatches(null, '10')).toBe(false);
  });

  test('extractCookieHeader joins name=value pairs from string or array', () => {
    const { extractCookieHeader } = __test__;
    expect(extractCookieHeader({ 'set-cookie': ['a=1; path=/', 'b=2; HttpOnly'] })).toBe('a=1; b=2');
    expect(extractCookieHeader({ 'Set-Cookie': 'c=3; path=/' })).toBe('c=3');
    expect(extractCookieHeader({})).toBe('');
  });

  test('mergeCookieHeaders combines warm + fresh, fresh wins on a name clash', () => {
    const { mergeCookieHeaders } = __test__;
    expect(mergeCookieHeaders('warm=1', 'cart=abc')).toBe('warm=1; cart=abc');
    expect(mergeCookieHeaders('cart=old; warm=1', 'cart=new')).toBe('cart=new; warm=1');
    expect(mergeCookieHeaders('', 'cart=abc')).toBe('cart=abc');
    expect(mergeCookieHeaders('warm=1', '')).toBe('warm=1');
  });
});
