import { jest } from '@jest/globals';
import path from 'node:path';
import fs from 'node:fs/promises';

jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));

const {
  wipeSessionCookies, rotateIdentity, isBotDetectionFailure, shouldRotateAfterFailure
} = await import('../../helpers/identity-rotator.js');

const TASK_ID = 999999; // unlikely to collide with a real task profile
const dir = path.resolve(process.cwd(), 'profiles', `task-${TASK_ID}`);

const seedProfile = async () => {
  await fs.mkdir(path.join(dir, 'Default'), { recursive: true });
  await fs.writeFile(path.join(dir, '_fingerprint.json'), '{"ua":"x"}');
  await fs.writeFile(path.join(dir, '_cf_clearance.json'), '{"cf":"y"}');
  await fs.writeFile(path.join(dir, 'Default', 'Cookies'), 'sqlite-blob');
};

afterEach(async () => {
  await fs.rm(dir, { recursive: true, force: true });
});

describe('wipeSessionCookies', () => {
  test('drops cookies/CF token/userDataDir but KEEPS the pinned fingerprint', async () => {
    await seedProfile();
    const ok = await wipeSessionCookies(TASK_ID);
    expect(ok).toBe(true);

    const remaining = await fs.readdir(dir);
    expect(remaining).toEqual(['_fingerprint.json']);
    // Fingerprint content is untouched
    const fp = await fs.readFile(path.join(dir, '_fingerprint.json'), 'utf8');
    expect(fp).toBe('{"ua":"x"}');
  });

  test('never throws when the profile dir does not exist', async () => {
    const ok = await wipeSessionCookies(TASK_ID); // nothing seeded
    expect(ok).toBe(true);
  });
});

describe('rotateIdentity vs wipeSessionCookies', () => {
  test('rotateIdentity wipes the fingerprint too (full identity reset)', async () => {
    await seedProfile();
    await rotateIdentity(TASK_ID);
    const remaining = await fs.readdir(dir).catch(() => []);
    expect(remaining).not.toContain('_fingerprint.json');
  });
});

describe('isBotDetectionFailure / shouldRotateAfterFailure', () => {
  test('detection failure classified by stage', () => {
    expect(isBotDetectionFailure({ ok: false, stage: 'datadome' })).toBe(true);
  });

  test('shouldRotateAfterFailure stays OFF for address-attached tasks', () => {
    expect(shouldRotateAfterFailure({
      task: { shipping_address_id: 3 }, lastResult: { ok: false, stage: 'imperva' }
    })).toBe(false);
  });
});
