// Shopify request-mode (browserless) checkout primitives.
//
// Phase status:
//   - classifyShopifyResponse: response-text classifier (pure, fully tested).
//   - tokenizeCard: Shopify card-vault tokenization. STABLE + safely testable —
//     it exchanges the raw card for an opaque session token and does NOT charge.
//   - prefillShopifyCheckout: dryRun (default) is fully READ-ONLY — it resolves
//     the variant and probes the storefront without mutating a cart or placing an
//     order. The mutating path is scaffolded but only runs when dryRun=false
//     (not yet wired into the runner — that's Phase 3, gated + live-validated).
//
// SECURITY: never log card fields or response bodies here.
import { HttpSession } from './http-session.js';
import { resolveShopifyVariant } from '../cart-reserver.js';

const CARD_VAULT_URL = 'https://deposit.shopifycs.com/sessions';

// Classify a Shopify response body into an actionable failure type, or null if
// nothing notable. Bias is toward NOT acting (a null means "looks fine"); the
// caller falls back to the browser flow on any non-null classification.
export const classifyShopifyResponse = (text = '') => {
  const t = String(text || '').toLowerCase();
  if (/just a moment|checking your browser|cf-browser-verification|px-captcha|hcaptcha|recaptcha|are you a human|verify you are (a )?human|access denied|pardon our interruption/.test(t)) return 'challenge';
  if (/you are in line|waiting room|queue-it|estimated wait|your turn/.test(t)) return 'queue';
  if (/sold out|out of stock|no longer available|currently unavailable|cannot find variant|not enough.*in stock|insufficient.*inventory/.test(t)) return 'oos';
  if (/card was declined|was declined|card.*declined|insufficient funds|invalid.*card|incorrect.*(card|cvv|cvc|security code)|\bavs\b|payment.*(failed|could not be|declined|unsuccessful)/.test(t)) return 'decline';
  if (/cart.*(is )?(empty|expired)|session.*(expired|invalid)|checkout.*(expired|not found)|your session has expired/.test(t)) return 'session';
  return null;
};

// Exchange a raw card for a Shopify card-vault session token. Returns
// { ok, sessionId } or { ok:false, error }. Does NOT charge the card.
// The raw card is sent only to Shopify's vault and is never logged.
export const tokenizeCard = async ({ pay, proxy = null, timeoutMs = 8000, session = null } = {}) => {
  if (!pay || !pay.card_number) return { ok: false, error: 'no card' };
  try {
    const s = session || new HttpSession({ proxy, timeoutMs });

    const rawYear = String(pay.expiration_year);
    const year = rawYear.length <= 2 ? Number(`20${rawYear.slice(-2)}`) : Number(rawYear);

    const body = JSON.stringify({
      credit_card: {
        number: String(pay.card_number).replace(/\s+/g, ''),
        name: pay.card_holder_name,
        month: Number(pay.expiration_month),
        year,
        verification_value: String(pay.cvv),
      },
    });

    const res = await s.post(CARD_VAULT_URL, {
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body,
      timeoutMs,
    });

    if (!res || !res.ok || res.status !== 200 || !res.body) {
      return { ok: false, error: res?.error || `status ${res?.status ?? 0}` };
    }
    let data;
    try { data = JSON.parse(res.body); } catch (_) { return { ok: false, error: 'bad vault json' }; }
    if (!data.id) return { ok: false, error: 'no session id' };
    return { ok: true, sessionId: data.id };
  } catch (err) {
    // Never throw out of a payment-flow call.
    return { ok: false, error: err.message };
  }
};

// Advance a Shopify checkout over plain HTTP, before any browser launches.
//
// dryRun=true (default): READ-ONLY. Resolves the variant and probes the cart
//   endpoint to confirm the request path reaches the store cleanly. Never adds to
//   a cart, never submits anything. Used as a pre-browser smoke test.
//
// dryRun=false: mutating path (Phase 3, not yet wired) — adds to cart and opens
//   the checkout, returning the checkout URL + warm cookies for handoff. Stops
//   BEFORE payment/submit.
export const prefillShopifyCheckout = async ({ task, proxy = null, cookieHeader = '', dryRun = true, timeoutMs = 8000 } = {}) => {
  const t0 = Date.now();
  try {
    let origin;
    try { origin = new URL(task.url).origin; } catch (_) { return { ok: false, stage: 'url', reason: 'bad url', durationMs: Date.now() - t0 }; }

    const session = new HttpSession({ proxy, cookieHeader, timeoutMs });

    const variantId = await resolveShopifyVariant({ task, proxy, cookieHeader });
    if (!variantId) {
      return { ok: false, stage: 'variant', reason: 'no available variant', durationMs: Date.now() - t0 };
    }

    if (dryRun) {
      // Read-only smoke test: /cart.js returns the current cart as JSON and never
      // mutates state. A 200 (or 404 on stores that disable it) means the
      // fingerprinted HTTP session reaches the store and isn't being challenged.
      const probe = await session.get(`${origin}/cart.js`, {
        headers: { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
      });
      const classified = probe && probe.body ? classifyShopifyResponse(probe.body) : null;
      const reachable = !!(probe && probe.ok && (probe.status === 200 || probe.status === 404));
      return {
        ok: reachable && !classified,
        dryRun: true,
        stage: 'dry_run',
        variantId,
        reachable,
        classified,
        status: probe?.status ?? 0,
        checkoutUrl: null,
        cookieHeader: session.cookieHeader,
        durationMs: Date.now() - t0,
      };
    }

    // --- Live request-first pre-checkout handoff ---
    const qty = task.quantity && task.quantity > 0 ? task.quantity : 1;
    const add = await session.post(`${origin}/cart/add.js`, {
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
        Origin: origin,
        Referer: task.url,
      },
      body: JSON.stringify({ id: Number(variantId), quantity: qty }),
    });
    if (!add || !add.ok || add.status !== 200) {
      const classified = add?.body ? classifyShopifyResponse(add.body) : null;
      return { ok: false, stage: 'cart_add', reason: classified || `status ${add?.status ?? 0}`, classified, variantId, durationMs: Date.now() - t0 };
    }

    const co = await session.get(`${origin}/checkout`, { headers: { Accept: 'text/html' } });
    const classified = co?.body ? classifyShopifyResponse(co.body) : null;
    if (classified) {
      return {
        ok: false,
        stage: 'checkout_open',
        reason: classified,
        classified,
        variantId,
        cartAdded: true,
        cookieHeader: session.cookieHeader,
        durationMs: Date.now() - t0,
      };
    }
    return {
      ok: true,
      stage: 'checkout_ready',
      variantId,
      cartAdded: true,
      checkoutUrl: co?.finalUrl || `${origin}/checkout`,
      cookieHeader: session.cookieHeader,
      durationMs: Date.now() - t0,
    };
  } catch (err) {
    // Never throw — the caller must always be free to fall back to the browser.
    return { ok: false, stage: 'error', reason: err.message, durationMs: Date.now() - t0 };
  }
};
