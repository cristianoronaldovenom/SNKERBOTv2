package main

// Performance + session-continuity layer for the sidecar.
//
// Two problems this exists to fix, both of which are measured costs:
//
//  1. handleRequest used to call tls_client.NewHttpClient() per request. That
//     threw the connection pool away every time, so EVERY request paid a fresh
//     TCP + TLS + HTTP/2 handshake (2 RTT before the first byte, more through
//     a residential proxy). Pooling by (profile, proxy) keeps the socket alive,
//     which is what makes a hot 350ms poll loop actually reach the origin in
//     about one RTT.
//
//  2. Nothing decompressed the response. Callers send "Accept-Encoding: gzip,
//     deflate, br" (Chrome does), so origins returned compressed bodies that
//     were then regex-matched as raw bytes - every HTML stock probe silently
//     returned false. decodeBody fixes that and also cuts proxy bandwidth.
//
// Pooling is also a fingerprint win: a real browser reuses one connection with
// ONE TLS ClientHello. Randomising the profile per poll meant the JA3 hash
// changed between two requests seconds apart on the same identity.
import (
	"bytes"
	"compress/flate"
	"compress/gzip"
	"compress/zlib"
	"context"
	"encoding/json"
	"io"
	"net"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"time"

	"github.com/andybalholm/brotli"
	fhttp "github.com/bogdanfinn/fhttp"
	tls_client "github.com/bogdanfinn/tls-client"
)

const (
	// Ceiling on pooled transports. One entry per (profile, proxy) pair.
	maxPooledClients = 64
	// Evict a client idle this long, closing its sockets. Shorter than any
	// origin idle timeout so we never hand out a dead socket.
	poolIdleTTL = 2 * time.Minute
	// Hard ceiling on a single decoded body (zip-bomb guard, ~8 MiB).
	maxDecodedBody = 8 << 20
	// SSRF-guard DNS cache: verdicts are stable for the life of a session.
	dnsCacheTTL = 60 * time.Second
	maxDNSCache = 512

	// Session jar budget. Each HttpSession generates a fresh session id, so
	// without a ceiling this map grows forever on a long-lived bot — a real
	// leak, not a theoretical one. Sessions older than cookieSessionTTL are
	// swept; if the ceiling is still hit, the oldest are dropped.
	cookieSessionTTL  = 10 * time.Minute
	maxCookieSessions = 256
)

type poolEntry struct {
	client   tls_client.HttpClient
	lastUsed time.Time
}

var (
	clientPool   = make(map[string]*poolEntry)
	clientPoolMu sync.Mutex
)

// A client is only interchangeable with another of the same profile and
// proxy: both are baked into the ClientHello / dialer at construction.
func poolKey(profile, proxy string) string {
	return strings.ToLower(profile) + "\x00" + proxy
}

// getClient returns a pooled client for this (profile, proxy), building one on
// first use. The second result reports whether the client was freshly built:
// a pooled one may have gone stale, which the caller retries around.
func getClient(profile, proxy string) (tls_client.HttpClient, bool, error) {
	key := poolKey(profile, proxy)

	clientPoolMu.Lock()
	if entry, ok := clientPool[key]; ok {
		entry.lastUsed = time.Now()
		clientPoolMu.Unlock()
		return entry.client, false, nil
	}
	// No entry: release the lock before building. NewHttpClient parses a
	// fingerprint and assembles a transport, which is slow enough to stall
	// every other task behind it if done under the global mutex — with many
	// concurrent tasks on many different proxies that stall was the
	// sidecar's effective concurrency ceiling. A double-check after
	// relocking keeps at most one client per key.
	clientPoolMu.Unlock()

	now := time.Now()

	// Pooled sockets through a residential gateway go stale fast: most
	// residential proxies drop idle keep-alives in 15-45s, well under what an
	// origin would hold one open. Reusing a dead socket would turn pooling
	// into a NEW failure mode, so proxied clients get a tighter idle ceiling
	// and the caller retries a stale reuse exactly once.
	idleTimeout := 90 * time.Second
	if proxy != "" {
		idleTimeout = 20 * time.Second
	}
	options := []tls_client.HttpClientOption{
		tls_client.WithTimeoutSeconds(45),
		tls_client.WithClientProfile(resolveProfile(profile)),
		tls_client.WithNotFollowRedirects(),
		tls_client.WithTransportOptions(&tls_client.TransportOptions{
			// Socket budget per client. The pool is keyed on (profile,
			// proxy), so every residential exit gets its own client — a
			// 64-wide idle ceiling per client multiplied out to thousands of
			// buffered sockets, which was the bulk of the sidecar's RAM.
			MaxIdleConns:        16,
			MaxIdleConnsPerHost: 8,
			IdleConnTimeout:     &idleTimeout,
			// We always send our own Accept-Encoding and decode in
			// decodeBody, so the transport must not try to do it too.
			DisableCompression: true,
		}),
	}
	if proxy != "" {
		options = append(options, tls_client.WithProxyUrl(proxy))
	}

	client, err := tls_client.NewHttpClient(tls_client.NewNoopLogger(), options...)
	if err != nil {
		return nil, true, err
	}

	clientPoolMu.Lock()
	defer clientPoolMu.Unlock()

	// Lost a race with a concurrent build for the same key: keep theirs.
	if entry, ok := clientPool[key]; ok {
		client.CloseIdleConnections()
		entry.lastUsed = time.Now()
		return entry.client, true, nil
	}

	for k, entry := range clientPool {
		if now.Sub(entry.lastUsed) > poolIdleTTL {
			entry.client.CloseIdleConnections()
			delete(clientPool, k)
		}
	}
	// Still full: drop the least recently used entry.
	if len(clientPool) >= maxPooledClients {
		oldestKey, oldest := "", time.Time{}
		for k, entry := range clientPool {
			if oldestKey == "" || entry.lastUsed.Before(oldest) {
				oldestKey, oldest = k, entry.lastUsed
			}
		}
		if oldestKey != "" {
			clientPool[oldestKey].client.CloseIdleConnections()
			delete(clientPool, oldestKey)
		}
	}

	clientPool[key] = &poolEntry{client: client, lastUsed: now}
	return client, true, nil
}

// evictClient drops a pooled client outright: it only happens after a
// transport-level failure on a reused socket, so rebuilding is cheaper than
// retrying the same dead connection again.
func evictClient(profile, proxy string) {
	key := poolKey(profile, proxy)
	clientPoolMu.Lock()
	defer clientPoolMu.Unlock()
	if entry, ok := clientPool[key]; ok {
		entry.client.CloseIdleConnections()
		delete(clientPool, key)
	}
}

// ── Session cookie store ────────────────────────────────────────────────────
// Browser-like cookie persistence, keyed by caller session id. A multi-step
// flow that reuses one session id keeps its cookies the way a browser tab
// would, instead of the caller having to thread a jar through every hop (and
// losing it the moment anything throws).
//
// session -> host -> cookie name -> value
var (
	// session -> host -> cookie name -> value
	cookieStore = make(map[string]map[string]map[string]string)
	// last time each session touched its jar; drives the RAM sweep.
	cookieLastUsed = make(map[string]time.Time)
	cookieStoreMu  sync.Mutex
	// The TTL sweep is O(sessions) and ran under the global jar lock on
	// EVERY request. That turned the jar lock into the sidecar's hottest
	// critical section exactly when many tasks were running. It is now
	// rate-limited to once per interval; the ceiling is still enforced
	// within at most one interval of lag, so the RAM bound holds.
	cookieSweepAt        time.Time
	cookieSweepInterval  = 15 * time.Second
)

// sweepCookieStoreLocked evicts dead sessions so the jar cannot grow without
// bound. Callers must hold cookieStoreMu.
func sweepCookieStoreLocked(now time.Time) {
	for s, last := range cookieLastUsed {
		if now.Sub(last) > cookieSessionTTL {
			delete(cookieStore, s)
			delete(cookieLastUsed, s)
		}
	}
	for len(cookieLastUsed) > maxCookieSessions {
		oldest, at := "", time.Time{}
		for s, last := range cookieLastUsed {
			if oldest == "" || last.Before(at) {
				oldest, at = s, last
			}
		}
		if oldest == "" {
			break
		}
		delete(cookieStore, oldest)
		delete(cookieLastUsed, oldest)
	}
}

// absorbCookies folds Set-Cookie values from resp into the session jar.
func absorbCookies(session, host string, resp *fhttp.Response) {
	if session == "" {
		return
	}
	cookieStoreMu.Lock()
	defer cookieStoreMu.Unlock()

	// Touch the session and sweep dead ones BEFORE the possible early return,
	// otherwise idle sessions would never age out of the map.
	now := time.Now()
	cookieLastUsed[session] = now
	if cookieSweepAt.IsZero() || now.Sub(cookieSweepAt) >= cookieSweepInterval {
		sweepCookieStoreLocked(now)
		cookieSweepAt = now
	}

	cookies := resp.Cookies()
	if len(cookies) == 0 {
		return
	}

	byHost, ok := cookieStore[session]
	if !ok {
		byHost = make(map[string]map[string]string)
		cookieStore[session] = byHost
	}
	jar, ok := byHost[host]
	if !ok {
		jar = make(map[string]string)
		byHost[host] = jar
	}
	for _, c := range cookies {
		// MaxAge < 0 is the deletion signal.
		if c.MaxAge < 0 {
			delete(jar, c.Name)
			continue
		}
		jar[c.Name] = c.Value
	}
}

// cookieHeaderFor renders the stored jar as a Cookie header value, or "".
func cookieHeaderFor(session, host string) string {
	if session == "" {
		return ""
	}
	cookieStoreMu.Lock()
	defer cookieStoreMu.Unlock()

	byHost, ok := cookieStore[session]
	if !ok {
		return ""
	}
	jar, ok := byHost[host]
	if !ok || len(jar) == 0 {
		return ""
	}
	parts := make([]string, 0, len(jar))
	for k, v := range jar {
		parts = append(parts, k+"="+v)
	}
	return strings.Join(parts, "; ")
}

// hostOf extracts the lowercase hostname from a URL string, "" on failure.
func hostOf(raw string) string {
	u, err := url.Parse(raw)
	if err != nil {
		return ""
	}
	return strings.ToLower(u.Hostname())
}

// ── Decompression ───────────────────────────────────────────────────────────
// decodeBody returns the decoded response body. It keys off the response's own
// Content-Encoding header, so it stays correct even if the transport ever
// starts decompressing on its own (net/http deletes that header when it does).
func decodeBody(resp *fhttp.Response) ([]byte, error) {
	raw, err := io.ReadAll(io.LimitReader(resp.Body, maxDecodedBody))
	if err != nil {
		return nil, err
	}
	enc := strings.ToLower(strings.TrimSpace(resp.Header.Get("Content-Encoding")))
	if enc == "" || enc == "identity" {
		return raw, nil
	}

	var reader io.Reader
	switch enc {
	case "gzip", "x-gzip":
		zr, zerr := gzip.NewReader(bytes.NewReader(raw))
		if zerr != nil {
			return raw, nil // malformed; hand back the raw bytes
		}
		defer zr.Close()
		reader = zr
	case "br":
		reader = brotli.NewReader(bytes.NewReader(raw))
	case "deflate":
		// Origins disagree: some send zlib-wrapped data, some raw flate.
		if zr, zerr := zlib.NewReader(bytes.NewReader(raw)); zerr == nil {
			defer zr.Close()
			reader = zr
		} else {
			reader = flate.NewReader(bytes.NewReader(raw))
		}
	default:
		return raw, nil
	}

	decoded, derr := io.ReadAll(io.LimitReader(reader, maxDecodedBody))
	if derr != nil {
		return raw, nil
	}
	resp.Header.Del("Content-Encoding")
	// Content-Length was the COMPRESSED length; after decoding it is wrong,
	// and a caller that trusts it will truncate a valid body.
	resp.Header.Del("Content-Length")
	return decoded, nil
}

// ── DNS cache for the SSRF guard ────────────────────────────────────────────
// validateTarget runs on the URL and again on every redirect hop, and each call
// did a blocking net.LookupIP. That is 10-40ms of dead time per request plus
// one more per hop, entirely avoidable: origins do not move mid-session.
type dnsEntry struct {
	private bool
	reason  string
	expires time.Time
}

var (
	dnsCache   = make(map[string]dnsEntry)
	dnsCacheMu sync.Mutex
)

// dnsVerdict reports a cached lookup result without touching the network.
func dnsVerdict(host string) (dnsEntry, bool) {
	dnsCacheMu.Lock()
	defer dnsCacheMu.Unlock()
	entry, ok := dnsCache[strings.ToLower(host)]
	if !ok || time.Now().After(entry.expires) {
		return dnsEntry{}, false
	}
	return entry, true
}

// lookupCached mirrors net.LookupIP but memoises the verdict briefly. The
// cached verdict itself is served by dnsVerdict; this just refreshes it.
func lookupCached(host string) ([]net.IP, error) {
	key := strings.ToLower(host)
	now := time.Now()

	addrs, err := net.LookupIP(host)
	if err != nil {
		return nil, err
	}
	private := false
	reason := ""
	for _, addr := range addrs {
		if ipIsPrivate(addr) {
			private, reason = true, addr.String()
			break
		}
	}

	dnsCacheMu.Lock()
	if len(dnsCache) >= maxDNSCache {
		for k, entry := range dnsCache {
			if now.After(entry.expires) {
				delete(dnsCache, k)
			}
		}
		// Every verdict is still fresh: hard-evict one so the map can never
		// grow past the ceiling under sustained multi-host load.
		if len(dnsCache) >= maxDNSCache {
			for k := range dnsCache {
				delete(dnsCache, k)
				break
			}
		}
	}
	dnsCache[key] = dnsEntry{private: private, reason: reason, expires: now.Add(dnsCacheTTL)}
	dnsCacheMu.Unlock()

	return addrs, nil
}

// ── Pre-warm ────────────────────────────────────────────────────────────────
// Node calls this shortly before hot-polling starts so the TCP/TLS/H2 setup is
// already paid for when the first real probe fires. Best effort: failures are
// swallowed because a cold first poll is still correct, just slower.
func handlePreconnect(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "POST required", http.StatusMethodNotAllowed)
		return
	}
	if !authOK(r) {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	var req RequestPayload
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.URL == "" {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}
	if err := validateTarget(req.URL); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	if req.Proxy != "" && !proxyAllowed {
		http.Error(w, "proxy disabled", http.StatusBadRequest)
		return
	}

	client, _, err := getClient(req.Profile, req.Proxy)
	if err != nil {
		http.Error(w, "client init: "+err.Error(), http.StatusInternalServerError)
		return
	}

	deadline := time.Duration(req.TimeoutMs) * time.Millisecond
	if deadline <= 0 {
		deadline = 5 * time.Second
	}
	ctx, cancel := context.WithTimeout(context.Background(), deadline)
	defer cancel()

	// HEAD is the cheapest request that still completes a handshake. Some
	// origins reject it, so fall back to a bounded GET; either way the pooled
	// socket is left behind for the real request to reuse.
	if hreq, herr := fhttp.NewRequestWithContext(ctx, http.MethodHead, req.URL, nil); herr == nil {
		hreq.Header.Set("Accept-Encoding", "gzip, deflate, br")
		if resp, derr := client.Do(hreq); derr == nil {
			io.Copy(io.Discard, io.LimitReader(resp.Body, 64<<10))
			resp.Body.Close()
			writeJSON(w, map[string]any{"ok": true, "profile": req.Profile})
			return
		}
	}

	ctx2, cancel2 := context.WithTimeout(context.Background(), deadline)
	defer cancel2()
	if greq, gerr := fhttp.NewRequestWithContext(ctx2, http.MethodGet, req.URL, nil); gerr == nil {
		if resp, derr := client.Do(greq); derr == nil {
			io.Copy(io.Discard, io.LimitReader(resp.Body, 64<<10))
			resp.Body.Close()
		}
	}
	writeJSON(w, map[string]any{"ok": true, "profile": req.Profile})
}

func writeJSON(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(v)
}
