// Queue fairness tests.
//
// The regression this guards: slot selection was pure priority. A continuous stream
// of hot restocks could starve background work forever, so a task could wait past
// the whole drop window and still never run. Ageing makes anything that has waited
// long enough outrank priority, which is the difference between a fair queue and a
// starved one.
import { beforeEach, describe, expect, test, jest } from '@jest/globals';

jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));

const q = await import('../../helpers/run-queue.js');

beforeEach(async () => {
  jest.useRealTimers();
  await q.__resetForTests?.();
});

// Drive the queue by force: cap 1, hold the slot, then queue waiters.
const setup = async () => {
  await q.setLimitsForTests?.({ maxConcurrent: 1, maxPerHost: 100 });
};

describe('priority ordering', () => {
  test('the highest priority waiter is served first while all are fresh', async () => {
    await setup();
    const release = await q.acquireSlot('holder', { priority: 0 });

    const order = [];
    const low = q.acquireSlot('low', { priority: 0 }).then(() => order.push('low'));
    const high = q.acquireSlot('high', { priority: 9 }).then(() => order.push('high'));
    // Let both reach the wait queue.
    await new Promise((r) => setTimeout(r, 20));
    expect(q.queueStatus().waiting).toBe(2);

    // One release must hand the single slot to the high-priority waiter.
    release();
    await new Promise((r) => setTimeout(r, 20));
    expect(order).toEqual(['high']);

    // `high` now holds the slot; releasing it frees `low`.
    expect(q.queueStatus().active).toBe(1);
  }, 10_000);
});

describe('bounded queue', () => {
  test('a full queue rejects instead of growing without bound', async () => {
    await setup();
    await q.acquireSlot('holder', { priority: 0 });

    const outcomes = [];
    for (let i = 0; i < q.WAITERS_MAX + 5; i++) {
      q.acquireSlot(`w${i}`).then(() => outcomes.push('ok'), (e) => outcomes.push(e.message));
    }
    await new Promise((r) => setTimeout(r, 60));

    const rejected = outcomes.filter((o) => String(o).includes('queue full'));
    expect(rejected.length).toBeGreaterThan(0);
    expect(q.queueStatus().waiting).toBeLessThanOrEqual(q.WAITERS_MAX);
  }, 10_000);
});
