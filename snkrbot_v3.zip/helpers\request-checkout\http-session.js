// Lightweight cookie-jar HTTP session for browserless ("request-mode") checkout.
//
// Wraps the Go TLS sidecar bridge (tls-client.js) so every call carries a real
// Chrome JA3/JA4 fingerprint, and accumulates Set-Cookie across requests the way
// a browser would — so a multi-step checkout flow (cart -> checkout -> rates ->
// pay) shares one consistent, warming session instead of N cold ones.
//
// SECURITY: this session is used for payment flows. It must NEVER log request or
// response bodies, because they can contain PAN / CVV / session tokens.
import { tlsRequest } from '../tls-client.js';
import { extractCookieHeader, mergeCookieHeaders } from '../cart-reserver.js';

const DEFAULT_UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

export class HttpSession {
  constructor({ proxy = null, cookieHeader = '', userAgent = DEFAULT_UA, timeoutMs = 8000 } = {}) {
    this.proxy = proxy;
    this.cookies = cookieHeader || '';
    this.ua = userAgent;
    this.timeoutMs = timeoutMs;
    // Stable id per session: activates sidecar-side cookie persistence and
    // pins the pooled TLS connection, so this flow looks like ONE browser tab.
    this.sessionId = `checkout-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  }

  get cookieHeader() {
    return this.cookies;
  }

  // Merge any Set-Cookie from a response into the jar (fresh values win).
  absorb(headers) {
    const fresh = extractCookieHeader(headers);
    if (fresh) this.cookies = mergeCookieHeaders(this.cookies, fresh);
    return this.cookies;
  }

  async request({ method = 'GET', url, headers = {}, body = null, noRedirect = false, timeoutMs } = {}) {
    let res;
    try {
      res = await tlsRequest({
        method,
        url,
        proxy: this.proxy,
        session: this.sessionId,
        timeoutMs: timeoutMs || this.timeoutMs,
        noRedirect,
        headers: {
          'User-Agent': this.ua,
          ...(this.cookies ? { Cookie: this.cookies } : {}),
          ...headers,
        },
        body,
      });
    } catch (err) {
      // tlsRequest is built to resolve with { ok:false }, but a thrown error
      // must never escape a payment-flow call — surface it as a soft failure.
      return { ok: false, status: 0, error: err.message };
    }
    if (res && res.ok && res.headers) this.absorb(res.headers);
    return res; // { ok, status, headers, body, finalUrl, fallback?, error? }
  }

  get(url, opts = {}) {
    return this.request({ ...opts, method: 'GET', url });
  }

  post(url, opts = {}) {
    return this.request({ ...opts, method: 'POST', url });
  }
}
