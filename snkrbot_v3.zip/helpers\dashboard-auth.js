import crypto from 'crypto';

const safeEqual = (a, b) => {
  const ab = Buffer.from(a);
  const bb = Buffer.from(b);
  if (ab.length !== bb.length) return false;
  return crypto.timingSafeEqual(ab, bb);
};

const dashboardAuth = (req, res, next) => {
  const password = process.env.DASHBOARD_PASSWORD;
  if (!password) return next();

  const header = req.headers.authorization || '';
  if (header.startsWith('Basic ')) {
    try {
      const decoded = Buffer.from(header.slice(6), 'base64').toString('utf8');
      const idx = decoded.indexOf(':');
      const supplied = idx >= 0 ? decoded.slice(idx + 1) : decoded;
      if (safeEqual(supplied, password)) return next();
    } catch (_) {}
  }

  res.set('WWW-Authenticate', 'Basic realm="SneakerBot Dashboard", charset="UTF-8"');
  return res.status(401).send('Authentication required');
};

export default dashboardAuth;
