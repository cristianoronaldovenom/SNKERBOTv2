import db from '../../db/index.js';
import logger from '../../helpers/logger.js';

export const startGroup = async (req, res, next) => {
  try {
    const { task_ids, tag, site_id } = req.body;

    let tasks;
    if (task_ids && Array.isArray(task_ids) && task_ids.length > 0) {
      tasks = await db('tasks').whereIn('id', task_ids).where({ is_deleted: false });
    } else if (tag) {
      tasks = await db('tasks').where({ tag, is_deleted: false }).whereNull('disabled_at');
    } else if (site_id) {
      tasks = await db('tasks').where({ site_id, is_deleted: false }).whereNull('disabled_at');
    } else {
      return res.status(400).json({
        success: false,
        message: 'Provide task_ids (array), tag (string), or site_id (number)'
      });
    }

    if (tasks.length === 0) {
      return res.status(404).json({ success: false, message: 'No matching tasks found' });
    }

    if (tasks.length > 50) {
      return res.status(400).json({
        success: false,
        message: `Too many tasks (${tasks.length}). Maximum 50 per group start.`
      });
    }

    const { default: startTask } = await import('../../scripts/start-task.js');

    const results = [];
    const startPromises = tasks.map((task) => {
      results.push({ taskId: task.id, status: 'started', url: task.url });
      return startTask(task);
    });

    Promise.allSettled(startPromises).then((settled) => {
      const succeeded = settled.filter((s) => s.status === 'fulfilled').length;
      const failed = settled.filter((s) => s.status === 'rejected').length;
      for (const s of settled) {
        if (s.status === 'rejected') {
          logger.error(`[StartGroup] Task failed: ${s.reason?.message || s.reason}`);
        }
      }
      logger.info(`[StartGroup] Batch complete: ${succeeded} succeeded, ${failed} failed out of ${tasks.length}`);
    });

    return res.json({
      success: true,
      message: `${tasks.length} tasks fired simultaneously`,
      data: { count: tasks.length, tasks: results }
    });
  } catch (err) {
    next(err);
  }
};
