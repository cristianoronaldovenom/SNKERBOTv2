// End-to-end latency harness.
//
// The review's consistent criticism across every round: micro-benchmarks and unit tests
// exist, but nothing measures the actual pipeline end-to-end. This closes that gap.
//
// It stands a real HTTP server in front of the real `checkStock()` path, so the whole
// chain runs — DNS-less socket, real TLS-less HTTP/1.1, real headers, real conditional
// requests, real parser, real coalescing, real byte accounting — instead of calling
// pure functions in isolation.
//
// It is honest about what it is: a local server, not a retailer. It measures PIPELINE
// cost with network held constant. Live retailer latency and success rate still need a
// drop, which is why the figures are reported with the server named.
//
// Run: node scripts/e2e-latency.mjs
import http from 'node:http';
import { performance } from 'node:perf_hooks';

const ITER = Math.max(5, Number(process.env.E2E_ITER || 20));
const COLD_ITER = Math.max(1, Number(process.env.E2E_COLD || 3));

// A Shopify-shaped product JSON document with a realistic variant grid.
const variantGrid = Array.from({ length: 24 }, (_, i) => ({
  id: 1000 + i, title: `Size ${6 + i}`, available: i % 4 === 0, price: '180.00', sku: `CF-${6 + i}`
}));
const API_BODY = JSON.stringify({ product: { id: 99, title: 'Crimson Foam', variants: variantGrid } });
const HTML_BODY = `<!doctype html><html><head><title>Crimson Foam</title></head><body>${
  variantGrid.map((v) => `<button data-size="${v.title}">${v.title}</button>`).join('')
}</body></html>`;

const stats = { api: [], html: [], warm: [], bytes: 0, requests: 0 };

const server = http.createServer((req, res) => {
  stats.requests += 1;
  // Mirror the retailer API contract the real checker expects.
  if (req.url.endsWith('.json')) {
    stats.bytes += Buffer.byteLength(API_BODY);
    res.writeHead(200, { 'content-type': 'application/json' });
    return res.end(API_BODY);
  }
  // Support Range the way a CDN does, and 304 on validators.
  if (req.headers['if-none-match'] === '"v1"') {
    res.writeHead(304, { etag: '"v1"' });
    return res.end();
  }
  if (req.headers.range) {
    const body = Buffer.from(HTML_BODY);
    const end = Math.min(body.length, Number((req.headers.range.match(/=(\d+)-(\d+)/) || [])[2]) + 1 || body.length);
    stats.bytes += end;
    res.writeHead(206, { 'content-type': 'text/html', etag: '"v1"', 'content-range': `bytes 0-${end - 1}/${body.length}` });
    return res.end(body.subarray(0, end));
  }
  stats.bytes += Buffer.byteLength(HTML_BODY);
  res.writeHead(200, { 'content-type': 'text/html', etag: '"v1"' });
  return res.end(HTML_BODY);
});

await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
const port = server.address().port;
const base = `http://127.0.0.1:${port}`;

const { checkStock } = await import('../helpers/stock-monitor.js');

const timed = async (bucket, url) => {
  const t0 = performance.now();
  await checkStock(url, {}).catch(() => null);
  bucket.push(performance.now() - t0);
};

const pct = (sorted, p) => sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * p))];

try {
  // Warm the module graph and JIT first, otherwise the very first samples measure
  // compilation rather than the pipeline.
  for (let i = 0; i < 3; i++) await checkStock(`${base}/warmup${i}.json`, {}).catch(() => null);
  for (let i = 0; i < 3; i++) await checkStock(`${base}/warmup${i}`, {}).catch(() => null);
  stats.api.length = 0;
  stats.html.length = 0;
  stats.bytes = 0;
  stats.requests = 0;

  // Cold: unique URLs so every call misses the coalesce cache and the validator store.
  for (let i = 0; i < COLD_ITER; i++) await timed(stats.api, `${base}/p${i}.json`);
  for (let i = 0; i < COLD_ITER; i++) await timed(stats.html, `${base}/p${i}`);

  // Warm: the SAME URL repeatedly. The coalesce cache is short, so space the calls past
  // it to exercise the conditional-request path (304) rather than measuring a Map hit.
  const gap = Number(process.env.E2E_GAP_MS || 900);
  for (let i = 0; i < ITER; i++) {
    await new Promise((r) => setTimeout(r, gap));
    await timed(stats.warm, `${base}/warm`);
  }

  console.log('metric                    p50      p95     mean   n');
  console.log('-'.repeat(58));
  const rows = [
    ['poll (json, cold cache)', stats.api],
    ['poll (html, cold cache)', stats.html],
    ['poll (html, 304 revalidate)', stats.warm]
  ];
  for (const [label, series] of rows) {
    const s = [...series].sort((a, b) => a - b);
    if (!s.length) continue;
    console.log(`${label.padEnd(24)}${pct(s, 0.5).toFixed(1).padStart(7)}${pct(s, 0.95).toFixed(1).padStart(9)}${(s.reduce((a, b) => a + b, 0) / s.length).toFixed(1).padStart(8)}${String(s.length).padStart(5)}`);
  }
  console.log(`\nserver=http/1.1 local  requests=${stats.requests}  bodyBytes=${stats.bytes}`);
  console.log('NOTE: local server, network held constant. Not a retailer measurement.');
} finally {
  server.close();
}
