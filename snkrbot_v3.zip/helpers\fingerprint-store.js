// Per-task persistent fingerprint store.
//
// Why this exists (the pro-bot tell we were leaking):
// Real returning users have a STABLE fingerprint. Every visit from the same
// laptop has the same UA, GPU, canvas hash, audio hash, hardware concurrency,
// timezone, and viewport. Bots that randomize all of these per launch trip
// the "new device every time" heuristic at Cloudflare/Imperva/PerimeterX.
//
// We now pin a single fingerprint to each task on first launch and reuse it
// forever. Combined with the persistent userDataDir from the previous batch,
// every subsequent attempt looks like the same returning shopper, not a new
// rented VM each time.
import path from 'node:path';
import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import logger from './logger.js';
import { validate, repair, deriveScreenMetrics, rendererFor, sizeBiasForHost } from './fingerprint-coherence.js';

// IMPORTANT: chromeVer / fullVer MUST match the actual Chromium binary.
// If we lie and claim Chrome 124 in Sec-Ch-Ua headers while the engine ships
// v131-only Web APIs, Imperva/Cloudflare detect the mismatch via JavaScript
// feature probing (e.g. CSS @starting-style, View Transitions API timing,
// navigator.gpu shape changes between versions). This was a major bot tell in v0.
//
// Overridable so the image can move to a newer Chromium without a code edit:
// set CHROME_FINGERPRINT_MAJOR / CHROME_FINGERPRINT_FULL alongside the rebuilt
// binary. Both default to the shipped Debian chromium (131.0.6778.204).
const CHROME_MAJOR = String(process.env.CHROME_FINGERPRINT_MAJOR || '131').replace(/[^\d]/g, '') || '131';
const CHROME_FULL = process.env.CHROME_FINGERPRINT_FULL || `${CHROME_MAJOR}.0.6778.204`;


// Every entry is coherent by construction: UA platform matches platform/arch,
// the renderer matches the GPU's real ANGLE backend, and the screen/viewport/
// dpr triad fits inside itself. The `gpu` values below are the real device
// names ANGLE reports on each platform.
const FINGERPRINT_TEMPLATES = [
  { ua: `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${CHROME_MAJOR}.0.0.0 Safari/537.36`,
    chromeVer: CHROME_MAJOR, fullVer: CHROME_FULL, platform: '"Windows"', platformVer: '"15.0.0"', arch: '"x86"', bitness: '"64"', model: '""', mobile: '?0', vendor: 'Google Inc.', cores: 8, mem: 8, gpu: 'Intel(R) UHD Graphics 620', webglVendor: 'Google Inc. (Intel)', webglRenderer: rendererFor('Windows', 'Intel(R) UHD Graphics 620'), tz: 'America/Toronto' },
  { ua: `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${CHROME_MAJOR}.0.0.0 Safari/537.36`,
    chromeVer: CHROME_MAJOR, fullVer: CHROME_FULL, platform: '"Windows"', platformVer: '"15.0.0"', arch: '"x86"', bitness: '"64"', model: '""', mobile: '?0', vendor: 'Google Inc.', cores: 12, mem: 16, gpu: 'NVIDIA GeForce GTX 1660', webglVendor: 'Google Inc. (NVIDIA)', webglRenderer: rendererFor('Windows', 'NVIDIA GeForce GTX 1660'), tz: 'America/New_York' },
  { ua: `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${CHROME_MAJOR}.0.0.0 Safari/537.36`,
    chromeVer: CHROME_MAJOR, fullVer: CHROME_FULL, platform: '"macOS"', platformVer: '"14.4.1"', arch: '"arm"', bitness: '"64"', model: '""', mobile: '?0', vendor: 'Google Inc.', cores: 8, mem: 8, gpu: 'Apple M1', webglVendor: 'Google Inc. (Apple)', webglRenderer: rendererFor('macOS', 'Apple M1'), tz: 'America/Vancouver' },
  { ua: `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${CHROME_MAJOR}.0.0.0 Safari/537.36`,
    chromeVer: CHROME_MAJOR, fullVer: CHROME_FULL, platform: '"Windows"', platformVer: '"15.0.0"', arch: '"x86"', bitness: '"64"', model: '""', mobile: '?0', vendor: 'Google Inc.', cores: 16, mem: 32, gpu: 'NVIDIA GeForce RTX 3060', webglVendor: 'Google Inc. (NVIDIA)', webglRenderer: rendererFor('Windows', 'NVIDIA GeForce RTX 3060'), tz: 'America/Toronto' },
  { ua: `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${CHROME_MAJOR}.0.0.0 Safari/537.36`,
    chromeVer: CHROME_MAJOR, fullVer: CHROME_FULL, platform: '"Windows"', platformVer: '"15.0.0"', arch: '"x86"', bitness: '"64"', model: '""', mobile: '?0', vendor: 'Google Inc.', cores: 6, mem: 8, gpu: 'AMD Radeon RX 580', webglVendor: 'Google Inc. (AMD)', webglRenderer: rendererFor('Windows', 'AMD Radeon RX 580'), tz: 'America/Montreal' },
  { ua: `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${CHROME_MAJOR}.0.0.0 Safari/537.36`,
    chromeVer: CHROME_MAJOR, fullVer: CHROME_FULL, platform: '"macOS"', platformVer: '"14.5.0"', arch: '"arm"', bitness: '"64"', model: '""', mobile: '?0', vendor: 'Google Inc.', cores: 10, mem: 16, gpu: 'Apple M2 Pro', webglVendor: 'Google Inc. (Apple)', webglRenderer: rendererFor('macOS', 'Apple M2 Pro'), tz: 'America/Toronto' }
];


// Fallback viewport used only by the legacy no-taskId path; real pinned profiles
// derive screen/viewport/dpr as one coherent triad (fingerprint-coherence.js).
const VIEWPORTS = [
  { width: 1280, height: 800 }, { width: 1366, height: 768 },
  { width: 1440, height: 900 }, { width: 1536, height: 864 },
  { width: 1600, height: 900 }, { width: 1920, height: 1080 }
];

const profileDir = (taskId) => path.resolve(process.cwd(), 'profiles', `task-${taskId}`);
const fpPath = (taskId) => path.join(profileDir(taskId), '_fingerprint.json');

const seedFromString = (s) => {
  const h = crypto.createHash('sha256').update(s).digest();
  return h.readUInt32BE(0);
};

// In-process single-flight: collapses concurrent calls for the same taskId
// onto one promise so we never double-generate-then-overwrite within this
// process. Cross-process safety is provided by the `wx` open-flag below.
const inflight = new Map();

const readIfPresent = async (taskId) => {
  try {
    const raw = await fs.readFile(fpPath(taskId), 'utf8');
    const fp = JSON.parse(raw);
    if (fp && fp.ua && fp.viewport && fp.canvasSeed != null) return fp;
  } catch (_) {}
  return null;
};

// Repair a pinned fingerprint that can no longer pass coherence validation.
// The seeds are preserved so the device still looks like the same machine; only
// contradictory fields are rewritten and persisted back to disk.
const healIfIncoherent = async (taskId, fp) => {
  const issues = validate(fp);
  if (issues.length === 0) return fp;

  const { profile: healed, changed } = repair(fp, { seed: fp.canvasSeed || 1 });
  if (changed.length === 0) return fp;

  const fatal = issues.filter((i) => i.severity === 'fatal').length;
  logger.warn(
    `[Fingerprint] Task ${taskId} pinned fingerprint was incoherent ` +
    `(${fatal} fatal / ${issues.length} total) — repaired ${changed.join(', ')}: ` +
    issues.map((i) => i.detail).join('; ')
  );
  await fs.writeFile(fpPath(taskId), JSON.stringify(healed, null, 2), 'utf8').catch((err) => {
    logger.warn(`[Fingerprint] Task ${taskId} could not persist repaired fingerprint: ${err.message}`);
  });
  return healed;
};

const generate = (taskId) => {
  const seed = `task-${taskId}-${Date.now()}-${Math.random()}`;
  const baseSeed = seedFromString(seed);
  const profile = FINGERPRINT_TEMPLATES[baseSeed % FINGERPRINT_TEMPLATES.length];
  // Screen, viewport and dpr are drawn together so the trio is coherent by
  // construction — the old code drew the viewport independently, which could
  // produce a window wider than its own monitor.
  //
  // The host's RAM biases which monitor is drawn: a small box composites a
  // smaller viewport, which is real memory saved and still a plausible laptop.
  // Read at generation time only, so an existing pinned profile is unaffected.
  const metrics = deriveScreenMetrics(
    String(profile.platform).replace(/"/g, ''),
    baseSeed,
    { sizeBias: sizeBiasForHost(Number(process.env.HOST_MEMORY_BYTES) || 0) }
  );
  return {
    ...profile,
    ...metrics,
    canvasSeed: seedFromString(seed + ':canvas') % 1_000_000_000,
    audioSeed: seedFromString(seed + ':audio') % 1_000_000_000,
    fontSeed: seedFromString(seed + ':font') % 1_000_000_000,
    pinnedAt: new Date().toISOString()
  };
};

// Returns a stable per-task fingerprint. On first call: picks one and persists
// atomically. On subsequent calls: returns the exact same one byte-for-byte.
// Safe under in-process and cross-process concurrency.
export const loadOrCreateFingerprint = async (taskId) => {
  if (inflight.has(taskId)) return inflight.get(taskId);
  const p = (async () => {
    await fs.mkdir(profileDir(taskId), { recursive: true });
    const existing = await readIfPresent(taskId);
    if (existing) {
      const coherent = await healIfIncoherent(taskId, existing);
      logger.info(`[Fingerprint] Task ${taskId} reusing pinned fingerprint: ${coherent.platform} Chrome/${coherent.chromeVer} ${coherent.gpu} (canvas seed ${coherent.canvasSeed})`);
      return coherent;
    }
    const fp = generate(taskId);
    // Truly atomic publish: write to a unique temp file first, then rename
    // into the final path with the `wx` exclusive-create-flavored fallback.
    // - rename() is atomic on POSIX and Windows for same-volume moves, so
    //   readers either see the OLD missing-file state or the NEW complete
    //   contents — never a partially-written file.
    // - link()+unlink() pattern would also work but rename is simpler.
    // - If another process beat us to it we read theirs with a tiny retry
    //   loop in case their rename hasn't landed yet.
    const tmpPath = `${fpPath(taskId)}.tmp.${process.pid}.${Date.now()}.${Math.random().toString(36).slice(2)}`;
    await fs.writeFile(tmpPath, JSON.stringify(fp, null, 2), 'utf8');
    try {
      await fs.link(tmpPath, fpPath(taskId)); // fails with EEXIST if another process won
      await fs.unlink(tmpPath).catch(() => {});
      logger.info(`[Fingerprint] Task ${taskId} pinned NEW fingerprint: ${fp.platform} Chrome/${fp.chromeVer} ${fp.gpu} ${fp.viewport.width}x${fp.viewport.height}`);
      return fp;
    } catch (err) {
      await fs.unlink(tmpPath).catch(() => {});
      if (err.code !== 'EEXIST') throw err;
      // Lost the race — read winner with bounded retry in case their write
      // is still flushing. Each attempt validates JSON via readIfPresent.
      for (let i = 0; i < 20; i++) {
        const winner = await readIfPresent(taskId);
        if (winner) {
          const coherent = await healIfIncoherent(taskId, winner);
          logger.info(`[Fingerprint] Task ${taskId} lost create race — using winner: ${coherent.platform} Chrome/${coherent.chromeVer}`);
          return coherent;
        }
        await new Promise((r) => setTimeout(r, 25));
      }
      throw new Error(`Fingerprint creation lost race for task ${taskId} but winner never produced valid file`);
    }
  })();
  inflight.set(taskId, p);
  try { return await p; }
  finally { inflight.delete(taskId); }
};

export const profileDirFor = profileDir;

// Legacy fallback used when a caller invokes launchBrowser() without a taskId.
// Keeps the bot working for ad-hoc scripts that don't go through the orchestrator.
// Built through the same coherence path so the fallback also carries a matching
// screen/dpr pair instead of a bare viewport.
const fallbackMetrics = deriveScreenMetrics('Windows', 3);
export const FALLBACK_PROFILE = { ...FINGERPRINT_TEMPLATES[3], ...fallbackMetrics };
export const FALLBACK_VIEWPORT = FALLBACK_PROFILE.viewport;

// Re-exported so callers can assert coherence after a launch without importing
// the coherence module directly.
export { validate as validateFingerprint } from './fingerprint-coherence.js';

// Read-only snapshot of the shipped profile table, for coherence tests.
export const FINGERPRINT_PROFILES = JSON.parse(JSON.stringify(FINGERPRINT_TEMPLATES));
