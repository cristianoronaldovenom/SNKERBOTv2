export const up = async (knex) => {
  const exists = await knex('settings').where({ key: 'max_armed_tasks' }).first();
  if (!exists) await knex('settings').insert({ key: 'max_armed_tasks', value: '30' });
};

export const down = async (knex) => {
  await knex('settings').where({ key: 'max_armed_tasks' }).del();
};
