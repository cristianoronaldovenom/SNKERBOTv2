// Residential provider dialects (Decodo / Smartproxy and compatible gateways).
//
// Why this exists: Topps and Pokemon Center block when the exit is in the wrong
// COUNTRY. A US-only shop served from a Brazilian residential exit scores as an
// anomaly that no amount of fingerprint patching cancels, and both are aggressive
// about it. Nothing here knew which provider was in use, so the username was a
// plain `{session}` template with no geo targeting — the gateway was free to hand
// out any exit on the planet.
//
// Providers express targeting in the PROXY USERNAME. Decodo/Smartproxy:
//
//     user-country-us-session-abc123
//     user-country-us-city-newyork-session-abc123
//
// so this composes that string from a per-site policy. Site policy beats
// everything because the constraint is the retailer's, not ours:
//
//   * Topps (7) and Pokemon Center (6) are US-only -> force country-us and prefer
//     a US timezone so TZ, locale and IP agree.
//   * everything else stays in the profile's own country, so a Canadian profile
//     does not suddenly look American.
//
// Opt-in by provider: an unknown provider returns the username untouched, which is
// today's behaviour, matching the degradation contract used elsewhere.
//
// Pure and I/O-free.

// `{user}` `{country}` `{city}` `{session}` are substituted. The separator is a
// hyphen, the documented convention and safe in a proxy username.
const DIALECTS = Object.freeze({
  decodo: Object.freeze({
    name: 'decodo',
    port: 7000,
    // Session must be LAST: the gateway stops parsing targeting after it.
    build: ({ user, country, city, session }) => [
      user,
      ...(country ? [`country-${country}`] : []),
      ...(city ? [`city-${city}`] : []),
      ...(session ? [`session-${session}`] : [])
    ].join('-')
  }),
  // Smartproxy is the same platform under the old brand.
  smartproxy: Object.freeze({ name: 'smartproxy', port: 7000, aliasOf: 'decodo' })
});

export const SUPPORTED = Object.freeze(['decodo', 'smartproxy']);

const resolveDialect = (name) => {
  const entry = DIALECTS[String(name || '').trim().toLowerCase()];
  if (!entry) return null;
  return entry.aliasOf ? DIALECTS[entry.aliasOf] : entry;
};

// Which provider is configured? Explicit env wins; otherwise sniff the host so an
// existing .decodo.com gateway works with no new configuration.
export const detectProvider = ({ env = process.env } = {}) => {
  const explicit = String(env.RESIDENTIAL_PROVIDER || '').trim().toLowerCase();
  if (explicit) return resolveDialect(explicit) ? explicit : null;

  const url = String(env.RESIDENTIAL_PROXY_URL || env.RESIDENTIAL_MONITOR_PROXY_URL || env.RESIDENTIAL_CHECKOUT_PROXY_URL || '');
  if (/decodo\./i.test(url)) return 'decodo';
  if (/smartproxy\./i.test(url)) return 'smartproxy';
  return null;
};

// Per-site geo policy. `country` is the market the RETAILER serves; `timezone` is
// an in-market clock so a pinned TZ cannot contradict a forced country.
const SITE_POLICY = Object.freeze({
  // Pokemon Center: US-only storefront.
  6: Object.freeze({ country: 'us', city: null, timezone: 'America/New_York', reason: 'us_only_retailer' }),
  // Topps: US-only, and DataDome sits in front so a domestic exit matters twice.
  7: Object.freeze({ country: 'us', city: null, timezone: 'America/New_York', reason: 'us_only_retailer' })
});

export const policyForSite = (siteId) => SITE_POLICY[Number(siteId)] || null;

// Country from a timezone, for sites with no policy. Mirrors the geo table's
// coverage and returns null outside it rather than guessing.
const COUNTRY_BY_TZ = Object.freeze({
  'America/Toronto': 'ca', 'America/Montreal': 'ca', 'America/Vancouver': 'ca',
  'America/New_York': 'us', 'America/Los_Angeles': 'us', 'America/Chicago': 'us', 'America/Denver': 'us',
  'Europe/London': 'gb', 'Europe/Berlin': 'de', 'Europe/Paris': 'fr'
});

export const countryForTimezone = (tz) => COUNTRY_BY_TZ[String(tz || '')] || null;

// Decide targeting for one request. All geo fields are null when the provider is
// unknown or there is nothing to say, so a caller can skip the work.
export const targetingFor = ({ siteId = null, profileTimezone = null, env = process.env } = {}) => {
  const provider = detectProvider({ env });
  if (!provider) return { provider: null, country: null, city: null, policy: null, reason: 'no_provider' };

  const policy = policyForSite(siteId);
  if (policy) {
    return { provider, country: policy.country, city: policy.city, policy, reason: policy.reason };
  }

  const derived = countryForTimezone(profileTimezone);
  if (derived) return { provider, country: derived, city: null, policy: null, reason: 'profile_country' };

  // Unmapped region: leave country off so the gateway decides, rather than force
  // a guess that could contradict the fingerprint.
  return { provider, country: null, city: null, policy: null, reason: 'unmapped' };
};

// Compose the final username. Returns a COPY — never mutates the proxy, which may
// be a cached pool entry or a DB row.
export const applyTargeting = (proxy, targeting = {}) => {
  if (!proxy?.username) return { proxy, applied: false, reason: 'no_username' };
  const dialect = resolveDialect(targeting.provider);
  if (!dialect) return { proxy, applied: false, reason: 'unsupported_provider' };
  if (!targeting.country && !targeting.city && !targeting.session) {
    return { proxy, applied: false, reason: 'nothing_to_apply' };
  }

  // Strip an existing targeting suffix first so re-applying cannot stack
  // directives into `country-us-country-ca`.
  const base = String(proxy.username).split('-country-')[0].split('-session-')[0].split('-city-')[0];

  const username = dialect.build({
    user: base,
    country: targeting.country,
    city: targeting.city,
    session: targeting.session
  });
  if (username === proxy.username) return { proxy, applied: false, reason: 'already_targeted' };
  return { proxy: { ...proxy, username }, applied: true, reason: 'targeted' };
};

export const providerConfig = ({ env = process.env } = {}) => ({
  detected: detectProvider({ env }),
  supported: SUPPORTED,
  policies: Object.keys(SITE_POLICY).map((id) => ({ siteId: Number(id), ...SITE_POLICY[id] }))
});
