// User-Agent Client Hint generation, in Chrome's own GREASE shape.
//
// Why this exists: we spoof `navigator.userAgentData.brands` in JS and send
// `Sec-Ch-Ua` on plain HTTP requests from four separate modules. Those two views
// are cross-checked by Imperva, DataDome, PerimeterX and FingerprintJS Pro — if
// the JS says one thing and the header says another, the session is flagged
// before any page script runs.
//
// The previous hardcoded strings were Chrome-99 vintage:
//   "Chromium";v="131", "Google Chrome";v="131", "Not-A.Brand";v="99"
// Real Chrome 131 emits a *rotating* GREASE brand with a separator drawn from
// ` ` `(` `:` `-` `.` `/` `)` `;` `=` `?` `_`, a version drawn from 8/99/24, and
// orders the three brands by `major % 6` — so the GREASE brand is first, second
// or third depending on the version. `Not-A.Brand`;v=99 is the OLD algorithm,
// which Chrome only still uses behind a Finch opt-out.
//
// Reference (M131): third_party/blink/common/user_agent/user_agent_metadata.cc,
// GetGreasedUserAgentBrandVersion() + GenerateBrandVersionList(). With branding
// the list is [grease, "Chromium", "Google Chrome"] permuted by `major % 6`.
//
// This module is pure and dependency-free so it is unit-testable.

// Order of separators is significant — index is `major % length`.
const GREASE_CHARS = Object.freeze([' ', '(', ':', '-', '.', '/', ')', ';', '=', '?', '_']);
const GREASED_VERSIONS = Object.freeze(['8', '99', '24']);
// Brand slot permutations, index = `major % 6` (the first 6 of Chrome's 3! list).
const PERMUTATIONS = Object.freeze([
  [0, 1, 2], [0, 2, 1], [1, 0, 2], [1, 2, 0], [2, 0, 1], [2, 1, 0]
]);

export const CHROMIUM_BRAND = 'Chromium';
export const CHROME_BRAND = 'Google Chrome';

const majorOf = (major) => {
  const n = parseInt(String(major ?? '').replace(/[^\d]/g, ''), 10);
  return Number.isFinite(n) && n > 0 ? n : 131;
};

// Chrome's GREASE brand for a given major version, e.g. 'Not_A Brand' / v='24'.
export const greaseBrand = (major) => {
  const m = majorOf(major);
  const brand =
    'Not' +
    GREASE_CHARS[m % GREASE_CHARS.length] +
    'A' +
    GREASE_CHARS[(m + 1) % GREASE_CHARS.length] +
    'Brand';
  return { brand, version: GREASED_VERSIONS[m % GREASED_VERSIONS.length] };
};

// navigator.userAgentData.brands equivalent, in Chrome's exact order.
// `version` is the major version for the normal list and the full version for
// the full-version list, matching how Chrome populates both.
export const brandVersionList = (major, { fullVersion = null } = {}) => {
  const m = majorOf(major);
  const list = new Array(3);
  const grease = greaseBrand(m);
  list[PERMUTATIONS[m % PERMUTATIONS.length][0]] = grease;
  list[PERMUTATIONS[m % PERMUTATIONS.length][1]] = { brand: CHROMIUM_BRAND, version: String(m) };
  list[PERMUTATIONS[m % PERMUTATIONS.length][2]] = { brand: CHROME_BRAND, version: String(m) };
  if (!fullVersion) return list;
  // Full-version list: real brands carry the full version string, the GREASE
  // brand keeps its own long form.
  const full = String(fullVersion);
  return list.map((b) =>
    b.brand === CHROMIUM_BRAND || b.brand === CHROME_BRAND
      ? { brand: b.brand, version: full }
      : { brand: b.brand, version: `${b.version}.0.0.0` }
  );
};

// `Sec-Ch-Ua` header value (low-entropy). Structured-header quoting rules mean
// the GREASE brand (which can contain `(`, `:`, `;` …) must be a quoted string.
export const secChUa = (major) =>
  brandVersionList(major)
    .map((b) => `"${b.brand}";v="${b.version}"`)
    .join(', ');

// `Sec-Ch-Ua-Full-Version-List` header value.
export const secChUaFullVersionList = (major, fullVersion) =>
  brandVersionList(major, { fullVersion: fullVersion || `${majorOf(major)}.0.0.0` })
    .map((b) => `"${b.brand}";v="${b.version}"`)
    .join(', ');

// The subset of high-entropy hints worth sending from background HTTP clients.
export const clientHintHeaders = ({ major, fullVersion, platform = '"Windows"', mobile = '?0' }) => ({
  'Sec-Ch-Ua': secChUa(major),
  'Sec-Ch-Ua-Mobile': mobile,
  'Sec-Ch-Ua-Platform': platform,
  'Sec-Ch-Ua-Full-Version-List': secChUaFullVersionList(major, fullVersion),
  'Sec-Ch-Ua-Arch': '"x86"',
  'Sec-Ch-Ua-Bitness': '"64"',
  'Sec-Ch-Ua-Model': '""',
  'Sec-Ch-Ua-Wow64': '?0'
});

export const __internals = { GREASE_CHARS, GREASED_VERSIONS, PERMUTATIONS, majorOf };
