// The 24/7 reconciler must NOT resurrect a payment-locked task. It re-arms
// anything whose last_status it doesn't recognise, so without 'payment_locked'
// in the skip set a task with a dead card is silently retried all night: each
// cycle burns a proxy session and captcha credits to reach the same decline.
import { jest } from '@jest/globals';
import knex from 'knex';
import { createTracker, MockClient } from 'knex-mock-client';

const db = knex({ client: MockClient });
jest.unstable_mockModule('../../db/index.js', () => ({ default: db }));
jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));

const task = (id, last_status) => ({
  id,
  last_status,
  url: `https://www.pokemoncenter.com/product/${id}`,
  site_id: 6,
  is_deleted: false,
  monitor_24_7: true
});

let tracker;
let monitor;
let probeIds;

beforeAll(async () => {
  // Every module the sweeps touch pulls in the DB or the network; stub them so
  // only the eligibility filter is under test.
  jest.unstable_mockModule('../../helpers/stock-monitor.js', () => ({
    checkStock: async () => ({}), getAdaptiveDelay: () => 1000,
    getReliabilitySnapshot: () => ({}), clearEscalation: () => {}
  }));
  jest.unstable_mockModule('../../helpers/monitor-store.js', () => ({
    setMonitor: () => {}, clearMonitor: () => {}, isMonitoring: () => false,
    getAllMonitors: () => ({}), getActiveMonitorCount: () => 0, getActiveMonitorHostCount: () => 0,
    addClient: () => {}, removeClient: () => {}, broadcastToClients: () => {},
    broadcastMonitorTick: () => {}, getMonitor: () => null, addGlobalClient: () => {},
    removeGlobalClient: () => {}, broadcastAllClients: () => {}
  }));
  jest.unstable_mockModule('../../scripts/start-task.js', () => ({ default: async () => ({}) }));
  jest.unstable_mockModule('../../helpers/cart-reserver.js', () => ({ reserveCart: async () => null }));
  jest.unstable_mockModule('../../helpers/request-checkout/index.js', () => ({ prepareRequestCheckout: async () => null }));
  jest.unstable_mockModule('../../helpers/prewarm-engine.js', () => ({
    prewarmEnabled: () => false, park: async () => null, disposePrewarm: async () => {},
    sweepParkedByRss: async () => []
  }));
  jest.unstable_mockModule('../../helpers/business-hours.js', () => ({
    PC_SITE_ID: 6, isWithinBusinessHours: () => true, businessHoursEnabled: async () => true
  }));
  // resolveTaskProxy runs early inside the start path, so recording the task id
  // here tells us exactly which rows got past the status filter.
  jest.unstable_mockModule('../../helpers/task-proxies.js', () => ({
    resolveTaskProxy: async (task) => {
      probeIds.push(task.id);
      return { proxy: null, source: 'none' };
    },
    sanitizeProxyMeta: (p) => p, getResidentialProxy: async () => null
  }));
  jest.unstable_mockModule('../../helpers/residential-budget.js', () => ({
    canStartResidentialSession: async () => true,
    remainingResidentialRatio: () => 0.8
  }));
  jest.unstable_mockModule('../../helpers/memory-guard.js', () => ({
    getMemorySnapshot: async () => ({ limitBytes: 0, currentBytes: 0, availableBytes: 0 })
  }));
  jest.unstable_mockModule('../../helpers/run-queue.js', () => ({
    getArmedTaskCapacity: async () => 1000, getArmedTaskHostCapacity: async () => 100
  }));

  monitor = await import('../../api/Tasks/monitor.js');
  tracker = createTracker(db);
});

beforeEach(() => { probeIds = []; });
afterEach(() => tracker.reset());
afterAll(() => db.destroy());

it('the 24/7 sweep skips a payment-locked task but still arms a fresh one', async () => {
  // Both rows are enabled and undisabled, so only the status can separate them.
  tracker.on.select('tasks').response([task(1, 'payment_locked'), task(2, 'armed')]);

  await monitor.runPersistentMonitorSweep();

  // resolveTaskProxy runs twice per task (monitor + checkout proxy) before the
  // status filter could matter, so dedupe to one entry per attempted row.
  expect([...new Set(probeIds)]).toEqual([2]);
});

it('the PC business-hours sweep also skips a payment-locked task', async () => {
  tracker.on.select('tasks').response([task(3, 'payment_locked'), task(4, 'armed')]);

  await monitor.runPcBusinessHoursSweep();

  expect([...new Set(probeIds)]).toEqual([4]);
});

it('a locked task is not resurrected even alongside other terminal statuses', async () => {
  // Guards the whole skip set, not just the lock: 'success' and 'needs_human'
  // must keep working, or the sweep re-buys an already-won drop.
  tracker.on.select('tasks').response([
    task(5, 'payment_locked'), task(6, 'success'), task(7, 'needs_human'), task(8, 'household_cap'), task(9, 'armed')
  ]);

  await monitor.runPersistentMonitorSweep();

  expect([...new Set(probeIds)]).toEqual([9]);
});

it('a payment_locked task is never in both no-restart sets by accident', async () => {
  // Regression guard: the two filters are separate code paths (24/7 vs the PC
  // window scheduler) and it is easy to add a status to one and forget the
  // other, which leaves a hole in whichever scheduler is disabled that day.
  const { readFile } = await import('node:fs/promises');
  const src = await readFile(new URL('../../api/Tasks/monitor.js', import.meta.url), 'utf8');
  const sets = src.match(/NO_RESTART_STATUSES = new Set\(\[[^\]]*\]\)/g) || [];
  expect(sets).toHaveLength(2);
  for (const set of sets) expect(set).toContain("'payment_locked'");
});
