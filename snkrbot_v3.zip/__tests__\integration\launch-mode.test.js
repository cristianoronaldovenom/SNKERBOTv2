// Launch-mode policy tests.
//
// The regression this guards: `headless: true` was hardcoded with no override, so
// every browser ran windowless no matter what the host could carry. That is the
// root cause the ~31 stealth patches spend their time papering over. Now the mode
// is a policy with an explicit override, a display probe and a memory gate — and
// crucially it must still land on headless rather than throwing when no display
// or not enough RAM exists.
import { describe, expect, test } from '@jest/globals';
import {
  MODE, displayArgs, hasDisplay, headfulReason, resolveHeadless, shouldBootstrapDisplay
} from '../../helpers/launch-mode.js';

const GB = 1024 ** 3;
const roomy = 8 * GB;

describe('display detection', () => {
  test('windows and macOS always have a desktop', () => {
    expect(hasDisplay({ platform: 'win32', env: {} })).toBe(true);
    expect(hasDisplay({ platform: 'darwin', env: {} })).toBe(true);
  });

  test('linux needs DISPLAY', () => {
    expect(hasDisplay({ platform: 'linux', env: {} })).toBe(false);
    expect(hasDisplay({ platform: 'linux', env: { DISPLAY: ':99' } })).toBe(true);
    expect(hasDisplay({ platform: 'linux', env: { DISPLAY: '  ' } })).toBe(false);
  });
});

describe('mode resolution', () => {
  test('auto goes headful when a display and RAM are available', () => {
    expect(headfulReason({ platform: 'win32', env: {}, totalMemoryBytes: roomy }))
      .toEqual({ mode: MODE.HEADFUL, reason: 'display_available' });
  });

  test('auto stays headless with no display', () => {
    expect(headfulReason({ platform: 'linux', env: {}, totalMemoryBytes: roomy }).mode).toBe(MODE.HEADLESS);
    expect(headfulReason({ platform: 'linux', env: {}, totalMemoryBytes: roomy }).reason).toBe('no_display');
  });

  test('auto stays headless on a starved host even with a display', () => {
    const out = headfulReason({ platform: 'win32', env: {}, totalMemoryBytes: 512 * 1024 * 1024 });
    expect(out.mode).toBe(MODE.HEADLESS);
    expect(out.reason).toBe('low_memory');
  });

  test('an unknown memory size does not block headful', () => {
    expect(headfulReason({ platform: 'win32', env: {}, totalMemoryBytes: 0 }).mode).toBe(MODE.HEADFUL);
  });

  // BROWSER_HEADLESS names the variable, so 0/false means "not headless" = headful.
  // Note `(v)` not `([v])`: jest passes a single-element row as a bare argument,
  // so destructuring would take the string's first character.
  test.each(['1', 'true', 'yes', 'headless'])('BROWSER_HEADLESS=%s forces headless', (v) => {
    expect(headfulReason({ platform: 'win32', env: { BROWSER_HEADLESS: v }, totalMemoryBytes: roomy }).mode)
      .toBe(MODE.HEADLESS);
  });

  test.each(['0', 'false', 'off', 'headful'])('BROWSER_HEADLESS=%s forces headful', (v) => {
    expect(headfulReason({ platform: 'win32', env: { BROWSER_HEADLESS: v }, totalMemoryBytes: roomy }).mode)
      .toBe(MODE.HEADFUL);
  });

  test('forced headful with no display degrades to headless instead of failing', () => {
    const out = headfulReason({ platform: 'linux', env: { BROWSER_HEADLESS: '0' }, totalMemoryBytes: roomy });
    expect(out.mode).toBe(MODE.HEADLESS);
    expect(out.reason).toBe('forced_headful_but_no_display');
  });

  test('forced headful ignores the memory gate', () => {
    const out = headfulReason({ platform: 'win32', env: { BROWSER_HEADLESS: '1'.replace('1', '0') }, totalMemoryBytes: 1 });
    expect(out.mode).toBe(MODE.HEADFUL);
  });

  test('resolveHeadless is the boolean form', () => {
    expect(resolveHeadless({ platform: 'win32', env: {}, totalMemoryBytes: roomy })).toBe(false);
    expect(resolveHeadless({ platform: 'linux', env: {}, totalMemoryBytes: roomy })).toBe(true);
  });
});

describe('display bootstrapping gate', () => {
  test('linux with no DISPLAY and RAM wants a display started', () => {
    expect(shouldBootstrapDisplay({ platform: 'linux', env: {}, totalMemoryBytes: roomy })).toBe(true);
  });

  test('an existing DISPLAY needs no bootstrap', () => {
    expect(shouldBootstrapDisplay({ platform: 'linux', env: { DISPLAY: ':0' }, totalMemoryBytes: roomy })).toBe(false);
  });

  test('non-linux never bootstraps', () => {
    expect(shouldBootstrapDisplay({ platform: 'win32', env: {}, totalMemoryBytes: roomy })).toBe(false);
  });

  test('forced headless skips the bootstrap', () => {
    expect(shouldBootstrapDisplay({ platform: 'linux', env: { BROWSER_HEADLESS: '1' }, totalMemoryBytes: roomy })).toBe(false);
  });

  test('a starved host skips it rather than spending RAM on Xvfb', () => {
    expect(shouldBootstrapDisplay({ platform: 'linux', env: {}, totalMemoryBytes: 400 * 1024 * 1024 })).toBe(false);
  });
});

describe('display args', () => {
  test('headless disables the GPU, headful enables the compositor', () => {
    expect(displayArgs(true)).toEqual(['--disable-gpu']);
    expect(displayArgs(false)).toContain('--use-angle=swiftshader');
    expect(displayArgs(false)).not.toContain('--disable-gpu');
  });

  test('headful re-enables occlusion tracking that headless drops', () => {
    expect(displayArgs(false).join(' ')).toContain('CalculateNativeWinOcclusion');
  });
});
