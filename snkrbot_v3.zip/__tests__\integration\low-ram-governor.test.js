// Low-RAM governor regression.
//
// On a 1 GB host the old governor computed `(1024 - 1536) / 500` — negative — and
// then applied a hard `Math.max(2, ...)` floor, so it still claimed TWO Chromium
// instances would fit. One GB cannot hold two headless browsers, so the second
// launch OOM-killed the first mid-checkout. The governor must also stay casual on
// a big host, so both directions are asserted.
import { describe, expect, test, jest, beforeEach, afterEach } from '@jest/globals';
import os from 'node:os';

// Every governor assertion must be independent of the ambient environment. The suite
// previously inherited CPU_PERFORMANCE_MODE and CHECKOUT_* from whatever shell ran it,
// so it passed alone and failed in a full run — an environment-sensitive test setup
// rather than a code fault. Pin the mode per test and restore it after.
const MODE_KEYS = ['CPU_PERFORMANCE_MODE', 'CHECKOUT_CONCURRENCY_CAP', 'CHECKOUT_MEMORY_BUDGET_MB', 'CHECKOUT_RESERVED_MEMORY_MB'];
let savedEnv = {};

const setMode = (mode) => {
  if (mode === null) delete process.env.CPU_PERFORMANCE_MODE;
  else process.env.CPU_PERFORMANCE_MODE = mode;
};

const loadGovernor = async (totalBytes) => {
  jest.resetModules();
  jest.spyOn(os, 'totalmem').mockReturnValue(totalBytes);
  // LOGICAL_CPUS is captured at module load from os.availableParallelism()/os.cpus().
  // Mocking memory alone left the cpuCap term dependent on the machine running the
  // tests, so the same assertion passed locally and failed in a small container.
  // Pin a large core count so RAM is the only binding constraint here.
  jest.spyOn(os, 'availableParallelism').mockReturnValue(16);
  jest.spyOn(os, 'cpus').mockReturnValue(new Array(16).fill({ model: 'test', speed: 1, times: {} }));
  return import('../../helpers/cpu-performance.js');
};

beforeEach(() => {
  savedEnv = Object.fromEntries(MODE_KEYS.map((k) => [k, process.env[k]]));
  for (const k of MODE_KEYS) delete process.env[k];
});

afterEach(() => {
  jest.restoreAllMocks();
  for (const k of MODE_KEYS) {
    if (savedEnv[k] === undefined) delete process.env[k];
    else process.env[k] = savedEnv[k];
  }
});

describe('checkout concurrency governor', () => {
  test('a 1 GB host gets exactly one checkout browser', async () => {
    const { recommendedCheckoutConcurrency } = await loadGovernor(1 * 1024 ** 3);
    expect(recommendedCheckoutConcurrency({ configured: 24 })).toBe(1);
  });

  test('a 2 GB host does not exceed what its RAM can hold', async () => {
    const { recommendedCheckoutConcurrency } = await loadGovernor(2 * 1024 ** 3);
    // Must be a real number, not the old forced floor of 2.
    const n = recommendedCheckoutConcurrency({ configured: 24 });
    expect(n).toBeGreaterThanOrEqual(1);
    expect(n).toBeLessThanOrEqual(3);
  });

  test('a 16 GB host scales past the small-host tiers', async () => {
    const { recommendedCheckoutConcurrency } = await loadGovernor(16 * 1024 ** 3);
    expect(recommendedCheckoutConcurrency({ configured: 24 })).toBeGreaterThan(1);
  });

  test('a large host still respects an operator cap below the computed value', async () => {
    const { recommendedCheckoutConcurrency } = await loadGovernor(64 * 1024 ** 3);
    expect(recommendedCheckoutConcurrency({ configured: 3 })).toBeLessThanOrEqual(3);
  });

  test('balanced mode stays conservative on a big host', async () => {
    setMode('balanced');
    const { recommendedCheckoutConcurrency } = await loadGovernor(64 * 1024 ** 3);
    expect(recommendedCheckoutConcurrency({ configured: 24 })).toBeLessThanOrEqual(8);
    // ...and actually reaches the ceiling rather than being needlessly timid.
    expect(recommendedCheckoutConcurrency({ configured: 24 })).toBe(8);
  });

  test('balanced mode is a CEILING, not a bypass of the RAM calculation', async () => {
    // The regression: balanced used to return min(8, configured) before any RAM
    // arithmetic, so a 1 GB host was handed 8 browsers while ramCap was 1.
    setMode('balanced');
    const one = await loadGovernor(1 * 1024 ** 3);
    expect(one.recommendedCheckoutConcurrency({ configured: 24 })).toBe(1);

    const two = await loadGovernor(2 * 1024 ** 3);
    expect(two.recommendedCheckoutConcurrency({ configured: 24 })).toBeLessThanOrEqual(2);
  });

  test('the result is always at least one so a run is never impossible', async () => {
    const { recommendedCheckoutConcurrency } = await loadGovernor(512 * 1024 ** 2);
    expect(recommendedCheckoutConcurrency({ configured: 24 })).toBeGreaterThanOrEqual(1);
  });

  test('mode is irrelevant to the RAM ceiling on a starved host', async () => {
    const { recommendedCheckoutConcurrency } = await loadGovernor(1 * 1024 ** 3);
    const results = [];
    for (const mode of ['balanced', 'high', 'max', null]) {
      setMode(mode);
      results.push(recommendedCheckoutConcurrency({ configured: 24 }));
    }
    // Whatever the mode, one browser is all a 1 GB host can hold.
    expect(new Set(results)).toEqual(new Set([1]));
  });
});
