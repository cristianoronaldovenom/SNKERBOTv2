import {
  listPendingChallenges,
  submitHarvesterSolution,
  harvesterStats
} from '../../helpers/captcha-harvester.js';

export const listPending = (_req, res) => {
  res.json({ success: true, data: listPendingChallenges(), stats: harvesterStats() });
};

export const submitSolution = (req, res) => {
  const { id } = req.params;
  const { token } = req.body || {};
  const result = submitHarvesterSolution({ id, token });
  if (!result.ok) return res.status(400).json({ success: false, error: result.error });
  res.json({ success: true });
};

export const stats = (_req, res) => {
  res.json({ success: true, data: harvesterStats() });
};
