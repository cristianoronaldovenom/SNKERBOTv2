// Kasada adapter tests.
//
// The regression this guards: stock-monitor classified 'kasada' and then did
// nothing — the vendor fell through to the generic bot-block branch. These tests
// pin the three layers (replay / fork / escalate), that a token is scoped per
// host+exit, and that a stale payload is retired rather than replayed.
import { afterEach, beforeEach, describe, expect, jest, test } from '@jest/globals';

const mockRequest = jest.fn();
jest.unstable_mockModule('../../helpers/tls-client.js', () => ({ tlsRequest: mockRequest }));

let k;
beforeEach(async () => {
  mockRequest.mockReset();
  k = await import('../../helpers/kasada.js');
  k.__resetKasada();
});

const proxy = { host: 'gate.net', port: 8000 };
const pageUrl = 'https://shop.example.com/p/1';

describe('detection', () => {
  test('kpsdk headers are a challenge on any status', () => {
    expect(k.isKasadaChallenge({ status: 200, headers: { 'x-kpsdk-ct': 'abc' } })).toBe(true);
  });

  test('a 429 carrying a payload is a challenge', () => {
    expect(k.isKasadaChallenge({ status: 429, body: '{"ct":"abcdefghijklmnop"}' })).toBe(true);
  });

  test('a plain 200 that merely mentions kpsdk is not', () => {
    expect(k.isKasadaChallenge({ status: 200, body: 'built with kpsdk' })).toBe(false);
  });

  test('a 403 with nothing identifying is not', () => {
    expect(k.isKasadaChallenge({ status: 403, body: '<h1>Denied</h1>' })).toBe(false);
  });
});

describe('payload extraction', () => {
  test('reads the JSON envelope', () => {
    const out = k.extractKasadaPayload({ body: '{"ct":"AAAAAAAAAAAAAAAAAAAA","cd":16999999999,"v":"2"}' });
    expect(out).toEqual({ ct: 'AAAAAAAAAAAAAAAAAAAA', cd: '16999999999', v: '2' });
  });

  test('reads escaped inline JSON', () => {
    const out = k.extractKasadaPayload({ body: `JSON.parse('{"ct":"BBBBBBBBBBBBBBBBBBBB"}')` });
    expect(out.ct).toBe('BBBBBBBBBBBBBBBBBBBB');
  });

  test('prefers headers when an echo carries them', () => {
    const out = k.extractKasadaPayload({ headers: { 'x-kpsdk-ct': 'CCC' }, body: '{"ct":"DDDDDDDDDDDDDDDDDD"}' });
    expect(out.ct).toBe('CCC');
  });

  test('a header value given as an array still resolves', () => {
    expect(k.extractKasadaPayload({ headers: { 'x-kpsdk-ct': ['EEE'] } }).ct).toBe('EEE');
  });

  test('nothing usable yields null', () => {
    expect(k.extractKasadaPayload({ body: 'no payload here' })).toBeNull();
    expect(k.extractKasadaPayload({ body: '{"ct":"short"}' })).toBeNull();
  });
});

describe('replay state', () => {
  test('a stored payload replays as headers', () => {
    k.storeKasadaPayload({ host: 'shop.example.com', proxy, payload: { ct: 'ttt', cd: '12345678', v: '2' } });
    expect(k.kasadaHeaders({ host: 'shop.example.com', proxy })).toEqual({
      'x-kpsdk-ct': 'ttt', 'x-kpsdk-cd': '12345678', 'x-kpsdk-v': '2'
    });
  });

  test('tokens are scoped per host AND per exit', () => {
    k.storeKasadaPayload({ host: 'shop.example.com', proxy, payload: { ct: 'ttt' } });
    expect(k.kasadaHeaders({ host: 'shop.example.com', proxy: null })).toEqual({});
    expect(k.kasadaHeaders({ host: 'other.example.com', proxy })).toEqual({});
  });

  test('a missing cd/v is simply not sent', () => {
    k.storeKasadaPayload({ host: 'h.com', payload: { ct: 'ttt' } });
    expect(Object.keys(k.kasadaHeaders({ host: 'h.com' }))).toEqual(['x-kpsdk-ct']);
  });

  test('clearing drops the entry', () => {
    k.storeKasadaPayload({ host: 'h.com', payload: { ct: 'ttt' } });
    k.clearKasada({ host: 'h.com' });
    expect(k.kasadaHeaders({ host: 'h.com' })).toEqual({});
  });

  test('a payload without ct is refused', () => {
    expect(k.storeKasadaPayload({ host: 'h.com', payload: {} })).toBe(false);
    expect(k.storeKasadaPayload({ host: null, payload: { ct: 'x' } })).toBe(false);
  });
});

describe('solve ladder', () => {
  test('layer 1 stores an inline payload and asks to retry', async () => {
    const out = await k.solveKasada({ pageUrl, proxy, status: 429, body: '{"ct":"AAAAAAAAAAAAAAAAAAAA"}' });
    expect(out).toMatchObject({ retry: true, needBrowser: false, reason: 'payload_in_response' });
    expect(k.kasadaHeaders({ host: 'shop.example.com', proxy })['x-kpsdk-ct']).toBe('AAAAAAAAAAAAAAAAAAAA');
    expect(mockRequest).not.toHaveBeenCalled();
  });

  test('layer 2 replays a held token without any network call', async () => {
    k.storeKasadaPayload({ host: 'shop.example.com', proxy, payload: { ct: 'held' } });
    const out = await k.solveKasada({ pageUrl, proxy, status: 429, body: 'denied' });
    expect(out.reason).toBe('cached_token');
    expect(mockRequest).not.toHaveBeenCalled();
  });

  test('layer 3 forks, and stores what the fork returned', async () => {
    mockRequest.mockResolvedValue({ ok: true, status: 429, body: '{"ct":"FORKEDFORKEDFORKEDFK"}' });
    const out = await k.solveKasada({ pageUrl, proxy, status: 429, body: 'denied' });
    expect(out).toMatchObject({ retry: true, reason: 'forked' });
    expect(k.kasadaHeaders({ host: 'shop.example.com', proxy })['x-kpsdk-ct']).toBe('FORKEDFORKEDFORKEDFK');
  });

  test('when nothing works a browser solve is demanded, not a blind retry', async () => {
    mockRequest.mockResolvedValue({ ok: true, status: 429, body: 'denied' });
    const out = await k.solveKasada({ pageUrl, proxy, status: 429, body: 'denied' });
    expect(out).toMatchObject({ retry: false, needBrowser: true, reason: 'browser_required' });
  });

  test('a failed fork is survivable', async () => {
    mockRequest.mockRejectedValue(new Error('socket hang up'));
    expect((await k.solveKasada({ pageUrl, proxy, status: 429, body: 'x' })).needBrowser).toBe(true);
  });

  test('a bad URL short-circuits', async () => {
    expect((await k.solveKasada({ pageUrl: 'not a url' })).reason).toBe('bad_url');
  });

  test('the fork sends our UA and scopes the request to the exit', async () => {
    mockRequest.mockResolvedValue({ ok: true, body: '{"ct":"AAAAAAAAAAAAAAAAAAAA"}' });
    await k.forkKasadaPayload({ pageUrl, proxy, ua: 'UA/1' });
    const args = mockRequest.mock.calls[0][0];
    expect(args.proxy).toBe('gate.net:8000');
    expect(args.headers['User-Agent']).toBe('UA/1');
  });
});
