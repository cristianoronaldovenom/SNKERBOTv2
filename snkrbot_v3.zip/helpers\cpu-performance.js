import os from 'node:os';
import { monitorEventLoopDelay } from 'node:perf_hooks';

const GB = 1024 ** 3;
const LOGICAL_CPUS = Math.max(1, os.availableParallelism?.() || os.cpus().length || 1);

const eventLoopLag = monitorEventLoopDelay({ resolution: 20 });
eventLoopLag.enable();

const parsePositiveInt = (v, fallback) => {
  const n = Number.parseInt(v, 10);
  return Number.isFinite(n) && n > 0 ? n : fallback;
};

export const cpuPerformanceMode = () => {
  const raw = String(process.env.CPU_PERFORMANCE_MODE || 'max').toLowerCase();
  return ['balanced', 'high', 'max'].includes(raw) ? raw : 'balanced';
};

export const cpuSnapshot = () => {
  const load1 = os.loadavg?.()[0] || 0;
  const cpuCount = LOGICAL_CPUS;
  const loadRatio = load1 / cpuCount;
  const totalMemGb = os.totalmem() / GB;
  return {
    cpuCount,
    load1,
    loadRatio,
    totalMemGb,
    freeMemGb: os.freemem() / GB,
    eventLoopP95Ms: Number((eventLoopLag.percentile(95) / 1e6).toFixed(1)),
    eventLoopMeanMs: Number((eventLoopLag.mean / 1e6).toFixed(1)),
    mode: cpuPerformanceMode(),
  };
};

// Browser tasks are CPU- and RAM-heavy. In high/max mode we raise concurrency,
// but only to a level the host can sustain. This avoids turning a fast i5 into
// a thermal-throttling machine, which would make checkout latency worse.
export const recommendedRunConcurrency = ({ configured = 16 } = {}) => {
  // `configured` is the number of lightweight monitor tasks the user may have
  // armed/queued. Heavyweight Chromium checkouts are separately governed below.
  const mode = cpuPerformanceMode();
  return Math.max(1, Math.min(1000, configured));
};

export const recommendedCheckoutConcurrency = ({ configured = 24 } = {}) => {
  const mode = cpuPerformanceMode();

  // Balanced is a CEILING, not a separate branch. It used to `return min(8,
  // configured)` here — before any RAM arithmetic — so a 1 GB host in balanced mode
  // was handed 8 browsers where ramCap is 1, which OOM-kills the first checkout
  // mid-run. It now takes part in the same min() as every other constraint.
  const modeCap = mode === 'balanced' ? 8 : 64;

  // The old governor reserved ~1.30 GB for every checkout browser. That was
  // intentionally conservative, but it also left a lot of unused capacity on
  // hosts where Chromium actually stays well below that budget. Keep a real
  // safety margin, but make the budget configurable so the governor scales from
  // observed host size instead of a hard 10/12-browser ceiling.
  const envCap = parsePositiveInt(
    process.env.CHECKOUT_CONCURRENCY_CAP,
    mode === 'max' ? 32 : 16
  );
  const configuredCap = Math.max(1, Math.min(64, configured));
  const cpuMultiplier = mode === 'max' ? 1.25 : 1.0;
  const cpuCap = Math.max(2, Math.min(32, Math.ceil(LOGICAL_CPUS * cpuMultiplier)));

  // Per-browser RAM budget and host reserve. Both used FIXED floors (500 MB
  // budget / 1536 MB reserve), which breaks small hosts outright: on a 1 GB box
  // `(1024 - 1536) / 500` is negative and the `Math.max(2, ...)` floor still
  // forced 2 Chromium instances, i.e. a guaranteed OOM. Scale both with host
  // size so the host itself is the hard limit.
  const totalMemoryMb = os.totalmem() / (1024 ** 2);
  const lowRamHost = totalMemoryMb <= 2.5 * 1024;
  const memoryBudgetMb = lowRamHost
    ? Math.max(160, Math.min(320, parsePositiveInt(process.env.CHECKOUT_MEMORY_BUDGET_MB, 260)))
    : Math.max(256, Math.min(1024, parsePositiveInt(process.env.CHECKOUT_MEMORY_BUDGET_MB, 500)));
  const reserveMb = lowRamHost
    ? Math.max(128, Math.min(512, parsePositiveInt(process.env.CHECKOUT_RESERVED_MEMORY_MB, Math.floor(totalMemoryMb * 0.25))))
    : Math.max(1536, Math.min(8192, parsePositiveInt(process.env.CHECKOUT_RESERVED_MEMORY_MB, 2048)));
  const ramCap = Math.max(1, Math.floor((totalMemoryMb - reserveMb) / memoryBudgetMb));

  const lagP95 = eventLoopLag.percentile(95) / 1e6;
  const loadRatio = (os.loadavg?.()[0] || 0) / LOGICAL_CPUS;
  const adaptivePenalty = lagP95 > 50 || loadRatio > 1.10 ? 2 : lagP95 > 35 || loadRatio > 0.95 ? 1 : 0;
  // On a low-RAM host the floor is ONE browser, not two — a second renderer
  // cannot fit and OOM-kills the first mid-checkout. Below 1.5 GB even the RAM
  // arithmetic is optimistic (the OS + Node baseline alone eats the budget), so
  // small hosts get an explicit hard ceiling as well.
  const floor = lowRamHost ? 1 : 2;
  const lowRamCeiling = lowRamHost ? (totalMemoryMb <= 1536 ? 1 : 2) : 64;
  return Math.max(
    floor,
    Math.min(64, lowRamCeiling, modeCap, envCap, configuredCap, cpuCap, ramCap) - adaptivePenalty
  );
};

const totalMemoryGbSafe = () => os.totalmem() / GB;

export const shouldThrottleCpu = () => {
  const { loadRatio, mode } = cpuSnapshot();
  if (mode === 'balanced') return false;
  const threshold = mode === 'max' ? 1.00 : 0.90;
  const lagP95 = eventLoopLag.percentile(95) / 1e6;
  return loadRatio >= threshold || lagP95 >= (mode === 'max' ? 45 : 35);
};

export const shouldRelaxCpu = () => {
  const { loadRatio, mode } = cpuSnapshot();
  if (mode === 'balanced') return false;
  const threshold = mode === 'max' ? 0.60 : 0.45;
  const lagP95 = eventLoopLag.percentile(95) / 1e6;
  return loadRatio <= threshold && lagP95 <= (mode === 'max' ? 25 : 20);
};

export const recommendedThreadPoolSize = () => {
  const mode = cpuPerformanceMode();
  if (mode === 'balanced') return 4;
  const configured = parsePositiveInt(process.env.UV_THREADPOOL_SIZE, mode === 'max' ? Math.min(12, Math.max(8, LOGICAL_CPUS)) : Math.min(8, LOGICAL_CPUS));
  return Math.max(4, Math.min(32, configured));
};


export const performanceProfile = () => ({
  mode: cpuPerformanceMode(),
  logicalCpus: LOGICAL_CPUS,
  armedTaskCapacity: recommendedRunConcurrency({ configured: 1000 }),
  recommendedCheckoutConcurrency: recommendedCheckoutConcurrency({ configured: 24 }),
  recommendedThreadPool: recommendedThreadPoolSize(),
  totalMemoryGb: Number((os.totalmem() / GB).toFixed(2)),
});
