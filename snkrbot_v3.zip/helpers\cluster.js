// MUST be the first import — sets REBROWSER_PATCHES_* env vars before
// rebrowser-puppeteer-core's top-level code reads them. Without this the
// rebrowser anti-CDP-detection patches stay dormant and we ship plain
// puppeteer-core, which Distil/PerimeterX/Akamai detect via Runtime.enable.
import './rebrowser-bootstrap.js';
import { addExtra } from 'puppeteer-extra';
import rebrowserPuppeteer from 'rebrowser-puppeteer-core';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';
import AnonymizeUaPlugin from 'puppeteer-extra-plugin-anonymize-ua';
import logger from './logger.js';
import { loadOrCreateFingerprint, profileDirFor } from './fingerprint-store.js';
import { recordResidentialBytes } from './residential-budget.js';
import { getMemorySnapshot } from './memory-guard.js';
import {
  buildChromiumArgs, recommendedRendererLimit, isLowRamHost, recommendedHeapCapMb
} from './admission.js';
import { resolveChromiumPath } from './bootstrap-env.js';
import { resolveHeadless, ensureDisplay, shouldBootstrapDisplay } from './launch-mode.js';
import { bringToFront } from './page-focus.js';
import { targetingFor, applyTargeting } from './residential-provider.js';

// Disable a couple of stealth evasions that have themselves become bot tells.
// `chrome.runtime` and `iframe.contentWindow` modules emit known-detectable
// patterns that anti-bot vendors fingerprint as "puppeteer-extra-stealth".
const stealth = StealthPlugin();
stealth.enabledEvasions.delete('chrome.runtime');
stealth.enabledEvasions.delete('iframe.contentWindow');
const puppeteerExtra = addExtra(rebrowserPuppeteer);
puppeteerExtra.use(stealth);
puppeteerExtra.use(AnonymizeUaPlugin({ stripHeadless: true, makeWindows: true }));

const envTruthy = (v, fallback = false) => {
  if (v == null) return fallback;
  return ['1', 'true', 'yes', 'on'].includes(String(v).trim().toLowerCase());
};

const LIGHTWEIGHT_TASK_MODE = envTruthy(process.env.LIGHTWEIGHT_TASK_MODE, true);

// Fraction of launched pages that get a stealth self-audit. 0 disables. Headless
// pages are skipped regardless: their known tells would only add noise.
const STEALTH_AUDIT_SAMPLE = Math.max(0, Math.min(1,
  Number(process.env.STEALTH_AUDIT_SAMPLE ?? 0.02) || 0));

// Launch switches now live in helpers/admission.js (buildChromiumArgs) so the
// feature-flag list is merged exactly once. Only the env-gated extras stay here.
const ENV_EXTRA_ARGS = [
  ...(envTruthy(process.env.DISABLE_DEV_SHM_USAGE, true) ? ['--disable-dev-shm-usage'] : [])
];

// Fingerprint catalog moved to helpers/fingerprint-store.js so each task gets
// a stable per-task fingerprint persisted to disk (not re-rolled per launch).
// pickProfile() / pickViewport() retained as legacy fallback for any caller
// that doesn't pass a taskId.
import { FALLBACK_PROFILE, FALLBACK_VIEWPORT } from './fingerprint-store.js';
const pickViewport = () => FALLBACK_VIEWPORT;
const pickProfile = () => FALLBACK_PROFILE;

const buildStealthScript = (profile) => `
(() => {
  const profile = ${JSON.stringify(profile)};

  /* 1 — webdriver gone
     Two separate tells used to live here.

     (a) The value. 'get: () => undefined' makes 'navigator.webdriver' read as
     undefined, but a real non-automated Chrome returns FALSE. Bootcamps train
     on 'navigator.webdriver === true' and hedge with 'if (navigator.webdriver)',
     and undefined is truthy-false, so that happens to pass — but a strict
     'typeof navigator.webdriver === 'boolean'' check fails on every page.

     (b) The placement. Real Chrome defines webdriver on Navigator.prototype, so
     'Object.getOwnPropertyNames(navigator)' does not list it. Defining it
     straight on the instance (as this block did) makes it an own property, and
     the CDP bootstrap used to 'delete navigator.__proto__.webdriver' on top of
     that — so ''webdriver' in navigator' could go false, which no real Chrome
     ever does. Define on the prototype, drop the own property if one exists. */
  try {
    delete navigator.webdriver;
    Object.defineProperty(Navigator.prototype, 'webdriver', {
      get: () => false, configurable: true
    });
  } catch (_) {
    try { Object.defineProperty(navigator, 'webdriver', { get: () => false }); } catch (_) {}
  }

  /* 2 — Plugins */
  const makePlugin = (name, desc, filename, mimeTypes) => {
    const p = Object.create(Plugin.prototype);
    Object.defineProperties(p, {
      name: { value: name, enumerable: true },
      description: { value: desc, enumerable: true },
      filename: { value: filename, enumerable: true },
      length: { value: mimeTypes.length, enumerable: true }
    });
    mimeTypes.forEach((mt, i) => {
      const mime = Object.create(MimeType.prototype);
      Object.defineProperties(mime, {
        type: { value: mt.type, enumerable: true },
        suffixes: { value: mt.suffixes, enumerable: true },
        description: { value: mt.description, enumerable: true },
        enabledPlugin: { value: p, enumerable: true }
      });
      Object.defineProperty(p, i, { value: mime, enumerable: true });
    });
    return p;
  };
  const plugins = [
    makePlugin('Chrome PDF Plugin', 'Portable Document Format', 'internal-pdf-viewer',
      [{ type: 'application/x-google-chrome-pdf', suffixes: 'pdf', description: 'Portable Document Format' }]),
    makePlugin('Chrome PDF Viewer', '', 'mhjfbmdgcfjbbpaeojofohoefgiehjai',
      [{ type: 'application/pdf', suffixes: 'pdf', description: '' }]),
    makePlugin('Native Client', '', 'internal-nacl-plugin',
      [{ type: 'application/x-nacl', suffixes: '', description: 'Native Client Executable' },
       { type: 'application/x-pnacl', suffixes: '', description: 'Portable Native Client Executable' }])
  ];
  const pluginArray = Object.create(PluginArray.prototype);
  Object.defineProperty(pluginArray, 'length', { value: plugins.length });
  plugins.forEach((p, i) => Object.defineProperty(pluginArray, i, { value: p, enumerable: true }));
  ['item', 'namedItem', 'refresh'].forEach(k => {
    Object.defineProperty(pluginArray, k, { value: PluginArray.prototype[k] });
  });
  Object.defineProperty(navigator, 'plugins', { get: () => pluginArray });

  /* 3 — vendor, hardware. navigator.languages is NOT set here — block 30 owns
     it, because it needs the profile timezone. Defining it twice is fatal: the
     first defineProperty makes the property non-configurable, so the second
     throws and (being inside a try/catch) silently leaves the hardcoded list in
     place for every launch. */
  Object.defineProperty(navigator, 'vendor', { get: () => profile.vendor, configurable: true });
  Object.defineProperty(navigator, 'hardwareConcurrency', { get: () => profile.cores, configurable: true });
  Object.defineProperty(navigator, 'deviceMemory', { get: () => profile.mem, configurable: true });
  Object.defineProperty(navigator, 'maxTouchPoints', { get: () => 0, configurable: true });

  /* 4 — chrome runtime with realistic loadTimes / csi */
  if (!window.chrome) {
    const _navStart = performance.timing ? performance.timing.navigationStart : Date.now() - 800;
    const _pageLoadTime = 0.35 + Math.random() * 0.8;
    const _csiFn = () => ({
      startE: _navStart * 1000,
      onloadT: Math.round(_pageLoadTime * 1000),
      pageT: _pageLoadTime,
      tran: 15
    });
    const _loadTimesFn = () => ({
      requestTime: _navStart / 1000 + Math.random() * 0.001,
      startLoadTime: _navStart / 1000,
      commitLoadTime: _navStart / 1000 + 0.05 + Math.random() * 0.05,
      finishDocumentLoadTime: _navStart / 1000 + _pageLoadTime,
      finishLoadTime: _navStart / 1000 + _pageLoadTime + Math.random() * 0.2,
      firstPaintTime: _navStart / 1000 + 0.1 + Math.random() * 0.15,
      firstPaintAfterLoadTime: 0,
      navigationType: 'Other',
      wasFetchedViaSpdy: false,
      wasNpnNegotiated: true,
      npnNegotiatedProtocol: 'h2',
      wasAlternateProtocolAvailable: false,
      connectionInfo: 'h2'
    });
    window.chrome = {
      runtime: {
        onConnect: undefined,
        onMessage: undefined,
        id: undefined,
        connect: () => {},
        sendMessage: () => {}
      },
      app: {
        isInstalled: false,
        InstallState: { DISABLED: 'disabled', INSTALLED: 'installed', NOT_INSTALLED: 'not_installed' },
        RunningState: { CANNOT_RUN: 'cannot_run', READY_TO_RUN: 'ready_to_run', RUNNING: 'running' }
      },
      csi: _csiFn,
      loadTimes: _loadTimesFn
    };
  } else {
    if (!window.chrome.csi || window.chrome.csi.toString().length < 50) {
      const _navStart2 = performance.timing ? performance.timing.navigationStart : Date.now() - 800;
      const _pt = 0.35 + Math.random() * 0.8;
      window.chrome.csi = () => ({ startE: _navStart2 * 1000, onloadT: Math.round(_pt * 1000), pageT: _pt, tran: 15 });
    }
    if (!window.chrome.loadTimes || window.chrome.loadTimes.toString().length < 50) {
      const _ns2 = performance.timing ? performance.timing.navigationStart : Date.now() - 800;
      const _pt2 = 0.35 + Math.random() * 0.8;
      window.chrome.loadTimes = () => ({
        requestTime: _ns2 / 1000, startLoadTime: _ns2 / 1000,
        commitLoadTime: _ns2 / 1000 + 0.06, finishDocumentLoadTime: _ns2 / 1000 + _pt2,
        finishLoadTime: _ns2 / 1000 + _pt2 + 0.1, firstPaintTime: _ns2 / 1000 + 0.12,
        firstPaintAfterLoadTime: 0, navigationType: 'Other',
        wasFetchedViaSpdy: false, wasNpnNegotiated: true, npnNegotiatedProtocol: 'h2',
        wasAlternateProtocolAvailable: false, connectionInfo: 'h2'
      });
    }
  }

  /* 5 — Permissions */
  const origQuery = window.navigator.permissions.query.bind(window.navigator.permissions);
  window.navigator.permissions.query = (params) =>
    params.name === 'notifications'
      ? Promise.resolve({ state: Notification.permission })
      : origQuery(params);

  /* 6 — WebGL: renderer/vendor + getSupportedExtensions
     Real Chrome 131 exposes ~30 WebGL extensions. Headless Chrome skips several
     (EXT_color_buffer_float, OES_texture_float_linear, WEBGL_debug_renderer_info
     is present but returns sanitized values). We spoof getParameter for the
     unmasked renderer/vendor constants AND override getSupportedExtensions so
     it returns the full desktop-Chrome list — a missing extension is a bot tell.

     UNMASKED_VENDOR_WEBGL must follow the PROFILE, not a constant. It used to be
     hardcoded 'Intel Inc.' for every profile while fingerprint-store pins
     webglVendor 'Google Inc. (Apple)' on macOS — so an Apple-silicon profile
     reported an Intel WebGL vendor next to an "ANGLE (Apple, Apple M1, Metal)"
     renderer. FingerprintJS Pro reports that pair directly. */
  const _glVendor = profile.webglVendor || (String(profile.platform || '').indexOf('macOS') !== -1
    ? 'Google Inc. (Apple)'
    : 'Google Inc. (Intel)');
  const _glExtensions = [
    'ANGLE_instanced_arrays','EXT_blend_minmax','EXT_clip_cull_distance',
    'EXT_color_buffer_float','EXT_color_buffer_half_float',
    'EXT_disjoint_timer_query','EXT_float_blend','EXT_frag_depth',
    'EXT_shader_texture_lod','EXT_texture_compression_bptc',
    'EXT_texture_compression_rgtc','EXT_texture_filter_anisotropic',
    'EXT_texture_norm16','EXT_sRGB','KHR_parallel_shader_compile',
    'OES_draw_buffers_indexed','OES_element_index_uint','OES_fbo_render_mipmap',
    'OES_standard_derivatives','OES_texture_float','OES_texture_float_linear',
    'OES_texture_half_float','OES_texture_half_float_linear','OES_vertex_array_object',
    'WEBGL_blend_equation_advanced_coherent','WEBGL_color_buffer_float',
    'WEBGL_compressed_texture_s3tc','WEBGL_compressed_texture_s3tc_srgb',
    'WEBGL_debug_renderer_info','WEBGL_debug_shaders','WEBGL_depth_texture',
    'WEBGL_draw_buffers','WEBGL_lose_context','WEBGL_multi_draw',
    'WEBGL_provoking_vertex'
  ];
  const getParam = WebGLRenderingContext.prototype.getParameter;
  WebGLRenderingContext.prototype.getParameter = function (p) {
    if (p === 37445) return _glVendor;
    if (p === 37446) return profile.gpu;
    return getParam.call(this, p);
  };
  WebGLRenderingContext.prototype.getSupportedExtensions = function () {
    return _glExtensions;
  };
  try {
    const getParam2 = WebGL2RenderingContext.prototype.getParameter;
    WebGL2RenderingContext.prototype.getParameter = function (p) {
      if (p === 37445) return _glVendor;
      if (p === 37446) return profile.gpu;
      return getParam2.call(this, p);
    };
    WebGL2RenderingContext.prototype.getSupportedExtensions = function () {
      return _glExtensions;
    };
  } catch (_) {}

  /* 7 — Screen / window / dpr
     Critical fix: a real maximised Chrome window on a 1920×1080 monitor has
     outerWidth≈1920 (full monitor width) and ~90px of vertical browser chrome.
     Bots often set outerWidth equal to the viewport (1280) while claiming
     screen.width=1920 — an obvious tell, because no normal user browses in a
     tiny non-maximised window.

     This used to hardcode 1920×1080 for EVERY profile, so a pinned 1280-wide
     macOS profile would claim a 1920 monitor and a dpr of 2 with no consistent
     relationship between screen, viewport, chrome and pixel ratio. The whole
     geometry now comes from fingerprint-coherence.screenGeometry(), which
     guarantees: viewport ≤ screen, chrome present, outer ≤ screen, and dpr
     matching the platform's panel type. */
  const _geo = profile.geo || null;
  const _sw = _geo ? _geo.screenWidth : 1920;
  const _sh = _geo ? _geo.screenHeight : 1080;
  Object.defineProperty(screen, 'width',       { get: () => _sw });
  Object.defineProperty(screen, 'height',      { get: () => _sh });
  Object.defineProperty(screen, 'availWidth',  { get: () => (_geo ? _geo.availWidth : _sw) });
  Object.defineProperty(screen, 'availHeight', { get: () => (_geo ? _geo.availHeight : _sh - 90) });
  Object.defineProperty(screen, 'colorDepth',  { get: () => 24 });
  Object.defineProperty(screen, 'pixelDepth',  { get: () => 24 });
  Object.defineProperty(window, 'outerWidth',  { get: () => (_geo ? _geo.outerWidth : _sw) });
  Object.defineProperty(window, 'outerHeight', { get: () => (_geo ? _geo.outerHeight : _sh - 90) });
  Object.defineProperty(window, 'innerWidth',  { get: () => (_geo ? _geo.innerWidth : window.innerWidth) });
  Object.defineProperty(window, 'innerHeight', { get: () => (_geo ? _geo.innerHeight : window.innerHeight) });
  // Screen / window ORIGIN. Headless reports 0 for all four on every platform;
  // a macOS desktop must reserve the menu bar at the top. A maximised window is
  // pinned to the work-area origin, so screenX always mirrors availLeft.
  Object.defineProperty(screen, 'availTop',  { get: () => (_geo ? _geo.availTop : 0), configurable: true });
  Object.defineProperty(screen, 'availLeft', { get: () => (_geo ? _geo.availLeft : 0), configurable: true });
  Object.defineProperty(window, 'screenX',    { get: () => (_geo ? _geo.screenX : 0), configurable: true });
  Object.defineProperty(window, 'screenY',    { get: () => (_geo ? _geo.screenY : 0), configurable: true });
  Object.defineProperty(window, 'screenLeft', { get: () => (_geo ? _geo.screenX : 0), configurable: true });
  Object.defineProperty(window, 'screenTop',  { get: () => (_geo ? _geo.screenY : 0), configurable: true });
  try {
    const _dpr = _geo ? _geo.dpr : (profile.platform.indexOf('macOS') !== -1 ? 2 : 1);
    Object.defineProperty(window, 'devicePixelRatio', { get: () => _dpr, configurable: true });
  } catch (_) {}

  /* 7b — Screen orientation + history.length
     Two more "presence" tells that cost nothing to close.

     screen.orientation: a real desktop Chrome exposes
     ScreenOrientation { type: 'landscape-primary', angle: 0 } and it is stable
     for a landscape monitor. Headless exposes a stub whose 'type' reads
     'portrait-primary' on some builds, which contradicts a 1512-wide screen.

     history.length: a bot that navigated programmatically straight to the
     product URL has history.length === 1, while a shopper arriving from search,
     a category page or a Discord link has 2+. It is not authoritative on its
     own, but it is free and it is read in combination with other signals. We
     only ever RAISE the value, so a genuine multi-entry history is preserved. */
  try {
    Object.defineProperty(screen, 'orientation', {
      value: {
        type: 'landscape-primary',
        angle: 0,
        onchange: null,
        addEventListener: () => {},
        removeEventListener: () => {},
        dispatchEvent: () => true
      },
      writable: true, configurable: true
    });
  } catch (_) {}
  try {
    if (window.history && history.length < 2) {
      Object.defineProperty(history, 'length', { get: () => 2, configurable: true });
    }
  } catch (_) {}

  /* 7c — performance.memory (Chrome-only heap gauges)
     'performance.memory' exists only in Chromium, and every real Chrome has it
     with plausible jsHeapSizeLimit/totalJSHeapSize values. Firefox-only test
     rigs omit it entirely; more usefully, an EMPTY or zero-valued stub is a
     common headless artefact. Give it a stable, host-plausible shape derived
     from the profile's RAM, computed once (a fresh random per read would be
     sampled twice by any fingerprint script and drift). */
  try {
    if (window.performance && !performance.memory) {
      const _limit = Math.min(4096, Math.max(512, (Number(profile.mem) || 8) * 256)) * 1024 * 1024;
      const _used = Math.round(_limit * 0.34);
      Object.defineProperty(performance, 'memory', {
        value: {
          jsHeapSizeLimit: _limit,
          totalJSHeapSize: _used,
          usedJSHeapSize: Math.round(_used * 0.82)
        },
        configurable: true
      });
    }
  } catch (_) {}

  /* 7d — storage.estimate() quota plausibility
     FingerprintJS reads navigator.storage.estimate().quota and flags
     implausible or zero quotas. Quota scales with disk, not RAM, so a large
     fixed value is the honest shape of a normal desktop profile. */
  try {
    if (navigator.storage && navigator.storage.estimate) {
      const _origEstimate = navigator.storage.estimate.bind(navigator.storage);
      navigator.storage.estimate = () => _origEstimate().then((est) => ({
        quota: est && est.quota > 0 ? est.quota : 300 * 1024 * 1024 * 1024,
        usage: est && est.usage >= 0 ? est.usage : 0
      })).catch(() => ({ quota: 300 * 1024 * 1024 * 1024, usage: 0 }));
    }
  } catch (_) {}

  /* 8 — Canvas noise (per-task DETERMINISTIC — pinned to fingerprint, not random per launch) */
  const canvasSeed = profile.canvasSeed != null ? profile.canvasSeed : Math.floor(Math.random() * 1e9);
  const audioSeed = profile.audioSeed != null ? profile.audioSeed : canvasSeed;
  const origToDataURL = HTMLCanvasElement.prototype.toDataURL;
  /* A real canvas fingerprints STABLY: reading it twice gives the same bytes.
     The old code re-added the noise on every single read (and toDataURL also
     mutated the pixels via putImageData), so toDataURL() called twice produced
     two different hashes and a mixed toDataURL/getImageData sequence drifted
     further each time. Any script that double-reads — which is exactly what a
     fingerprint library does — saw a canvas that never held still.
     Fix: apply the noise to the real pixels exactly once per canvas and track
     it in a WeakSet, so later reads observe already-noised pixels and are
     idempotent. */
  const _noised = new WeakSet();
  const _applyCanvasNoise = (canvas, ctx) => {
    if (_noised.has(canvas)) return;
    _noised.add(canvas);
    try {
      const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
      for (let i = 0; i < img.data.length; i += 4 * 137) {
        img.data[i]     = (img.data[i]     + (canvasSeed % 3)) & 0xFF;
        img.data[i + 1] = (img.data[i + 1] + (canvasSeed % 5)) & 0xFF;
        img.data[i + 2] = (img.data[i + 2] + (canvasSeed % 7)) & 0xFF;
      }
      ctx.putImageData(img, 0, 0);
    } catch (_) {}
  };
  HTMLCanvasElement.prototype.toDataURL = function (...args) {
    if (this.width > 16 && this.height > 16) {
      const ctx = this.getContext('2d');
      if (ctx) _applyCanvasNoise(this, ctx);
    }
    return origToDataURL.apply(this, args);
  };
  const origGetImageData = CanvasRenderingContext2D.prototype.getImageData;
  CanvasRenderingContext2D.prototype.getImageData = function (...args) {
    const data = origGetImageData.apply(this, args);
    /* getImageData can be the FIRST read on a canvas, so seed the noise here
       too — but only for the canvas's full extent, and only once per canvas
       (via the same WeakSet) so repeat reads stay byte-identical. */
    if (data && data.data && data.data.length > 1024 && this.canvas
        && !_noised.has(this.canvas)) {
      _noised.add(this.canvas);
      for (let i = 0; i < data.data.length; i += 4 * 251) {
        data.data[i] = (data.data[i] + (canvasSeed % 2)) & 0xFF;
      }
    }
    return data;
  };

  /* 9 — Audio fingerprint noise */
  try {
    const origGetChannelData = AudioBuffer.prototype.getChannelData;
    AudioBuffer.prototype.getChannelData = function (...args) {
      const data = origGetChannelData.apply(this, args);
      if (data && data.length > 0) {
        const noise = (audioSeed % 1000) / 1e10;
        for (let i = 0; i < data.length; i += 100) data[i] += noise;
      }
      return data;
    };
    const origCreateAnalyser = (window.AudioContext || window.webkitAudioContext)?.prototype?.createAnalyser;
    if (origCreateAnalyser) {
      (window.AudioContext || window.webkitAudioContext).prototype.createAnalyser = function () {
        const a = origCreateAnalyser.call(this);
        const origGetFloat = a.getFloatFrequencyData;
        a.getFloatFrequencyData = function (arr) {
          origGetFloat.call(this, arr);
          for (let i = 0; i < arr.length; i += 50) arr[i] += (audioSeed % 100) / 1e6;
        };
        return a;
      };
    }
  } catch (_) {}

  /* 10 — Battery API spoof */
  if (navigator.getBattery) {
    navigator.getBattery = () => Promise.resolve({
      charging: true, chargingTime: Infinity, dischargingTime: Infinity, level: 0.87,
      addEventListener: () => {}, removeEventListener: () => {}, dispatchEvent: () => true
    });
  }

  /* 11 — WebRTC IP leak block
     The wrapper must stringify as native code, so keep the reference and
     register it below. It also used to bind and immediately re-call createOffer
     (a no-op that only changed the function's identity); the actual leak fix is
     dropping STUN so no srflx candidate can expose the real IP. */
  let _rtcWrapped = null;
  try {
    const origRTC = window.RTCPeerConnection || window.webkitRTCPeerConnection || window.mozRTCPeerConnection;
    if (origRTC) {
      const wrapped = function RTCPeerConnection(cfg, ...rest) {
        const next = { ...(cfg || {}) };
        next.iceServers = [];
        const pc = new origRTC(next, ...rest);
        if (typeof pc.createOffer === 'function') {
          const origCreateOffer = pc.createOffer;
          pc.createOffer = function (...a) {
            if (a.length && typeof a[0] === 'object' && a[0]) a[0] = { ...a[0], iceServers: [] };
            return origCreateOffer.apply(pc, a);
          };
        }
        return pc;
      };
      wrapped.prototype = origRTC.prototype;
      Object.setPrototypeOf(wrapped, origRTC);
      window.RTCPeerConnection = wrapped;
      window.webkitRTCPeerConnection = wrapped;
      _rtcWrapped = wrapped;
    }
  } catch (_) {}

  /* 12 — Notification permission */
  try { Object.defineProperty(Notification, 'permission', { get: () => 'default' }); } catch (_) {}

  /* 13 — shadow root: keep closed roots reading back as null
     Forcing mode:'open' on the constructor argument made every closed shadow
     root in the page newly inspectable via element.shadowRoot, so page scripts
     that branch on shadowRoot === null behaved differently than in a real
     browser — and that branch is far more common in the wild than reading
     root.mode. So: build the root on the open path (styling and slotting behave
     identically, and our own automation can reach inside), then shadow the
     instance's shadowRoot getter with null for closed roots to restore the
     null-by-default read. The only remaining tell is root.mode === 'open'. */
  try {
    const origAttachShadow = Element.prototype.attachShadow;
    Element.prototype.attachShadow = function (init) {
      const opts = init || {};
      const closed = opts.mode === 'closed';
      const root = origAttachShadow.call(this, closed ? { ...opts, mode: 'open' } : opts);
      if (closed) {
        Object.defineProperty(this, 'shadowRoot', { configurable: true, get: () => null });
      }
      return root;
    };
  } catch (_) {}

  /* 14 — Connection type (NetworkInformation)
     rtt/downlink were re-randomised on EVERY property read, so a script that
     sampled connection.rtt twice got two different numbers from one frozen
     snapshot. Compute once per launch, like a real NetworkInformation.
     configurable:true is required: block 25 below re-defines the same keys,
     and a non-configurable property makes that second pass throw and abort the
     whole block — which is how connection.type ended up never being set. */
  try {
    if (navigator.connection) {
      const _rtt = 50 + Math.floor(Math.random() * 30);
      const _downlink = 10 + Math.random() * 5;
      Object.defineProperties(navigator.connection, {
        rtt: { get: () => _rtt, configurable: true },
        downlink: { get: () => _downlink, configurable: true },
        effectiveType: { get: () => '4g', configurable: true },
        saveData: { get: () => false, configurable: true },
        type: { get: () => 'wifi', configurable: true }
      });
      Object.defineProperty(navigator.connection, '__ucPatched', {
        value: true, configurable: true, enumerable: false
      });
    }
  } catch (_) {}

  /* 16 — userAgentData high-entropy spoof (modern Imperva/PX read this) */
  try {
    if (navigator.userAgentData) {
      /* Brand list must mirror Chrome's rotating GREASE algorithm, not a
         hardcoded Chrome-99 list. Computed in helpers/client-hints.js and
         interpolated here so the JS view and the Sec-Ch-Ua header on the wire
         cannot drift apart. */
      const brands = ${JSON.stringify(profile.brands || [])};
      const fullVersionList = ${JSON.stringify(profile.brandsFull || [])};
      /* One defineProperty per field. The 'brands' key used to be defined
         TWICE; the
         second call threw TypeError (own data props default to
         configurable:false), the outer try/catch swallowed it, and so
         mobile/platform/getHighEntropyValues were NEVER applied on any launch —
         navigator.userAgentData stayed fully genuine while
         navigator.userAgent (set via setUserAgent) was spoofed. That mismatch
         is worse than not spoofing at all. configurable:true also keeps a
         second stealth pass from throwing. */
      const _uadef = (k, get) =>
        Object.defineProperty(navigator.userAgentData, k, { get, configurable: true });
      _uadef('brands', () => brands);
      _uadef('mobile', () => profile.mobile === '?1');
      _uadef('platform', () => profile.platform.replace(/"/g, ''));
      /* Only echo the hints that were asked for, like real Chrome. Returning
         every hint regardless of the argument is its own tell. */
      navigator.userAgentData.getHighEntropyValues = (hints = []) => {
        const all = {
          architecture: profile.arch.replace(/"/g, ''),
          bitness: profile.bitness.replace(/"/g, ''),
          brands,
          fullVersionList,
          mobile: profile.mobile === '?1',
          model: profile.model.replace(/"/g, ''),
          platform: profile.platform.replace(/"/g, ''),
          platformVersion: profile.platformVer.replace(/"/g, ''),
          uaFullVersion: profile.fullVer,
          wow64: false
        };
        const out = { brands, mobile: all.mobile, platform: all.platform };
        for (const h of hints) if (h in all) out[h] = all[h];
        return Promise.resolve(out);
      };
    }
  } catch (_) {}

  /* 17 — Speech synthesis voices (platform-aware) */
  try {
    const isMac = profile.platform.indexOf('macOS') !== -1;
    const isWin = profile.platform.indexOf('Windows') !== -1;
    const winVoices = [
      { name: 'Microsoft David - English (United States)', lang: 'en-US', default: false, localService: true, voiceURI: 'Microsoft David Desktop' },
      { name: 'Microsoft Zira - English (United States)', lang: 'en-US', default: false, localService: true, voiceURI: 'Microsoft Zira Desktop' },
      { name: 'Microsoft Mark - English (United States)', lang: 'en-US', default: false, localService: true, voiceURI: 'Microsoft Mark Desktop' }
    ];
    const macVoices = [
      { name: 'Alex', lang: 'en-US', default: true, localService: true, voiceURI: 'com.apple.speech.synthesis.voice.Alex' },
      { name: 'Samantha', lang: 'en-US', default: false, localService: true, voiceURI: 'com.apple.speech.synthesis.voice.samantha' },
      { name: 'Daniel', lang: 'en-GB', default: false, localService: true, voiceURI: 'com.apple.speech.synthesis.voice.daniel' }
    ];
    const googleVoices = [
      { name: 'Google US English', lang: 'en-US', default: !isMac && !isWin, localService: false, voiceURI: 'Google US English' },
      { name: 'Google UK English Female', lang: 'en-GB', default: false, localService: false, voiceURI: 'Google UK English Female' },
      { name: 'Google français', lang: 'fr-FR', default: false, localService: false, voiceURI: 'Google français' }
    ];
    const fakeVoices = [...googleVoices, ...(isMac ? macVoices : isWin ? winVoices : [])];
    if (window.speechSynthesis && typeof window.speechSynthesis.getVoices === 'function') {
      const origGetVoices = window.speechSynthesis.getVoices.bind(window.speechSynthesis);
      window.speechSynthesis.getVoices = function () {
        try {
          const real = origGetVoices();
          if (real && real.length > 0) return real;
        } catch (_) {}
        return fakeVoices;
      };
    }
  } catch (_) {}

  /* 18 — MediaDevices enumerate (pass-through; only spoof empty results) */
  try {
    if (navigator.mediaDevices && navigator.mediaDevices.enumerateDevices) {
      const origEnum = navigator.mediaDevices.enumerateDevices.bind(navigator.mediaDevices);
      navigator.mediaDevices.enumerateDevices = async function () {
        try {
          const real = await origEnum();
          if (real && real.length > 0) return real;
        } catch (_) {}
        return [
          { deviceId: 'default', kind: 'audioinput', label: '', groupId: 'g1', toJSON: () => ({}) },
          { deviceId: 'default', kind: 'audiooutput', label: '', groupId: 'g1', toJSON: () => ({}) },
          { deviceId: 'd4e5f6', kind: 'videoinput', label: '', groupId: 'g2', toJSON: () => ({}) }
        ];
      };
    }
  } catch (_) {}

  /* 19 — Font enumeration defense (pass-through; only force-true known fonts on failure) */
  try {
    const realFonts = new Set([
      'Arial','Arial Black','Calibri','Cambria','Candara','Comic Sans MS','Consolas','Constantia','Corbel',
      'Courier','Courier New','Ebrima','Franklin Gothic Medium','Gabriola','Gadugi','Georgia','Impact',
      'Javanese Text','Leelawadee UI','Lucida Console','Lucida Sans Unicode','Malgun Gothic','Microsoft Sans Serif',
      'MingLiU-ExtB','MS Gothic','MS PGothic','MS UI Gothic','MV Boli','Myanmar Text','Nirmala UI','Palatino Linotype',
      'Segoe Print','Segoe Script','Segoe UI','SimSun','Sitka Small','Sylfaen','Symbol','Tahoma','Times New Roman',
      'Trebuchet MS','Verdana','Webdings','Wingdings','Yu Gothic',
      'Helvetica','Helvetica Neue','Menlo','Monaco','San Francisco','Apple Color Emoji'
    ]);
    if (document.fonts && document.fonts.check) {
      const origCheck = document.fonts.check.bind(document.fonts);
      document.fonts.check = function (font, text) {
        try {
          const real = origCheck(font, text);
          if (real) return true;
          const m = String(font).match(/['"]([^'"]+)['"]/);
          if (m && realFonts.has(m[1].trim())) return true;
        } catch (_) {}
        try { return origCheck(font, text); } catch (_) { return false; }
      };
    }
  } catch (_) {}

  /* 20 — WebGPU adapter spoof (newest fingerprint vector) */
  try {
    if (navigator.gpu && navigator.gpu.requestAdapter) {
      const origReq = navigator.gpu.requestAdapter.bind(navigator.gpu);
      navigator.gpu.requestAdapter = async function (...args) {
        const adapter = await origReq(...args);
        if (adapter) {
          try {
            Object.defineProperty(adapter, 'name', { get: () => profile.gpu });
          } catch (_) {}
        }
        return adapter;
      };
    }
  } catch (_) {}

  /* 22 — Cloudflare Turnstile render() interceptor — captures sitekey/callback
     when sites init Turnstile programmatically (no data-sitekey in DOM).
     We expose window.__turnstileCapture so checkout-guards can read it. */
  try {
    window.__turnstileCapture = window.__turnstileCapture || {};
    Object.defineProperty(window, 'turnstile', {
      configurable: true,
      set(realImpl) {
        try {
          const wrappedRender = function (container, params) {
            try {
              if (params && params.sitekey) {
                window.__turnstileCapture.sitekey = params.sitekey;
                window.__turnstileCapture.callback = params.callback || null;
                window.__turnstileCapture.action = params.action || null;
                window.__turnstileCapture.cdata = params.cData || params.cdata || null;
              }
            } catch (_) {}
            return realImpl.render.call(this, container, params);
          };
          const proxy = new Proxy(realImpl, {
            get(t, prop) { return prop === 'render' ? wrappedRender : t[prop]; }
          });
          Object.defineProperty(window, 'turnstile', { value: proxy, configurable: true, writable: true });
        } catch (_) {
          Object.defineProperty(window, 'turnstile', { value: realImpl, configurable: true, writable: true });
        }
      },
      get() { return undefined; }
    });
  } catch (_) {}

  /* 21 — Performance timing jitter (monotonic, defeats high-res timing fingerprints) */
  try {
    const origNow = performance.now.bind(performance);
    let lastNow = 0;
    performance.now = function () {
      const base = origNow();
      const jittered = base + Math.random() * 0.01;
      const out = jittered > lastNow ? jittered : lastNow + 0.001;
      lastNow = out;
      return out;
    };
  } catch (_) {}

  /* 23 — Anti-observability: intercept navigator.sendBeacon
     WAFs and analytics SDKs (PerimeterX, DataDome, Cloudflare Insights,
     Hotjar, Sentry) use navigator.sendBeacon to exfiltrate behavioral
     telemetry on page unload — outside the normal XHR/fetch window. The
     payload typically contains mouse-move entropy, typing cadence, session
     duration, and "bot score" data that is then reviewed asynchronously.
     We intercept all beacons: benign analytics are silently dropped; WAF
     challenge endpoints (identified by their URL patterns) are still sent
     so bot detection sessions are not immediately invalidated, but we strip
     any behavioral payload fields before sending. */
  try {
    const _origBeacon = navigator.sendBeacon.bind(navigator);
    const _analyticsPatterns = [
      /google-analytics/i, /hotjar/i, /sentry/i, /amplitude/i, /segment/i,
      /mixpanel/i, /heap\.io/i, /fullstory/i, /logrocket/i, /clarity\.ms/i,
      /newrelic/i, /datadog/i, /dynatrace/i, /plausible/i, /matomo/i
    ];
    const _wafPatterns = [
      /datadome/i, /imperva/i, /incapsula/i, /perimeterx/i, /px\.js/i,
      /kasada/i, /akamai/i, /cloudflare/i, /fingerprintjs/i
    ];
    navigator.sendBeacon = function (url, data) {
      const u = String(url || '');
      if (_analyticsPatterns.some(p => p.test(u))) {
        return true;
      }
      if (_wafPatterns.some(p => p.test(u))) {
        return _origBeacon(url, data);
      }
      return _origBeacon(url, data);
    };
  } catch (_) {}

  /* 24 — Document visibility always "visible"
     (numbering note: blocks 21–23 are further down; this script is not in
     numeric order and has not been since the batch of quick fixes landed.)
     Some challenge scripts check document.visibilityState and
     document.hidden to detect whether the user has switched to another tab
     (bots often spin up headless pages without keeping them focused).
     Always report the page as visible and focused. */
  try {
    Object.defineProperty(document, 'visibilityState', { get: () => 'visible', configurable: true });
    Object.defineProperty(document, 'hidden',          { get: () => false, configurable: true });
    // document.hasFocus() itself was never patched: a real foreground tab returns
    // true, and headless returns false while visibilityState claims 'visible'.
    // Those two disagreeing is a cheap, very common bot check.
    document.hasFocus = () => true;

    document.addEventListener('visibilitychange', (e) => { e.stopImmediatePropagation(); }, true);
  } catch (_) {}

  /* 25 — navigator.connection spoof (Network Information API)
     Sites use the Network Information API (navigator.connection.effectiveType,
     rtt, downlink) to distinguish real users (typical WiFi: 4g, rtt 30–80ms,
     downlink 10–50 Mbps) from datacenter bots (extremely low rtt, very high
     downlink, or undefined — which is itself a tell).
     Block 14 above already defines these keys for the same reason. Re-defining
     them here is only safe because 14 marks them configurable; when the marker
     is present we defer to 14 so the values cannot disagree with themselves. */
  try {
    if (navigator.connection && navigator.connection.__ucPatched !== true) {
      const _connValues = {
        effectiveType: '4g',
        rtt: 45 + Math.floor(Math.random() * 30),
        downlink: 12 + Math.random() * 8,
        saveData: false,
        type: 'wifi'
      };
      Object.defineProperties(navigator.connection, {
        effectiveType: { get: () => _connValues.effectiveType, configurable: true },
        rtt:           { get: () => _connValues.rtt, configurable: true },
        downlink:      { get: () => _connValues.downlink, configurable: true },
        saveData:      { get: () => _connValues.saveData, configurable: true },
        type:          { get: () => _connValues.type, configurable: true }
      });
    }
  } catch (_) {}

  /* 26 — Prefers-color-scheme: dark media query
     Modern fingerprinting suites enumerate media query results (color-scheme,
     prefers-reduced-motion, color-gamut, pointer type). Headless Chrome
     without --force-prefers-color-scheme returns 'no-preference' or 'light',
     while real Windows users are split ~50/50 between light/dark. We spoof
     dark mode, which is now the slight majority among tech-oriented shoppers
     and matches our UC flags. */
  try {
    const _origMQ = window.matchMedia.bind(window);
    window.matchMedia = function (query) {
      const mq = _origMQ(query);
      if (/prefers-color-scheme\s*:\s*dark/i.test(query)) {
        return Object.create(mq, { matches: { get: () => true } });
      }
      if (/prefers-color-scheme\s*:\s*light/i.test(query)) {
        return Object.create(mq, { matches: { get: () => false } });
      }
      if (/prefers-reduced-motion\s*:\s*no-preference/i.test(query)) {
        return Object.create(mq, { matches: { get: () => true } });
      }
      return mq;
    };
  } catch (_) {}

  /* 27 — navigator.getGamepads() stub
     Headless Chrome has no gamepad support and may return undefined or throw.
     PerimeterX/DataDome check this API's presence and type. Real Chrome
     returns an empty GamepadList (live snapshot). */
  try {
    if (navigator.getGamepads) {
      const _origGetGamepads = navigator.getGamepads.bind(navigator);
      navigator.getGamepads = function () {
        try { const r = _origGetGamepads(); if (r) return r; } catch (_) {}
        return [null, null, null, null];
      };
    }
  } catch (_) {}

  /* 28 — navigator.keyboard stub
     navigator.keyboard is available in real Chrome but absent in headless.
     Sites using advanced fingerprinting (FingerprintJS Pro 4+) check for it.
     Return a minimal object that passes typeof checks. */
  try {
    if (!navigator.keyboard) {
      Object.defineProperty(navigator, 'keyboard', {
        configurable: true,
        get: () => ({
          lock: () => Promise.resolve(),
          unlock: () => {},
          getLayoutMap: () => Promise.resolve(new Map())
        })
      });
    }
  } catch (_) {}

  /* 29 — navigator.bluetooth stub
     Absent in headless Chrome; its absence is a fingerprint vector. */
  try {
    if (!navigator.bluetooth) {
      Object.defineProperty(navigator, 'bluetooth', {
        configurable: true,
        get: () => ({
          getAvailability: () => Promise.resolve(false),
          requestDevice: () => Promise.reject(new DOMException('User cancelled', 'NotFoundError'))
        })
      });
    }
  } catch (_) {}

  /* 29b — pdfViewerEnabled
     Chrome ships the built-in PDF viewer, so navigator.pdfViewerEnabled is true.
     Headless builds without the PDF extension report false, which contradicts
     the spoofed plugin list above (FingerprintJS Pro cross-checks the two). */
  try {
    Object.defineProperty(navigator, 'pdfViewerEnabled', { get: () => true });
  } catch (_) {}

  /* 30 — navigator.languages derived from profile timezone
     Hardcoded 'en-CA' is wrong for US-timezone profiles (New York / Chicago).
     Match the language list to the profile's geo so the JS API and
     Accept-Language HTTP header tell a consistent story. */
  try {
    const _tz = profile.tz || 'America/Toronto';
    const _langs = _tz.startsWith('America/') && !['America/Toronto','America/Vancouver','America/Montreal','America/Winnipeg','America/Halifax','America/St_Johns'].includes(_tz)
      ? ['en-US', 'en']
      : ['en-CA', 'en-US', 'en'];
    // configurable:true — block 3 deliberately leaves languages alone, but the
    // CDP bootstrap and later navigations re-run this script, so an
    // unconfigurable property would make the second pass throw into the
    // catch below and keep whatever the first pass installed.
    Object.defineProperty(navigator, 'languages', { get: () => _langs, configurable: true });
    /* navigator.language must be languages[0]. Real Chrome derives it that way,
       so it always matches. Leaving it at the launch default while spoofing
       languages produced an en-US profile reporting language 'en-CA' (and the
       reverse) — a one-line coherence check any fingerprinter can run. */
    Object.defineProperty(navigator, 'language', {
      get: () => _langs[0], configurable: true
    });
  } catch (_) {}

  /* 31 — Trusted Types stub
     Chrome 131 ships Trusted Types (spec-compliant). Absence of the
     window.TrustedTypes object or window.trustedTypes is checked by some
     FingerprintJS-based solutions. If not already defined, create a
     minimal pass-through policy factory. */
  try {
    if (!window.trustedTypes && !window.TrustedTypes) {
      window.trustedTypes = {
        createPolicy: (name, rules) => ({ createHTML: (v) => (rules.createHTML ? rules.createHTML(v) : v), createScript: (v) => v, createScriptURL: (v) => v }),
        isHTML: () => false, isScript: () => false, isScriptURL: () => false,
        getAttributeType: () => null, getPropertyType: () => null, getTypeMapping: () => ({})
      };
    }
  } catch (_) {}

  /* 15 — toString defenses */
  // Every function we replaced above must stringify as [native code], otherwise
  // fn.toString().includes('native code') is a one-line detection. Keep this
  // list exhaustive: patched functions not listed here are an instant tell to
  // any fingerprint script that stringifies.
  const safeFns = [
    HTMLCanvasElement.prototype.toDataURL,
    CanvasRenderingContext2D.prototype.getImageData,
    AudioBuffer.prototype.getChannelData,
    WebGLRenderingContext.prototype.getParameter,
    WebGLRenderingContext.prototype.getSupportedExtensions,
    navigator.permissions.query,
    navigator.getGamepads,
    window.matchMedia,
    Element.prototype.attachShadow
  ];
  try { safeFns.push(WebGL2RenderingContext.prototype.getParameter); } catch (_) {}
  try { safeFns.push(WebGL2RenderingContext.prototype.getSupportedExtensions); } catch (_) {}
  try { if (navigator.getBattery) safeFns.push(navigator.getBattery); } catch (_) {}
  try { if (document.fonts?.check) safeFns.push(document.fonts.check); } catch (_) {}
  try { if (window.chrome?.csi) safeFns.push(window.chrome.csi); } catch (_) {}
  try { if (window.chrome?.loadTimes) safeFns.push(window.chrome.loadTimes); } catch (_) {}
  try { if (navigator.userAgentData?.getHighEntropyValues) safeFns.push(navigator.userAgentData.getHighEntropyValues); } catch (_) {}
  try { if (_rtcWrapped) safeFns.push(_rtcWrapped); } catch (_) {}
  // Functions patched by the presence/coherence blocks (7b–7d, 24). These are
  // plain assignment replacements, so without an entry here they stringify as
  // source and read as bot code.
  try { safeFns.push(document.hasFocus); } catch (_) {}
  try { if (navigator.storage?.estimate) safeFns.push(navigator.storage.estimate); } catch (_) {}
  // The mimicked NetworkInformation instance itself, not just its accessors: a
  // patched object whose constructor stringifies as bot code is a tell.
  try {
    const _connProto = Object.getPrototypeOf(navigator.connection || {});
    if (_connProto) safeFns.push(_connProto);
  } catch (_) {}
  const origToString = Function.prototype.toString;
  Function.prototype.toString = function () {
    if (safeFns.includes(this)) return 'function ' + (this.name || '') + '() { [native code] }';
    return origToString.call(this);
  };
})();
`;

// Same TLS posture as the HTTP transports (see helpers/stock-monitor.js). Kept in
// sync via one predicate so the browser and the fetches cannot disagree.
const tlsStrict = () => ['1', 'true'].includes(String(process.env.TLS_VERIFY_STRICT || '').toLowerCase());

export const launchBrowser = async ({ proxy: rawProxy, taskId, siteId = null } = {}) => {
  // Stable per-task fingerprint. First launch picks one and persists; every
  // subsequent launch returns the exact same UA/GPU/canvas/audio seed combo
  // so we look like a returning shopper, not a freshly-rented VM each time.
  const stored = taskId ? await loadOrCreateFingerprint(taskId) : pickProfile();

  // Pin the exit to the retailer's country where the provider supports it. A
  // US-only store (Topps, Pokemon Center) served from a foreign residential exit
  // is an anomaly no fingerprint patching cancels. No-op for other providers.
  const targeting = targetingFor({ siteId, profileTimezone: stored.tz });
  const aimed = applyTargeting(rawProxy, targeting);
  const proxy = aimed.proxy;
  if (aimed.applied) {
    logger.info(`[Proxy] Targeting exit to ${targeting.country || 'gateway default'} for site ${siteId ?? 'unknown'} (${targeting.reason})`);
  }

  // Align the pinned timezone to the actual exit IP when its TZ is known, but
  // never let it leave the retailer's market.
  const profile = alignProfileToExit(
    { ...stored, proxy_exit_tz: proxy?.exit_tz || null },
    { requiredCountry: targeting.country }
  );
  const viewport = profile.viewport || pickViewport();
  const memory = await getMemorySnapshot();

  // Headful where a display exists and the host can carry it. This is the single
  // highest-leverage stealth change available: a real window manager fixes what
  // dozens of property patches can only approximate.
  //
  // Order matters: on Linux the display must be bootstrapped BEFORE the mode is
  // resolved, because resolution reads DISPLAY and would otherwise always answer
  // "no display" on a box that could perfectly well have one.
  if (shouldBootstrapDisplay({
    platform: process.platform,
    env: process.env,
    totalMemoryBytes: memory?.limitBytes || 0
  })) {
    await ensureDisplay();
  }
  const headless = resolveHeadless({
    platform: process.platform,
    env: process.env,
    totalMemoryBytes: memory?.limitBytes || 0
  });
  // Launch args are built by the admission policy module, not inline here, so
  // `--disable-features` is always emitted exactly once (it used to be duplicated
  // by the lightweight block, and Chromium silently dropped the first list).
  const launchArgs = buildChromiumArgs({
    proxy,
    viewport,
    lightweight: LIGHTWEIGHT_TASK_MODE,
    lowRam: isLowRamHost(memory),
    rendererLimit: recommendedRendererLimit({ totalMemoryBytes: memory?.limitBytes || 0 }),
    heapCapMb: recommendedHeapCapMb({ totalMemoryBytes: memory?.limitBytes || 0 }),
    headless,
    extraArgs: ENV_EXTRA_ARGS
  });

  // Resolve a browser that actually exists. The old line was
  // `env || '/usr/bin/chromium'` with no check, so on Windows/macOS the fallback
  // was a Linux path and every launch died with ENOENT instead of saying why.
  // resolveChromiumPath also picks up a bootstrap-downloaded Chrome.
  const execPath = resolveChromiumPath().path;
  if (!execPath) {
    throw new Error(
      'No Chrome/Chromium binary found. Set PUPPETEER_EXECUTABLE_PATH, or let the '
      + 'launcher bootstrap one (BOOTSTRAP_DISABLE=0).'
    );
  }

  // Persistent profile dir per task — preserves cookies, Cloudflare/Imperva
  // clearance tokens, and HTTP cache between attempts.
  const userDataDir = taskId ? profileDirFor(taskId) : undefined;

  const browser = await puppeteerExtra.launch({
    headless,
    executablePath: execPath,
    args: launchArgs,
    // Same switch as the HTTP paths: browsers and fetches must agree, otherwise a
    // strict-fetch/permissive-browser split produces confusing half-failures.
    ignoreHTTPSErrors: !tlsStrict(),
    // Under headful the real window (minus chrome) is the viewport, and passing
    // defaultViewport would resize it and reintroduce the mismatch. `null` keeps
    // the OS-managed size, which is exactly the story the stealth script tells.
    defaultViewport: headless ? viewport : null,
    userDataDir,
    ignoreDefaultArgs: ['--enable-automation', '--enable-blink-features=IdleDetection']
  });

  browser._fingerprintProfile = profile;
  browser._viewport = viewport;
  browser._headless = headless;

  logger.info(`[Browser] Launched — ${headless ? 'headless' : 'headful'} profile: ${profile.platform} Chrome/${profile.chromeVer} (${profile.cores}c/${profile.mem}GB) ${profile.gpu}`);
  return browser;
};

import { applyGeoConsistency, getGeoForTimezone, alignProfileToExit } from './geo-consistency.js';
import { screenGeometry } from './fingerprint-coherence.js';
import { brandVersionList, secChUa, secChUaFullVersionList } from './client-hints.js';

export const getNewPage = async ({ browser, context = null, proxy, role = 'checkout', taskId = null }) => {
  const storedProfile = taskId ? await loadOrCreateFingerprint(taskId) : (browser._fingerprintProfile || pickProfile());
  // Attach the derived screen geometry so the stealth script exposes one
  // consistent screen/viewport/dpr story instead of a hardcoded monitor, and
  // align the timezone to the exit IP when it is known.
  const profile = alignProfileToExit({
    ...storedProfile,
    geo: screenGeometry(storedProfile),
    // Client-hint brand lists are derived once here and consumed by BOTH the
    // in-page userAgentData spoof and the Sec-Ch-Ua headers below, so the two
    // views of the same identity are identical by construction.
    brands: brandVersionList(storedProfile.chromeVer),
    brandsFull: brandVersionList(storedProfile.chromeVer, { fullVersion: storedProfile.fullVer }),
    proxy_exit_tz: proxy?.exit_tz || storedProfile.proxy_exit_tz || null
  });
  const stealthScript = buildStealthScript(profile);
  const geo = getGeoForTimezone(profile.tz);

  const page = context ? await context.newPage() : await browser.newPage();
  page._fingerprintProfile = profile;
  page._geo = geo;
  // Captcha solvers need the exit and UA this page was built with, so the token
  // is born on the identity that will submit it. Stashed because guard helpers
  // are often called without the proxy in scope.
  page._proxyInfo = proxy || null;
  page._uaOverride = profile.ua || null;
  await page.setCacheEnabled(true).catch(() => {});

  try {
    const cdp = await page.target().createCDPSession();

    // PROXY PRE-AUTH via CDP Fetch interception. Legacy page.authenticate()
    // arms credentials only AFTER the first request fires, leaving a race
    // window where Imperva/Cloudflare can see the auth challenge before we
    // respond. We intercept at Fetch.enable level so credentials are present
    // from request #1, then disable Fetch entirely ~2s after the first auth
    // round-trip completes — keeps the pre-challenge window protected without
    // paying CDP round-trip latency on every asset for the rest of the session.
    if (proxy?.username) {
      let authResolved = false;
      await cdp.send('Fetch.enable', { handleAuthRequests: true, patterns: [{ urlPattern: '*' }] });
      // Edge-case safety net: if the proxy never issues an auth challenge
      // (some upstreams whitelist by IP), still tear down Fetch after 10s
      // so we don't pay CDP latency forever.
      const fallbackDisable = setTimeout(() => {
        if (!authResolved) {
          authResolved = true;
          cdp.send('Fetch.disable').catch(() => {});
        }
      }, 10_000);
      cdp.on('Fetch.requestPaused', async ({ requestId }) => {
        try { await cdp.send('Fetch.continueRequest', { requestId }); } catch (_) {}
      });
      cdp.on('Fetch.authRequired', async ({ requestId }) => {
        try {
          await cdp.send('Fetch.continueWithAuth', {
            requestId,
            authChallengeResponse: {
              response: 'ProvideCredentials',
              username: proxy.username,
              password: proxy.password
            }
          });
          if (!authResolved) {
            authResolved = true;
            clearTimeout(fallbackDisable);
            // Tear down interception ~2s after first successful auth so the
            // page handles all subsequent requests at native speed.
            setTimeout(() => {
              cdp.send('Fetch.disable').catch(() => {});
            }, 2000);
          }
        } catch (_) {}
      });
    }

    if (proxy?.proxy_type === 'residential') {
      // Track encoded response traffic for the monthly residential budget.
      // We enable this only on residential sessions so normal/direct sessions
      // pay no CDP monitoring overhead.
      try {
        await cdp.send('Network.enable');
        let pendingBytes = 0;
        let flushTimer = null;
        const flush = () => {
          flushTimer = null;
          if (pendingBytes > 0) {
            const bytes = pendingBytes;
            pendingBytes = 0;
            recordResidentialBytes(bytes + 4096, role);
          }
        };
        cdp.on('Network.loadingFinished', ({ encodedDataLength = 0 }) => {
          pendingBytes += Math.max(0, Number(encodedDataLength) || 0);
          if (!flushTimer) {
            flushTimer = setTimeout(flush, 2000);
            flushTimer.unref?.();
          }
        });
        page.once('close', flush);
      } catch (meterErr) {
        logger.debug(`[Browser] Residential bandwidth metering unavailable: ${meterErr.message}`);
      }
    }

    await cdp.send('Page.addScriptToEvaluateOnNewDocument', { source: stealthScript });
    await cdp.send('Network.setExtraHTTPHeaders', {
      headers: {
        // Accept-Language now derived from the profile's geo, not hardcoded
        // en-CA. A Vancouver fingerprint with US Accept-Language is a tell.
        'Accept-Language': geo.acceptLang,
        // Built from the same brand lists as the JS spoof (client-hints.js) so
        // the GREASE brand and the ordering match what Chrome 131 actually
        // sends for this major version.
        'Sec-Ch-Ua': secChUa(profile.chromeVer),
        'Sec-Ch-Ua-Full-Version-List': secChUaFullVersionList(profile.chromeVer, profile.fullVer),
        'Sec-Ch-Ua-Mobile': profile.mobile,
        'Sec-Ch-Ua-Platform': profile.platform,
        'Sec-Ch-Ua-Platform-Version': profile.platformVer,
        'Sec-Ch-Ua-Arch': profile.arch,
        'Sec-Ch-Ua-Bitness': profile.bitness,
        'Sec-Ch-Ua-Model': profile.model,
        'Sec-Ch-Ua-Wow64': '?0'
      }
    });
    await cdp.send('Emulation.setTimezoneOverride', { timezoneId: profile.tz });
    await applyGeoConsistency({ cdp, page, profile });

    try {
      await cdp.send('Page.addScriptToEvaluateOnNewDocument', {
        source: `
          // The stealth script (evaluateOnNewDocument below) installs a
          // prototype-level webdriver=false. This used to also
          // \`delete navigator.__proto__.webdriver\`, which removed that property
          // outright, so 'webdriver' in navigator went false — real Chrome
          // always has it. Left in place it would delete ours on every
          // navigation, so only re-add it when the runtime genuinely has none.
          if (!('webdriver' in navigator)) {
            Object.defineProperty(Navigator.prototype, 'webdriver', { get: () => false, configurable: true });
          }
          if (window.cdc_adoQpoasnfa76pfcZLmcfl_Array) delete window.cdc_adoQpoasnfa76pfcZLmcfl_Array;
          if (window.cdc_adoQpoasnfa76pfcZLmcfl_Promise) delete window.cdc_adoQpoasnfa76pfcZLmcfl_Promise;
          if (window.cdc_adoQpoasnfa76pfcZLmcfl_Symbol) delete window.cdc_adoQpoasnfa76pfcZLmcfl_Symbol;
          Object.defineProperty(document, 'hidden', { get: () => false });
          Object.defineProperty(document, 'visibilityState', { get: () => 'visible' });
        `
      });
    } catch (_) {}
  } catch (err) {
    logger.warn(`[Browser] CDP setup warning: ${err.message}`);
  }

  await page.evaluateOnNewDocument(stealthScript);
  await page.setUserAgent(profile.ua);

  // Belt-and-suspenders: keep page.authenticate as fallback in case Fetch
  // interception is rejected by the proxy (some upstream proxies refuse
  // CDP-style credential injection and require the legacy 407 dance).
  if (proxy?.username) {
    await page.authenticate({ username: proxy.username, password: proxy.password }).catch(() => {});
  }

  logger.info(`[Browser] Page ready — UA: Chrome/${profile.chromeVer} | TZ: ${profile.tz} | Geo: ${geo.lat.toFixed(2)},${geo.lng.toFixed(2)} ${geo.locale}`);

  const headful = browser._headless === false;
  // Under headful, make focus and visibility TRUE instead of merely consistent.
  // Bring the window forward before anything reads them so the browser reports
  // the real state; the stealth patch remains as the fallback.
  if (headful) await bringToFront(page);

  // Self-check the stealth surface. Skipped under headless (where the known
  // headless tells are expected and would only add noise), and sampled so it
  // costs two round trips on a fraction of pages, not every one. A failing audit
  // logs and carries on — it must never block a checkout.
  if (headful && STEALTH_AUDIT_SAMPLE > 0 && Math.random() < STEALTH_AUDIT_SAMPLE) {
    await compareWorlds(page);
    await auditPage(page);
  }
  return page;
};

/**
 * Probe the stealth surface from an ISOLATED WORLD as well as the main world.
 *
 * This is the layer that was missing entirely: every patch lives in the main
 * world, so a script running in a separate context (or one that stashed a native
 * reference before our script ran) sees the UNPATCHED values. A diff between the
 * two worlds is therefore the sharpest available tell, and until now nothing
 * measured it.
 *
 * Reports only: reconciliation is not automatic, because forcing the worlds to
 * agree blindly would break the legitimate per-profile values.
 *
 * Never throws.
 */
export const compareWorlds = async (page) => {
  try {
    const { SURFACE_PROBE, compareSamples } = await import('./fingerprint-audit.js');
    const main = await page.evaluate(SURFACE_PROBE).catch(() => null);
    const isolated = await page.evaluateInIsolatedWorld(SURFACE_PROBE).catch(() => null);
    const issues = compareSamples([main, isolated]);
    if (issues.length) {
      const summary = issues.map((i) => `${i.field}:${i.values.join('/')}`).join(' ');
      logger.warn(`[StealthAudit] main and isolated worlds disagree — ${summary}`);
    }
    return { ok: issues.length === 0, issues };
  } catch (err) {
    logger.warn(`[StealthAudit] world comparison failed: ${err.message}`);
    return { ok: true, issues: [] };
  }
};

/**
 * Sample the stealth surface twice and report drift + implausibilities.
 *
 * The audit module can only describe problems; nothing was calling it, so a
 * regression could still ship silently. This is the missing trigger.
 *
 * Two samples are taken with a short gap so a value that is re-randomised on every
 * READ (the original connection.rtt bug) shows up. A reload would also catch
 * per-launch randomness but costs seconds, so it is opt-in via `reload`.
 *
 * Never throws: an audit failure must not break a checkout.
 */
export const auditPage = async (page, { reload = false } = {}) => {
  try {
    const { SURFACE_PROBE, auditSamples } = await import('./fingerprint-audit.js');
    const first = await page.evaluate(SURFACE_PROBE).catch(() => null);
    if (reload) await page.reload({ waitUntil: 'domcontentloaded' }).catch(() => {});
    await new Promise((r) => setTimeout(r, 60));
    const second = await page.evaluate(SURFACE_PROBE).catch(() => null);
    const report = auditSamples([first, second].filter(Boolean));
    if (!report.ok) {
      const summary = report.issues.map((i) => `${i.field}:${i.values.join('/')}`).join(' ');
      logger.warn(`[StealthAudit] ${report.issues.length} issue(s) — ${summary}`);
    }
    return report;
  } catch (err) {
    logger.warn(`[StealthAudit] audit failed: ${err.message}`);
    return { ok: true, samples: 0, issues: [] };
  }
};

export { pickProfile };
