export const SITE_CHECKOUT_CONTRACTS = {
  "amazon": {
    "final": "placeOrder",
    "required": "saved account address/payment"
  },
  "bestbuy": {
    "final": "placeOrder",
    "required": [
      "shipping",
      "payment",
      "billing"
    ]
  },
  "demandware": {
    "final": "placeOrder",
    "required": [
      "shipping",
      "payment"
    ]
  },
  "footsites": {
    "final": "placeOrder",
    "required": [
      "shipping",
      "payment"
    ]
  },
  "gamestop": {
    "final": "placeOrder",
    "required": [
      "shipping",
      "payment"
    ]
  },
  "nike": {
    "final": "placeOrder",
    "required": [
      "shipping",
      "payment"
    ]
  },
  "pokemoncenter": {
    "final": "placeOrder",
    "required": [
      "shipping",
      "payment"
    ]
  },
  "shopify": {
    "final": "completeOrder",
    "required": [
      "contact",
      "shipping",
      "payment"
    ]
  },
  "supremenewyork": {
    "final": "submitOrder",
    "required": [
      "shipping",
      "payment"
    ]
  },
  "target": {
    "final": "placeOrderButton",
    "required": [
      "shipping",
      "payment"
    ]
  },
  "topps": {
    "final": "placeOrder",
    "required": [
      "shipping",
      "payment"
    ]
  },
  "walmart": {
    "final": "placeOrder",
    "required": [
      "shipping",
      "payment"
    ]
  }
};
export const getSiteCheckoutContract = (siteName) => SITE_CHECKOUT_CONTRACTS[String(siteName || '').toLowerCase()] || null;
