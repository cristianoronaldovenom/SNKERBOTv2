// Fingerprint coherence validation + repair.
//
// Why this exists (the tell we were leaking):
// fingerprint-store.js pins ONE identity per task and reuses it forever. That is
// correct behaviour for returning-shopper continuity — but it also means a
// single bad pick is reused byte-for-byte until the task is rotated. Worse, the
// stealth script derives some JS-visible values from the profile and hardcodes
// others, so a "coherent" profile can still render an incoherent browser:
//
//   * a pinned macOS/Apple-M1 profile used to inherit a hardcoded
//     1920x1080 screen, a Windows ANGLE/D3D11 renderer, and no dpr.
//   * viewports were drawn independently of screen size, so screen.width could
//     be SMALLER than the window (physically impossible).
//   * deviceMemory/hardwareConcurrency were free variables, so a "budget
//     laptop" profile could claim 32 GB and 16 cores.
//
// Imperva, DataDome, PerimeterX and FingerprintJS Pro all score these pairwise
// contradictions directly, and each one alone is enough to downscore the
// session before any page JS even runs.
//
// This module is deliberately dependency-free and pure so it can be exercised
// by tests without a browser. It has three jobs:
//   1. validate()  — report every contradiction as structured issues
//   2. repair()    — fix contradictions in place WITHOUT discarding the pinned
//                    canvas/audio/font seeds (so the task still looks like the
//                    same device, just a correctly-configured one)
//   3. deriveScreenMetrics() — the single source of truth for screen/viewport/
//                    dpr pairing, used both at generation time and by repair

// Plausible-per-platform hardware. Ordered most-common first; generation picks
// by seed so two tasks on the same host do not converge on one machine.
const PLATFORM_HARDWARE = Object.freeze({
  Windows: Object.freeze([
    { cores: 8, mem: 8, gpu: 'Intel(R) UHD Graphics 620', dprChoices: [1, 1.25] },
    { cores: 12, mem: 16, gpu: 'NVIDIA GeForce GTX 1660', dprChoices: [1] },
    { cores: 6, mem: 8, gpu: 'AMD Radeon RX 580', dprChoices: [1, 1.25] },
    { cores: 16, mem: 32, gpu: 'NVIDIA GeForce RTX 3060', dprChoices: [1] },
    { cores: 4, mem: 4, gpu: 'Intel(R) HD Graphics 4000', dprChoices: [1] }
  ]),
  macOS: Object.freeze([
    { cores: 8, mem: 8, gpu: 'Apple M1', dprChoices: [2, 1.5] },
    { cores: 10, mem: 16, gpu: 'Apple M2 Pro', dprChoices: [2] },
    { cores: 12, mem: 24, gpu: 'Apple M3 Pro', dprChoices: [2] }
  ])
});

// Physical monitor sizes as (screen, viewport) pairs. A real browser never has a
// window larger than the screen, and the leftover is browser chrome — roughly
// 90-120px of vertical on a maximised real session. Every pair here is derived
// so viewport always fits inside screen.
const SCREEN_CATALOG = Object.freeze({
  Windows: Object.freeze([
    { screen: { width: 1920, height: 1080 }, viewport: { width: 1600, height: 900 } },
    { screen: { width: 1920, height: 1080 }, viewport: { width: 1536, height: 864 } },
    { screen: { width: 2560, height: 1440 }, viewport: { width: 1920, height: 1080 } },
    { screen: { width: 1366, height: 768 }, viewport: { width: 1366, height: 657 } },
    { screen: { width: 1600, height: 900 }, viewport: { width: 1440, height: 780 } }
  ]),
  macOS: Object.freeze([
    // Retina: CSS pixels are halved relative to the physical panel.
    { screen: { width: 1512, height: 982 }, viewport: { width: 1470, height: 860 }, dpr: 2 },
    { screen: { width: 1440, height: 900 }, viewport: { width: 1400, height: 800 }, dpr: 2 },
    { screen: { width: 1728, height: 1117 }, viewport: { width: 1680, height: 980 }, dpr: 2 }
  ])
});

const PLAUSIBLE_CORES = new Set([2, 4, 6, 8, 10, 12, 16, 24]);
const PLAUSIBLE_MEM = new Set([2, 4, 8, 16, 24, 32]);
const PLAUSIBLE_DPR = new Set([1, 1.25, 1.5, 2, 3]);

// Browser chrome height. Windows Chrome is beefier than macOS; both are far
// below any viewport we pair, by construction above.
const CHROME_UI_HEIGHT = 90;

export const platformOf = (profile) => {
  const token = String(profile?.platform || '').replace(/"/g, '');
  if (token === 'macOS' || token === 'MacIntel') return 'macOS';
  if (token === 'Windows') return 'Windows';
  return null;
};

const uaPlatformOf = (ua) => {
  const s = String(ua || '');
  if (/Macintosh|Mac OS X/.test(s)) return 'macOS';
  if (/Windows NT/.test(s)) return 'Windows';
  if (/Android/.test(s)) return 'Android';
  if (/Linux/.test(s)) return 'Linux';
};

// ANGLE renderer strings must name the platform-appropriate graphics backend.
const windowsVendorOf = (gpu) => {
  if (!/Intel|NVIDIA|AMD|Radeon|GeForce|UHD|HD Graphics/i.test(String(gpu || ''))) return null;
  if (/NVIDIA|GeForce|RTX|GTX/i.test(gpu)) return 'NVIDIA';
  if (/AMD|Radeon/i.test(gpu)) return 'AMD';
  return 'Intel';
};

const rendererMatchesPlatform = (profile, platform) => {
  const gpu = String(profile?.gpu || '');
  const renderer = String(profile?.webglRenderer || '');
  if (!renderer) return false;
  if (platform === 'macOS') {
    // Apple silicon reports an ANGLE-on-Metal backend, never D3D11.
    if (/D3D11|Direct3D/i.test(renderer)) return false;
    return /ANGLE \(Apple/i.test(renderer) || /^Apple M/.test(gpu);
  }
  if (platform === 'Windows') {
    if (/Apple M/i.test(gpu)) return false;
    return /D3D11|Direct3D/i.test(renderer) && Boolean(windowsVendorOf(gpu));
  }
  return true;
};

// Build the WebGL renderer string the way real ANGLE reports it. Chrome on
// Windows always ships the `ANGLE (vendor, device, D3D11 vs_5_0 ps_5_0, D3D11)`
// shape; Apple silicon reports the ANGLE-on-Metal shape.
export const rendererFor = (platform, gpu) => {
  const device = gpu || (platform === 'macOS' ? 'Apple M1' : 'Intel(R) UHD Graphics 620');
  if (platform === 'macOS') return `ANGLE (Apple, ${device}, Metal)`;
  return `ANGLE (${windowsVendorOf(device) || 'Intel'}, ${device} Direct3D11 vs_5_0 ps_5_0, D3D11)`;
};

// Pixel-weight of a monitor pair, used to rank catalog entries for a RAM budget.
// Compositor and renderer cost scale with area, so this is the right axis to
// trade against memory rather than, say, slightly smaller font metrics.
const pixelWeight = (entry) => entry.screen.width * entry.screen.height;

// Catalog entries ranked lightest-first, computed once.
const CATALOG_BY_WEIGHT = Object.fromEntries(
  Object.entries(SCREEN_CATALOG).map(([platform, list]) => [
    platform,
    [...list].sort((a, b) => pixelWeight(a) - pixelWeight(b))
  ])
);

// Derive the screen/viewport/dpr triad from a seed so the trio is coherent by
// construction. Returns a new object — never mutates the input.
//
// `sizeBias` 0..1 requests a LIGHTER monitor; it only ever selects among the
// lighter half of the catalog, never below the lightest, and the viewport still
// fits inside the screen because the pairs are precomputed as pairs. A tighter
// viewport is a real RAM saving: fewer composited pixels and no layout reflow of
// a wide grid, and 1366x768 is a completely ordinary laptop that the fingerprint
// already considers plausible.
export const deriveScreenMetrics = (platform, seed, { sizeBias = 0 } = {}) => {
  const full = SCREEN_CATALOG[platform] || SCREEN_CATALOG.Windows;
  const bias = Math.min(1, Math.max(0, Number(sizeBias) || 0));
  // Keep at least one entry regardless of how extreme the bias is.
  const usable = bias > 0
    ? (CATALOG_BY_WEIGHT[platform] || full).slice(0, Math.max(1, Math.ceil(full.length * (1 - bias))))
    : full;
  const pick = usable[Math.abs(seed | 0) % usable.length];
  const hardware = PLATFORM_HARDWARE[platform] || PLATFORM_HARDWARE.Windows;
  const hw = hardware[Math.abs((seed >> 3) | 0) % hardware.length];
  return {
    screen: { ...pick.screen },
    viewport: { ...pick.viewport },
    dpr: pick.dpr || hw.dprChoices[Math.abs((seed >> 5) | 0) % hw.dprChoices.length]
  };
};

// Map a host memory ceiling to a size bias. Only small boxes get a small monitor;
// an 8 GB host should still look like a normal desktop.
export const sizeBiasForHost = (totalMemoryBytes = 0) => {
  const gb = Number(totalMemoryBytes) / (1024 ** 3);
  if (!Number.isFinite(gb) || gb <= 0) return 0;
  if (gb <= 1) return 1;
  if (gb <= 2) return 0.75;
  if (gb <= 3) return 0.5;
  return 0;
};

// Report every pairwise contradiction. Empty array == coherent fingerprint.
export const validate = (profile) => {
  const issues = [];
  if (!profile || typeof profile !== 'object') {
    return [{ field: 'profile', detail: 'missing profile object', severity: 'fatal' }];
  }

  const platform = platformOf(profile);
  if (!platform) {
    issues.push({ field: 'platform', detail: `unsupported platform ${JSON.stringify(profile.platform)}`, severity: 'fatal' });
  }

  const uaPlatform = uaPlatformOf(profile.ua);
  if (platform && uaPlatform && platform !== uaPlatform) {
    issues.push({ field: 'ua', detail: `UA says ${uaPlatform} but platform token says ${platform}`, severity: 'fatal' });
  }
  if (!uaPlatform) {
    issues.push({ field: 'ua', detail: 'UA has no recognisable platform token', severity: 'fatal' });
  } else if (platform === 'macOS' && /Intel Mac OS X 1[0-9]_/.test(String(profile.ua)) === false) {
    issues.push({ field: 'ua', detail: 'macOS UA missing standard Intel Mac OS X token', severity: 'warn' });
  }

  if (profile.chromeVer && !String(profile.ua || '').includes(`Chrome/${profile.chromeVer}.`)) {
    issues.push({
      field: 'chromeVer',
      detail: `chromeVer ${profile.chromeVer} does not appear in UA (engine/UA version mismatch)`,
      severity: 'fatal'
    });
  }
  if (profile.fullVer && profile.chromeVer && !String(profile.fullVer).startsWith(`${profile.chromeVer}.`)) {
    issues.push({
      field: 'fullVer',
      detail: `fullVer ${profile.fullVer} does not start with major ${profile.chromeVer}`,
      severity: 'fatal'
    });
  }

  if (!PLAUSIBLE_CORES.has(Number(profile.cores))) {
    issues.push({ field: 'cores', detail: `implausible hardwareConcurrency ${profile.cores}`, severity: 'warn' });
  }
  if (!PLAUSIBLE_MEM.has(Number(profile.mem))) {
    issues.push({ field: 'mem', detail: `implausible deviceMemory ${profile.mem}`, severity: 'warn' });
  }
  if (profile.dpr != null && !PLAUSIBLE_DPR.has(Number(profile.dpr))) {
    issues.push({ field: 'dpr', detail: `implausible devicePixelRatio ${profile.dpr}`, severity: 'warn' });
  }

  if (platform && !rendererMatchesPlatform(profile, platform)) {
    issues.push({
      field: 'webglRenderer',
      detail: `renderer ${JSON.stringify(profile.webglRenderer || '')} inconsistent with ${platform} GPU ${JSON.stringify(profile.gpu || '')}`,
      severity: 'fatal'
    });
  }

  const sw = Number(profile.screen?.width);
  const sh = Number(profile.screen?.height);
  const vw = Number(profile.viewport?.width);
  const vh = Number(profile.viewport?.height);
  if (!sw || !sh) issues.push({ field: 'screen', detail: 'missing screen dimensions', severity: 'fatal' });
  if (!vw || !vh) issues.push({ field: 'viewport', detail: 'missing viewport dimensions', severity: 'fatal' });
  if (sw && sh && vw && vh) {
    if (vw > sw || vh > sh) {
      issues.push({
        field: 'viewport',
        detail: `viewport ${vw}x${vh} larger than screen ${sw}x${sh}`,
        severity: 'fatal'
      });
    } else if (sh - vh < 40) {
      // A window with no vertical headroom cannot have any browser chrome.
      issues.push({ field: 'viewport', detail: `viewport leaves only ${sh - vh}px for browser chrome`, severity: 'fatal' });
    } else if (sh - vh > 400) {
      // A maximised-looking session should not leave 400+px of headroom below.
      issues.push({ field: 'viewport', detail: `viewport leaves ${sh - vh}px vertical headroom`, severity: 'warn' });
    }
  }

  if (platform === 'macOS' && profile.dpr != null && Number(profile.dpr) < 1.5) {
    issues.push({ field: 'dpr', detail: `macOS profile with non-Retina dpr ${profile.dpr}`, severity: 'warn' });
  }

  if (!profile.tz) issues.push({ field: 'tz', detail: 'missing timezone', severity: 'fatal' });
  if (!profile.vendor) issues.push({ field: 'vendor', detail: 'missing navigator.vendor', severity: 'warn' });
  else if (profile.vendor !== 'Google Inc.') {
    issues.push({ field: 'vendor', detail: `vendor ${profile.vendor} is not Chrome's`, severity: 'warn' });
  }
  if (!profile.fontSeed) issues.push({ field: 'fontSeed', detail: 'missing font set seed', severity: 'warn' });

  return issues;
};

export const isCoherent = (profile) => validate(profile).every((i) => i.severity !== 'fatal');


// Repair contradictions while preserving device identity signals.
//
// Only hardware/screen/UA-version fields are rewritten. The canvas/audio/font
// seeds, tz and pinnedAt are intentionally preserved: those are what make the
// task look like the *same* returning device, and none of them can be
// contradicted by another field.
export const repair = (profile, { seed = 1 } = {}) => {
  const issues = validate(profile);
  if (issues.length === 0) return { profile, changed: [], issues };

  const next = { ...profile };
  const changed = [];
  const platform = platformOf(next) || 'Windows';
  const fields = new Set(issues.map((i) => i.field));

  const fix = (field, value) => {
    if (JSON.stringify(next[field]) === JSON.stringify(value)) return;
    next[field] = value;
    changed.push(field);
  };

  // UA / platform coherence: the platform token wins, the UA is rebuilt from it.
  if (fields.has('ua') || fields.has('platform')) {
    const major = String(next.chromeVer || '131').replace(/[^\d]/g, '') || '131';
    next.platform = platform === 'macOS' ? '"macOS"' : '"Windows"';
    next.ua = platform === 'macOS'
      ? `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${major}.0.0.0 Safari/537.36`
      : `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${major}.0.0.0 Safari/537.36`;
    fix('platformVer', platform === 'macOS' ? '"14.5.0"' : '"15.0.0"');
    fix('arch', platform === 'macOS' ? '"arm"' : '"x86"');
    fix('bitness', '"64"');
    changed.push('ua', 'platform');
  }

  if (fields.has('chromeVer') || fields.has('fullVer')) {
    const major = String(next.chromeVer || '131').replace(/[^\d]/g, '') || '131';
    fix('chromeVer', major);
    fix('fullVer', next.fullVer && String(next.fullVer).startsWith(`${major}.`) ? next.fullVer : `${major}.0.0.0`);
  }

  // Hardware: pull a coherent bundle for the platform instead of patching the
  // individual numbers, so cores/mem/gpu cannot drift apart again.
  const hardware = PLATFORM_HARDWARE[platform] || PLATFORM_HARDWARE.Windows;
  if (fields.has('cores') || fields.has('mem') || fields.has('webglRenderer')) {
    const hw = hardware[Math.abs(seed | 0) % hardware.length];
    fix('cores', hw.cores);
    fix('mem', hw.mem);
    fix('gpu', hw.gpu);
    fix('webglVendor', platform === 'macOS' ? 'Google Inc. (Apple)' : 'Google Inc. (Intel)');
    fix('webglRenderer', rendererFor(platform, hw.gpu));
  }

  // Screen/viewport/dpr: re-derive the triad together when any member is bad.
  if (fields.has('screen') || fields.has('viewport') || fields.has('dpr') || fields.has('webglRenderer')) {
    const metrics = deriveScreenMetrics(platform, seed);
    if (fields.has('screen') || fields.has('viewport')) {
      fix('screen', metrics.screen);
      fix('viewport', metrics.viewport);
    }
    fix('dpr', metrics.dpr);
  }

  if (fields.has('vendor')) fix('vendor', 'Google Inc.');
  if (fields.has('fontSeed') || !next.fontSeed) fix('fontSeed', Math.abs(seed) % 1_000_000_000);
  if (!next.audioSeed) fix('audioSeed', Math.abs((seed >> 2) | 0) % 1_000_000_000);
  if (!next.canvasSeed) fix('canvasSeed', Math.abs((seed >> 4) | 0) % 1_000_000_000);

  return { profile: next, changed: [...new Set(changed)], issues };
};

// Geometry the stealth script must expose consistently. Keeping this in one
// place stops the script hardcoding a 1920x1080 screen for every profile.
export const screenGeometry = (profile) => {
  const screen = profile.screen || { width: 1920, height: 1080 };
  const viewport = profile.viewport || { width: 1600, height: 900 };
  // A macOS desktop reserves the menu bar at the TOP, so a maximised window
  // starts below it (availTop/screenY > 0) while Windows reserves a taskbar at
  // the BOTTOM and reports availTop = 0. Headless reports 0 for all four on
  // every platform, which is a clean tell on a macOS profile and the reason
  // these are derived here rather than left to the browser.
  const menuBar = profile.platform === 'macOS' ? 25 : 0;
  return {
    screenWidth: screen.width,
    screenHeight: screen.height,
    availWidth: screen.width,
    // Real maximised windows lose the OS chrome from the *available* height.
    availHeight: Math.max(viewport.height, screen.height - CHROME_UI_HEIGHT),
    availTop: menuBar,
    availLeft: 0,
    // A maximised window is pinned to the work area origin.
    screenX: 0,
    screenY: menuBar,
    // 16px of side chrome, but never wider than the physical panel.
    outerWidth: Math.min(screen.width, viewport.width + 16),
    outerHeight: viewport.height + CHROME_UI_HEIGHT,
    innerWidth: viewport.width,
    innerHeight: viewport.height,
    dpr: profile.dpr || 1,
    colorDepth: 24
  };
};

export const __internals = { PLATFORM_HARDWARE, SCREEN_CATALOG, uaPlatformOf, windowsVendorOf };

