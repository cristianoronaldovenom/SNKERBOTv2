// Request-first checkout engine — router + browser fallback.
// Generic Shopify is wired into the live monitor hot path for cart + checkout-open.
// Final payment/order submission stays in the dedicated browser adapter.
import db from '../../db/index.js';
import { getSessionCookies } from '../stock-monitor.js';
import { prefillShopifyCheckout, tokenizeCard, classifyShopifyResponse } from './shopify.js';

// Site_ids whose CHECKOUT adapter speaks the Shopify HTTP contract. Only generic
// Shopify (2) today — Topps (7) reads Shopify JSON but checks out on SFCC.
const SHOPIFY_SITE_IDS = new Set([2]);

const truthy = (v) => v === true || v === 'true' || v === '1' || v === 1;

// Feature gate. Defaults to false (disabled) on any read error. Cache briefly
// because the gate can be consulted on every retry of a checkout.
let requestModeCache = { value: false, expiresAt: 0 };
const REQUEST_MODE_TTL_MS = 5000;
export const requestModeEnabled = async () => {
  const now = Date.now();
  if (requestModeCache.expiresAt > now) return requestModeCache.value;
  try {
    const r = await db('settings').where({ key: 'request_mode_enabled' }).first();
    requestModeCache.value = truthy(r?.value);
  } catch (_) {
    requestModeCache.value = false;
  }
  requestModeCache.expiresAt = now + REQUEST_MODE_TTL_MS;
  return requestModeCache.value;
};

export const isRequestModeSupported = (siteId) => SHOPIFY_SITE_IDS.has(Number(siteId));

// Live request-first preparation. This never submits the final order; it only
// creates the cart and opens checkout so Chromium can take over with the same
// cookie jar and checkout URL. Always resolves.
export const prepareRequestCheckout = async ({ task, proxy = null } = {}) => {
  return tryRequestCheckout({ task, proxy, dryRun: false });
};

// Attempt to advance the checkout over plain HTTP before the browser launches.
// dryRun (default) is fully read-only. Always resolves.
export const tryRequestCheckout = async ({ task, proxy = null, dryRun = true } = {}) => {
  try {
    if (!task?.url) return { ok: false, reason: 'no url' };
    if (!isRequestModeSupported(task.site_id)) return { ok: false, reason: `site_id ${task.site_id} unsupported` };

    let host;
    try { host = new URL(task.url).hostname; } catch (_) { return { ok: false, reason: 'bad url' }; }

    const cookieHeader = getSessionCookies(host) || '';
    return await prefillShopifyCheckout({ task, proxy, cookieHeader, dryRun });
  } catch (err) {
    return { ok: false, reason: err.message };
  }
};

export { tokenizeCard, classifyShopifyResponse };
