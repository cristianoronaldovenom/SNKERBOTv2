// Captcha pre-solve arming.
//
// The regression this guards: the stockpile only helped a SECOND solve in one task, but
// a drop usually needs exactly one — so the cache was empty when it mattered. Arming on
// first sight of a sitekey means tokens are being minted while the user browses.
//
// The budget invariants are as important as the latency win: arming is idempotent per
// sitekey, deposits are capped so a hot loop cannot burn paid credit, and an idle
// sitekey is disarmed rather than solving all day.
import { afterEach, beforeEach, describe, expect, jest, test } from '@jest/globals';

jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));

const pile = await import('../../helpers/token-stockpile.js');

// The reaper runs on real timers, so use a short idle window via env instead of fake
// timers (which do not reliably reach intervals created inside an ESM module).
const loadArm = async (idleMs) => {
  process.env.CAPTCHA_ARM_IDLE_MS = String(idleMs);
  jest.resetModules();
  return import('../../helpers/captcha-arm.js');
};

let arm;
const KEY = '0x4AAAAAAA-dummy-key-0000000000';
const opts = () => ({ type: 'turnstile', siteKey: KEY, pageUrl: 'https://x.test/p', targetDepth: 2 });

beforeEach(async () => {
  process.env.CAPTCHA_ARM_IDLE_MS = '1500';
  jest.resetModules();
  arm = await import('../../helpers/captcha-arm.js');
  arm.__resetArmed();
  pile.__resetForTests();
});
afterEach(() => {
  arm.__resetArmed();
  delete process.env.CAPTCHA_ARM_IDLE_MS;
});

describe('arming', () => {
  test('arming is idempotent — one loop per sitekey', () => {
    arm.armForSiteKey(opts());
    expect(arm.armedSiteKeys()).toHaveLength(1);
    arm.armForSiteKey(opts());
    expect(arm.armedSiteKeys()).toHaveLength(1);
  });

  test('different sitekeys arm separately', () => {
    arm.armForSiteKey(opts());
    arm.armForSiteKey({ ...opts(), siteKey: KEY + '-b' });
    expect(arm.armedSiteKeys()).toHaveLength(2);
  });

  test('a missing sitekey arms nothing', () => {
    arm.armForSiteKey({ ...opts(), siteKey: '' });
    expect(arm.armedSiteKeys()).toHaveLength(0);
  });

  test('an idle sitekey is disarmed so it stops paying for solves', async () => {
    arm.armForSiteKey(opts());
    expect(arm.armedSiteKeys()).toHaveLength(1);
    // Idle window is 1.5s; the reaper ticks at ~0.5s. Wait past two sweeps.
    await new Promise((r) => setTimeout(r, 2600));
    expect(arm.armedSiteKeys()).toHaveLength(0);
  }, 10_000);

  test('a disarmed sitekey can be re-armed', async () => {
    arm.armForSiteKey(opts());
    await new Promise((r) => setTimeout(r, 2600));
    expect(arm.armedSiteKeys()).toHaveLength(0);
    arm.armForSiteKey(opts());
    expect(arm.armedSiteKeys()).toHaveLength(1);
  }, 10_000);

  test('touch keeps the sitekey alive across the idle window', async () => {
    arm.armForSiteKey(opts());
    // Touch every 600ms for 2s: never idle long enough to be reaped.
    for (let i = 0; i < 4; i++) {
      await new Promise((r) => setTimeout(r, 600));
      arm.touchArmed(KEY);
    }
    expect(arm.armedSiteKeys()).toHaveLength(1);
  }, 10_000);
});

describe('depth cap', () => {
  test('deposits beyond the cap are refused', () => {
    for (let i = 0; i < 5; i++) {
      const ok = pile.depositToken('turnstile', KEY, `t${i}`.padEnd(24, 'x'));
      if (i < 3) expect(ok).toBe(true);
      else expect(ok).toBe(false);
    }
    expect(pile.stockpileDepth('turnstile', KEY)).toBe(3);
  });

  test('an expired token frees a cap slot', () => {
    const realNow = Date.now;
    for (let i = 0; i < 3; i++) pile.depositToken('turnstile', KEY, `t${i}`.padEnd(24, 'x'));
    Date.now = () => realNow() + 300_000; // past the 240s turnstile TTL
    expect(pile.depositToken('turnstile', KEY, 'fresh'.padEnd(24, 'x'))).toBe(true);
    Date.now = realNow;
  });

  test('a too-short token is refused without consuming a slot', () => {
    expect(pile.depositToken('turnstile', KEY, 'short')).toBe(false);
    expect(pile.stockpileDepth('turnstile', KEY)).toBe(0);
  });
});
