export const up = async (knex) => {
  await knex.schema.alterTable('proxies', (t) => {
    t.string('proxy_type', 24).notNullable().defaultTo('unknown');
    t.string('label', 120).notNullable().defaultTo('');
  });
};

export const down = async (knex) => {
  await knex.schema.alterTable('proxies', (t) => {
    t.dropColumn('proxy_type');
    t.dropColumn('label');
  });
};
