/**
 * Realistic human-like mouse movement using cubic Bezier curves.
 *
 * Why this matters: PerimeterX v3, Akamai Edge Auth, DataDome, and Imperva all
 * analyze mouse trajectory data — recording velocity, acceleration, path curvature,
 * and the statistical distribution of inter-event intervals. Puppeteer's built-in
 * page.mouse.move(x, y, { steps }) produces perfectly linear motion at uniform
 * speed — a near-perfect bot signal. This module produces naturalistic paths with:
 *   - Cubic Bezier curves (non-linear path)
 *   - Ease-in-out speed profile (slow at ends, fast in middle)
 *   - Sub-pixel micro-jitter at each point (~1-2px)
 *   - Occasional overshoot + correction (humans frequently overshoot targets)
 *   - Organic timing variance (2–20ms per step)
 *   - Idle entropy while waiting (real users keep moving their mouse)
 */

const bezierPoint = (p0, p1, p2, p3, t) => {
  const u = 1 - t;
  return {
    x: u * u * u * p0.x + 3 * u * u * t * p1.x + 3 * u * t * t * p2.x + t * t * t * p3.x,
    y: u * u * u * p0.y + 3 * u * u * t * p1.y + 3 * u * t * t * p2.y + t * t * t * p3.y,
  };
};

const randRange = (min, max) => min + Math.random() * (max - min);
const randInt = (min, max) => Math.floor(randRange(min, max + 1));

const controlPoint = (p0, p1, tFrac = 0.25, spread = 0.45) => {
  const dx = p1.x - p0.x;
  const dy = p1.y - p0.y;
  return {
    x: p0.x + dx * tFrac + (Math.random() - 0.5) * (Math.abs(dx) + 60) * spread,
    y: p0.y + dy * tFrac + (Math.random() - 0.5) * (Math.abs(dy) + 60) * spread,
  };
};

/**
 * Move mouse from `from` to `to` along a Bezier curve with human-like velocity.
 *
 * @param {import('puppeteer').Page} page
 * @param {{ x: number, y: number }} from
 * @param {{ x: number, y: number }} to
 * @param {{ overshoot?: boolean }} opts
 */
export const moveMouse = async (page, from, to, { overshoot = true } = {}) => {
  const dist = Math.hypot(to.x - from.x, to.y - from.y);
  if (dist < 2) return;

  const steps = Math.max(20, Math.min(130, Math.floor(dist / 3)));

  let actualTarget = { ...to };
  const willOvershoot = overshoot && Math.random() < 0.35 && dist > 75;
  if (willOvershoot) {
    const factor = 1.02 + Math.random() * 0.08;
    actualTarget = {
      x: Math.round(from.x + (to.x - from.x) * factor),
      y: Math.round(from.y + (to.y - from.y) * factor),
    };
  }

  const cp1 = controlPoint(from, actualTarget, 0.18 + Math.random() * 0.18, 0.45);
  const cp2 = controlPoint(actualTarget, from, 0.18 + Math.random() * 0.18, 0.35);

  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const eased = t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
    const pt = bezierPoint(from, cp1, cp2, actualTarget, eased);

    const jx = (Math.random() - 0.5) * 1.8;
    const jy = (Math.random() - 0.5) * 1.8;
    await page.mouse.move(Math.round(pt.x + jx), Math.round(pt.y + jy));

    const posInCurve = Math.abs(t - 0.5) * 2;
    const delay = i < 3 || i > steps - 3
      ? randRange(8, 20)
      : randRange(2, 7) + posInCurve * randRange(3, 9);
    await new Promise((r) => setTimeout(r, delay));
  }

  if (willOvershoot) {
    await new Promise((r) => setTimeout(r, randRange(12, 45)));
    const corrSteps = randInt(5, 12);
    for (let i = 1; i <= corrSteps; i++) {
      const t = i / corrSteps;
      await page.mouse.move(
        Math.round(actualTarget.x + (to.x - actualTarget.x) * t),
        Math.round(actualTarget.y + (to.y - actualTarget.y) * t),
      );
      await new Promise((r) => setTimeout(r, randRange(4, 12)));
    }
  }
};

/**
 * Move to an element by selector and click it, with realistic Bezier movement.
 *
 * @param {import('puppeteer').Page} page
 * @param {{ x: number, y: number }} from  Current mouse position
 * @param {string} selector
 * @returns {{ x: number, y: number }}  New mouse position (the click target)
 */
export const moveAndClick = async (page, from, selector) => {
  const el = await page.$(selector);
  if (!el) throw new Error(`moveAndClick: element not found: ${selector}`);
  const box = await el.boundingBox();
  if (!box) throw new Error(`moveAndClick: element not visible: ${selector}`);
  const to = {
    x: Math.round(box.x + box.width * (0.3 + Math.random() * 0.4)),
    y: Math.round(box.y + box.height * (0.3 + Math.random() * 0.4)),
  };
  await moveMouse(page, from, to);
  await new Promise((r) => setTimeout(r, randRange(35, 110)));
  await page.mouse.click(to.x, to.y);
  return to;
};

/**
 * Realistic scroll gesture: chunked increments with micro-pauses, as if
 * using a scroll wheel and pausing briefly to read content.
 *
 * @param {import('puppeteer').Page} page
 * @param {{ direction?: 'down'|'up', totalPx?: number }} opts
 */
export const humanScroll = async (page, { direction = 'down', totalPx = null } = {}) => {
  const vp = page.viewport() || { width: 1280, height: 800 };
  const amount = totalPx ?? Math.floor(randRange(180, vp.height * 1.1));
  const scrolled = direction === 'down' ? amount : -amount;

  const chunks = randInt(4, 10);
  let remaining = scrolled;

  for (let i = 0; i < chunks; i++) {
    const isLast = i === chunks - 1;
    const fraction = randRange(0.65, 1.35) / (chunks - i);
    const chunk = isLast ? remaining : Math.round(remaining * fraction);
    remaining -= chunk;
    await page.evaluate((dy) => window.scrollBy({ top: dy, behavior: 'instant' }), chunk);
    await new Promise((r) => setTimeout(r, randRange(18, 75)));
    if (Math.random() < 0.25) {
      await new Promise((r) => setTimeout(r, randRange(180, 550)));
    }
  }
};

/**
 * Small idle movements while waiting for a page event (navigation, captcha, etc.).
 * Real users don't freeze their mouse for seconds at a time.
 *
 * @param {import('puppeteer').Page} page
 * @param {{ durationMs?: number }} opts
 */
export const idleMouseEntropy = async (page, { durationMs = 3000 } = {}) => {
  const vp = page.viewport() || { width: 1280, height: 800 };
  const end = Date.now() + durationMs;
  let cur = {
    x: Math.round(randRange(180, vp.width - 180)),
    y: Math.round(randRange(140, vp.height - 140)),
  };
  await page.mouse.move(cur.x, cur.y).catch(() => {});

  while (Date.now() < end) {
    const next = {
      x: Math.max(30, Math.min(vp.width - 30, cur.x + randRange(-130, 130))),
      y: Math.max(30, Math.min(vp.height - 30, cur.y + randRange(-90, 90))),
    };
    await moveMouse(page, cur, next, { overshoot: false }).catch(() => {});
    cur = next;
    const pause = randRange(180, 850);
    await new Promise((r) => setTimeout(r, Math.min(pause, end - Date.now())));
  }
};

/**
 * Synthesise realistic mouse-entropy statistics for DataDome / PerimeterX
 * payloads. Simulates ~30 mouse-move samples collected during a 4-8s page load.
 *
 * Returned fields match DataDome's behavioral telemetry schema:
 *   es_sigmdn  — std-dev of speed (px/s)
 *   es_mumdn   — mean of movement distances (px)
 *   es_distmdn — total path distance (px)
 *   es_angsmdn — std-dev of start-angles (degrees)
 *   es_angemdn — std-dev of end-angles (degrees)
 */
export const syntheticMouseStats = () => {
  const n = randInt(18, 40);
  const speeds = [];
  const dists = [];
  const startAngles = [];
  const endAngles = [];

  for (let i = 0; i < n; i++) {
    const dx = randRange(-200, 200);
    const dy = randRange(-150, 150);
    const dist = Math.max(5, Math.hypot(dx, dy));
    const dt = randRange(80, 400);
    const startAngle = (Math.atan2(dy, dx) * 180) / Math.PI;
    speeds.push((dist / dt) * 1000);
    dists.push(dist);
    startAngles.push(startAngle);
    // End angle of a segment is its start bearing plus a small turn. This used
    // `startAngles[startAngles.length - 1]` AFTER pushing, i.e. the current
    // sample's own start angle, so every value was noise around itself and the
    // reported es_angemdn was far too tight.
    endAngles.push(startAngle + randRange(-20, 20));
  }

  const mean = (arr) => arr.reduce((a, b) => a + b, 0) / arr.length;
  const stddev = (arr) => {
    const m = mean(arr);
    return Math.sqrt(arr.reduce((s, v) => s + (v - m) ** 2, 0) / arr.length);
  };

  return {
    es_sigmdn: parseFloat(stddev(speeds).toFixed(4)),
    es_mumdn: parseFloat(mean(dists).toFixed(4)),
    es_distmdn: parseFloat(dists.reduce((a, b) => a + b, 0).toFixed(2)),
    es_angsmdn: parseFloat(stddev(startAngles).toFixed(4)),
    es_angemdn: parseFloat(stddev(endAngles).toFixed(4)),
  };
};
