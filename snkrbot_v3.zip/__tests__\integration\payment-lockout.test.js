// Payment lockout: 5 consecutive declines must park the task until an operator
// clears it. Pins the threshold, the neutral-outcome behaviour (a proxy death or
// an OOS must NOT burn a strike), and the fact that a locked task stays locked
// on further declines instead of re-tripping with a fresh timestamp.
import { jest } from '@jest/globals';

jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));

const {
  PAYMENT_LOCKOUT_THRESHOLD,
  isPaymentLocked,
  nextPaymentState,
  recordPaymentOutcome,
  clearPaymentLock
} = await import('../../helpers/payment-lockout.js');

const NOW = new Date('2026-10-24T12:00:00Z');
const TASK = { id: 7, pay_fail_count: 0, pay_disabled_at: null, pay_disabled_reason: null };

// Minimal knex-shaped recorder.
const makeDb = () => {
  const calls = [];
  const db = (table) => {
    expect(table).toBe('tasks');
    return {
      where: (where) => {
        calls.push({ where });
        return { update: async (patch) => { calls[calls.length - 1].patch = patch; } };
      }
    };
  };
  db.calls = calls;
  return db;
};

test('threshold is five declines', () => {
  expect(PAYMENT_LOCKOUT_THRESHOLD).toBe(5);
});

test('four declines stay unlocked, the fifth locks', () => {
  let task = { ...TASK };
  for (let i = 0; i < 4; i += 1) {
    const next = nextPaymentState(task, 'decline', NOW);
    expect(next.locked).toBe(false);
    expect(next.newlyLocked).toBe(false);
    task = { ...task, pay_fail_count: next.pay_fail_count, pay_disabled_at: next.pay_disabled_at };
  }
  expect(task.pay_fail_count).toBe(4);

  const trip = nextPaymentState(task, 'decline', NOW);
  expect(trip.pay_fail_count).toBe(5);
  expect(trip.newlyLocked).toBe(true);
  expect(trip.locked).toBe(true);
  expect(trip.pay_disabled_at).toEqual(NOW);
  expect(trip.pay_disabled_reason).toMatch(/5\/5/);
  expect(trip.pay_disabled_reason).toMatch(/dashboard/);
});

test('neutral outcomes do not burn a strike', () => {
  // OOS, proxy transport death and session expiry are not the card's fault.
  const task = { ...TASK, pay_fail_count: 3 };
  const next = nextPaymentState(task, 'neutral', NOW);
  expect(next.pay_fail_count).toBe(3);
  expect(next.pay_disabled_at).toBeNull();
  expect(next.newlyLocked).toBe(false);
});

test('success clears the streak and any lock', () => {
  const locked = { ...TASK, pay_fail_count: 5, pay_disabled_at: NOW, pay_disabled_reason: 'x' };
  const next = nextPaymentState(locked, 'success', NOW);
  expect(next.pay_fail_count).toBe(0);
  expect(next.pay_disabled_at).toBeNull();
  expect(next.pay_disabled_reason).toBeNull();
  expect(next.locked).toBe(false);
});

test('a locked task that declines again keeps its original lock timestamp', () => {
  const locked = { ...TASK, pay_fail_count: 5, pay_disabled_at: NOW, pay_disabled_reason: 'reason' };
  const later = new Date('2026-10-25T00:00:00Z');
  const next = nextPaymentState(locked, 'decline', later);
  expect(next.pay_fail_count).toBe(6);
  expect(next.pay_disabled_at).toEqual(NOW); // not the newer date
  expect(next.newlyLocked).toBe(false); // no duplicate "locked" notification
  expect(next.pay_disabled_reason).toBe('reason');
});

test('isPaymentLocked keys off the timestamp, not the counter', () => {
  expect(isPaymentLocked({ pay_fail_count: 9 })).toBe(false);
  expect(isPaymentLocked({ pay_fail_count: 5, pay_disabled_at: NOW })).toBe(true);
  expect(isPaymentLocked({})).toBe(false);
  expect(isPaymentLocked(null)).toBe(false);
});

test('recordPaymentOutcome persists the computed state', async () => {
  const db = makeDb();
  const next = await recordPaymentOutcome(db, 7, { ...TASK, pay_fail_count: 4 }, 'decline', NOW);
  expect(next.newlyLocked).toBe(true);
  expect(db.calls).toHaveLength(1);
  expect(db.calls[0].where).toEqual({ id: 7 });
  expect(db.calls[0].patch).toMatchObject({ pay_fail_count: 5, pay_disabled_at: NOW });
  expect(db.calls[0].patch.pay_disabled_reason).toMatch(/5\/5/);
});

test('recordPaymentOutcome skips the write when a neutral outcome changes nothing', async () => {
  const db = makeDb();
  await recordPaymentOutcome(db, 7, { ...TASK, pay_fail_count: 2 }, 'neutral', NOW);
  expect(db.calls).toHaveLength(0);
});

test('recordPaymentOutcome never throws on a DB failure', async () => {
  const db = () => ({ where: () => ({ update: async () => { throw new Error('disk gone'); } }) });
  await expect(recordPaymentOutcome(db, 7, TASK, 'decline', NOW)).resolves.toBeDefined();
});

test('clearPaymentLock resets count and lock columns', async () => {
  const db = makeDb();
  await clearPaymentLock(db, 7);
  expect(db.calls[0].patch).toEqual({
    pay_fail_count: 0, pay_disabled_at: null, pay_disabled_reason: null
  });
});
