// Identity rotation between failed retries.
//
// Why pro bots do this: when a checkout attempt fails for bot-detection
// reasons (Imperva 403, Cloudflare 1015, Akamai 401), retrying with the
// SAME fingerprint+cookies is wasted ammo — the site has already flagged
// that identity. Stellar and Hidden rotate the entire identity (fingerprint,
// userDataDir, persisted cookies, GPU/TZ profile) between retry attempts so
// each retry looks like a brand new shopper.
//
// We make this OPT-IN per task via task.rotate_on_retry so users with fixed
// payment identities (which need cookie continuity for fraud scoring) can
// disable it. Default ON for tasks without billing/shipping addresses
// associated; default OFF when an address is attached (since address +
// payment + fingerprint should travel together for Stripe Radar / Riskified).
import path from 'node:path';
import fs from 'node:fs/promises';
import logger from './logger.js';

const profileDir = (taskId) => path.resolve(process.cwd(), 'profiles', `task-${taskId}`);

// Rotate the identity for the next attempt. Wipes:
//   - profiles/task-<id>/_fingerprint.json (forces new pick on next launch)
//   - profiles/task-<id>/_cf_clearance.json (drops the burned CF token)
//   - profiles/task-<id>/<chromium userDataDir> (drops cookies, IndexedDB, localStorage)
// Keeps the profile DIRECTORY itself so the task-scoped path stays stable.
export const rotateIdentity = async (taskId) => {
  const dir = profileDir(taskId);
  let wiped = 0;
  try {
    const entries = await fs.readdir(dir).catch(() => []);
    for (const entry of entries) {
      const full = path.join(dir, entry);
      await fs.rm(full, { recursive: true, force: true });
      wiped += 1;
    }
    logger.info(`[IdentityRotator] Task ${taskId} rotated — wiped ${wiped} profile entries (fingerprint + CF cookies + userDataDir)`);
    return true;
  } catch (err) {
    logger.warn(`[IdentityRotator] Task ${taskId} rotation failed: ${err.message}`);
    return false;
  }
};

// Cookies-only wipe: drop the burned session cookies (Chromium userDataDir,
// CF token, persisted cookies) but KEEP the pinned fingerprint. Used on a proxy
// swap for address-attached tasks, where we can't rotate the fingerprint (it
// must travel with the payment identity) but the old proxy's WAF cookies are
// often IP-bound — carrying them to the new exit IP would re-flag the session.
// Wiping them forces a clean re-warm on the new IP.
export const wipeSessionCookies = async (taskId) => {
  const dir = profileDir(taskId);
  let wiped = 0;
  try {
    const entries = await fs.readdir(dir).catch(() => []);
    for (const entry of entries) {
      if (entry === '_fingerprint.json') continue; // keep the pinned fingerprint
      await fs.rm(path.join(dir, entry), { recursive: true, force: true });
      wiped += 1;
    }
    logger.info(`[IdentityRotator] Task ${taskId} session cookies wiped (kept fingerprint) — ${wiped} entries removed`);
    return true;
  } catch (err) {
    logger.warn(`[IdentityRotator] Task ${taskId} cookie wipe failed: ${err.message}`);
    return false;
  }
};

// Decide whether to rotate based on the failure stage. Some failures (e.g.
// captcha solver timeout, network blip) aren't identity-related and rotating
// would burn a fingerprint for nothing.
const ROTATE_WORTHY_STAGES = new Set([
  'pdp_load', 'imperva', 'cloudflare', 'akamai', 'turnstile',
  'cart_load', 'checkout_load', 'session_warm', 'datadome'
]);

// Classify whether a failed result looks like a bot-detection / IP-reputation
// block (as opposed to an OOS, decline, or network blip). Shared by both the
// fingerprint-rotation and proxy-rotation deciders so they agree on what counts
// as "the site flagged us."
export const isBotDetectionFailure = (lastResult) => {
  if (!lastResult || lastResult.ok) return false;
  // Bot-detection-class failure stages.
  if (lastResult.stage && ROTATE_WORTHY_STAGES.has(lastResult.stage.toLowerCase())) return true;
  // Detection by error message keywords (in case stage wasn't tagged).
  const msg = (lastResult.error || '').toLowerCase();
  if (/imperva|cloudflare|akamai|datadome|forbidden|403|1015|access denied|blocked/i.test(msg)) return true;
  return false;
};

export const shouldRotateAfterFailure = ({ task, lastResult }) => {
  if (task.rotate_on_retry === false) return false; // explicit opt-out
  // If a billing/shipping address is attached, we keep identity continuity
  // for payment fraud scoring — rotating mid-checkout-pipeline burns the
  // payment trust.
  if (task.billing_address_id || task.shipping_address_id) return false;
  return isBotDetectionFailure(lastResult);
};
