// Liveness tracking for residential exits.
//
// Why this exists: a residential exit can be alive at the TCP level and still be
// useless — silently dropping bytes, or answering 200s in seconds. Nothing
// measured that, so a dead exit was only discovered by a full poll cycle timing
// out, and then it could be picked again straight away. Every one of those cycles
// bills bandwidth and delays a restock.
//
// So the pool keeps a per-exit latency series and a pass/fail record, and this
// module turns them into a single health verdict the pool can act on:
//
//   healthy   — recent traffic succeeded at a normal pace.
//   slow      — succeeding, but materially behind the exit's own baseline. Not an
//               error: a 3s exit still beats a rotation, and rotating costs an IP.
//               Warn only, unless the caller is time-critical.
//   degraded  — failing often enough that the next attempt is likely a waste.
//   dead      — a run of consecutive failures. Deprioritise hard.
//
// The comparison is deliberately against the exit's OWN baseline, not an absolute
// threshold: residential gateways differ by an order of magnitude between regions
// and providers, and a flat 2s cut would mark every far-region exit as slow.
//
// Pure and I/O-free.

const DEFAULT_WINDOW = 8;
const MAX_SAMPLES = 24;

// Absolute floor for the "slow" band, so an exit whose baseline happens to be
// very fast does not get flagged for a 200ms wobble.
const SLOW_FLOOR_MS = 900;
const SLOW_FACTOR = 2.5;
const DEGRADED_FAILURES = 3;
const DEAD_FAILURES = 5;

export const VERDICT = Object.freeze({ HEALTHY: 'healthy', SLOW: 'slow', DEGRADED: 'degraded', DEAD: 'dead' });

const push = (list, value, cap = MAX_SAMPLES) => {
  const next = [...list, value];
  return next.length > cap ? next.slice(next.length - cap) : next;
};

export const mean = (list = []) => (list.length
  ? list.reduce((a, b) => a + b, 0) / list.length
  : 0);

const median = (list = []) => {
  if (!list.length) return 0;
  const sorted = [...list].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
};

// `samples` is a list of { ok, latencyMs }; oldest first.
// Accept both `{ ok, latencyMs }` records and bare latency numbers, so a caller
// can log a plain timing without wrapping it.
const asSample = (s) => (typeof s === 'number'
  ? { ok: true, latencyMs: s }
  : (s && typeof s === 'object' ? s : null));

export const assessLiveness = ({ samples = [], failures = 0, slowFactor = SLOW_FACTOR } = {}) => {
  const consecutiveFailures = Math.max(0, Number(failures) || 0);
  if (consecutiveFailures >= DEAD_FAILURES) {
    return { verdict: VERDICT.DEAD, baselineMs: 0, lastMs: 0, reasons: [`consecutive_failures_${consecutiveFailures}`] };
  }
  if (consecutiveFailures >= DEGRADED_FAILURES) {
    return { verdict: VERDICT.DEGRADED, baselineMs: 0, lastMs: 0, reasons: [`consecutive_failures_${consecutiveFailures}`] };
  }

  const normalized = samples.map(asSample).filter(Boolean);
  const ok = normalized.filter((s) => s.ok && Number.isFinite(Number(s.latencyMs)));
  if (ok.length === 0) {
    // No successful sample yet is not evidence of illness — a fresh exit.
    return { verdict: VERDICT.HEALTHY, baselineMs: 0, lastMs: 0, reasons: ['no_samples'] };
  }

  const recent = ok.slice(-DEFAULT_WINDOW).map((s) => Number(s.latencyMs));
  // Baseline excludes the newest sample so one slow response cannot raise its own
  // bar and hide itself.
  const baselineMs = median(recent.slice(0, -1));
  const lastMs = recent[recent.length - 1];
  const reasons = [];

  if (baselineMs > 0) {
    const limit = Math.max(SLOW_FLOOR_MS, baselineMs * slowFactor);
    if (lastMs > limit) {
      reasons.push(`slow_${Math.round(lastMs)}ms_vs_${Math.round(baselineMs)}ms`);
      return { verdict: VERDICT.SLOW, baselineMs, lastMs, reasons };
    }
  }

  return { verdict: VERDICT.HEALTHY, baselineMs, lastMs, reasons };
};

// Sample series live per proxy id. Kept here rather than in the pool so the
// bookkeeping is unit-testable and the pool keeps only its transport concerns.
const series = new Map(); // proxyId → { samples, failures }

export const recordLatency = (proxyId, latencyMs) => {
  if (proxyId == null) return;
  const entry = series.get(proxyId) || { samples: [], failures: 0 };
  entry.samples = push(entry.samples, { ok: true, latencyMs: Math.max(0, Number(latencyMs) || 0) });
  entry.failures = 0;
  series.set(proxyId, entry);
};

export const recordFailure = (proxyId) => {
  if (proxyId == null) return;
  const entry = series.get(proxyId) || { samples: [], failures: 0 };
  entry.samples = push(entry.samples, { ok: false, latencyMs: null });
  entry.failures += 1;
  series.set(proxyId, entry);
};

export const verdictFor = (proxyId) => {
  const entry = series.get(proxyId);
  if (!entry) return { verdict: VERDICT.HEALTHY, baselineMs: 0, lastMs: 0, reasons: ['no_samples'] };
  return assessLiveness(entry);
};

// Should the caller rotate away from this exit for a time-critical step?
// A merely slow exit is kept — rotating costs an IP, which is usually worse.
export const shouldAbandon = (proxyId, { timeCritical = false } = {}) => {
  const { verdict } = verdictFor(proxyId);
  if (verdict === VERDICT.DEAD) return true;
  if (verdict === VERDICT.DEGRADED) return true;
  if (verdict === VERDICT.SLOW) return Boolean(timeCritical);
  return false;
};

export const snapshot = () => Array.from(series.entries()).map(([proxyId, e]) => ({
  proxyId,
  ...assessLiveness(e)
}));

export const __resetLiveness = () => series.clear();
export const livenessConfig = () => ({
  window: DEFAULT_WINDOW, slowFloorMs: SLOW_FLOOR_MS, slowFactor: SLOW_FACTOR,
  degradedFailures: DEGRADED_FAILURES, deadFailures: DEAD_FAILURES
});
