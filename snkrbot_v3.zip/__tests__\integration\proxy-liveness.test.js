// Proxy liveness tests.
//
// The regression this guards: a residential exit could be alive at TCP level and
// still be useless, and nothing noticed until a full poll timed out — then it
// could be picked again. Every wasted cycle bills bandwidth and delays a restock.
//
// The baseline is deliberately each exit's OWN median: gateways differ by an
// order of magnitude between regions, so an absolute threshold would mark every
// far-region exit as slow.
import { beforeEach, describe, expect, test } from '@jest/globals';
import {
  VERDICT, assessLiveness, livenessConfig, recordFailure, recordLatency,
  shouldAbandon, verdictFor, __resetLiveness
} from '../../helpers/proxy-liveness.js';

beforeEach(() => __resetLiveness());

const sample = (latencyMs, ok = true) => ({ ok, latencyMs });

describe('assessment', () => {
  test('no samples at all is healthy, not sick', () => {
    expect(assessLiveness({ samples: [] }).verdict).toBe(VERDICT.HEALTHY);
    expect(assessLiveness({}).reasons).toContain('no_samples');
  });

  test('consistent fast responses are healthy', () => {
    const out = assessLiveness({ samples: [200, 210, 205, 215].map((n) => sample(n)) });
    expect(out.verdict).toBe(VERDICT.HEALTHY);
  });

  test('a sudden slow response against a fast baseline is flagged slow', () => {
    const out = assessLiveness({ samples: [200, 210, 205, sample(4000)] });
    expect(out.verdict).toBe(VERDICT.SLOW);
    expect(out.reasons[0]).toContain('slow_');
  });

  test('the slow floor protects a very fast exit from a small wobble', () => {
    // Baseline 40ms, so a 2.5x rule alone would flag 120ms; the floor holds it.
    const out = assessLiveness({ samples: [40, 40, 40, sample(120)] });
    expect(out.verdict).toBe(VERDICT.HEALTHY);
  });

  test('a far-region exit is judged against its own baseline, not an absolute', () => {
    // 3s responses are fine when that IS the baseline.
    const out = assessLiveness({ samples: [3000, 3100, 3050, sample(3100)] });
    expect(out.verdict).toBe(VERDICT.HEALTHY);
    expect(out.baselineMs).toBeGreaterThan(2900);
  });

  test('the newest sample cannot raise its own bar', () => {
    const out = assessLiveness({ samples: [100, 100, 100, sample(100000)] });
    expect(out.verdict).toBe(VERDICT.SLOW);
  });

  test('repeated failures escalate to degraded and then dead', () => {
    const cfg = livenessConfig();
    expect(assessLiveness({ failures: cfg.degradedFailures }).verdict).toBe(VERDICT.DEGRADED);
    expect(assessLiveness({ failures: cfg.deadFailures }).verdict).toBe(VERDICT.DEAD);
  });

  test('consecutive failures outrank a good latency history', () => {
    const out = assessLiveness({ samples: [100, 100, 100].map((n) => sample(n)), failures: livenessConfig().deadFailures });
    expect(out.verdict).toBe(VERDICT.DEAD);
  });
});

describe('tracking', () => {
  test('a success clears the failure run', () => {
    recordFailure(7);
    recordFailure(7);
    expect(verdictFor(7).verdict).toBe(VERDICT.HEALTHY); // 2 is under the degrade threshold
    recordFailure(7);
    expect(verdictFor(7).verdict).toBe(VERDICT.DEGRADED);
    recordLatency(7, 120);
    expect(verdictFor(7).verdict).toBe(VERDICT.HEALTHY);
  });

  test('an unknown proxy is healthy so a fresh exit is not punished', () => {
    expect(verdictFor('never-seen').verdict).toBe(VERDICT.HEALTHY);
  });

  test('a null id is ignored rather than stored under undefined', () => {
    recordLatency(null, 100);
    recordFailure(undefined);
    expect(verdictFor(null).verdict).toBe(VERDICT.HEALTHY);
  });

  test('a negative latency is clamped', () => {
    recordLatency(3, -50);
    expect(verdictFor(3).lastMs).toBe(0);
  });
});

describe('abandon decision', () => {
  test('healthy is kept', () => {
    expect(shouldAbandon(1)).toBe(false);
  });

  test('degraded and dead are abandoned', () => {
    for (let i = 0; i < livenessConfig().deadFailures; i++) recordFailure(2);
    expect(shouldAbandon(2)).toBe(true);
  });

  test('merely slow is kept unless the caller is time-critical', () => {
    for (let i = 0; i < 4; i++) recordLatency(4, 150);
    recordLatency(4, 6000);
    expect(verdictFor(4).verdict).toBe(VERDICT.SLOW);
    // Rotating costs an IP, so a slow-but-working exit is kept by default.
    expect(shouldAbandon(4)).toBe(false);
    expect(shouldAbandon(4, { timeCritical: true })).toBe(true);
  });
});
