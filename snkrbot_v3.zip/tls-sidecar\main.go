// SneakerBot TLS sidecar — forges Chrome's exact TLS ClientHello so background
// HTTP calls (drop-watcher probes, captcha API calls, session warming, etc.)
// match Chrome's JA3/JA4 fingerprint instead of Node/OpenSSL's distinctive
// fingerprint that anti-bot vendors (Cloudflare, Akamai, Imperva, DataDome,
// PerimeterX) flag instantly.
//
// Why this exists: even with perfect Chrome 131 user-agent and JS-layer
// fingerprinting (navigator props, WebGL, audio, fonts), Node.js's TLS stack
// uses OpenSSL which produces a cipher suite ordering and extension list
// that is NOT Chrome. A single TLS handshake is enough for a tier-1 WAF to
// classify the connection as "definitely not real Chrome." This sidecar
// closes that gap by routing all "stealth" HTTP traffic through Go's utls
// library (via bogdanfinn/tls-client), which can replay any Chrome
// ClientHello byte-for-byte.
//
// Listens on 127.0.0.1:7654 (localhost only — never exposed externally).
// Node calls POST /request with {method, url, headers, body, profile, proxy}
// and gets back {status, headers, body_b64}. GET /health for readiness.
package main

import (
        "bytes"
        "context"
        "crypto/rand"
        "crypto/subtle"
        "encoding/base64"
        "encoding/hex"
        "encoding/json"
        "fmt"
        "io"
        "log"
        "net"
        "net/http"
        "net/url"
        "os"
        "strings"
        "time"

        fhttp "github.com/bogdanfinn/fhttp"
        "github.com/bogdanfinn/tls-client/profiles"
)

// Shared-secret token between Node bridge and Go sidecar. Required because
// Replit auto-maps the workflow's listening port to the public internet — so
// even though the sidecar is "container-internal" by intent, the port IS
// reachable from outside. Without this auth, the unauthenticated /request
// endpoint would be an open SSRF/HTTP proxy primitive accessible to the
// world. Generated at startup if TLS_SIDECAR_TOKEN env not set, written to
// /tmp/tls-sidecar.token so the Node bridge (same container) can read it.
var authToken string

const tokenFilePath = "/tmp/tls-sidecar.token"

// Allow proxy parameter only when explicitly enabled. By default, blocks
// user-supplied proxy URLs to prevent attackers from chaining the sidecar
// through their own infrastructure or reaching internal services.
var proxyAllowed bool

// Optional strict host allowlist (suffix match, e.g. "pokemoncenter.ca"
// matches "www.pokemoncenter.ca"). When empty, all PUBLIC hosts are allowed
// and the IP-policy guard is the only host check. Setting this env in prod
// is the strongest defense — it eliminates DNS-rebinding TOCTOU because the
// allowlist is by NAME, not by resolved IP, and an attacker cannot rebind
// the DNS of a domain they don't control.
var hostAllowlist []string

func initAuth() {
        authToken = os.Getenv("TLS_SIDECAR_TOKEN")
        if authToken == "" {
                buf := make([]byte, 32)
                if _, err := rand.Read(buf); err != nil {
                        log.Fatalf("[TLS] cannot generate token: %v", err)
                }
                authToken = hex.EncodeToString(buf)
                log.Printf("[TLS] generated random auth token (64 hex chars)")
        }
        // Atomic, no-clobber write — resists a same-UID attacker pre-creating a
        // symlink at the predictable path. If the file already exists from a prior
        // run, remove and recreate (sidecar owns the path).
        _ = os.Remove(tokenFilePath)
        f, err := os.OpenFile(tokenFilePath, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0o600)
        if err != nil {
                log.Fatalf("[TLS] cannot create token file %s: %v", tokenFilePath, err)
        }
        if _, err := f.WriteString(authToken); err != nil {
                log.Fatalf("[TLS] cannot write token: %v", err)
        }
        _ = f.Close()
        proxyAllowed = os.Getenv("TLS_SIDECAR_ALLOW_PROXY") == "true"
        if raw := strings.TrimSpace(os.Getenv("TLS_SIDECAR_ALLOW_HOSTS")); raw != "" {
                for _, h := range strings.Split(raw, ",") {
                        h = strings.ToLower(strings.TrimSpace(h))
                        if h != "" {
                                hostAllowlist = append(hostAllowlist, h)
                        }
                }
                log.Printf("[TLS] strict host allowlist active (%d entries): %v", len(hostAllowlist), hostAllowlist)
        }
}

func hostAllowed(host string) bool {
        if len(hostAllowlist) == 0 {
                return true // no strict allowlist; IP-policy guard is the only check
        }
        host = strings.ToLower(host)
        for _, allowed := range hostAllowlist {
                if host == allowed || strings.HasSuffix(host, "."+allowed) {
                        return true
                }
        }
        return false
}

// validateTarget runs scheme + host-allowlist + IP-policy checks. Called for
// the initial URL AND for every redirect hop, so an attacker cannot use a
// 30x from a public host to a private one.
func validateTarget(rawURL string) error {
        parsed, err := url.Parse(rawURL)
        if err != nil {
                return fmt.Errorf("invalid url: %w", err)
        }
        if parsed.Scheme != "http" && parsed.Scheme != "https" {
                return fmt.Errorf("only http/https schemes allowed (got %s)", parsed.Scheme)
        }
        host := parsed.Hostname()
        if !hostAllowed(host) {
                return fmt.Errorf("host %q not in allowlist", host)
        }
        if blocked, reason := isPrivateOrLoopback(host); blocked {
                return fmt.Errorf("SSRF guard: target host blocked (%s)", reason)
        }
        return nil
}

func authOK(r *http.Request) bool {
        hdr := r.Header.Get("Authorization")
        if !strings.HasPrefix(hdr, "Bearer ") {
                return false
        }
        got := strings.TrimPrefix(hdr, "Bearer ")
        return subtle.ConstantTimeCompare([]byte(got), []byte(authToken)) == 1
}

// SSRF guard — reject if the target hostname resolves to any private,
// loopback, link-local, or cloud-metadata IP. Anti-bot vendors don't live
// on private ranges; any request targeting one is either a misconfiguration
// or an attack. Cloud metadata service (169.254.169.254) is the classic
// SSRF target that leaks AWS/GCP credentials.
func isPrivateOrLoopback(host string) (bool, string) {
        if host == "" {
                return true, "empty host"
        }
        // Try parse as literal IP first
        if ip := net.ParseIP(host); ip != nil {
                return ipIsPrivate(ip), ip.String()
        }
        // Hot path: a verdict cached within TTL skips the blocking lookup this
        // guard would otherwise pay on the URL and on every redirect hop.
        if verdict, ok := dnsVerdict(host); ok {
                return verdict.private, verdict.reason
        }
        addrs, err := lookupCached(host)
        if err != nil {
                return true, "DNS lookup failed: " + err.Error()
        }
        for _, ip := range addrs {
                if ipIsPrivate(ip) {
                        return true, ip.String() + " is private/loopback"
                }
        }
        return false, ""
}

func ipIsPrivate(ip net.IP) bool {
        if ip.IsLoopback() || ip.IsPrivate() || ip.IsLinkLocalUnicast() || ip.IsLinkLocalMulticast() || ip.IsUnspecified() {
                return true
        }
        // Cloud metadata services
        if ip.Equal(net.ParseIP("169.254.169.254")) || ip.Equal(net.ParseIP("fd00:ec2::254")) {
                return true
        }
        return false
}

type RequestPayload struct {
        Method    string            `json:"method"`
        URL       string            `json:"url"`
        Headers   map[string]string `json:"headers"`
        Body      string            `json:"body"`        // raw string (sent as-is)
        BodyB64   string            `json:"body_b64"`    // optional binary body
        Profile   string            `json:"profile"`     // chrome131, chrome120, firefox120, etc.
        Proxy     string            `json:"proxy"`       // optional http(s)://user:pass@host:port
        TimeoutMs int               `json:"timeout_ms"`  // request timeout (default 15s)
        NoRedirect bool             `json:"no_redirect"` // disable auto-follow
        Session    string            `json:"session"`     // optional: enables sidecar-side cookie persistence for this caller
}

type ResponsePayload struct {
        Status  int                 `json:"status"`
        Headers map[string][]string `json:"headers"`
        BodyB64 string              `json:"body_b64"`
        Error   string              `json:"error,omitempty"`
        Final   string              `json:"final_url,omitempty"`
}

// Map Node-friendly profile name to tls-client's ClientProfile.
// Default Chrome131 to match our pinned Chrome version in fingerprint-store.js.
// The browser's real version is authoritative: if the sidecar is left on an
// older profile than the UA claims, the ClientHello (JA3/JA4) contradicts the
// UA header on the very same request — an immediate Chrome-mismatch signal.
func resolveProfile(name string) profiles.ClientProfile {
        switch strings.ToLower(name) {
        case "chrome133", "chrome_133", "chrome131_psk", "chrome_131_psk":
                // v1.7.10 has no Chrome_133 profile; 131_PSK is the closest
                // newer ClientHello (post-quantum key share, newer cipher order).
                return profiles.Chrome_131_PSK
        case "chrome131", "chrome_131", "":
                return profiles.Chrome_131
        case "chrome124":
                return profiles.Chrome_124
        case "chrome120":
                return profiles.Chrome_120
        case "firefox133", "firefox133_0":
                return profiles.Firefox_133
        case "firefox120", "firefox":
                return profiles.Firefox_120
        case "safari17_0", "safari":
                return profiles.Safari_IOS_17_0
        default:
                log.Printf("[TLS] Unknown profile %q, defaulting to Chrome_131", name)
                return profiles.Chrome_131
        }
}

// chromeHeaderOrder defines Chrome's canonical H2 request header order.
// HTTP/2 transmits headers as HPACK-compressed name-value pairs in the order
// they appear in the request. Chrome 131 sends headers in this specific
// sequence, which WAFs (Cloudflare Bot Management, Akamai mPulse, Imperva)
// use as a fingerprint alongside the TLS ClientHello. Sending headers in
// Node's default map-iteration order (random) produces a non-Chrome
// fingerprint even though the cipher suites are correct.
//
// Pseudo-headers (:method, :authority, :scheme, :path) are handled by the
// HTTP/2 framing layer and not included here — they always appear first.
// chromeHeaderOrder defines Chrome's canonical H2 request header order.
// HTTP/2 transmits headers as HPACK-compressed name-value pairs in the order
// they appear in the request. Chrome sends headers in this specific sequence,
// which WAFs (Cloudflare Bot Management, Akamai mPulse, Imperva) use as a
// fingerprint alongside the TLS ClientHello. Sending headers in Node's default
// map-iteration order (random) produces a non-Chrome fingerprint even though
// the cipher suites are correct.
//
// The Sec-Ch-Ua-* block is contiguous and in Chrome's own order because these
// are emitted by the network stack in that exact sequence. Splitting them (or
// sorting alphabetically) is itself detectable.
//
// Pseudo-headers (:method, :authority, :scheme, :path) are handled by the
// HTTP/2 framing layer and not included here — they always appear first.
var chromeHeaderOrder = []string{
        "cache-control",
        "sec-ch-ua",
        "sec-ch-ua-mobile",
        "sec-ch-ua-platform",
        "sec-ch-ua-arch",
        "sec-ch-ua-bitness",
        "sec-ch-ua-model",
        "sec-ch-ua-platform-version",
        "sec-ch-ua-full-version-list",
        "sec-ch-ua-wow64",
        "upgrade-insecure-requests",
        "user-agent",
        "accept",
        "sec-fetch-site",
        "sec-fetch-mode",
        "sec-fetch-user",
        "sec-fetch-dest",
        "referer",
        "accept-encoding",
        "accept-language",
        "content-type",
        "content-length",
        "origin",
        "dnt",
        "pragma",
        "priority",
        "cookie",
        "authorization",
}


// applyHeadersInChromeOrder applies request headers in Chrome's canonical H2
// order. Headers not in the priority list are appended alphabetically after
// the known-ordered set.
func applyHeadersInChromeOrder(httpReq *fhttp.Request, headers map[string]string) {
        seen := make(map[string]bool, len(headers))
        // Apply known-ordered headers first (preserves Chrome's canonical sequence)
        for _, name := range chromeHeaderOrder {
                lower := strings.ToLower(name)
                for k, v := range headers {
                        if strings.ToLower(k) == lower {
                                httpReq.Header.Set(k, v)
                                seen[strings.ToLower(k)] = true
                                break
                        }
                }
        }
        // Append remaining headers in sorted order (deterministic, not random)
        remaining := make([]string, 0, len(headers))
        for k := range headers {
                if !seen[strings.ToLower(k)] {
                        remaining = append(remaining, k)
                }
        }
        // sort remaining for determinism
        for i := 0; i < len(remaining)-1; i++ {
                for j := i + 1; j < len(remaining); j++ {
                        if strings.ToLower(remaining[i]) > strings.ToLower(remaining[j]) {
                                remaining[i], remaining[j] = remaining[j], remaining[i]
                        }
                }
        }
        for _, k := range remaining {
                httpReq.Header.Set(k, headers[k])
        }
}

func handleRequest(w http.ResponseWriter, r *http.Request) {
        if r.Method != http.MethodPost {
                http.Error(w, "POST required", http.StatusMethodNotAllowed)
                return
        }
        if !authOK(r) {
                w.WriteHeader(http.StatusUnauthorized)
                json.NewEncoder(w).Encode(ResponsePayload{Error: "unauthorized: missing or invalid Bearer token"})
                return
        }
        var req RequestPayload
        if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
                writeErr(w, "decode body: "+err.Error())
                return
        }
        if req.URL == "" {
                writeErr(w, "url required")
                return
        }
        if req.Method == "" {
                req.Method = "GET"
        }

        if err := validateTarget(req.URL); err != nil {
                writeErr(w, err.Error())
                return
        }
        if req.Proxy != "" && !proxyAllowed {
                writeErr(w, "proxy parameter disabled (set TLS_SIDECAR_ALLOW_PROXY=true to enable)")
                return
        }
        timeout := time.Duration(req.TimeoutMs) * time.Millisecond
        if timeout <= 0 {
                timeout = 15 * time.Second
        }

        // Always disable auto-redirect at the client level — we follow manually
        // below so we can re-run validateTarget() on every Location hop, closing
        // the "public URL 30x to private IP" SSRF bypass.
        // Pooled client: reuses the TLS/H2 connection across requests instead
        // of paying a fresh TCP+TLS handshake on every poll.
        // Pooled client: reuses the TLS/H2 connection across requests instead
        // of paying a fresh TCP+TLS handshake on every poll.
        client, wasFresh, err := getClient(req.Profile, req.Proxy)
        if err != nil {
                writeErr(w, "client init: "+err.Error())
                return
        }

        var bodyBytes []byte
        if req.BodyB64 != "" {
                decoded, derr := base64.StdEncoding.DecodeString(req.BodyB64)
                if derr != nil {
                        writeErr(w, "body_b64 decode: "+derr.Error())
                        return
                }
                bodyBytes = decoded
        } else if req.Body != "" {
                bodyBytes = []byte(req.Body)
        }

        currentURL := req.URL
        method := strings.ToUpper(req.Method)
        maxRedirects := 5
        if req.NoRedirect {
                maxRedirects = 0
        }

        // Per-request deadline: the pooled client serves many callers, so the
        // timeout travels with the request, not with the client.
        ctx, cancel := context.WithTimeout(context.Background(), timeout+2*time.Second)
        defer cancel()

        // Was the caller's own Cookie header supplied? It always wins over the
        // sidecar jar, so capture it once up front. Also initialises the map
        // when the payload carried no headers at all (a nil map cannot be
        // written to below).
        callerCookie := false
        if req.Headers == nil {
                req.Headers = make(map[string]string)
        } else {
                _, callerCookie = req.Headers["Cookie"]
                if _, ok := req.Headers["cookie"]; ok {
                        callerCookie = true
                }
        }

        // buildHop constructs the request for one hop. Rebuilt rather than
        // reused on retry, because a failed Do may already have consumed the
        // body reader.
        buildHop := func() (*fhttp.Request, error) {
                var br io.Reader
                if bodyBytes != nil {
                        br = bytes.NewReader(bodyBytes)
                }
                httpReq, herr := fhttp.NewRequestWithContext(ctx, method, currentURL, br)
                if herr != nil {
                        return nil, herr
                }
                // Sidecar-side jar: fill in cookies the session already holds,
                // but only when the caller did not bring its own Cookie header.
                // The header is recomputed PER HOP: a redirect to another host
                // must not carry the previous host's cookies — a real browser
                // never does that, and leaking them is both a fingerprint tell
                // and a data leak into the next origin.
                if req.Session != "" && !callerCookie {
                        delete(req.Headers, "Cookie")
                        delete(req.Headers, "cookie")
                        if jar := cookieHeaderFor(req.Session, hostOf(currentURL)); jar != "" {
                                req.Headers["Cookie"] = jar
                        }
                }
                applyHeadersInChromeOrder(httpReq, req.Headers)
                return httpReq, nil
        }

        var resp *fhttp.Response
        for hop := 0; hop <= maxRedirects; hop++ {
                httpReq, herr := buildHop()
                if herr != nil {
                        writeErr(w, "build req: "+herr.Error())
                        return
                }

                resp, err = client.Do(httpReq)
                if err != nil {
                        // A pooled socket through a residential gateway can go
                        // stale between polls even with a tight idle timeout —
                        // that is a transport hiccup, not a real failure.
                        // Retry once on a rebuilt client; only for GET, because
                        // a retried POST could duplicate the action.
                        if method == "GET" && !wasFresh {
                                evictClient(req.Profile, req.Proxy)
                                if c2, _, e2 := getClient(req.Profile, req.Proxy); e2 == nil {
                                        client = c2
                                        wasFresh = true
                                        if retryReq, rerr := buildHop(); rerr == nil {
                                                resp, err = client.Do(retryReq)
                                        }
                                }
                        }
                        if err != nil {
                                writeErr(w, "do: "+err.Error())
                                return
                        }
                }
                // 3xx → re-validate Location and follow (or stop if exhausted)
                if resp.StatusCode >= 300 && resp.StatusCode < 400 && hop < maxRedirects {
                        loc := resp.Header.Get("Location")
                        resp.Body.Close()
                        if loc == "" {
                                writeErr(w, fmt.Sprintf("redirect %d without Location header", resp.StatusCode))
                                return
                        }
                        // Resolve relative Location against current URL
                        base, _ := url.Parse(currentURL)
                        locURL, perr := url.Parse(loc)
                        if perr != nil {
                                writeErr(w, "redirect Location parse: "+perr.Error())
                                return
                        }
                        next := base.ResolveReference(locURL).String()
                        if verr := validateTarget(next); verr != nil {
                                writeErr(w, "redirect blocked: "+verr.Error())
                                return
                        }
                        currentURL = next
                        // Per RFC 7231: 301/302/303 to GET, drop body. 307/308 preserve.
                        if resp.StatusCode == 301 || resp.StatusCode == 302 || resp.StatusCode == 303 {
                                method = "GET"
                                bodyBytes = nil
                        }
                        continue
                }
                break
        }
        defer resp.Body.Close()

        body, err := decodeBody(resp)
        if err != nil {
                writeErr(w, "read body: "+err.Error())
                return
        }
        // Persist any Set-Cookie into the session jar before headers are
        // serialised, so the next request in this session already has them.
        absorbCookies(req.Session, hostOf(currentURL), resp)

        out := ResponsePayload{
                Status:  resp.StatusCode,
                Headers: resp.Header,
                BodyB64: base64.StdEncoding.EncodeToString(body),
                Final:   currentURL,
        }
        w.Header().Set("Content-Type", "application/json")
        json.NewEncoder(w).Encode(out)
}

func writeErr(w http.ResponseWriter, msg string) {
        w.Header().Set("Content-Type", "application/json")
        w.WriteHeader(http.StatusBadRequest)
        json.NewEncoder(w).Encode(ResponsePayload{Error: msg})
}

func handleHealth(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")
        json.NewEncoder(w).Encode(map[string]any{
                "ok":      true,
                "profile": "chrome131",
                "library": "github.com/bogdanfinn/tls-client",
        })
}

func main() {
        initAuth()
        // Bind to 0.0.0.0 so Replit's port-readiness probe can see the listener.
        // IMPORTANT: Replit auto-maps this port externally, so /request is
        // reachable from the public internet. Without the Bearer token check,
        // it would be an open HTTP proxy / SSRF primitive. The token is the
        // ONLY thing protecting it. For local dev (Windows), bind to localhost
        // via TLS_SIDECAR_ADDR=127.0.0.1:8099.
        addr := os.Getenv("TLS_SIDECAR_ADDR")
        if addr == "" {
                addr = "0.0.0.0:8099"
        }
        mux := http.NewServeMux()
        mux.HandleFunc("/request", handleRequest)
        mux.HandleFunc("/preconnect", handlePreconnect)
        mux.HandleFunc("/health", handleHealth)

        log.Printf("[TLS] sidecar listening on %s (Chrome131 default profile)", addr)
        srv := &http.Server{
                Addr:              addr,
                Handler:           mux,
                ReadHeaderTimeout: 5 * time.Second,
        }
        if err := srv.ListenAndServe(); err != nil {
                log.Fatalf("[TLS] listen failed: %v", err)
        }

        fmt.Println("exiting")
}
