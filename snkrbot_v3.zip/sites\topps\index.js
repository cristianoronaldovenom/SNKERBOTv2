import { tryRequestFirstAddToCart } from '../../helpers/browser-request-atc.js';
import { navigateCartUnlessReady } from '../../helpers/site-checkout-fastpath.js';
import logger from '../../helpers/logger.js';
import { solveCloudflareTurnstile } from '../../helpers/captcha.js';
import { getCachedToken } from '../../helpers/captcha-cache.js';
import { consumeToken, depositToken, ensureStockpiling } from '../../helpers/token-stockpile.js';
import { storePageInTaskCache } from '../../helpers/task-cache.js';
import { humanType, humanTypeInFrames, humanSelect, humanClick } from '../../helpers/human-type.js';
import { captureCloudflareCookies, restoreCloudflareCookies } from '../../helpers/cf-clearance.js';
import {
  formatPostal, stripPhone, dismissAutocomplete, verifyFieldValue,
  requireCardIframe, verifyCartHasItem, FillReport, assertCriticalFields
} from '../../helpers/autofill-utils.js';
import {
  takeFailureScreenshot,
  guardedGoto,
  postClickGuard,
  preOrderGuard,
  retryWithBackoff
} from '../../helpers/checkout-guards.js';
import { captureOrderSuccess } from '../../helpers/order-capture.js';
import { assertActionButtonIntent } from '../../helpers/checkout-controls.js';

const BASE_URL = 'https://www.topps.com';
import { waitForAnySelector } from '../../helpers/site-runtime.js';

const TIMEOUT = 15000;
const PLACE_ORDER_TIMEOUT = 60000;

const SELECTORS = {
  // PDP — try multiple common SFCC patterns; first match wins.
  addToCart: [
    'button.add-to-cart',
    'button[data-action="add-to-cart"]',
    'button[name="add-to-cart"]',
    'button.pdp-add-to-cart',
    '[data-testid="add-to-cart"]',
    'button[class*="AddToCart"]'
  ],
  variantTile: [
    '.product-variations .variation-attribute-value',
    'button.swatch',
    '.size-list button',
    'button[data-attr="size"]'
  ],
  miniCart: [
    'a.minicart-link',
    'a[href*="/cart"]',
    '.minicart .checkout-button'
  ],
  cartCheckoutBtn: [
    'a.checkout-btn',
    'button.checkout-btn',
    'a[href*="/checkout"]',
    'button[name="dwfrm_cart_checkoutCart"]'
  ],
  guestCheckout: [
    'button.guest-continue',
    'button[name="dwfrm_login_unregistered"]',
    'a.guest-checkout',
    'button[data-action="guest"]'
  ],
  // Shipping / contact
  email:        ['input[name="dwfrm_billing_billingAddress_email_emailAddress"]', 'input[name="email"]', 'input#email', 'input[type="email"]'],
  firstName:    ['input[name="dwfrm_shipping_shippingAddress_addressFields_firstName"]', 'input[name="firstName"]', 'input#shippingFirstName', 'input[id*="FirstName"]'],
  lastName:     ['input[name="dwfrm_shipping_shippingAddress_addressFields_lastName"]',  'input[name="lastName"]',  'input#shippingLastName',  'input[id*="LastName"]'],
  address1:     ['input[name="dwfrm_shipping_shippingAddress_addressFields_address1"]',  'input[name="address1"]',  'input#shippingAddressOne'],
  address2:     ['input[name="dwfrm_shipping_shippingAddress_addressFields_address2"]',  'input[name="address2"]',  'input#shippingAddressTwo'],
  city:         ['input[name="dwfrm_shipping_shippingAddress_addressFields_city"]',      'input[name="city"]',      'input#shippingCity'],
  state:        ['select[name="dwfrm_shipping_shippingAddress_addressFields_states_state"]', 'select[name="state"]', 'select#shippingState'],
  postalCode:   ['input[name="dwfrm_shipping_shippingAddress_addressFields_postalCode"]', 'input[name="postalCode"]', 'input[name="zipCode"]', 'input#shippingZipCode'],
  country:      ['select[name="dwfrm_shipping_shippingAddress_addressFields_country"]',   'select[name="country"]', 'select#shippingCountry'],
  phone:        ['input[name="dwfrm_shipping_shippingAddress_addressFields_phone"]',     'input[name="phone"]',     'input#shippingPhoneNumber', 'input[type="tel"]'],
  shippingSubmit: ['button.submit-shipping', 'button[name="submit-shipping"]', 'button.shipping-summary-edit + button', 'button[data-action="submit-shipping"]'],
  // Payment — card fields may be in Adyen/CyberSource iframes on SFCC checkouts
  cardNumber:   ['input[name="dwfrm_billing_creditCardFields_cardNumber"]', 'input#cardNumber', 'input[name="cardNumber"]', 'input[autocomplete="cc-number"]', 'input[data-cse="encryptedCardNumber"]'],
  cardOwner:    ['input[name="dwfrm_billing_creditCardFields_cardOwner"]',  'input#cardOwner',  'input[name="cardholderName"]', 'input[autocomplete="cc-name"]', 'input[data-cse="holderName"]'],
  expMonth:     ['select[name="dwfrm_billing_creditCardFields_expirationMonth"]', 'select#expirationMonth', 'select[name="expirationMonth"]'],
  expYear:      ['select[name="dwfrm_billing_creditCardFields_expirationYear"]',  'select#expirationYear',  'select[name="expirationYear"]'],
  cvv:          ['input[name="dwfrm_billing_creditCardFields_securityCode"]', 'input#securityCode', 'input[autocomplete="cc-csc"]', 'input[name="cvv"]', 'input[data-cse="encryptedSecurityCode"]'],
  paymentSubmit: ['button.submit-payment', 'button[name="submit-payment"]', 'button[data-action="submit-payment"]'],
  // Billing address (separate from shipping)
  billingFirstName: ['input[name="dwfrm_billing_billingAddress_addressFields_firstName"]', 'input[name="billing_firstName"]', 'input#billingFirstName'],
  billingLastName:  ['input[name="dwfrm_billing_billingAddress_addressFields_lastName"]',  'input[name="billing_lastName"]',  'input#billingLastName'],
  billingAddress1:  ['input[name="dwfrm_billing_billingAddress_addressFields_address1"]',  'input[name="billing_address1"]',  'input#billingAddressOne'],
  billingAddress2:  ['input[name="dwfrm_billing_billingAddress_addressFields_address2"]',  'input[name="billing_address2"]',  'input#billingAddressTwo'],
  billingCity:      ['input[name="dwfrm_billing_billingAddress_addressFields_city"]',      'input[name="billing_city"]',      'input#billingCity'],
  billingState:     ['select[name="dwfrm_billing_billingAddress_addressFields_states_state"]', 'select[name="billing_state"]', 'select#billingState'],
  billingPostal:    ['input[name="dwfrm_billing_billingAddress_addressFields_postalCode"]',  'input[name="billing_postalCode"]', 'input[name="billing_zipCode"]', 'input#billingZipCode'],
  billingCountry:   ['select[name="dwfrm_billing_billingAddress_addressFields_country"]',  'select[name="billing_country"]',  'select#billingCountry'],
  billingPhone:     ['input[name="dwfrm_billing_billingAddress_addressFields_phone"]',     'input[name="billing_phone"]',     'input#billingPhoneNumber'],
  sameAsBilling:    ['input[name="sameAsBillingAddress"]', 'input[id*="sameAsBilling"]', 'input[id*="shipToBilling"]', 'input[id*="billingAddressSameAsShipping"]'],
  // Coupon
  couponInput:  ['input[name="couponCode"]', 'input#couponCode', 'input[placeholder*="coupon" i]', 'input[placeholder*="promo" i]'],
  couponSubmit: ['button.promo-code-btn', 'button.promo-code-submit', 'button[data-action="apply-coupon"]'],
  // Final order
  placeOrder:   ['button.place-order', 'button[name="submit-order"]', 'button[data-action="place-order"]', 'button.btn-primary.place-order'],
  orderConfirmation: ['.order-confirmation-number', '.order-thank-you', 'h1.order-thank-you-msg', '[data-testid="order-confirmation"]']
};

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const findFirst = async (page, selectorList, timeout = TIMEOUT) => {
  const selector = await waitForAnySelector(page, selectorList, { timeout });
  if (!selector) return null;
  const el = await page.$(selector).catch(() => null);
  return el ? { el, selector } : null;
};

const fillField = async (page, selectorList, value, { type = 'text', label = '', report = null } = {}) => {
  const name = label || 'unnamed';
  if (value == null || value === '') {
    if (report) report.record(name, true, 'skipped (empty)');
    return false;
  }
  const found = await findFirst(page, selectorList, 8000);
  if (!found) {
    if (report) report.record(name, false, 'selector not found');
    logger.warn(`[Topps] ${name}: no selector matched in [${selectorList.join(', ')}]`);
    return false;
  }
  const formatted = type === 'postal' ? formatPostal(value) : type === 'phone' ? stripPhone(value) : String(value);
  for (let attempt = 0; attempt < 2; attempt++) {
    await found.el.click({ clickCount: 3 }).catch(() => {});
    await page.keyboard.press('Backspace').catch(() => {});
    await humanType(page, found.selector, formatted);
    await dismissAutocomplete(page, found.selector);
    await page.keyboard.press('Tab').catch(() => {});
    const v = await verifyFieldValue(page, found.selector, formatted, type);
    if (v.ok) {
      if (report) report.record(name, true);
      return true;
    }
    logger.warn(`[Topps] ${name} did not stick on attempt ${attempt + 1} (got "${v.actual}", expected "${v.expected}"), retrying`);
  }
  if (report) report.record(name, false, 'verify failed after retry');
  return false;
};

// For PCI card fields that may be inside Adyen/CyberSource iframes.
// Falls back to regular humanType in main frame if iframe variant fails.
const fillCardField = async (page, selectorList, value, { label = '', report = null, tabAfter = true } = {}) => {
  const name = label || 'unnamed';
  if (!value) { if (report) report.record(name, true, 'skipped (empty)'); return false; }
  const selector = selectorList.join(', ');
  const ok = await humanTypeInFrames(page, selector, String(value), { tabAfter });
  if (ok) {
    if (report) report.record(name, true);
    return true;
  }
  if (report) report.record(name, false, 'not found in main frame or iframes');
  logger.warn(`[Topps] ${name}: card field not found in main frame or any iframe — tried [${selectorList.join(', ')}]`);
  return false;
};

const selectField = async (page, selectorList, value, { label = '', report = null, fallbackValues = [] } = {}) => {
  const name = label || 'unnamed';
  if (!value) { if (report) report.record(name, true, 'skipped (empty)'); return false; }
  const found = await findFirst(page, selectorList, 3000);
  if (!found) { if (report) report.record(name, false, 'select not found'); return false; }

  const valuesToTry = [value, ...fallbackValues].filter(Boolean);
  for (const v of valuesToTry) {
    const ok = await humanSelect(page, found.selector, String(v)).catch(() => false);
    if (ok) { if (report) report.record(name, true); return true; }
  }
  if (report) report.record(name, false, `could not match value "${value}"`);
  return false;
};

const clickFirst = async (page, selectorList, { stage = '' } = {}) => {
  const found = await findFirst(page, selectorList, TIMEOUT);
  if (!found) {
    throw new Error(`Could not find a clickable element at stage "${stage}" — tried [${selectorList.join(', ')}]`);
  }
  await humanClick(page, found.selector);
  return found.selector;
};

const STOCKPILE_ARMED = new Set();
// Arm a background pre-solver the first time this sitekey is seen, so the later
// checkout stage gets an instant token instead of paying solver latency on the
// hot path. Mirrors the identical helper in the bestbuy/pokemoncenter adapters.
const armStockpile = (siteKey, pageUrl) => {
  try {
    if (!siteKey) return;
    if (STOCKPILE_ARMED.has(siteKey)) return;
    STOCKPILE_ARMED.add(siteKey);
    ensureStockpiling({
      type: 'turnstile',
      siteKey,
      pageUrl,
      targetDepth: Math.max(1, Number(process.env.CAPTCHA_STOCKPILE_DEPTH || 2)),
      refillIntervalMs: Math.max(5000, Number(process.env.CAPTCHA_STOCKPILE_REFILL_MS || 30000)),
      solveOnce: (type, key, url) => solveCloudflareTurnstile({ siteKey: key, pageUrl: url, page: null }),
    });
  } catch (_) { /* stockpiling is an optimisation, never fatal */ }
};

const detectAndSolveTurnstile = async (page, stage = 'turnstile') => {
  const info = await page.evaluate(() => {
    // Try render-hook capture first (injected by cluster.js stealth script)
    if (window.__turnstileCapture && window.__turnstileCapture.sitekey) {
      return {
        siteKey: window.__turnstileCapture.sitekey,
        callback: typeof window.__turnstileCapture.callback === 'function' ? '__captured__' : null,
        source: 'render-hook'
      };
    }
    const cf = document.querySelector('.cf-turnstile[data-sitekey], div[data-sitekey][class*="turnstile" i], iframe[src*="challenges.cloudflare.com"]');
    if (!cf) return null;
    const sk = cf.getAttribute('data-sitekey')
      || cf.querySelector?.('[data-sitekey]')?.getAttribute('data-sitekey')
      || (cf.src || '').match(/[?&]k=([^&]+)/)?.[1]
      || null;
    return sk ? { siteKey: sk, source: 'dom' } : null;
  }).catch(() => null);

  if (!info) return false;
  const url = page.url();
  armStockpile(info.siteKey, url);
  try {
    let token = consumeToken('turnstile', info.siteKey)
      || getCachedToken('turnstile', info.siteKey, url);
    if (!token) {
      logger.info(`[Topps] Cloudflare Turnstile detected at "${stage}" (source: ${info.source}) — solving`);
      token = await solveCloudflareTurnstile({ siteKey: info.siteKey, pageUrl: url, page });
      // Stockpile only: one token, one entry — a duplicate cache copy lets the
      // next stage replay an already-spent Turnstile token.
      if (token) depositToken('turnstile', info.siteKey, token);
    }
    await page.evaluate((tok) => {
      document.querySelectorAll('input[name="cf-turnstile-response"], textarea[name="cf-turnstile-response"]').forEach((i) => {
        i.value = tok;
        i.dispatchEvent(new Event('input', { bubbles: true }));
        i.dispatchEvent(new Event('change', { bubbles: true }));
      });
      if (window.__turnstileCapture && typeof window.__turnstileCapture.callback === 'function') {
        try { window.__turnstileCapture.callback(tok); } catch (_) {}
      }
      ['onloadTurnstileCallback', 'turnstileCallback', 'cfCallback', '_turnstileCb'].forEach((name) => {
        if (typeof window[name] === 'function') { try { window[name](tok); } catch (_) {} }
      });
    }, token).catch(() => {});
    return true;
  } catch (e) {
    throw new Error(`Cloudflare Turnstile failed at stage "${stage}": ${e.message}`);
  }
};

const runTopps = async ({ page, task }) => {
  const startedAt = Date.now();
  logger.info(`[Topps] Starting checkout for task ${task.id}: ${task.url}`);
  storePageInTaskCache({ taskId: task.id, page });

  page.setDefaultNavigationTimeout(30000);

  // Restore any saved Cloudflare clearance cookie BEFORE the first navigation.
  await restoreCloudflareCookies({ page, taskId: task.id });

  // 1. Land on PDP (guarded: queue + bot-block detection on every goto)
  await guardedGoto(page, task.url, { taskId: task.id, stage: 'pdp_load', waitUntil: 'domcontentloaded' });
  await detectAndSolveTurnstile(page, 'pdp_load');
  await captureCloudflareCookies({ page, taskId: task.id });

  // 2. Variant selection (optional)
  if (task.keywords) {
    const kws = task.keywords.toLowerCase().split(',').map((s) => s.trim()).filter(Boolean);
    if (kws.length > 0) {
      logger.info(`[Topps] Trying to match variant for keywords [${kws.join(', ')}]`);
      const matched = await page.evaluate(({ selectors, kws }) => {
        for (const sel of selectors) {
          const tiles = Array.from(document.querySelectorAll(sel));
          const hit = tiles.find((t) => {
            const text = (t.textContent || t.getAttribute('aria-label') || t.getAttribute('title') || '').toLowerCase();
            return kws.every((k) => text.includes(k));
          });
          if (hit) { hit.click(); return true; }
        }
        return false;
      }, { selectors: SELECTORS.variantTile, kws }).catch(() => false);
      if (!matched) logger.warn(`[Topps] No variant matched [${kws.join(', ')}] — proceeding anyway`);
      else await waitForAnySelector(page, SELECTORS.addToCart, { timeout: 2500 });
    }
  }

  // 3. Quantity
  if (task.quantity && task.quantity > 1) {
    const qtySels = ['select.quantity-select', 'select[name="quantity"]', 'input[name="quantity"]', 'input.quantity-select'];
    const qtyFound = await findFirst(page, qtySels, 5000);
    if (qtyFound) {
      const tag = await qtyFound.el.evaluate((el) => el.tagName.toLowerCase());
      if (tag === 'select') {
        await page.select(qtyFound.selector, String(task.quantity)).catch(() => {});
      } else {
        await qtyFound.el.click({ clickCount: 3 }).catch(() => {});
        await page.keyboard.press('Backspace').catch(() => {});
        await humanType(page, qtyFound.selector, String(task.quantity));
      }
      logger.info(`[Topps] Quantity set to ${task.quantity}`);
    } else {
      logger.warn('[Topps] Quantity selector not found — proceeding with default qty');
    }
  }

  // 4. Add to Cart
  await retryWithBackoff(
    async () => {
      if (!(await tryRequestFirstAddToCart(page, SELECTORS.addToCart))) {
        await clickFirst(page, SELECTORS.addToCart, { stage: 'add_to_cart' });
      }
    },
    { attempts: 3, baseMs: 1200, label: `Topps ATC task ${task.id}` }
  );
  logger.info('[Topps] Added to cart');

  // 5. Verify cart is not empty
  await navigateCartUnlessReady({ page, cartUrl: `${BASE_URL}/cart`, navigate: guardedGoto, taskId: task.id, stage: 'cart_load', waitUntil: 'domcontentloaded' });
  await detectAndSolveTurnstile(page, 'cart_load');

  const cartCheck = await verifyCartHasItem(page, { timeout: 6000 });
  if (cartCheck.empty) {
    const err = new Error('Cart is empty after add-to-cart — product may be out of stock');
    err.failureType = 'oos';
    throw err;
  }
  logger.info(`[Topps] Cart verified (${cartCheck.count} item(s))`);

  // 6. Proceed to checkout
  await clickFirst(page, SELECTORS.cartCheckoutBtn, { stage: 'cart_to_checkout' });
  await page.waitForNavigation({ waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
  await detectAndSolveTurnstile(page, 'checkout_load');
  await postClickGuard(page, { taskId: task.id, stage: 'checkout_load' });

  // 7. Guest checkout (if a login wall appears)
  const guest = await findFirst(page, SELECTORS.guestCheckout, 4000);
  if (guest) {
    await humanClick(page, guest.selector);
    await waitForAnySelector(page, [...SELECTORS.email, ...SELECTORS.firstName], { timeout: 8000 });
    await postClickGuard(page, { taskId: task.id, stage: 'guest_checkout' });
  }

  // 8. Shipping form
  const ship = task.shippingAddress;
  if (!ship) throw new Error('Shipping address missing at stage "fill_shipping"');

  const shipReport = new FillReport(task.id, 'Topps Shipping');

  await fillField(page, SELECTORS.email,      task.notification_email_address || ship.email, { label: 'email',      report: shipReport });
  await fillField(page, SELECTORS.firstName,  ship.first_name,  { label: 'firstName',  report: shipReport });
  await fillField(page, SELECTORS.lastName,   ship.last_name,   { label: 'lastName',   report: shipReport });
  await fillField(page, SELECTORS.address1,   ship.address1,    { label: 'address1',   report: shipReport });
  if (ship.address2) {
    await fillField(page, SELECTORS.address2, ship.address2,    { label: 'address2',   report: shipReport });
  }
  await fillField(page, SELECTORS.city,       ship.city,        { label: 'city',       report: shipReport });
  await fillField(page, SELECTORS.postalCode, ship.zip,         { label: 'postalCode', type: 'postal', report: shipReport });
  await fillField(page, SELECTORS.phone,      ship.phone,       { label: 'phone',      type: 'phone',  report: shipReport });

  const stateSel = await findFirst(page, SELECTORS.state, 3000);
  if (stateSel) await humanSelect(page, stateSel.selector, ship.state).catch((e) => logger.warn(`[Topps] State select failed: ${e.message}`));

  const countrySel = await findFirst(page, SELECTORS.country, 1500);
  if (countrySel && ship.country) await humanSelect(page, countrySel.selector, ship.country).catch(() => {});

  shipReport.log();
  assertCriticalFields(shipReport, ['email', 'firstName', 'lastName', 'address1', 'city', 'postalCode']);
  const shipFailed = shipReport.summary().failed;
  if (shipFailed.length > 0) {
    await takeFailureScreenshot(page, task.id, 'fillShipping-mismatch');
    throw new Error(`Shipping fill incomplete at stage "fill_shipping": ${shipFailed.map(f => f.name).join(', ')}`);
  }

  await clickFirst(page, SELECTORS.shippingSubmit, { stage: 'submit_shipping' });
  await waitForAnySelector(page, [...SELECTORS.cardNumber, ...SELECTORS.placeOrder], { timeout: 12000 });
  await detectAndSolveTurnstile(page, 'submit_shipping');
  await postClickGuard(page, { taskId: task.id, stage: 'submit_shipping' });

  // 9. Payment — card fields may be inside Adyen/CyberSource iframes
  const pay = task.paymentProfile;
  if (!pay) throw new Error('Payment profile missing at stage "fill_payment"');

  // Wait for PCI card fields to appear (in any frame) before filling
  await requireCardIframe(page, { timeout: 15000 });

  const payReport = new FillReport(task.id, 'Topps Payment');

  await fillCardField(page, SELECTORS.cardOwner,  pay.card_holder_name, { label: 'cardOwner',  report: payReport });
  await fillCardField(page, SELECTORS.cardNumber, pay.card_number.replace(/\s/g, ''), { label: 'cardNumber', report: payReport });
  await fillCardField(page, SELECTORS.cvv,        pay.cvv,              { label: 'cvv',        report: payReport });

  // Expiration month — try raw value, integer string, and zero-padded string
  const rawMonth   = String(pay.expiration_month);
  const intMonth   = String(parseInt(rawMonth, 10));
  const padMonth   = intMonth.padStart(2, '0');
  await selectField(page, SELECTORS.expMonth, rawMonth, {
    label: 'expMonth', report: payReport, fallbackValues: [intMonth, padMonth]
  });

  // Expiration year — try full year and 2-digit year
  const rawYear = String(pay.expiration_year);
  const shortYear = rawYear.length === 4 ? rawYear.slice(2) : rawYear;
  await selectField(page, SELECTORS.expYear, rawYear, {
    label: 'expYear', report: payReport, fallbackValues: [shortYear]
  });

  payReport.log();
  assertCriticalFields(payReport, ['cardNumber']);
  const payFailed = payReport.summary().failed;
  if (payFailed.length > 0) {
    await takeFailureScreenshot(page, task.id, 'fillPayment-mismatch');
    throw new Error(`Payment fill incomplete at stage "fill_payment": ${payFailed.map(f => f.name).join(', ')}`);
  }

  // 10. Billing address — check for "same as shipping" first
  await fillBillingAddress({ page, task });

  // 11. Coupon code (optional)
  if (task.coupon_code) {
    await applyCoupon({ page, task });
  }

  await clickFirst(page, SELECTORS.paymentSubmit, { stage: 'submit_payment' });
  await waitForAnySelector(page, SELECTORS.placeOrder, { timeout: 12000 });
  await detectAndSolveTurnstile(page, 'submit_payment');
  await postClickGuard(page, { taskId: task.id, stage: 'submit_payment' });

  // 12. Pre-order guard: checks for bot blocks AND 3D Secure before charging card
  const guardResult = await preOrderGuard(page, { taskId: task.id });
  if (guardResult.threeDSecure) {
    logger.warn(`[Topps] Task ${task.id} — 3D Secure detected (${guardResult.threeDSecure.url}). Waiting up to 3 minutes for manual resolution…`);
  }

  // 13. Place order
  await assertActionButtonIntent(page, SELECTORS.placeOrder, { stage: 'place order', allow: /place order|submit order|complete order/i });
  await clickFirst(page, SELECTORS.placeOrder, { stage: 'place_order' });

  // 14. Wait for confirmation
  const confirmed = await Promise.race([
    findFirst(page, SELECTORS.orderConfirmation, PLACE_ORDER_TIMEOUT),
    page.waitForFunction(
      () => /thank-you|order-confirmation|confirmation/.test(window.location.pathname),
      { timeout: PLACE_ORDER_TIMEOUT }
    ).then(() => ({ url: true })).catch(() => null)
  ]);

  if (!confirmed) {
    await takeFailureScreenshot(page, task.id, 'place_order_no_confirmation');
    throw new Error('Order confirmation not detected at stage "confirm_order" — checkout may have failed silently');
  }

  // Extract order number from confirmation page
  const orderNumber = await page.evaluate(() => {
    const candidates = [
      document.querySelector('.order-confirmation-number'),
      document.querySelector('[data-order-id]'),
      document.querySelector('.order-number'),
      document.querySelector('.summary-order-number'),
      document.querySelector('[class*="orderNumber" i]'),
      document.querySelector('[class*="order-number" i]')
    ];
    for (const el of candidates) {
      if (el) {
        const text = (el.textContent || el.getAttribute('data-order-id') || '').trim();
        if (text) return text;
      }
    }
    return null;
  }).catch(() => null);

  logger.info(`[Topps] ✅ Order placed for task ${task.id}! Order: ${orderNumber || 'N/A'}`);

  await captureOrderSuccess({
    page,
    taskId: task.id,
    orderNumber,
    productUrl: task.url,
    durationMs: Date.now() - startedAt
  }).catch((err) => logger.warn(`[Topps] Order capture failed: ${err.message}`));
};

const fillBillingAddress = async ({ page, task }) => {
  const billing = task.billingAddress || task.shippingAddress;
  if (!billing) return;

  // Check for "same as shipping" checkbox — if checked, skip billing form
  const sameCheck = await findFirst(page, SELECTORS.sameAsBilling, 2000);
  if (sameCheck) {
    const checked = await sameCheck.el.evaluate((el) => el.checked).catch(() => false);
    if (checked) {
      logger.info('[Topps] Billing = shipping (checkbox already checked)');
      return;
    }
    // If the checkbox exists but is unchecked, click it to use same address
    await humanClick(page, sameCheck.selector).catch(() => {});
    await sleep(600);
    const nowChecked = await sameCheck.el.evaluate((el) => el.checked).catch(() => false);
    if (nowChecked) {
      logger.info('[Topps] Billing = shipping (checkbox clicked)');
      return;
    }
  }

  // No "same as shipping" toggle, or it didn't work — fill billing fields manually
  const billingReport = new FillReport(task.id, 'Topps Billing');
  const postal = formatPostal(billing.zip, billing.country);

  await fillField(page, SELECTORS.billingFirstName, billing.first_name, { label: 'billingFirstName', report: billingReport });
  await fillField(page, SELECTORS.billingLastName,  billing.last_name,  { label: 'billingLastName',  report: billingReport });
  await fillField(page, SELECTORS.billingAddress1,  billing.address1,   { label: 'billingAddress1',  report: billingReport });
  if (billing.address2) {
    await fillField(page, SELECTORS.billingAddress2, billing.address2,  { label: 'billingAddress2',  report: billingReport });
  }
  await fillField(page, SELECTORS.billingCity,      billing.city,       { label: 'billingCity',      report: billingReport });
  await fillField(page, SELECTORS.billingPostal,    postal,             { label: 'billingPostal',    report: billingReport });

  if (billing.phone) {
    await fillField(page, SELECTORS.billingPhone, billing.phone, { label: 'billingPhone', type: 'phone', report: billingReport });
  }

  const billingStateSel = await findFirst(page, SELECTORS.billingState, 2000);
  if (billingStateSel) {
    await humanSelect(page, billingStateSel.selector, billing.state).catch((e) => logger.warn(`[Topps] Billing state select failed: ${e.message}`));
  }

  const billingCountrySel = await findFirst(page, SELECTORS.billingCountry, 1500);
  if (billingCountrySel && billing.country) {
    await humanSelect(page, billingCountrySel.selector, billing.country).catch(() => {});
  }

  billingReport.log();
};

const applyCoupon = async ({ page, task }) => {
  try {
    const inputFound = await findFirst(page, SELECTORS.couponInput, 3000);
    if (!inputFound) return;
    await humanType(page, inputFound.selector, task.coupon_code, { tabAfter: false });
    const submitFound = await findFirst(page, SELECTORS.couponSubmit, 2000);
    if (submitFound) {
      await humanClick(page, submitFound.selector);
      await sleep(2000);
    }
    logger.info(`[Topps] Coupon "${task.coupon_code}" applied for task ${task.id}`);
  } catch (err) {
    logger.warn(`[Topps] Coupon failed for task ${task.id}: ${err.message}`);
  }
};

export default runTopps;
