import { jest } from '@jest/globals';

jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));

const {
  resolveTimezoneForExit, alignProfileToExit, getGeoForTimezone, supportedTimezones
} = await import('../../helpers/geo-consistency.js');

describe('market-crossing guard', () => {
  // Topps and Pokemon Center are US-only. A Decodo exit is confined to the target
  // country, but the pinned profile can still be Canadian — and then the exit TZ
  // (US) must not be overridden back to Canada.
  test('a Canadian profile on a US exit keeps the US clock', () => {
    const r = resolveTimezoneForExit(
      { tz: 'America/Toronto', proxy_exit_tz: 'America/New_York' },
      { requiredCountry: 'us' }
    );
    expect(r.tz).toBe('America/New_York');
    expect(r.blocked).toBe(false);
  });

  test('an in-country city change is still accepted', () => {
    const r = resolveTimezoneForExit(
      { tz: 'America/New_York', proxy_exit_tz: 'America/Los_Angeles' },
      { requiredCountry: 'us' }
    );
    expect(r.tz).toBe('America/Los_Angeles');
    expect(r.blocked).toBe(false);
  });

  test('an exit outside the required market is refused', () => {
    const r = resolveTimezoneForExit(
      { tz: 'America/New_York', proxy_exit_tz: 'Europe/London' },
      { requiredCountry: 'us' }
    );
    expect(r.tz).toBe('America/New_York');
    expect(r.blocked).toBe(true);
    expect(r.mismatch).toBe('Europe/London');
  });

  test('no required country keeps the old always-follow-the-exit behaviour', () => {
    const r = resolveTimezoneForExit({ tz: 'America/Toronto', proxy_exit_tz: 'Europe/London' });
    expect(r.tz).toBe('Europe/London');
    expect(r.blocked).toBe(false);
  });

  test('the guard does not fire when the exit country is unknown', () => {
    // Unmapped exit TZ: no basis to claim a border crossing.
    const r = resolveTimezoneForExit(
      { tz: 'America/New_York', proxy_exit_tz: 'America/Denver' },
      { requiredCountry: 'us' }
    );
    expect(r.blocked).toBe(false);
  });

  test('alignProfileToExit threads the requirement through', () => {
    const out = alignProfileToExit(
      { tz: 'America/New_York', proxy_exit_tz: 'Europe/Paris' },
      { requiredCountry: 'us' }
    );
    expect(out.tz).toBe('America/New_York');
  });
});

describe('resolveTimezoneForExit', () => {
  test('falls back to the pinned profile timezone', () => {
    expect(resolveTimezoneForExit({ tz: 'America/Chicago' })).toEqual({
      tz: 'America/Chicago', source: 'profile', mismatch: null, blocked: false
    });
  });

  test('the exit IP timezone wins over a conflicting pinned timezone', () => {
    const r = resolveTimezoneForExit({ tz: 'America/Toronto', proxy_exit_tz: 'America/Los_Angeles' });
    expect(r.tz).toBe('America/Los_Angeles');
    expect(r.source).toBe('proxy-exit');
    expect(r.mismatch).toBe('America/Toronto');
  });

  test('an agreeing exit timezone reports no mismatch', () => {
    const r = resolveTimezoneForExit({ tz: 'America/Toronto', proxy_exit_tz: 'America/Toronto' });
    expect(r).toEqual({ tz: 'America/Toronto', source: 'proxy-exit', mismatch: null, blocked: false });
  });

  test('an unmapped exit timezone is ignored', () => {
    expect(resolveTimezoneForExit({ tz: 'America/Toronto', proxy_exit_tz: 'Asia/Tokyo' }).tz)
      .toBe('America/Toronto');
  });

  test('keeps an unmapped pinned timezone instead of the default', () => {
    const r = resolveTimezoneForExit({ tz: 'Asia/Tokyo' });
    expect(r.tz).toBe('Asia/Tokyo');
    expect(r.source).toBe('profile-unmapped');
  });

  test('defaults when nothing is known', () => {
    expect(resolveTimezoneForExit({})).toEqual({
      tz: 'America/Toronto', source: 'default', mismatch: null, blocked: false
    });
  });
});

describe('alignProfileToExit', () => {
  test('returns a new profile with the exit timezone applied', () => {
    const pinned = { tz: 'America/Toronto', chromeVer: '131' };
    const out = alignProfileToExit({ ...pinned, proxy_exit_tz: 'Europe/London' });
    expect(out.tz).toBe('Europe/London');
    expect(out.chromeVer).toBe('131');
    expect(pinned.tz).toBe('America/Toronto');
  });
});

describe('getGeoForTimezone', () => {
  test('locale and Accept-Language travel with the timezone', () => {
    const geo = getGeoForTimezone('Europe/Berlin');
    expect(geo.locale).toBe('de-DE');
    expect(geo.acceptLang).toMatch(/^de-DE/);
    expect(geo.matched).toBe(true);
  });

  test('jittered coordinates stay near the city', () => {
    const geo = getGeoForTimezone('America/Toronto');
    expect(Math.abs(geo.lat - 43.6532)).toBeLessThan(0.1);
    expect(Math.abs(geo.lng - (-79.3832))).toBeLessThan(0.1);
  });

  test('unknown timezones fall back to the default and say so', () => {
    const geo = getGeoForTimezone('Asia/Tokyo');
    expect(geo.matched).toBe(false);
    expect(geo.tz).toBe('America/Toronto');
    expect(geo.locale).toBe('en-CA');
  });

  test('the supported list is non-empty and includes the default', () => {
    expect(supportedTimezones()).toContain('America/Toronto');
  });
});
