// Residential bandwidth accounting for polls.
//
// The regression this guards: a 304 Not Modified serves the body from our own
// validator cache but the old code billed its FULL size again as fresh
// residential bytes. Every conditional poll therefore overstated usage by the
// whole payload, which trips the monthly budget early and makes the operator
// buy bandwidth that was never spent. Conditional requests are also the cheapest
// poll available, so mispricing them discourages exactly the right behaviour.
import { describe, expect, test } from '@jest/globals';
import { billedPollBytes } from '../../helpers/stock-monitor.js';

describe('billedPollBytes', () => {
  test('a normal poll bills its body plus fixed request overhead', () => {
    expect(billedPollBytes({ bodyLength: 10_000 })).toBe(10_000 + 4096);
  });

  test('a 304 bills a small header-only cost regardless of the cached body', () => {
    expect(billedPollBytes({ bodyLength: 10_000, notModified: true })).toBe(1024);
    // The point: a conditional poll is an order of magnitude cheaper than a miss.
    expect(billedPollBytes({ bodyLength: 200_000, notModified: true }))
      .toBeLessThan(billedPollBytes({ bodyLength: 200_000 }) / 50);
  });

  test('an empty body still bills overhead, never a negative', () => {
    expect(billedPollBytes({ bodyLength: 0 })).toBe(4096);
    expect(billedPollBytes({})).toBe(4096);
  });

  test('a non-numeric body length is treated as zero', () => {
    expect(billedPollBytes({ bodyLength: null })).toBe(4096);
    expect(billedPollBytes({ bodyLength: 'nope' })).toBe(4096);
    expect(billedPollBytes({ bodyLength: -50 })).toBe(4096);
  });
});
