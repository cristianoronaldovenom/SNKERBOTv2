// Fingerprint stability audit tests.
//
// Regression this guards: three separate live bugs (double-randomised rtt,
// per-launch canvas noise, webdriver changing type) were all cross-sample drift
// and all invisible to the single-snapshot checks in fingerprint-coherence.js.
// The auditor must flag drift, ignore legitimately volatile fields, and never
// invent an issue from fewer than two samples.
import { describe, expect, test } from '@jest/globals';
import {
  SURFACE_PROBE, auditSamples, compareSamples, implausibilities
} from '../../helpers/fingerprint-audit.js';

const base = () => ({
  webdriverType: 'boolean', webdriverValue: false,
  hardwareConcurrency: 8, deviceMemory: 8, language: 'en-CA', languages: 'en-CA,en',
  platform: 'MacIntel', connectionRtt: 50, connectionDownlink: 10, connectionType: 'wifi',
  screenWidth: 1512, screenHeight: 982, availWidth: 1512, availTop: 25,
  outerWidth: 1486, outerHeight: 982, dpr: 2, hasFocus: true, visibility: 'visible',
  webglVendor: 'Google Inc. (Apple)', webglRenderer: 'ANGLE (Apple, Apple M1, Metal)',
  plugins: 5, mimeTypes: 2, brandCount: 3, timezone: 'America/Toronto', quota: 'present'
});

describe('the probe itself', () => {
  test('it is a self-contained IIFE that survives being embedded', () => {
    expect(SURFACE_PROBE.startsWith('(() => {')).toBe(true);
    expect(SURFACE_PROBE.endsWith('})()')).toBe(true);
    // Each read is individually guarded, or one blocked API voids the sample.
    expect(SURFACE_PROBE).toContain('catch (_)');
  });

  test('it probes the surfaces the earlier bugs lived in', () => {
    for (const field of ['webdriverType', 'connectionRtt', 'availTop', 'screenY', 'hasFocus']) {
      expect(SURFACE_PROBE).toContain(field);
    }
  });
});

describe('cross-sample comparison', () => {
  test('identical samples produce no issues', () => {
    expect(compareSamples([base(), base()])).toHaveLength(0);
  });

  test('fewer than two samples cannot conclude anything', () => {
    expect(compareSamples([])).toHaveLength(0);
    expect(compareSamples([base()])).toHaveLength(0);
    expect(compareSamples([base(), null])).toHaveLength(0);
  });

  test('a drifting numeric field is high severity', () => {
    const issues = compareSamples([base(), { ...base(), connectionRtt: 1234 }]);
    expect(issues).toHaveLength(1);
    expect(issues[0].field).toBe('connectionRtt');
    expect(issues[0].severity).toBe('high');
    expect(issues[0].values).toEqual(['50', '1234']);
  });

  test('webdriver changing type between samples is caught', () => {
    const issues = compareSamples([base(), { ...base(), webdriverType: 'undefined' }]);
    expect(issues.map((i) => i.field)).toContain('webdriverType');
  });

  test('a drifting string field is reported at medium severity', () => {
    const issues = compareSamples([base(), { ...base(), webglRenderer: 'SwiftShader' }]);
    expect(issues[0].severity).toBe('medium');
  });

  test('volatile fields are ignored', () => {
    expect(compareSamples([base(), { ...base(), quota: 'other' }])).toHaveLength(0);
  });

  test('null and undefined compare equal, so a blocked read is not drift', () => {
    expect(compareSamples([{ ...base(), connectionRtt: null }, { ...base(), connectionRtt: undefined }]))
      .toHaveLength(0);
  });

  test('three samples exposing a field the first omitted still report drift', () => {
    const a = base();
    delete a.screenY;
    const issues = compareSamples([a, { ...base(), screenY: 0 }, { ...base(), screenY: 25 }]);
    expect(issues.map((i) => i.field)).toContain('screenY');
  });
});

describe('static implausibilities', () => {
  test('a clean sample has none', () => {
    expect(implausibilities(base())).toHaveLength(0);
  });

  test('webdriver must be a boolean', () => {
    expect(implausibilities({ ...base(), webdriverType: 'function' })).toHaveLength(1);
  });

  test('the primary language must be first in the list', () => {
    const issues = implausibilities({ ...base(), language: 'fr' });
    expect(issues[0].field).toBe('language');
  });

  test('a visible page must report focus', () => {
    expect(implausibilities({ ...base(), hasFocus: false })[0].field).toBe('hasFocus');
  });

  test('the work area and window may not exceed the screen', () => {
    expect(implausibilities({ ...base(), availWidth: 2000 })[0].field).toBe('availWidth');
    expect(implausibilities({ ...base(), outerWidth: 2000 })[0].field).toBe('outerWidth');
  });
});

describe('auditSamples', () => {
  test('clean samples are ok', () => {
    const out = auditSamples([base(), base()]);
    expect(out.ok).toBe(true);
    expect(out.samples).toBe(2);
    expect(out.issues).toHaveLength(0);
  });

  test('statics and drift are combined into one report', () => {
    const out = auditSamples([{ ...base(), language: 'fr' }, { ...base(), connectionRtt: 9 }]);
    expect(out.ok).toBe(false);
    expect(out.issues.map((i) => i.field).sort()).toEqual(['connectionRtt', 'language']);
  });

  test('no samples is reported without inventing issues', () => {
    const out = auditSamples([]);
    expect(out.samples).toBe(0);
    expect(out.ok).toBe(true);
  });
});
