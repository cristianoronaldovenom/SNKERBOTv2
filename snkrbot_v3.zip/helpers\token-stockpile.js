// Challenge precomputation — pre-solve captcha tokens so checkout is instant.
//
// Why this exists: the costliest step in a hot-drop checkout isn't the ATC or
// form-fill — it's the captcha solve (10–30s for hCaptcha, 15–25s for
// reCAPTCHA v2, 3–8s for Turnstile). Pro bots run a background harvester loop
// that pre-solves tokens for known sitekeys BEFORE the drop, so when the
// adapter calls captcha.solve(), it gets a token instantly from the cache
// instead of waiting.
//
// Token TTLs:
//   hCaptcha  — ~120s from solve time
//   reCAPTCHA — ~120s
//   Turnstile — ~300s (5 min)
//
// We conservatively expire tokens at 80% of TTL to avoid submitting stale ones.
// When the cache is empty, the adapter falls back to real-time solving normally.

import logger from './logger.js';

const TOKEN_TTL_MS = {
  hcaptcha:  0.80 * 120_000,   // 96 seconds
  recaptcha: 0.80 * 120_000,   // 96 seconds
  turnstile: 0.80 * 300_000    // 240 seconds
};

// cache[type+sitekey] = [{ token, harvestedAt }, ...]
const cache = new Map();
// stockpiling state: Map<type+sitekey, { stop: fn, interval }>
const loops = new Map();

const cacheKey = (type, siteKey) => `${type}::${siteKey}`;

// Push a freshly-solved token into the stockpile — see the capped depositToken below.

// Pop the freshest valid token for this type+sitekey. Returns null if none.
export const consumeToken = (type, siteKey) => {
  const k = cacheKey(type, siteKey);
  const pool = cache.get(k) || [];
  const ttl = TOKEN_TTL_MS[type] || 96_000;
  const now = Date.now();

  // Sweep expired tokens first
  const fresh = pool.filter((t) => now - t.harvestedAt < ttl);
  if (fresh.length !== pool.length) {
    cache.set(k, fresh);
    logger.debug(`[TokenStockpile] Swept ${pool.length - fresh.length} expired tokens for ${siteKey}`);
  }
  if (fresh.length === 0) return null;

  // Pop freshest (most recently harvested — highest remaining TTL)
  fresh.sort((a, b) => b.harvestedAt - a.harvestedAt);
  const { token, harvestedAt } = fresh.shift();
  cache.set(k, fresh);

  // `ageS` used to be a chained expression evaluated against the *next* item
  // (and never logged). Report the real age of the token actually popped.
  const ageS = ((now - harvestedAt) / 1000).toFixed(1);
  logger.info(`[TokenStockpile] ⚡ Consumed pre-solved ${type} token for ${siteKey} (age ${ageS}s) — ${fresh.length} remaining`);
  return token;
};

// Depth cap. Without it a hot refill loop (or a task that keeps re-arming the same
// sitekey) keeps calling PAID providers forever, which burns API credit for tokens
// that expire unused. Two fresh tokens cover a burst; a third is rarely consumable
// inside the 96-240s TTL.
const MAX_DEPTH = Math.max(1, Number(process.env.CAPTCHA_STOCKPILE_MAX_DEPTH || 3));

// How many fresh tokens are in the stockpile for a given sitekey.
export const stockpileDepth = (type, siteKey) => {
  const k = cacheKey(type, siteKey);
  const pool = cache.get(k) || [];
  const ttl = TOKEN_TTL_MS[type] || 96_000;
  const now = Date.now();
  return pool.filter((t) => now - t.harvestedAt < ttl).length;
};

// A deposit is refused when the pool is already at cap, so the caller knows not to
// keep solving. Returns false on refusal.
export const depositToken = (type, siteKey, token) => {
  if (typeof token !== 'string' || token.length < 20) return false;
  const k = cacheKey(type, siteKey);
  const pool = cache.get(k) || [];
  const ttl = TOKEN_TTL_MS[type] || 96_000;
  const now = Date.now();
  if (pool.filter((t) => now - t.harvestedAt < ttl).length >= MAX_DEPTH) {
    logger.debug(`[TokenStockpile] Pool full (${MAX_DEPTH}) for ${siteKey} — refusing another paid solve`);
    return false;
  }
  if (!cache.has(k)) cache.set(k, []);
  cache.get(k).push({ token, harvestedAt: now });
  logger.info(`[TokenStockpile] Deposited ${type} token for ${siteKey} — pool size: ${cache.get(k).length}`);
  return true;
};

// Start a background loop that pre-solves tokens for a sitekey using the
// configured captcha solvers. The loop refills whenever the stockpile drops
// below `targetDepth` (default 2 tokens). On major drops you want 2–3 tokens
// ready per concurrent task to handle bursts without blocking on the solver.
//
// `solveOnce` must be an async fn(type, sitekey, pageUrl) → token string.
// Wire it to your captcha cascade (helpers/captcha.js solve()).
//
// Returns a stop() function that cancels the background loop.
export const startStockpiling = ({
  type,
  siteKey,
  pageUrl,
  solveOnce,
  targetDepth = 2,
  refillIntervalMs = 15_000    // check every 15s, solve if below target
}) => {
  if (typeof solveOnce !== 'function') throw new Error('startStockpiling: solveOnce must be a function');
  // `depth >= targetDepth` with a 0/negative target never solves, and the
  // `need` loop then runs zero times — a silently dead background loop.
  targetDepth = Math.max(1, Number.parseInt(targetDepth, 10) || 1);
  refillIntervalMs = Math.max(1000, Number.parseInt(refillIntervalMs, 10) || 15_000);
  const k = cacheKey(type, siteKey);
  if (loops.has(k)) {
    logger.warn(`[TokenStockpile] Already stockpiling ${type} for ${siteKey} — skipping duplicate`);
    return loops.get(k).stop;
  }

  let active = true;
  let inflight = false;

  const tick = async () => {
    if (!active || inflight) return;
    const depth = stockpileDepth(type, siteKey);
    if (depth >= targetDepth) return;

    inflight = true;
    const need = targetDepth - depth;
    logger.info(`[TokenStockpile] Refilling ${type} pool for ${siteKey} (have ${depth}, want ${targetDepth}) — solving ${need}×`);

    for (let i = 0; i < need && active; i++) {
      try {
        const token = await solveOnce(type, siteKey, pageUrl);
        if (token && typeof token === 'string' && token.length > 20) {
          depositToken(type, siteKey, token);
        } else {
          logger.warn(`[TokenStockpile] Solve returned empty/invalid token for ${siteKey}`);
        }
      } catch (err) {
        logger.warn(`[TokenStockpile] Background solve failed for ${siteKey}: ${err.message}`);
      }
    }
    inflight = false;
  };

  // Initial fill
  tick().catch(() => {});
  const timer = setInterval(tick, refillIntervalMs);

  const stop = () => {
    active = false;
    clearInterval(timer);
    loops.delete(k);
    logger.info(`[TokenStockpile] Stopped stockpiling ${type} for ${siteKey}`);
  };

  loops.set(k, { stop });
  logger.info(`[TokenStockpile] Started stockpiling ${type} for siteKey=${siteKey} (target depth ${targetDepth}, refill every ${refillIntervalMs / 1000}s)`);
  return stop;
};

// Idempotent variant of startStockpiling: safe to call from a hot adapter path
// (e.g. every captcha detection) — reuses the existing loop instead of warning.
// This is what lets an adapter "arm" a background pre-solver the first time it
// sees a retailer's sitekey, so later stages get an instant token.
export const ensureStockpiling = (opts) => {
  if (typeof opts?.solveOnce !== 'function') return null;
  const k = cacheKey(opts.type, opts.siteKey);
  if (loops.has(k)) return loops.get(k).stop;
  return startStockpiling(opts);
};

// Diagnostic snapshot.
export const stockpileReport = () => {
  const report = [];
  for (const [k] of cache.entries()) {
    const [type, siteKey] = k.split('::');
    report.push({
      type, siteKey,
      depth: stockpileDepth(type, siteKey),
      loopActive: loops.has(k)
    });
  }
  return report;
};

// Test helpers
export const __resetForTests = () => { cache.clear(); for (const { stop } of loops.values()) stop(); };
