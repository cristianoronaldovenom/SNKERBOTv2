import { tryRequestFirstAddToCart } from '../../helpers/browser-request-atc.js';
import { navigateCartUnlessReady } from '../../helpers/site-checkout-fastpath.js';
import logger from '../../helpers/logger.js';
import { humanType, humanTypeInFrames, humanClick, humanSelect } from '../../helpers/human-type.js';
import {
  formatPostal, stripPhone, dismissAutocomplete, verifyFieldValue,
  requireCardIframe, verifyCartHasItem, FillReport, assertCriticalFields,
  dismissAddressSuggestion, detectCardType
} from '../../helpers/autofill-utils.js';
import {
  guardedGoto, preOrderGuard, postClickGuard, takeFailureScreenshot, retryWithBackoff,
  detectBotBlockOnPage, detectQueuePage, waitForQueueToPass, hasCaptchaApiKey
} from '../../helpers/checkout-guards.js';
import { runStageWithRecovery } from '../../helpers/stage-retry.js';
import { captureOrderSuccess } from '../../helpers/order-capture.js';
import { storePageInTaskCache } from '../../helpers/task-cache.js';
import { waitForAnySelector, waitForUrlOrSelector, classifySiteError, sleep as runtimeSleep } from '../../helpers/site-runtime.js';
import { assertActionButtonIntent } from '../../helpers/checkout-controls.js';
import { detectAndSolveAkamai } from '../../helpers/akamai.js';
import { solveCaptcha, solveHCaptcha } from '../../helpers/captcha.js';
import { getCachedToken } from '../../helpers/captcha-cache.js';
import { consumeToken, depositToken, ensureStockpiling } from '../../helpers/token-stockpile.js';
import { notify } from '../../helpers/notifier.js';

const BASE_URL = 'https://www.bestbuy.ca';
const TIMEOUT = 15000;
const PLACE_ORDER_TIMEOUT = 60000;
const PDP_READY_TIMEOUT = 12000;
const CART_READY_TIMEOUT = 12000;
const CHECKOUT_READY_TIMEOUT = 20000;

// PDP stock polling. Best Buy releases stock mid-flip: a single PDP load that
// happens 400 ms too early sees "coming soon" and, without a poll loop, the task
// dies while the product is actually live. These mirror the Pokemon Center
// adapter's fast-burst-then-backoff shape so both flagship adapters recover from
// the same race.
const MONITOR_MAX_ATTEMPTS = Math.max(1, Number(process.env.BESTBUY_MONITOR_ATTEMPTS || 60));
const POLL_BASE_MS = 1600;
const POLL_JITTER_MS = 600;
const POLL_MAX_MS = 5000;
const FAST_BURST_ATTEMPTS = 4;

const computePollDelay = (attempt) => {
  const jitter = Math.floor((Math.random() - 0.5) * 2 * POLL_JITTER_MS);
  if (attempt < FAST_BURST_ATTEMPTS) return Math.max(800, POLL_BASE_MS + jitter);
  const backoff = Math.min(POLL_MAX_MS, POLL_BASE_MS + (attempt - FAST_BURST_ATTEMPTS) * 200);
  return Math.max(1200, backoff + jitter);
};

const BB_ATC_SELECTORS = 'button.addToCartButton:not([disabled]), button[data-testid="addToCartButton"]:not([disabled]), button[data-button-state="ADD_TO_CART"]:not([disabled])';

const BB_SOLD_OUT_SELECTORS = [
  '[class*="soldOut" i]',
  '[class*="sold-out" i]',
  '.availabilityMessage',
  '.productAvailability',
  '[data-automation*="availability" i]'
].join(', ');

const CART_BADGE_SELECTORS = [
  '[data-testid="cart-count"]',
  '[data-cart-count]',
  '.cart-count',
  '[aria-label*="cart" i]'
];

const SELECTORS = {
  addToCart: [
    'button.addToCartButton',
    'button[data-testid="addToCartButton"]',
    'button.add-to-cart-button',
    'button[data-button-state="ADD_TO_CART"]',
    '.pdp-cta button.primary',
    'button[data-automation="add-to-cart"]'
  ],
  qtySelect: [
    'select.quantity-dropdown',
    'select[name="quantity"]',
    'select[aria-label="Quantity"]',
    'input[name="quantity"]'
  ],
  cartCheckout: [
    'button[data-testid="checkout"]',
    'a.checkout-button',
    'button.checkout-btn',
    'a[href*="/checkout"]'
  ],
  guestCheckout: [
    'button[data-testid="guest-checkout"]',
    'a.guest-checkout',
    'button.continue-as-guest'
  ],
  email:      ['input[name="email"]', 'input#email', 'input[type="email"]'],
  firstName:  ['input[name="firstName"]', 'input#firstName'],
  lastName:   ['input[name="lastName"]', 'input#lastName'],
  address1:   ['input[name="addressLine"]', 'input[name="address1"]', 'input#addressLine'],
  address2:   ['input[name="addressLine2"]', 'input[name="address2"]', 'input#addressLine2', 'input[placeholder*="apt" i]'],
  city:       ['input[name="city"]', 'input#city'],
  province:   ['select[name="regionCode"]', 'select[name="state"]', 'select#regionCode'],
  postalCode: ['input[name="postalCode"]', 'input#postalCode'],
  phone:      ['input[name="phone"]', 'input[type="tel"]'],
  cardNumber: ['input[name="cardNumber"]', 'input#cardNumber', 'input[autocomplete="cc-number"]'],
  cardName:   ['input[name="nameOnCard"]', 'input#nameOnCard', 'input[autocomplete="cc-name"]'],
  expMonth:   ['select[name="expiryMonth"]', 'select#expiryMonth'],
  expYear:    ['select[name="expiryYear"]', 'select#expiryYear'],
  cvv:        ['input[name="cvv"]', 'input#cvv', 'input[autocomplete="cc-csc"]'],
  continue: [
    'button[data-testid="continue"]',
    'button.continue-button',
    'button[data-action="continue"]',
    'button[type="submit"].continue'
  ],
  billingSameAsShipping: [
    'input[name*="billing" i][name*="shipping" i]',
    'input[id*="billing" i][id*="shipping" i]',
    'input[name*="same" i][name*="billing" i]',
    'input[id*="same" i][id*="billing" i]'
  ],
  billingFirstName: ['input[name="billingFirstName"]', 'input[name*="billing" i][name*="first" i]', 'input[id*="billing" i][id*="first" i]'],
  billingLastName: ['input[name="billingLastName"]', 'input[name*="billing" i][name*="last" i]', 'input[id*="billing" i][id*="last" i]'],
  billingAddress1: ['input[name="billingAddress1"]', 'input[name*="billing" i][name*="address" i][name*="1"]', 'input[id*="billing" i][id*="address" i][id*="1"]'],
  billingAddress2: ['input[name="billingAddress2"]', 'input[name*="billing" i][name*="address" i][name*="2"]', 'input[id*="billing" i][id*="address" i][id*="2"]'],
  billingCity: ['input[name="billingCity"]', 'input[name*="billing" i][name*="city" i]', 'input[id*="billing" i][id*="city" i]'],
  billingProvince: ['select[name*="billing" i][name*="region" i]', 'select[id*="billing" i][id*="state" i]', 'select[id*="billing" i][id*="province" i]'],
  billingPostalCode: ['input[name="billingPostalCode"]', 'input[name*="billing" i][name*="postal" i]', 'input[id*="billing" i][id*="postal" i]'],
  billingPhone: ['input[name="billingPhone"]', 'input[name*="billing" i][name*="phone" i]', 'input[id*="billing" i][id*="phone" i]'],
  placeOrder: [
    'button[data-testid="place-order"]',
    'button.place-order-button',
    'button[data-action*="place-order" i]',
    'button[name*="place" i][type="submit"]',
    'button[type="submit"].order-now',
    'button[type="submit"][data-testid*="order" i]'
  ],
  orderConfirmation: [
    '.order-confirmation',
    '[data-testid="order-confirmation"]',
    '.thank-you-container',
    'h1.order-confirmation-title'
  ]
};

const sleep = runtimeSleep;

const isVisibleAndEnabled = async (el) => {
  try {
    return await el.evaluate((node) => {
      const r = node.getBoundingClientRect();
      const s = window.getComputedStyle(node);
      return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none' && !node.disabled && node.getAttribute('aria-disabled') !== 'true';
    });
  } catch (_) {
    return false;
  }
};

const findFirst = async (page, selectorList, timeout = TIMEOUT, { requireEnabled = true } = {}) => {
  const selector = await waitForAnySelector(page, selectorList, { timeout, requireEnabled });
  if (!selector) return null;
  const el = await page.$(selector).catch(() => null);
  return el ? { el, selector } : null;
};

const firstExistingSelector = async (page, selectorList) => {
  const found = await findFirst(page, selectorList, 2500);
  return found?.selector || null;
};

const clickFirst = async (page, selectorList, { stage = '', timeout = TIMEOUT } = {}) => {
  const found = await findFirst(page, selectorList, timeout);
  if (!found) throw new Error(`Could not find clickable element at stage "${stage}" — tried [${selectorList.join(', ')}]`);
  await humanClick(page, found.selector);
  return found.selector;
};

const waitForAnyVisible = async (page, selectorList, timeout = TIMEOUT) => {
  const found = await findFirst(page, selectorList, timeout, { requireEnabled: false });
  return found?.selector || null;
};

const waitForUrlOrSurface = async (page, { urlPattern = null, selectors = [], timeout = TIMEOUT } = {}) =>
  Boolean(await waitForUrlOrSelector(page, { urlPattern, selectors, timeout }));

const fillField = async (page, selectorList, value, { label = '', report = null, fieldHint = '', attempts = 3, optional = false } = {}) => {
  const name = label || 'unnamed';
  if (value == null || String(value) === '') {
    if (optional) {
      if (report) report.record(name, true, 'skipped (empty optional field)');
      return true;
    }
    if (report) report.record(name, false, 'empty value');
    return false;
  }

  for (let attempt = 1; attempt <= attempts; attempt++) {
    const found = await findFirst(page, selectorList, Math.min(8000, 4000 + attempt * 1000));
    if (!found) {
      if (attempt === attempts && report) report.record(name, false, 'selector not found');
      continue;
    }

    await found.el.click({ clickCount: 3 }).catch(() => {});
    await page.keyboard.press('Backspace').catch(() => {});
    const typed = await humanType(page, found.selector, String(value), { tabAfter: false, fieldType: fieldHint || 'text' });
    if (!typed) {
      if (attempt === attempts && report) report.record(name, false, 'typing failed');
      await sleep(250 * attempt);
      continue;
    }

    await dismissAutocomplete(page);
    await page.keyboard.press('Tab').catch(() => {});
    await sleep(80);

    const verifySelector = found.selector;
    const verification = await verifyFieldValue(page, verifySelector, value, fieldHint || name);
    if (verification.ok) {
      if (report) report.record(name, true);
      return true;
    }

    logger.warn(`[BestBuy] ${name} mismatch on attempt ${attempt}/${attempts}: got "${verification.actual}" expected "${verification.expected}"`);
    await sleep(120 * attempt);
  }

  if (report && !report.fields.some(f => f.name === name)) report.record(name, false, 'verification failed');
  return false;
};

const selectField = async (page, selectorList, value, { label = '', report = null, attempts = 2, optional = false } = {}) => {
  const name = label || 'select';
  if (value == null || String(value) === '') {
    if (optional) {
      if (report) report.record(name, true, 'skipped (empty optional field)');
      return true;
    }
    if (report) report.record(name, false, 'empty value');
    return false;
  }
  for (let attempt = 1; attempt <= attempts; attempt++) {
    const found = await findFirst(page, selectorList, 5000);
    if (!found) {
      await sleep(200 * attempt);
      continue;
    }
    const ok = await humanSelect(page, found.selector, value).catch(() => false);
    if (ok) {
      if (report) report.record(name, true);
      return true;
    }
    await sleep(200 * attempt);
  }
  if (report) report.record(name, false, 'select failed');
  return false;
};

const isCheckoutAuditEnabled = () => String(process.env.BESTBUY_CHECKOUT_AUDIT || '').toLowerCase() === '1' || String(process.env.BESTBUY_CHECKOUT_AUDIT || '').toLowerCase() === 'true';

// QA-only diagnostic: enumerate checkout controls without submitting the order.
// This is intentionally read-only so a test run cannot place a live order.
const auditCheckoutControls = async (page, stage) => {
  if (!isCheckoutAuditEnabled()) return null;

  const result = await page.evaluate(() => {
    const visible = (el) => {
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none';
    };
    const controls = Array.from(document.querySelectorAll('button, a, input[type="submit"], input[type="button"], [role="button"]'))
      .filter(visible)
      .map((el) => ({
        tag: el.tagName.toLowerCase(),
        text: String(el.innerText || el.value || el.getAttribute('aria-label') || '').replace(/\\s+/g, ' ').trim(),
        id: el.id || '',
        name: el.getAttribute('name') || '',
        testid: el.getAttribute('data-testid') || '',
        disabled: Boolean(el.disabled || el.getAttribute('aria-disabled') === 'true')
      }))
      .filter((x) => x.text || x.id || x.name || x.testid);

    const keywords = /(guest|continue|payment|shipping|delivery|review|place order|submit|checkout|next|apply|save|confirm)/i;
    const relevant = controls.filter((x) => keywords.test(`${x.text} ${x.id} ${x.name} ${x.testid}`));
    return { url: location.href, relevant, totalVisibleControls: controls.length };
  }).catch(() => ({ url: page.url(), relevant: [], totalVisibleControls: 0 }));

  logger.info(`[BestBuy][AUDIT] stage=${stage} url=${result.url}`);
  logger.info(`[BestBuy][AUDIT] relevant controls: ${result.relevant.map((x) => JSON.stringify(x)).join(' | ') || 'none'}`);
  return result;
};

const clickTextFallback = async (page, labels) => {
  const wanted = labels.map((x) => String(x).trim().toLowerCase());
  return await page.evaluate((terms) => {
    const visible = (el) => {
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none' && !el.disabled && el.getAttribute('aria-disabled') !== 'true';
    };
    const nodes = Array.from(document.querySelectorAll('button, a, input[type="submit"], [role="button"]')).filter(visible);
    for (const node of nodes) {
      const text = String(node.innerText || node.value || node.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim().toLowerCase();
      if (terms.some(term => text === term || text.includes(term))) {
        node.click();
        return text;
      }
    }
    return null;
  }, wanted).catch(() => null);
};

const waitForCheckoutSurface = async (page, timeout = CHECKOUT_READY_TIMEOUT) => {
  const found = await findFirst(page, [
    ...SELECTORS.email,
    ...SELECTORS.firstName,
    ...SELECTORS.address1,
    ...SELECTORS.cardNumber,
    ...SELECTORS.guestCheckout,
    ...SELECTORS.placeOrder
  ], timeout, { requireEnabled: false });
  if (!found) throw new Error('Best Buy checkout form did not become ready within the expected time');
  return found.selector;
};

const setQuantity = async (page, quantity) => {
  if (!quantity || quantity <= 1) return;
  const found = await findFirst(page, SELECTORS.qtySelect, 5000);
  if (!found) { logger.warn('[BestBuy] Quantity selector not found'); return; }
  const tag = await found.el.evaluate((el) => el.tagName.toLowerCase());
  if (tag === 'select') {
    await page.select(found.selector, String(quantity)).catch(() => {});
  } else {
    await found.el.click({ clickCount: 3 }).catch(() => {});
    await humanType(page, found.selector, String(quantity));
  }
  await page.waitForFunction((sel, expected) => {
    const el = document.querySelector(sel);
    if (!el) return true;
    return String(el.value || '') === String(expected);
  }, { timeout: 2500 }, found.selector, quantity).catch(() => {});
  logger.info(`[BestBuy] Quantity set to ${quantity}`);
};

// Refresh Akamai _abck/bm_sz via the local BMP generator and reload once.
const refreshAkamaiSession = async (page, task) => {
  const html = await page.content();
  const ua = await page.evaluate(() => navigator.userAgent);
  const cookies = await page.cookies();
  const host = new URL(task.url).hostname;
  const sessionCookies = new Map([[host, cookies.map((c) => `${c.name}=${c.value}`).join('; ')]]);
  const freshAbck = await detectAndSolveAkamai({ html, pageUrl: page.url(), ua, sessionCookies });
  if (freshAbck) {
    await page.setCookie({ name: '_abck', value: freshAbck, domain: '.bestbuy.ca', path: '/' }).catch(() => {});
    logger.info(`[BestBuy] Task ${task.id} — _abck refreshed via Akamai BMP, reloading`);
    await page.reload({ waitUntil: 'domcontentloaded', timeout: 30000 });
  } else {
    await page.reload({ waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
  }
};

// Read PDP availability without acting on it. Reporting `soldOut`/`atcReady`
// separately lets the poll loop keep retrying a "coming soon" page instead of
// treating it as a hard failure.
const readPdpState = async (page) => page.evaluate(({ atcSel, soldSel }) => {
  const visible = (el) => {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    const st = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && st.display !== 'none' && st.visibility !== 'hidden';
  };
  const atc = Array.from(document.querySelectorAll('button, input[type=submit], [role=button]')).find((el) =>
    visible(el) &&
    /(add to cart|add to bag|pre-?order)/i.test(String(el.innerText || el.value || el.getAttribute('aria-label') || '')) &&
    !el.disabled && el.getAttribute('aria-disabled') !== 'true'
  );
  const soldOut = Array.from(document.querySelectorAll(soldSel))
    .some((el) => visible(el) && /(sold out|out of stock|currently unavailable|not available)/i.test(el.textContent || ''));
  const comingSoon = /coming soon|notify me when available|release date/i.test(document.body?.innerText || '');
  const hasAtcSelector = Boolean(document.querySelector(atcSel));
  return { atcReady: Boolean(atc) || hasAtcSelector, soldOut, comingSoon };
}, { atcSel: BB_ATC_SELECTORS, soldSel: BB_SOLD_OUT_SELECTORS })
  .catch(() => ({ atcReady: false, soldOut: false, comingSoon: false }));

const waitForPdpReady = async (page, timeout = 3000) => {
  await page.waitForFunction((sel) => Boolean(document.querySelector(sel)), { timeout }, BB_ATC_SELECTORS).catch(() => {});
  return readPdpState(page);
};

// Detect and inject a captcha token. Tries the background stockpile first
// (pre-solved, zero latency), then the short-lived in-process cache, and only
// then spends a paid solve — so a warm stockpile makes checkout effectively
// captcha-free on a drop.
// Start (once per sitekey) a background captcha pre-solver so the next stage can
// consume an already-solved token. Idempotent and off the critical path.
const STOCKPILE_ARMED = new Set();
const armStockpile = (type, siteKey, pageUrl) => {
  try {
    if (!type || !siteKey) return;
    const key = `${type}::${siteKey}`;
    if (STOCKPILE_ARMED.has(key)) return;
    STOCKPILE_ARMED.add(key);
    ensureStockpiling({
      type,
      siteKey,
      pageUrl,
      targetDepth: Math.max(1, Number(process.env.CAPTCHA_STOCKPILE_DEPTH || 2)),
      refillIntervalMs: Math.max(5000, Number(process.env.CAPTCHA_STOCKPILE_REFILL_MS || 30000)),
      solveOnce: async (t, key2, url) => (t === 'hcaptcha'
        ? solveHCaptcha({ siteKey: key2, pageUrl: url })
        : solveCaptcha({ siteKey: key2, pageUrl: url }))
    });
    logger.info(`[BestBuy] Captcha stockpile armed for ${key}`);
  } catch (err) {
    logger.warn(`[BestBuy] Captcha stockpile arming failed: ${err.message}`);
  }
};

const handleCaptcha = async ({ page, task, where = 'unknown' }) => {
  const info = await page.evaluate(() => {
    const rc = document.querySelector('.g-recaptcha, [data-sitekey]');
    const hc = document.querySelector('.h-captcha, [data-hcaptcha-sitekey]');
    const iframeRC = document.querySelector('iframe[src*="recaptcha"]');
    const iframeHC = document.querySelector('iframe[src*="hcaptcha"]');
    if (hc || iframeHC) {
      const siteKey = hc?.dataset?.sitekey || hc?.dataset?.hcaptchaSitekey
        || iframeHC?.src?.match(/[?&]sitekey=([^&]+)/)?.[1] || null;
      return { type: 'hcaptcha', siteKey };
    }
    if (rc || iframeRC) {
      const siteKey = rc?.dataset?.sitekey || iframeRC?.src?.match(/[?&]k=([^&]+)/)?.[1] || null;
      return { type: 'recaptcha', siteKey };
    }
    return null;
  }).catch(() => null);

  if (!info?.siteKey) return;

  armStockpile(info.type, info.siteKey, page.url());

  let token = consumeToken(info.type, info.siteKey)
    || getCachedToken(info.type, info.siteKey, page.url());

  if (!token) {
    token = info.type === 'hcaptcha'
      ? await solveHCaptcha({ siteKey: info.siteKey, pageUrl: page.url(), page })
      : await solveCaptcha({ siteKey: info.siteKey, pageUrl: page.url(), page });
    // Store in the stockpile ONLY. Both a captcha token and its cache entry are
    // single-use; writing the same token to the stockpile *and* the token cache
    // meant the next stage could hand the site an already-spent copy (the read
    // chain below hits the stockpile first, so the cache copy is only reachable
    // once the stockpile copy is gone — i.e. always the second read).
    if (token) depositToken(info.type, info.siteKey, token);
  }
  if (!token) return;

  await page.evaluate(({ token, type }) => {
    const isH = type === 'hcaptcha';
    const el = document.querySelector(isH ? '[name="h-captcha-response"]' : '#g-recaptcha-response');
    if (el) {
      el.style.display = 'block';
      el.value = token;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    }
    if (isH) {
      try { globalThis.hcaptcha?.execute?.(); } catch (_) {}
    } else {
      const cfg = globalThis.___grecaptcha_cfg;
      if (cfg) {
        Object.values(cfg.clients || {}).forEach((client) => {
          const walk = (obj, depth = 0) => {
            if (depth > 6 || !obj || typeof obj !== 'object') return;
            if (typeof obj.callback === 'function') { try { obj.callback(token); } catch (_) {} }
            Object.values(obj).forEach((v) => walk(v, depth + 1));
          };
          walk(client);
        });
      }
    }
  }, { token, type: info.type }).catch(() => {});

  await sleep(900);
  logger.info(`[BestBuy] ${info.type} token injected at "${where}" for task ${task.id}`);
};


const tryAutoCaptcha = async ({ page, task, where }) => {
  try {
    if (!(await hasCaptchaApiKey())) return;
    await handleCaptcha({ page, task, where });
  } catch (err) {
    logger.warn(`[BestBuy] tryAutoCaptcha(${where}) error: ${err.message}`);
  }
};

// Bot-block + captcha gate, matching the Pokemon Center adapter's hardened
// pre-stage check. Best Buy Canada fronts checkout with Akamai, so a stampede can
// land on the "Access Denied"/bm-verify interstitial; a stale _abck cookie is
// refreshed here before the click instead of after a failed one.
const guardedStage = async (page, task, stageName) => {
  const block = await detectBotBlockOnPage(page);
  if (block.blocked) {
    logger.warn(`[BestBuy] Task ${task.id} — bot-block detected before ${stageName} (vendor: ${block.vendor}). Attempting Akamai refresh…`);
    await refreshAkamaiSession(page, task).catch(() => {});
    const after = await detectBotBlockOnPage(page);
    if (after.blocked) {
      throw new Error(`Site blocked bot at "${stageName}" (vendor: ${after.vendor}). HTML snippet: ${after.htmlSnippet?.slice(0, 200)}`);
    }
  }
  await postClickGuard(page, { taskId: task.id, stage: stageName });
  await tryAutoCaptcha({ page, task, where: stageName });
  return true;
};

const addToCart = async ({ page, task }) => {
  await retryWithBackoff(async () => {
    const addSelector = await firstExistingSelector(page, SELECTORS.addToCart)
      || await firstExistingSelector(page, [BB_ATC_SELECTORS]);
    if (!addSelector) throw new Error('Best Buy Add to Cart control not ready');

    // Request-first: when the visible button belongs to a same-origin POST form,
    // submitting it directly skips a click round-trip. Falls back to a real
    // human click when the PDP does the mutation in JS.
    if (!(await tryRequestFirstAddToCart(page, [...SELECTORS.addToCart, BB_ATC_SELECTORS]))) {
      await humanClick(page, addSelector);
    }

    const cartReady = await waitForUrlOrSurface(page, {
      urlPattern: /(?:cart|basket|checkout)/i,
      selectors: [...SELECTORS.cartCheckout, ...SELECTORS.guestCheckout],
      timeout: 5000
    });
    if (!cartReady) {
      // Some Best Buy variants keep the PDP URL while mutating the mini-cart.
      const cartSignal = await waitForAnyVisible(page, CART_BADGE_SELECTORS, 2500);
      if (!cartSignal) throw new Error('Add to Cart click did not produce a cart readiness signal');
    }
  }, { attempts: 3, baseMs: 500, label: `BestBuy addToCart task ${task.id}` });
};

const navigateToCheckout = async ({ page, task }) => {
  if (!/(?:\/checkout|\/basket|\/cart)(?:\/|$)/i.test(page.url())) {
    await guardedGoto(page, `${BASE_URL}/checkout`, { taskId: task.id, stage: 'checkout_load' }).catch(() =>
      guardedGoto(page, `${BASE_URL}/basket`, { taskId: task.id, stage: 'basket_load' })
    );
  }

  const cartCheck = await verifyCartHasItem(page, { timeout: CART_READY_TIMEOUT });
  if (cartCheck.empty) {
    const err = new Error('Cart is empty after add-to-cart — product may be out of stock');
    err.failureType = 'oos';
    throw err;
  }

  const queue = await detectQueuePage(page);
  if (queue.queued) {
    logger.info(`[BestBuy] Task ${task.id} entered ${queue.type} queue — waiting`);
    const passed = await waitForQueueToPass(page, { timeout: 1800000, taskId: task.id });
    if (!passed) throw classifySiteError(new Error(`Queue timeout during checkout (${queue.type})`), 'queue', 'navigateToCheckout');
  }

  const checkoutSelector = await firstExistingSelector(page, SELECTORS.cartCheckout, 5000);
  if (checkoutSelector) {
    await humanClick(page, checkoutSelector);
    await waitForUrlOrSurface(page, {
      urlPattern: /checkout/i,
      selectors: [...SELECTORS.guestCheckout, ...SELECTORS.email, ...SELECTORS.firstName],
      timeout: 10000
    });
    await guardedStage(page, task, 'cart_to_checkout');
  }

  const guestSelector = await firstExistingSelector(page, SELECTORS.guestCheckout);
  if (guestSelector) {
    await humanClick(page, guestSelector);
    await waitForCheckoutSurface(page, CHECKOUT_READY_TIMEOUT);
    await guardedStage(page, task, 'guest_checkout');
  } else {
    const guestByText = await clickTextFallback(page, ['continue as guest', 'guest checkout']);
    if (guestByText) {
      await waitForCheckoutSurface(page, CHECKOUT_READY_TIMEOUT);
      await guardedStage(page, task, 'guest_checkout_text');
    }
  }

  await waitForCheckoutSurface(page, CHECKOUT_READY_TIMEOUT);
};

const fillShipping = async ({ page, task }) => {
  const ship = task.shippingAddress;
  if (!ship) throw new Error('Shipping address missing at stage "fill_shipping"');

  const report = new FillReport(task.id, 'BestBuy Shipping');
  const fields = [
    [SELECTORS.email, task.notification_email_address || ship.email, { label: 'email' }],
    [SELECTORS.firstName, ship.first_name, { label: 'firstName' }],
    [SELECTORS.lastName, ship.last_name, { label: 'lastName' }],
    [SELECTORS.address1, ship.address1, { label: 'address1' }],
    [SELECTORS.address2, ship.address2, { label: 'address2', optional: true }],
    [SELECTORS.city, ship.city, { label: 'city' }],
    [SELECTORS.postalCode, formatPostal(ship.zip, ship.country || 'CA'), { label: 'postalCode', fieldHint: 'postal' }],
    [SELECTORS.phone, stripPhone(ship.phone), { label: 'phone', fieldHint: 'phone' }],
  ];
  for (const [selectors, value, opts] of fields) {
    await fillField(page, selectors, value, { ...opts, report });
  }
  await selectField(page, SELECTORS.province, ship.state, { label: 'province', report });
  await dismissAddressSuggestion(page);

  report.log();
  assertCriticalFields(report, ['email', 'firstName', 'lastName', 'address1', 'city', 'postalCode', 'phone']);

  const continueSelector = await firstExistingSelector(page, SELECTORS.continue);
  if (continueSelector) await humanClick(page, continueSelector);
  else {
    const clicked = await clickTextFallback(page, ['continue to payment', 'continue', 'next']);
    if (!clicked) throw new Error('Best Buy shipping continue button not found');
  }

  await waitForAnyVisible(page, [...SELECTORS.cardNumber, ...SELECTORS.placeOrder], 15000);
  await guardedStage(page, task, 'continue_to_payment');
};

const fillPayment = async ({ page, task }) => {
  const pay = task.paymentProfile;
  if (!pay) throw new Error('Payment profile missing at stage "fill_payment"');

  await requireCardIframe(page, { timeout: 15000 });
  const report = new FillReport(task.id, 'BestBuy Payment');
  const cardNumber = String(pay.card_number || '').replace(/\s/g, '');

  let cardNameOk = false;
  let cardNumberOk = false;
  for (let attempt = 1; attempt <= 3 && (!cardNameOk || !cardNumberOk); attempt++) {
    if (!cardNameOk) cardNameOk = await humanTypeInFrames(page, SELECTORS.cardName.join(', '), pay.card_holder_name, { tabAfter: true, fieldType: 'text' });
    if (!cardNumberOk) cardNumberOk = await humanTypeInFrames(page, SELECTORS.cardNumber.join(', '), cardNumber, { tabAfter: true, fieldType: 'number' });
    if (!cardNameOk || !cardNumberOk) {
      await requireCardIframe(page, { timeout: 5000 }).catch(() => {});
      await sleep(250 * attempt);
    }
  }
  report.record('cardName', cardNameOk, cardNameOk ? '' : 'not found in main page or payment iframe');
  report.record('cardNumber', cardNumberOk, cardNumberOk ? '' : 'not found in main page or payment iframe');

  const cardType = detectCardType(cardNumber);
  if (cardType) {
    const cardTypeFound = await firstExistingSelector(page, ['select[name="cardType"]', 'select#cardType', 'select[id*=cardtype i]']);
    if (cardTypeFound) report.record('cardType', await humanSelect(page, cardTypeFound, cardType).catch(() => false));
  }

  const monthOk = await selectField(page, ['select[name="expiryMonth"]', 'select[name="expirationMonth"]', 'select#expiryMonth', 'select[id*=month i]'], pay.expiration_month, { label: 'expirationMonth', report, attempts: 2 });
  const yearOk = await selectField(page, ['select[name="expiryYear"]', 'select[name="expirationYear"]', 'select#expiryYear', 'select[id*=year i]'], pay.expiration_year, { label: 'expirationYear', report, attempts: 2 });
  if (!monthOk) {
    const typedMonth = await humanTypeInFrames(page, 'input[name="expiryMonth"], input[name="expirationMonth"], input[data-cse*="ExpiryMonth"]', pay.expiration_month, { tabAfter: true }).catch(() => false);
    if (typedMonth) {
      const entry = report.fields.find((f) => f.name === 'expirationMonth');
      if (entry) entry.ok = true;
    }
  }
  if (!yearOk) {
    const typedYear = await humanTypeInFrames(page, 'input[name="expiryYear"], input[name="expirationYear"], input[data-cse*="ExpiryYear"]', pay.expiration_year, { tabAfter: true }).catch(() => false);
    if (typedYear) {
      const entry = report.fields.find((f) => f.name === 'expirationYear');
      if (entry) entry.ok = true;
    }
  }

  let cvvOk = false;
  for (let attempt = 1; attempt <= 3 && !cvvOk; attempt++) {
    cvvOk = await humanTypeInFrames(page, SELECTORS.cvv.join(', '), pay.cvv, { tabAfter: true, fieldType: 'number' });
    if (!cvvOk) await sleep(250 * attempt);
  }
  report.record('cvv', cvvOk, cvvOk ? '' : 'not found in main page or payment iframe');

  const billingFormPresent = await fillBillingAddress({ page, billing: task.billingAddress || task.shippingAddress, report });
  if (billingFormPresent) assertCriticalFields(report, ['billingFirstName', 'billingLastName', 'billingAddress1', 'billingCity', 'billingPostalCode']);
  report.log();
  assertCriticalFields(report, ['cardName', 'cardNumber', 'expirationMonth', 'expirationYear', 'cvv']);

  const paymentContinue = await firstExistingSelector(page, SELECTORS.continue);
  if (paymentContinue) await humanClick(page, paymentContinue);
  else {
    const clicked = await clickTextFallback(page, ['review order', 'continue to review', 'continue']);
    if (!clicked) logger.info('[BestBuy] No separate payment continue button found; continuing to order review detection');
  }
  await waitForAnyVisible(page, SELECTORS.placeOrder, 15000);
  await guardedStage(page, task, 'payment_review');
};

const placeOrder = async ({ page, task, startedAt }) => {
  await waitForAnyVisible(page, SELECTORS.placeOrder, PLACE_ORDER_TIMEOUT);
  const placeOrderSelector = await firstExistingSelector(page, SELECTORS.placeOrder);
  if (!placeOrderSelector) throw new Error('Best Buy Place Order control not found');

  const queue = await detectQueuePage(page);
  if (queue.queued) {
    logger.info(`[BestBuy] Task ${task.id} entered ${queue.type} queue before order — waiting`);
    const passed = await waitForQueueToPass(page, { timeout: 1800000, taskId: task.id });
    if (!passed) throw classifySiteError(new Error(`Queue timeout before Place Order (${queue.type})`), 'queue', 'placeOrder');
  }

  const guardResult = await preOrderGuard(page, { taskId: task.id });
  if (guardResult.threeDSecure) {
    // The bot cannot answer an OTP/SMS challenge. Clicking Place Order into a 3DS
    // interstitial leaves an ambiguous "did it submit?" state, so stop before the
    // click and alert the operator loudly enough to finish this one by hand.
    logger.warn(`[BestBuy] Task ${task.id} — 3D Secure detected (${guardResult.threeDSecure.url}). NOT clicking Place Order; alerting for manual action.`);
    await takeFailureScreenshot(page, task.id, 'placeOrder-3ds').catch(() => {});
    await notify({
      taskId: task.id,
      success: false,
      message: '🔐 3D Secure / bank verification required before Place Order. The bot cannot solve OTP/SMS — please finish this order manually now.',
      stage: 'place_order_3ds',
      productUrl: task.url,
      siteId: task.site_id || 9
    }).catch(() => {});
    const err = new Error('3D Secure challenge requires manual verification — stopped before Place Order to avoid an ambiguous submit');
    err.failureType = 'human_required';
    throw err;
  }

  await assertActionButtonIntent(page, SELECTORS.placeOrder, { stage: 'place order', allow: /place order|submit order|complete order/i });
  await humanClick(page, placeOrderSelector);

  const confirmed = await Promise.race([
    findFirst(page, SELECTORS.orderConfirmation, PLACE_ORDER_TIMEOUT),
    page.waitForFunction(() => /thank-you|order-confirmation|confirmation|order-complete/.test(window.location.pathname), { timeout: PLACE_ORDER_TIMEOUT }).then(() => ({ url: true })).catch(() => null)
  ]);
  if (!confirmed) {
    await takeFailureScreenshot(page, task.id, 'confirm_order_fail');
    throw new Error('Order confirmation not detected at stage "confirm_order"');
  }

  const orderNumber = await page.evaluate(() => {
    const selectors = [
      '[data-testid="order-number"]', '[data-test="order-number"]', '.order-number',
      '[class*="orderNumber" i]', '[class*="order-number" i]', '[aria-label*="order number" i]'
    ];
    for (const selector of selectors) {
      const el = document.querySelector(selector);
      if (el?.textContent?.trim()) return el.textContent.trim();
    }
    const text = document.body?.innerText || '';
    const match = text.match(/(?:order\s*(?:number|#)|confirmation\s*(?:number|#))\s*[:#]?\s*([A-Z0-9-]{5,})/i);
    return match ? match[1] : null;
  }).catch(() => null);

  logger.info(`[BestBuy] ✅ Order placed for task ${task.id}! Order: ${orderNumber || 'N/A'}`);
  await captureOrderSuccess({ page, taskId: task.id, orderNumber, productUrl: task.url, durationMs: Date.now() - startedAt }).catch(() => {});
};

// Poll the PDP until the Add to Cart control is genuinely live, then ATC.
//
// Why a loop and not a single load: the API monitor arms this task the moment
// stock flips, which is routinely 200–1500 ms before the PDP finishes rendering
// its live state. A one-shot load sees "coming soon"/disabled, throws, and the
// task is gone for the whole drop. Retrying in-page (no extra navigation) keeps
// the task alive across that window. If an ATC partially lands and then throws
// (mini-cart mutated but the signal timed out), the cart is re-checked so we
// don't double-add.
const monitorAndAtc = async ({ page, task }) => {
  logger.info(`[BestBuy] Monitoring product for task ${task.id}`);

  for (let attempt = 0; attempt < MONITOR_MAX_ATTEMPTS; attempt++) {
    try {
      if (attempt === 0 || !/\/product\//i.test(page.url())) {
        await guardedGoto(page, task.url, { taskId: task.id, stage: 'pdp_load', waitUntil: 'domcontentloaded', timeout: 30000 });
      }

      const queue = await detectQueuePage(page);
      if (queue.queued) {
        logger.info(`[BestBuy] Task ${task.id} entered ${queue.type} queue on PDP — waiting`);
        const passed = await waitForQueueToPass(page, { timeout: 1800000, taskId: task.id });
        if (!passed) throw classifySiteError(new Error(`Queue timeout on PDP (${queue.type})`), 'queue', 'monitorAndAtc');
      }

      const state = await waitForPdpReady(page, attempt === 0 ? PDP_READY_TIMEOUT : 3000);
      if (state.soldOut || !state.atcReady) {
        const delay = computePollDelay(attempt);
        logger.info(`[BestBuy] Task ${task.id} — ${state.soldOut ? 'sold out' : 'not ready'}, retrying in ${delay}ms (attempt ${attempt + 1}/${MONITOR_MAX_ATTEMPTS})`);
        await sleep(delay);
        continue;
      }

      // Blocked-but-rendered pages can still expose a stale Add to Cart button.
      // Refresh the Akamai session before clicking rather than after a failure.
      const block = await detectBotBlockOnPage(page);
      if (block.blocked) {
        logger.warn(`[BestBuy] Task ${task.id} — bot-block on PDP (vendor: ${block.vendor}), refreshing session`);
        await refreshAkamaiSession(page, task).catch(() => {});
        await sleep(computePollDelay(attempt));
        continue;
      }

      await auditCheckoutControls(page, 'pdp_loaded');
      await setQuantity(page, task.quantity);
      await addToCart({ page, task });
      return;
    } catch (err) {
      // A retryable in-page failure: if the item already reached the cart, stop
      // looping so the checkout stages run against a valid session.
      const cartCheck = await verifyCartHasItem(page, { timeout: 2500 }).catch(() => ({ empty: false }));
      if (!cartCheck.empty) {
        logger.info(`[BestBuy] Task ${task.id} — ATC recovered (cart already populated), continuing`);
        return;
      }
      logger.warn(`[BestBuy] Task ${task.id} monitor error: ${err.message}`);
      await sleep(computePollDelay(attempt));
    }
  }

  throw new Error(`[BestBuy] Task ${task.id} timed out waiting for product to be available`);
};

const runBestBuy = async ({ page, task, reportStage = null }) => {
  const startedAt = Date.now();
  logger.info(`[BestBuy] Starting task ${task.id}: ${task.url}`);
  page.setDefaultNavigationTimeout(30000);

  storePageInTaskCache({ taskId: task.id, page });

  const stages = [
    { name: 'monitorAndAtc', fn: () => monitorAndAtc({ page, task }) },
    { name: 'navigateToCheckout', fn: () => navigateToCheckout({ page, task }) },
    { name: 'fillShipping', fn: () => fillShipping({ page, task }) },
    { name: 'fillPayment', fn: () => fillPayment({ page, task }) },
    { name: 'placeOrder', fn: () => placeOrder({ page, task, startedAt }) },
  ];

  for (const stage of stages) {
    try {
      await reportStage?.(stage.name, 'running');
      // Gate every stage on bot-block/captcha state, exactly like the Pokemon
      // Center adapter. monitorAndAtc runs its own per-poll check inside the
      // loop, so it is skipped here to avoid doubling the work.
      if (stage.name !== 'monitorAndAtc') await guardedStage(page, task, stage.name);
      const stageAttempts = stage.name === 'placeOrder' ? 1 : (stage.name === 'monitorAndAtc' ? 1 : 2);
      await runStageWithRecovery(() => stage.fn(), {
        taskId: task.id, stage: stage.name, attempts: stageAttempts, baseMs: 350
      });
      await reportStage?.(stage.name, 'completed');
    } catch (err) {
      await takeFailureScreenshot(page, task.id, stage.name);
      if (/cart is empty|out of stock|sold out/i.test(err.message || '')) err.failureType = 'oos';
      else if (/session|cookie|cart.*expired|invalid.*session/i.test(err.message || '')) err.failureType = 'session_expired';
      else if (/queue timeout/i.test(err.message || '')) err.failureType = 'queue';
      else if (/3d secure|verification/i.test(err.message || '')) err.failureType = 'human_required';
      logger.error(`[BestBuy] Task ${task.id} failed at stage "${stage.name}": ${err.message}`);
      throw err;
    }
  }
};

const fillBillingAddress = async ({ page, billing, report }) => {
  if (!billing) return;

  const sameAsSelector = await firstExistingSelector(page, SELECTORS.billingSameAsShipping);
  if (sameAsSelector) {
    const same = await page.$eval(sameAsSelector, (el) => Boolean(el.checked)).catch(() => false);
    if (same) {
      report.record('billing', true, 'same as shipping');
      return false;
    }
  }

  const anyBillingField = await firstExistingSelector(page, [
    ...SELECTORS.billingFirstName,
    ...SELECTORS.billingLastName,
    ...SELECTORS.billingAddress1,
    ...SELECTORS.billingCity
  ]);
  if (!anyBillingField) {
    report.record('billing', true, 'billing form not present / shipping used');
    return false;
  }

  await fillField(page, SELECTORS.billingFirstName, billing.first_name, { label: 'billingFirstName', report });
  await fillField(page, SELECTORS.billingLastName, billing.last_name, { label: 'billingLastName', report });
  await fillField(page, SELECTORS.billingAddress1, billing.address1, { label: 'billingAddress1', report });
  await fillField(page, SELECTORS.billingAddress2, billing.address2, { label: 'billingAddress2', report, optional: true });
  await fillField(page, SELECTORS.billingCity, billing.city, { label: 'billingCity', report });
  await selectField(page, SELECTORS.billingProvince, billing.state, { label: 'billingProvince', report, optional: true });
  await fillField(page, SELECTORS.billingPostalCode, formatPostal(billing.zip, billing.country || 'CA'), { label: 'billingPostalCode', report, fieldHint: 'postal', optional: true });
  await fillField(page, SELECTORS.billingPhone, stripPhone(billing.phone), { label: 'billingPhone', report, fieldHint: 'phone', optional: true });
  return true;
};

export default runBestBuy;
