// Instant cart reservation — "secure the spot" the millisecond stock is detected.
//
// Why pro bots ship this: there's a gap of several seconds between detecting
// stock and a browser finishing a full checkout (launch, warm, navigate, fill).
// On a hot drop the item can sell out inside that gap. Pro bots close it by
// adding the item to a cart over plain HTTP *immediately* (no browser), which
// holds the unit while the slower browser checkout catches up.
//
// Scope (deliberately narrow to avoid speculative private-API breakage):
//   - Generic Shopify stores (site_id 2) via the public, unauthenticated
//     POST /cart/add.js endpoint — this is the ONLY adapter that consumes a
//     reservation (sites/shopify/index.js). Topps (site_id 7) is intentionally
//     excluded: although its stock check reads Shopify product JSON, its
//     CHECKOUT adapter is Demandware/SFCC-based and would not honor a Shopify
//     cart cookie, so reserving there would be wasted/incorrect work.
//   - Every other site returns { site:'unsupported' } so the caller falls back
//     to the existing browser ATC with ZERO behavior change.
//
// The reservation reuses the warm session cookies (so the add comes from an
// already-trusted session) and the task's proxy (so the add comes from the SAME
// IP that will run the checkout — a consistent identity, not a fresh one).
import logger from './logger.js';
import { tlsRequest } from './tls-client.js';
import { getSessionCookies } from './stock-monitor.js';
import { shopifyCheck } from './site-stock-apis.js';

const RESERVE_TIMEOUT_MS = 1500;
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

// Site_ids whose CHECKOUT adapter both speaks the /cart/add.js + /products/{handle}.json
// contract AND consumes task.reservation. Only generic Shopify (2) qualifies today.
const SHOPIFY_SITE_IDS = new Set([2]);

// Loose size match (e.g. "10.5" matches variant title "US 10.5" / option "10.5").
export const sizeMatches = (variantField, size) => {
  if (!size) return true;
  if (variantField == null || variantField === '') return false;
  const v = String(variantField).toLowerCase().trim();
  const s = String(size).toLowerCase().trim();
  return v === s || v.includes(s) || s.includes(v);
};

// Build a "name=value; name2=value2" Cookie header from a Set-Cookie response
// header (which may be a string or an array of strings depending on the sidecar).
export const extractCookieHeader = (headers = {}) => {
  if (!headers) return '';
  // Header keys can be any case; find the set-cookie one.
  let raw = null;
  for (const [k, val] of Object.entries(headers)) {
    if (k.toLowerCase() === 'set-cookie') { raw = val; break; }
  }
  if (!raw) return '';
  const list = Array.isArray(raw) ? raw : [raw];
  const pairs = [];
  for (const line of list) {
    if (typeof line !== 'string') continue;
    const first = line.split(';')[0].trim(); // "name=value"
    if (first && first.includes('=')) pairs.push(first);
  }
  return pairs.join('; ');
};

// Merge a warm "name=value; ..." cookie header with the fresh cart cookies,
// fresh values winning on a name clash. Handing BOTH to the browser preserves
// the trusted warm session AND the new cart token, so the reserved cart actually
// carries over instead of the browser opening a clean (cartless) session.
export const mergeCookieHeaders = (warm = '', fresh = '') => {
  const map = new Map();
  for (const part of [warm, fresh]) {
    if (!part) continue;
    for (const pair of part.split('; ')) {
      const p = pair.trim();
      const i = p.indexOf('=');
      if (i > 0) map.set(p.slice(0, i), p.slice(i + 1));
    }
  }
  return Array.from(map.entries()).map(([k, v]) => `${k}=${v}`).join('; ');
};

// Resolve the variant id to add. Priority: explicit ?variant= in the URL, then
// the public product JSON's first available variant matching the requested size.
export const resolveShopifyVariant = async ({ task, proxy, cookieHeader }) => {
  try {
    const fromUrl = new URL(task.url).searchParams.get('variant');
    if (fromUrl) return fromUrl;
  } catch (_) {}

  const apiUrl = shopifyCheck.extractApiUrl(task.url);
  if (!apiUrl) return null;

  const res = await tlsRequest({
    url: apiUrl,
    proxy,
    timeoutMs: RESERVE_TIMEOUT_MS,
    headers: {
      'User-Agent': UA,
      'Accept': 'application/json',
      ...(cookieHeader ? { Cookie: cookieHeader } : {}),
    },
  });
  if (!res.ok || res.status !== 200 || !res.body) return null;

  let data;
  try { data = JSON.parse(res.body); } catch (_) { return null; }
  const variants = data?.product?.variants || [];
  const available = variants.filter((v) => v.available);
  if (available.length === 0) return null;

  const target = task.size
    ? available.find((v) => sizeMatches(v.title, task.size) || sizeMatches(v.option1, task.size) || sizeMatches(v.option2, task.size))
    : available[0];
  return target ? String(target.id) : null;
};

const reserveShopify = async ({ task, proxy, cookieHeader }) => {
  const origin = new URL(task.url).origin;
  const variantId = await resolveShopifyVariant({ task, proxy, cookieHeader });
  if (!variantId) return { ok: true, reserved: false, site: 'shopify', error: 'no available variant resolved' };

  const qty = task.quantity && task.quantity > 0 ? task.quantity : 1;
  const res = await tlsRequest({
    method: 'POST',
    url: `${origin}/cart/add.js`,
    proxy,
    timeoutMs: RESERVE_TIMEOUT_MS,
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'X-Requested-With': 'XMLHttpRequest',
      'User-Agent': UA,
      'Origin': origin,
      'Referer': task.url,
      ...(cookieHeader ? { Cookie: cookieHeader } : {}),
    },
    body: JSON.stringify({ id: Number(variantId), quantity: qty }),
  });

  if (!res.ok) return { ok: false, reserved: false, site: 'shopify', variantId, error: res.error || 'tls request failed' };
  if (res.status !== 200) return { ok: false, reserved: false, site: 'shopify', variantId, error: `status ${res.status}` };

  // Hand the browser the warm session cookies AND the fresh cart token together
  // so the reserved cart actually carries over into Puppeteer.
  const cartCookies = mergeCookieHeaders(cookieHeader, extractCookieHeader(res.headers));

  // Request-first checkout handoff: opening /checkout over the same HTTP session
  // is materially cheaper than making Chromium navigate PDP -> cart -> checkout.
  // This is intentionally limited to generic Shopify's public checkout surface.
  let checkoutUrl = null;
  let checkoutReady = false;
  try {
    const checkout = await tlsRequest({
      method: 'GET',
      url: `${origin}/checkout`,
      proxy,
      timeoutMs: Math.max(RESERVE_TIMEOUT_MS, 1800),
      headers: {
        'Accept': 'text/html',
        'User-Agent': UA,
        'Referer': task.url,
        ...(cartCookies ? { Cookie: cartCookies } : {}),
      },
    });
    const body = String(checkout?.body || '').toLowerCase();
    const challenged = /just a moment|checking your browser|access denied|captcha|verify you are human/.test(body);
    if (checkout?.ok && checkout?.status >= 200 && checkout?.status < 400 && !challenged) {
      checkoutUrl = checkout.finalUrl || `${origin}/checkout`;
      checkoutReady = true;
    }
  } catch (_) {
    // Cart reservation remains valid even when opening /checkout over HTTP fails.
  }

  return { ok: true, reserved: true, site: 'shopify', variantId, cartCookies, checkoutUrl, checkoutReady };
};

// Attempt to secure a cart spot over HTTP. Always resolves (never throws) so a
// reservation failure can never block the real checkout. Returns:
//   { ok, reserved, site, variantId?, cartCookies?, error? }
export const reserveCart = async ({ task, proxy = null } = {}) => {
  try {
    if (!task?.url) return { ok: false, reserved: false, site: null, error: 'no task url' };

    if (!SHOPIFY_SITE_IDS.has(task.site_id)) {
      return { ok: false, reserved: false, site: 'unsupported', error: `site_id ${task.site_id} has no HTTP reservation path` };
    }

    let host;
    try { host = new URL(task.url).hostname; } catch (_) { return { ok: false, reserved: false, site: null, error: 'bad url' }; }

    const cookieHeader = getSessionCookies(host) || '';
    const result = await reserveShopify({ task, proxy, cookieHeader });

    if (result.reserved) {
      logger.info(`[CartReserver] 🛒 Secured a spot for task ${task.id} (${result.site}, variant ${result.variantId}) — browser checkout will reuse it`);
    } else {
      logger.info(`[CartReserver] No HTTP reservation for task ${task.id} (${result.error}) — browser ATC will handle it`);
    }
    return result;
  } catch (err) {
    logger.warn(`[CartReserver] reserveCart error for task ${task?.id}: ${err.message}`);
    return { ok: false, reserved: false, site: null, error: err.message };
  }
};

// Exported for unit testing the pure helpers without a live sidecar.
export const __test__ = { sizeMatches, extractCookieHeader, mergeCookieHeaders };
