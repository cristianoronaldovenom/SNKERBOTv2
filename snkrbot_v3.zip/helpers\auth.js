import session from 'express-session';
import connectPgSimple from 'connect-pg-simple';
import bcrypt from 'bcryptjs';
import db from '../db/index.js';

// Session secret. A known default is fine on a laptop and fatal in production: an
// attacker who read the source can forge a signed cookie for any userId.
//
// The supplied Compose config requires the variable, but launching outside it (bare
// `node app.js`, a PaaS, a one-off container) silently accepted the fallback. In
// production that is now a hard error unless explicitly allowed; in development it
// stays a warning so local runs are frictionless.
const FALLBACK_SECRET = 'sneakerbot-change-me-set-SESSION_SECRET';

// Any documented placeholder counts, not just our internal one. `.env.example` ships
// `change-me-to-a-random-64-char-hex-string` and the Compose flow copies that file
// verbatim, so checking only FALLBACK_SECRET meant the most likely real deployment
// path sailed through production with a publicly known secret and no warning.
const KNOWN_PLACEHOLDERS = new Set([
  FALLBACK_SECRET,
  'change-me-to-a-random-64-char-hex-string',
  'change-me',
  'changeme'
]);

export const isPlaceholderSecret = (value) => {
  const v = String(value || '').trim();
  if (!v) return false;
  if (KNOWN_PLACEHOLDERS.has(v)) return true;
  // A raw placeholder also tends to be short and literal. Catch the pattern without
  // flagging a real 64-hex secret (which never contains a hyphenated word).
  return /^change[-_]?me/i.test(v);
};


const secret = (() => {
  const configured = String(process.env.SESSION_SECRET || '').trim();
  const isProd = String(process.env.NODE_ENV || '').toLowerCase() === 'production';
  const allowFallback = ['1', 'true'].includes(String(process.env.ALLOW_INSECURE_SESSION_SECRET || '').toLowerCase());

  if (configured) {
    if (isProd && isPlaceholderSecret(configured)) {
      console.warn('[Auth] SESSION_SECRET is still a documented placeholder — sessions are forgeable until it is changed');
    }
    return configured;
  }

  if (isProd && !allowFallback) {
    throw new Error(
      'SESSION_SECRET is required in production. Generate one with `openssl rand -hex 32`, '
      + 'or set ALLOW_INSECURE_SESSION_SECRET=1 to run with the built-in fallback.'
    );
  }
  console.warn('[Auth] SESSION_SECRET not set — using fallback (sessions lost on restart, cookies forgeable)');
  return FALLBACK_SECRET;
})();

// Same posture as the rest of the app (TLS_VERIFY_STRICT). The session store is where
// session ids travel, so it should not be the one link that never verifies. Exported
// for the test matrix.
export const pgSsl = () => ({ rejectUnauthorized: ['1', 'true'].includes(String(process.env.TLS_VERIFY_STRICT || '').toLowerCase()) });

let store;
if (process.env.DATABASE_URL) {
  const PgSession = connectPgSimple(session);
  store = new PgSession({
    // Pass SSL inside conObject so pg.Pool picks it up correctly.
    conObject: {
      connectionString: process.env.DATABASE_URL,
      ssl: pgSsl()
    },
    createTable: false,   // table is created by Knex migration instead
    tableName: 'user_sessions',
    errorLog: (err) => console.warn('[Auth] Session store error (non-fatal):', err.message)
  });
}

// Should the session cookie carry `secure`?
//
// Only when the request really is HTTPS: setting it unconditionally breaks
// plain-HTTP LAN access, and leaving it off leaks the session id over cleartext
// (CWE-614). Explicit env wins (TLS-terminating proxies set it manually); otherwise
// it follows the configured public URL.
export const cookieSecure = ({ env = process.env } = {}) => {
  const explicit = String(env.SESSION_COOKIE_SECURE ?? '').trim().toLowerCase();
  if (explicit === 'true' || explicit === '1') return true;
  if (explicit === 'false' || explicit === '0') return false;
  return String(env.APP_URL || env.PUBLIC_URL || '').trim().toLowerCase().startsWith('https://');
};

export const sessionMiddleware = session({
  ...(store ? { store } : {}),
  secret,
  resave: false,
  saveUninitialized: false,
  // Rolling re-issue: the cookie is refreshed on activity so a long-lived dashboard
  // tab does not silently expire mid-drop.
  rolling: true,
  name: 'sneakerbot.sid',
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    secure: cookieSecure(),
    maxAge: 7 * 24 * 60 * 60 * 1000
  }
});

export const hashPassword = (plain) => bcrypt.hash(plain, 12);
export const verifyPassword = (plain, hash) => bcrypt.compare(plain, hash);

export const requireAuth = (req, res, next) => {
  if (req.session?.userId) return next();
  const wantsJson =
    req.path.startsWith('/v1/') ||
    (req.headers.accept || '').includes('application/json') ||
    (req.headers['content-type'] || '').includes('application/json');
  if (wantsJson) {
    return res.status(401).json({ success: false, message: 'Not authenticated', data: {} });
  }
  return res.redirect('/login');
};

export const isFirstRun = async () => {
  const row = await db('users').count('id as n').first();
  return parseInt(row.n, 10) === 0;
};
