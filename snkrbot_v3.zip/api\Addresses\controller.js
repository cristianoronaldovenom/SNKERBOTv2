import db from '../../db/index.js';

export const findAll = async (req, res, next) => {
  try {
    const addresses = await db('addresses').where({ is_deleted: false }).select('*');
    if (addresses.length === 0) {
      return res.json({ success: true, message: 'Addresses not found', data: addresses });
    }
    return res.json({ success: true, message: 'Addresses successfully found', data: addresses });
  } catch (err) {
    next(err);
  }
};

export const findOne = async (req, res, next) => {
  try {
    const address = await db('addresses')
      .where({ id: req.params.id, is_deleted: false })
      .first('*');
    if (!address) {
      return res.json({ success: true, message: 'Address not found', data: undefined });
    }
    return res.json({ success: true, message: 'Address successfully found', data: address });
  } catch (err) {
    next(err);
  }
};

export const create = async (req, res, next) => {
  try {
    const [address] = await db('addresses').insert(req.body).returning('*');
    return res.json({ success: true, message: 'Address successfully created', data: address });
  } catch (err) {
    next(err);
  }
};

export const update = async (req, res, next) => {
  try {
    const [address] = await db('addresses')
      .where({ id: req.params.id })
      .update({ ...req.body, updated_at: new Date() })
      .returning('*');
    return res.json({ success: true, message: 'Address successfully updated', data: address });
  } catch (err) {
    next(err);
  }
};

export const remove = async (req, res, next) => {
  try {
    await db('addresses').where({ id: req.params.id }).update({ is_deleted: true });
    return res.json({ success: true, message: 'Address successfully deleted', data: {} });
  } catch (err) {
    next(err);
  }
};
