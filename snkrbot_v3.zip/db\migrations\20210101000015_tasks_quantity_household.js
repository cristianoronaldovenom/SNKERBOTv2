export const up = (knex) =>
  knex.schema.alterTable('tasks', (table) => {
    table.integer('quantity').notNullable().defaultTo(1);
    table.integer('household_limit').nullable();
  });

export const down = (knex) =>
  knex.schema.alterTable('tasks', (table) => {
    table.dropColumn('quantity');
    table.dropColumn('household_limit');
  });
