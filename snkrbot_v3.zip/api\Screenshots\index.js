import { Router } from 'express';
import fs from 'fs';
import path from 'path';

const SHOTS_DIR = '/tmp/sneakerbot-shots';
const router = Router();

router.get('/', (req, res) => {
  try {
    if (!fs.existsSync(SHOTS_DIR)) {
      return res.json({ success: true, message: 'No screenshots yet', data: [] });
    }
    const files = fs.readdirSync(SHOTS_DIR)
      .filter(f => f.toLowerCase().endsWith('.png'))
      .map(f => {
        const full = path.join(SHOTS_DIR, f);
        const st = fs.statSync(full);
        const m = f.match(/^task-(\d+)-([^-]+(?:-[^-]+)*)-(\d+)\.png$/);
        return {
          filename: f,
          taskId: m ? Number(m[1]) : null,
          stage: m ? m[2] : null,
          createdAt: m ? Number(m[3]) : st.mtimeMs,
          sizeKb: Math.round(st.size / 1024),
          url: `/v1/screenshots/${encodeURIComponent(f)}`
        };
      })
      .sort((a, b) => b.createdAt - a.createdAt)
      .slice(0, 100);
    return res.json({ success: true, message: 'Screenshots', data: files });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message, data: [] });
  }
});

router.get('/:filename', (req, res) => {
  const safe = path.basename(req.params.filename);
  const full = path.join(SHOTS_DIR, safe);
  if (!full.startsWith(SHOTS_DIR) || !fs.existsSync(full)) {
    return res.status(404).json({ success: false, message: 'Not found' });
  }
  res.setHeader('Content-Type', 'image/png');
  fs.createReadStream(full).pipe(res);
});

router.delete('/:filename', (req, res) => {
  try {
    const safe = path.basename(req.params.filename);
    const full = path.join(SHOTS_DIR, safe);
    if (full.startsWith(SHOTS_DIR) && fs.existsSync(full)) fs.unlinkSync(full);
    return res.json({ success: true, message: 'Deleted', data: {} });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message, data: {} });
  }
});

export default router;
