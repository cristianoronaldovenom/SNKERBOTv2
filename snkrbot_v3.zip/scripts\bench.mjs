// Benchmark: repeatable numbers for the hot paths, so speed claims are measured
// rather than asserted.
//
// Deliberately dependency-free and offline: every stage here is pure or
// memory-only, except an optional live HTTPS fetch that proves the TLS path
// end-to-end. Nothing is stubbed in a way that flatters the numbers — the parser
// sees a real 120 KB product page and the transport does a real handshake.
//
// Run: node scripts/bench.mjs
// Exits non-zero if any metric misses its budget, so it can gate a release.

import { performance } from 'node:perf_hooks';

const ITER = Number(process.env.BENCH_ITER || 300);
const results = [];

const time = (label, fn, budgetMs, { iterations = ITER } = {}) => {
  // Warm up so JIT and lazy module init do not pollute the first samples.
  for (let i = 0; i < Math.min(50, iterations); i++) fn(i);

  const samples = [];
  for (let i = 0; i < iterations; i++) {
    const t0 = performance.now();
    fn(i);
    samples.push(performance.now() - t0);
  }
  samples.sort((a, b) => a - b);
  const mean = samples.reduce((a, b) => a + b, 0) / samples.length;
  const p95 = samples[Math.floor(samples.length * 0.95)] ?? samples[samples.length - 1];
  const ok = budgetMs === null || p95 <= budgetMs;
  results.push({ label, mean, p95, budgetMs, ok });
  return ok;
};

const ms = (n) => `${n.toFixed(3)}ms`;

// ── Synthetic product page: the parser's actual workload shape ───────────────
const buildPage = () => {
  const sizeBlocks = Array.from({ length: 24 }, (_, i) =>
    `<button data-size="${6 + i}" data-available="${i % 3 === 0}" class="size-btn">${6 + i}</button>`
  ).join('');
  const filler = '<div class="promo"><span class="t">Deal of the day</span><img src="x.png"></div>'.repeat(700);
  return `<!doctype html><html><head><title>Crimson Foam - US${9}</title>
    <meta property="product:price:amount" content="180.00">
    <meta property="og:image" content="https://cdn.example/p.jpg"></head>
    <body><h1 class="product-name">Crimson Foam</h1>
    <span class="price">$180.00</span>${sizeBlocks}${filler}
    <script>var __NUXT__={"available":true,"variants":[{"size":9,"inStock":true}]}</script>
    </body></html>`;
};
const PAGE = buildPage();

const {
  validateStockResult, SITE_CHECKERS, autoDetectChecker
} = await import('../helpers/site-stock-apis.js');
const { nextPollDelay } = await import('../helpers/poll-economy.js');
const { assessBrowser } = await import('../helpers/rss-watchdog.js');
const { qualityScore } = await import('../helpers/proxy-quality.js');
const { applyTargeting } = await import('../helpers/residential-provider.js');
const { auditSamples } = await import('../helpers/fingerprint-audit.js');
const { billedPollBytes } = await import('../helpers/stock-monitor.js');

console.log(`[bench] page=${Math.round(PAGE.length / 1024)}KB iterations=${ITER}\n`);

// Attribute the parser to whichever checker handles a real shopify-shaped page.
// The entry point is `parseHtml` (parseStock is the JSON-API variant).
const checker = autoDetectChecker('https://shop.example.com/products/x') || SITE_CHECKERS[2];

const parserOk = checker
  ? time('parse product page', () => validateStockResult(checker.parseHtml(PAGE, 9)), 25)
  : (console.log('[bench] WARN no checker auto-detected; parser benchmark skipped'), true);

time('poll delay decision', () => nextPollDelay({
  key: 'task-1|shop.example.com',
  msSinceChange: 120_000,
  budgetRemainingRatio: 0.4
}), 0.5);

time('rss verdict', () => assessBrowser({
  rssBytes: 640 * 1024 * 1024, hostLimitBytes: 4 * 1024 ** 3, parked: false, growthMbPerMin: 12
}), 0.5);

time('proxy quality score', () => qualityScore({
  entry: { successes: 9, blocks: 1, meanLatencyMs: 420 },
  proxyCountry: 'us', profileCountry: 'us'
}), 0.5);

time('residential targeting', () => applyTargeting(
  { host: 'gate.decodo.com', port: 7000, username: 'user1' },
  { provider: 'decodo', country: 'us' }
), 0.5);

const probe = { hardwareConcurrency: 8, screenWidth: 1920, webdriverType: 'boolean', connectionRtt: 50 };
time('fingerprint audit (2 samples)', () => auditSamples([probe, { ...probe }]), 1);

time('poll byte accounting', () => billedPollBytes({ bodyLength: 120_000, notModified: false }), 0.1);

// ── Live end-to-end transport, optional ──────────────────────────────────────
let liveOk = true;
if (process.env.BENCH_LIVE === '1') {
  const { tlsRequest } = await import('../helpers/tls-client.js');
  liveOk = await (async () => {
    const t0 = performance.now();
    const res = await tlsRequest({ url: 'https://shop.example.com', timeoutMs: 8000 }).catch(() => null);
    const elapsed = performance.now() - t0;
    const ok = Boolean(res?.ok);
    results.push({ label: 'live TLS request', mean: elapsed, p95: elapsed, budgetMs: 3000, ok });
    return ok;
  })();
}

console.log('metric'.padEnd(32) + 'p95'.padStart(10) + 'mean'.padStart(10) + 'budget'.padStart(10));
console.log('-'.repeat(62));
for (const r of results) {
  console.log(
    r.label.padEnd(32)
    + ms(r.p95).padStart(10)
    + ms(r.mean).padStart(10)
    + (r.budgetMs === null ? 'n/a' : ms(r.budgetMs)).padStart(10)
    + (r.ok ? '' : '  FAIL')
  );
}

const failed = results.filter((r) => !r.ok).length;
console.log(`\n${results.length - failed}/${results.length} within budget`);
if (!parserOk) console.log('NOTE: parser benchmark skipped (no checker matched)');
process.exit(failed === 0 && liveOk ? 0 : 1);
