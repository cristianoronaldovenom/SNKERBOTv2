import { jest } from '@jest/globals';

// ─── Mocks ──────────────────────────────────────────────────────────────────
jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));

// Settings-backed db mock. Tests mutate `settings` to flip the gate / cap.
const settings = new Map();
jest.unstable_mockModule('../../db/index.js', () => ({
  default: (table) => {
    if (table !== 'settings') throw new Error(`unexpected table ${table}`);
    let key = null;
    const builder = {
      where: (q) => { key = q.key; return builder; },
      first: async () => (settings.has(key) ? { key, value: settings.get(key) } : undefined),
    };
    return builder;
  }
}));

// Fake browser/page factory. launchBrowser hands back a fresh fake each call.
let launchCount = 0;
const makeBrowser = () => {
  const b = {
    _closed: false,
    close: jest.fn(async () => { b._closed = true; }),
    isConnected: () => !b._closed,
    createBrowserContext: jest.fn(async () => {
      const ctx = {
        _closed: false,
        newPage: jest.fn(async () => ({ close: jest.fn(async () => {}), target: () => ({ createCDPSession: async () => ({ send: async () => {}, on: () => {} }) }) })),
        close: jest.fn(async () => { ctx._closed = true; })
      };
      return ctx;
    })
  };
  return b;
};
const launchBrowser = jest.fn(async () => { launchCount += 1; return makeBrowser(); });
const getNewPage = jest.fn(async () => ({ _fake: true }));
jest.unstable_mockModule('../../helpers/cluster.js', () => ({ launchBrowser, getNewPage }));

const enableResourceBlocker = jest.fn(async () => {});
jest.unstable_mockModule('../../helpers/resource-blocker.js', () => ({ enableResourceBlocker }));

const injectCookies = jest.fn(async () => false);
const harvestCookies = jest.fn(async () => []);
jest.unstable_mockModule('../../helpers/cookie-pool.js', () => ({ injectCookies, harvestCookies }));

const warmInPlace = jest.fn(async () => true);
jest.unstable_mockModule('../../helpers/session-warmer.js', () => ({ warmInPlace }));

// Memory-guard is mocked so the suite is deterministic: on a loaded dev box the
// real host ratio sits right on the pressure boundary (0.82-0.84) and park()
// would intermittently bail with reason 'memory_pressure' instead of exercising
// the code under test. Tests that care about pressure flip `memoryPressure`.
let memoryPressure = false;
jest.unstable_mockModule('../../helpers/memory-guard.js', () => ({
  getMemorySnapshot: async () => ({ currentBytes: 1, limitBytes: 10, availableBytes: 9 }),
  isMemoryPressure: async () => memoryPressure,
  recommendedPrewarmCap: async (cap) => cap,
  armParkingStorm: () => {},
}));

const {
  prewarmEnabled, park, adoptPrewarm, disposePrewarm, disposeAll,
  isParked, parkedCount, __test__,
} = await import('../../helpers/prewarm-engine.js');

const flush = () => new Promise((r) => setTimeout(r, 0));

beforeEach(() => {
  settings.clear();
  __test__.resetCaches();
  memoryPressure = false;
  launchCount = 0;
  launchBrowser.mockClear();
  getNewPage.mockClear();
  enableResourceBlocker.mockClear();
  injectCookies.mockClear();
  injectCookies.mockResolvedValue(false);
  warmInPlace.mockClear();
});

afterEach(async () => {
  await disposeAll();
  __test__.registry.clear();
});

// ─── Gate ─────────────────────────────────────────────────────────────────────
describe('prewarmEnabled — feature gate', () => {
  test('missing setting → false (safe default)', async () => {
    expect(await prewarmEnabled()).toBe(false);
  });
  test('empty string → false', async () => {
    settings.set('prewarm_enabled', '');
    expect(await prewarmEnabled()).toBe(false);
  });
  test('"true" / "1" → true', async () => {
    settings.set('prewarm_enabled', 'true');
    expect(await prewarmEnabled()).toBe(true);
    settings.set('prewarm_enabled', '1');
    expect(await prewarmEnabled()).toBe(true);
  });
});

// ─── Park + adopt happy path ────────────────────────────────────────────────
describe('park → adopt', () => {
  test('parks a warmed browser, then adopts it (skipping a fresh launch)', async () => {
    const task = { id: 1, url: 'https://www.pokemoncenter.com/en-ca/product/x' };
    const proxy = { id: 7, host: 'p', port: 1 };

    const res = await park({ task, proxy });
    expect(res.parked).toBe(true);
    expect(isParked(1)).toBe(true);
    expect(launchBrowser).toHaveBeenCalledTimes(1);
    expect(getNewPage).toHaveBeenCalledTimes(1);

    const adopted = await adoptPrewarm(1, { proxyId: 7 });
    expect(adopted).not.toBeNull();
    expect(adopted.browser).toBeDefined();
    expect(adopted.page).toBeDefined();
    // Adoption must NOT launch another browser.
    expect(launchBrowser).toHaveBeenCalledTimes(1);
    // Registry is emptied on claim so nothing else can grab it.
    expect(isParked(1)).toBe(false);
  });

  test('adopting does not close the browser (checkout owns it now)', async () => {
    const task = { id: 2, url: 'https://shop.com/products/x' };
    await park({ task });
    const adopted = await adoptPrewarm(2, { proxyId: null });
    expect(adopted.browser._closed).toBe(false);
  });

  test('a second adopt returns null (already claimed)', async () => {
    const task = { id: 3, url: 'https://shop.com/products/x' };
    await park({ task });
    const first = await adoptPrewarm(3, { proxyId: null });
    expect(first).not.toBeNull();
    const second = await adoptPrewarm(3, { proxyId: null });
    expect(second).toBeNull();
  });

  test('adopt with nothing parked is an instant no-op (null, no launch)', async () => {
    const adopted = await adoptPrewarm(999, { proxyId: null });
    expect(adopted).toBeNull();
    expect(launchBrowser).not.toHaveBeenCalled();
  });

  test('adopt awaits an in-flight re-warm before handing over the page', async () => {
    const task = { id: 7, url: 'https://shop.com/products/x' };
    await park({ task });
    let warmDone = false;
    // Simulate a re-warm mid-goto: publish an in-flight warm on the entry.
    __test__.registry.get(7).warmInFlight = new Promise((r) =>
      setTimeout(() => { warmDone = true; r(); }, 30));
    const adopted = await adoptPrewarm(7, { proxyId: null });
    expect(adopted).not.toBeNull();
    expect(warmDone).toBe(true); // adopt did not return until the warm settled
  });
});

// ─── Fallback / profile-lock safety ─────────────────────────────────────────
describe('adopt disposes non-adoptable contexts (frees the profile lock)', () => {
  test('proxy mismatch → null AND the parked browser is closed', async () => {
    const task = { id: 4, url: 'https://shop.com/products/x' };
    await park({ task, proxy: { id: 5 } });
    const parkedBrowser = __test__.registry.get(4).browser;

    const adopted = await adoptPrewarm(4, { proxyId: 9 }); // different proxy
    expect(adopted).toBeNull();
    expect(parkedBrowser._closed).toBe(true); // freed for a clean cold launch
    expect(isParked(4)).toBe(false);
  });

  test('stale context (past warm TTL) → null AND closed', async () => {
    const task = { id: 5, url: 'https://shop.com/products/x' };
    await park({ task });
    const entry = __test__.registry.get(5);
    const parkedBrowser = entry.browser;
    entry.lastWarmedAt = Date.now() - (__test__.PREWARM_TTL_MS + 1000); // force stale

    const adopted = await adoptPrewarm(5, { proxyId: null });
    expect(adopted).toBeNull();
    expect(parkedBrowser._closed).toBe(true);
    expect(isParked(5)).toBe(false);
  });

  test('disconnected browser → null AND cleaned up', async () => {
    const task = { id: 6, url: 'https://shop.com/products/x' };
    await park({ task });
    const entry = __test__.registry.get(6);
    entry.browser._closed = true; // simulate a dead browser

    const adopted = await adoptPrewarm(6, { proxyId: null });
    expect(adopted).toBeNull();
    expect(isParked(6)).toBe(false);
  });
});

// ─── Cap + dedupe ────────────────────────────────────────────────────────────
describe('parked-browser cap + dedupe', () => {
  test('honors prewarm_max_parked and falls back once full', async () => {
    settings.set('prewarm_max_parked', '2');
    expect((await park({ task: { id: 10, url: 'https://a.com/products/x' } })).parked).toBe(true);
    expect((await park({ task: { id: 11, url: 'https://b.com/products/x' } })).parked).toBe(true);
    const third = await park({ task: { id: 12, url: 'https://c.com/products/x' } });
    expect(third.parked).toBe(false);
    expect(third.reason).toBe('cap');
    expect(parkedCount()).toBe(2);
    expect(launchBrowser).toHaveBeenCalledTimes(2); // 3rd never launched
  });

  test('double-park of the same task is deduped', async () => {
    const task = { id: 20, url: 'https://a.com/products/x' };
    await park({ task });
    const again = await park({ task });
    expect(again.parked).toBe(false);
    expect(again.reason).toBe('already parked');
    expect(launchBrowser).toHaveBeenCalledTimes(1);
  });

  test('multiple tasks on the same host/proxy share one prewarm browser', async () => {
    const proxy = { id: 101, host: 'proxy.example', port: 8080, username: 'u', password: 'p' };
    expect((await park({ task: { id: 21, url: 'https://a.com/products/one' }, proxy })).parked).toBe(true);
    expect((await park({ task: { id: 22, url: 'https://a.com/products/two' }, proxy: { ...proxy, id: 202 } })).parked).toBe(true);
    expect(launchBrowser).toHaveBeenCalledTimes(1);
    expect(parkedCount()).toBe(1);
  });
});

// ─── Dispose ──────────────────────────────────────────────────────────────────
describe('dispose', () => {
  test('disposePrewarm closes the browser and clears the registry', async () => {
    const task = { id: 30, url: 'https://a.com/products/x' };
    await park({ task });
    const b = __test__.registry.get(30).browser;
    await disposePrewarm(30);
    expect(b._closed).toBe(true);
    expect(isParked(30)).toBe(false);
  });

  test('disposePrewarm is idempotent (double dispose closes once)', async () => {
    const task = { id: 31, url: 'https://a.com/products/x' };
    await park({ task });
    const b = __test__.registry.get(31).browser;
    await disposePrewarm(31);
    await disposePrewarm(31);
    expect(b.close).toHaveBeenCalledTimes(1);
  });

  test('disposeAll tears down every parked browser', async () => {
    await park({ task: { id: 40, url: 'https://a.com/products/x' } });
    await park({ task: { id: 41, url: 'https://b.com/products/x' } });
    const b1 = __test__.registry.get(40).browser;
    const b2 = __test__.registry.get(41).browser;
    await disposeAll();
    expect(b1._closed).toBe(true);
    expect(b2._closed).toBe(true);
    expect(parkedCount()).toBe(0);
  });
});

// ─── Never-throws contract ──────────────────────────────────────────────────
describe('never throws', () => {
  test('park with no task returns a status, never throws', async () => {
    await expect(park({})).resolves.toEqual(expect.objectContaining({ parked: false }));
    await expect(park({ task: { id: 1 } })).resolves.toEqual(expect.objectContaining({ parked: false }));
  });

  test('a launch failure falls back cleanly and frees the slot', async () => {
    launchBrowser.mockRejectedValueOnce(new Error('chrome boom'));
    const res = await park({ task: { id: 50, url: 'https://a.com/products/x' } });
    expect(res.parked).toBe(false);
    expect(isParked(50)).toBe(false);   // reservation cleared → cold path unblocked
    expect(parkedCount()).toBe(0);
  });
});
