import { Router } from 'express';
import addressesRoutes from '../api/Addresses/index.js';
import proxiesRoutes from '../api/Proxies/index.js';
import tasksRoutes from '../api/Tasks/index.js';
import logsRoutes from '../api/Logs/index.js';
import settingsRoutes from '../api/Settings/index.js';
import paymentProfilesRoutes from '../api/PaymentProfiles/index.js';
import statsRoutes from '../api/Stats/index.js';
import screenshotsRoutes from '../api/Screenshots/index.js';
import runsRoutes from '../api/Runs/index.js';
import harvesterRoutes from '../api/Harvester/index.js';
import botLearnerRoutes from '../api/BotLearner/index.js';
import trainerRoutes from '../api/Trainer/index.js';
import validationHandler from '../helpers/validation-handler.js';

const router = Router();

router.get('/', (req, res) => res.send('Welcome to the SneakerBot API'));
router.use('/addresses', addressesRoutes);
router.use('/proxies', proxiesRoutes);
router.use('/tasks', tasksRoutes);
router.use('/logs', logsRoutes);
router.use('/settings', settingsRoutes);
router.use('/payment-profiles', paymentProfilesRoutes);
router.use('/stats', statsRoutes);
router.use('/screenshots', screenshotsRoutes);
router.use('/runs', runsRoutes);
router.use('/harvester', harvesterRoutes);
router.use('/bot-learner', botLearnerRoutes);
router.use('/trainer', trainerRoutes);

router.use(validationHandler);

export default router;
