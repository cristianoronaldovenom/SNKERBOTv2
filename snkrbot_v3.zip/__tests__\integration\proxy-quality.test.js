// Proxy quality: region fit, monthly IP quota, deterministic ordering.
//
// The regression this guards: selection only knew about transport failures, so a
// geo-wrong or quota-spent exit ranked the same as a clean in-region one. Both
// mistakes are billable — a wrong-region exit contradicts the profile's timezone
// and locale, and a spent quota throttles the account.
import { describe, expect, test } from '@jest/globals';
import {
  WEIGHTS, pickBestProxy, qualityScore, quotaRemaining, rankProxies
} from '../../helpers/proxy-quality.js';

const cand = (over = {}) => ({
  id: 1, countryCode: 'CA', monthlyIpCap: 0, ipsUsedThisMonth: 0, entry: null, ...over
});

describe('quota', () => {
  test('an uncapped proxy is never exhausted', () => {
    const q = quotaRemaining({ ipsUsedThisMonth: 999, monthlyIpCap: 0 });
    expect(q.exhausted).toBe(false);
    expect(q.remaining).toBe(Infinity);
  });

  test('usage against a cap reports the remainder', () => {
    expect(quotaRemaining({ ipsUsedThisMonth: 3, monthlyIpCap: 10 })).toMatchObject({
      remaining: 7, exhausted: false
    });
  });

  test('reaching the cap is exhausted and clamps at zero', () => {
    const q = quotaRemaining({ ipsUsedThisMonth: 12, monthlyIpCap: 10 });
    expect(q.exhausted).toBe(true);
    expect(q.remaining).toBe(0);
    expect(q.spentRatio).toBe(1);
  });
});

describe('scoring', () => {
  test('a matching region beats a mismatched one', () => {
    const match = qualityScore({ proxyCountry: 'CA', profileCountry: 'CA' });
    const miss = qualityScore({ proxyCountry: 'DE', profileCountry: 'CA' });
    expect(match.score).toBeGreaterThan(miss.score);
    expect(miss.reasons).toContain('region_miss');
  });

  test('unknown region data contributes nothing either way', () => {
    const none = qualityScore({});
    expect(none.score).toBe(0);
    expect(none.region).toBe('unknown');
  });

  test('region comparison is case-insensitive', () => {
    expect(qualityScore({ proxyCountry: 'ca', profileCountry: 'CA' }).region).toBe('match');
  });

  test('an unused proxy scores neutral, not a freshness bonus', () => {
    // Otherwise a brand-new proxy always wins and rotation never settles.
    expect(qualityScore({ entry: null }).score).toBe(0);
    expect(qualityScore({ entry: { successes: 0 } }).score).toBe(0);
  });

  test('clean successes raise the score and blocks lower it more', () => {
    const clean = qualityScore({ entry: { successes: 3 } }).score;
    const blocked = qualityScore({ entry: { successes: 3, blocks: 3 } }).score;
    expect(clean).toBeGreaterThan(0);
    // A block must cost more than a win gains, or repeated blocking washes out.
    expect(WEIGHTS.block).toBeGreaterThan(WEIGHTS.clean);
    expect(blocked).toBeLessThan(clean);
  });

  test('latency is penalised', () => {
    expect(qualityScore({ entry: { meanLatencyMs: 3000 } }).score).toBeLessThan(0);
  });

  test('an exhausted quota outranks every quality term', () => {
    const args = { entry: { successes: 100 }, proxyCountry: 'CA', profileCountry: 'CA' };
    const fresh = qualityScore(args);
    const spent = qualityScore({ ...args, quota: quotaRemaining({ ipsUsedThisMonth: 5, monthlyIpCap: 5 }) });
    expect(spent.reasons).toContain('quota_exhausted');
    // A perfect but spent proxy must rank below the same proxy with quota left.
    expect(spent.score).toBeLessThan(fresh.score - 900);
  });

  test('a nearly spent quota is a soft penalty only', () => {
    const out = qualityScore({ quota: quotaRemaining({ ipsUsedThisMonth: 95, monthlyIpCap: 100 }) });
    expect(out.reasons).toContain('quota_low');
    expect(out.score).toBeGreaterThan(-100);
  });
});

describe('ranking', () => {
  test('orders best-first and breaks ties on id so order is stable', () => {
    const ranked = rankProxies({
      profileCountry: 'CA',
      candidates: [cand({ id: 5, countryCode: 'DE' }), cand({ id: 9, countryCode: 'CA' }), cand({ id: 2 })]
    });
    expect(ranked[0].id).toBe(2); // id 2 and 9 both match; lowest id first
    expect(ranked[ranked.length - 1].id).toBe(5);
  });

  test('the same input always produces the same order', () => {
    const build = () => rankProxies({ profileCountry: 'CA', candidates: [cand({ id: 3 }), cand({ id: 1 }), cand({ id: 2 })] });
    expect(build().map((c) => c.id)).toEqual(build().map((c) => c.id));
  });

  test('pickBestProxy skips an exhausted candidate entirely', () => {
    const picked = pickBestProxy({
      candidates: [
        cand({ id: 1, entry: { successes: 50 }, monthlyIpCap: 5, ipsUsedThisMonth: 5 }),
        cand({ id: 2, entry: { successes: 1 } })
      ]
    });
    expect(picked.id).toBe(2);
  });

  test('pickBestProxy still returns something when every quota is spent', () => {
    const picked = pickBestProxy({
      candidates: [cand({ id: 1, monthlyIpCap: 1, ipsUsedThisMonth: 1 }), cand({ id: 2, monthlyIpCap: 1, ipsUsedThisMonth: 1 })]
    });
    expect(picked).not.toBeNull();
  });

  test('an empty candidate list yields null', () => {
    expect(pickBestProxy({ candidates: [] })).toBeNull();
  });
});
