// Captcha pre-solve arming.
//
// The regression this guards: the stockpile only helped a SECOND solve in one task, but
// a drop usually needs exactly one - so the cache was empty when it mattered. Arming on
// first sight of a sitekey means tokens are already being minted while the user browses,
// so the 10-30s solve becomes a Map lookup by the time the widget appears.
//
// Budget matters as much as latency: every pre-solve is a PAID provider call. So arming
// is idempotent per sitekey, deposits are capped upstream, and an idle sitekey is
// disarmed rather than solving all day.
//
// solveOnce is the provider cascade itself, so pre-solves use the same providers,
// health tracking and budget accounting as a foreground solve.
import logger from './logger.js';
import { ensureStockpiling } from './token-stockpile.js';
import { solveWithCascade } from './captcha.js';

const ARM_IDLE_STOP_MS = Math.max(1_000, Number(process.env.CAPTCHA_ARM_IDLE_MS || 5 * 60_000));
// Reaper tick is a fraction of the idle window so the sweep is prompt. No 5s floor:
// a 1.5s idle window (tests, or an operator tuning aggressively) would never tick.
const REAP_INTERVAL_MS = Math.max(500, Math.floor(ARM_IDLE_STOP_MS / 3));



// siteKey -> { stop, lastUsedAt }
const armed = new Map();

// One module-level reaper rather than one per arm: N armed sitekeys would otherwise
// mean N intervals doing the same sweep, and a per-arm timer is easy to leak.
let reaperTimer = null;

const ensureReaper = () => {
  if (reaperTimer) return;
  reaperTimer = setInterval(() => {
    const now = Date.now();
    for (const [k, v] of armed) {
      if (now - v.lastUsedAt > ARM_IDLE_STOP_MS) {
        try { v.stop(); } catch (_) { /* already stopped */ }
        armed.delete(k);
        logger.info(`[Captcha] Disarmed idle pre-solve for ${k.slice(0, 10)}... after ${Math.round((now - v.lastUsedAt) / 1000)}s idle`);
      }
    }
  }, REAP_INTERVAL_MS);
  reaperTimer.unref?.();
};

// Arm (or re-touch) the pre-solver for one sitekey. Returns the stop function.
export const armForSiteKey = ({ type, siteKey, pageUrl, targetDepth = 2 }) => {
  if (!type || !siteKey) return null;
  const existing = armed.get(siteKey);
  if (existing) {
    existing.lastUsedAt = Date.now();
    return existing.stop;
  }

  const stop = ensureStockpiling({
    type,
    siteKey,
    pageUrl,
    targetDepth: Math.max(1, Number(targetDepth) || 2),
    solveOnce: async (t, k, u) => solveWithCascade({ type: t, siteKey: k, pageUrl: u })
  });

  armed.set(siteKey, { stop, lastUsedAt: Date.now() });
  ensureReaper();
  logger.info(`[Captcha] Armed pre-solve for ${type} siteKey=${siteKey.slice(0, 10)}... (target depth ${targetDepth})`);
  return stop;
};

// Touch keeps an armed sitekey alive. Call from the solve path so an active challenge
// is never reaped mid-use.
export const touchArmed = (siteKey) => {
  const v = armed.get(siteKey);
  if (v) v.lastUsedAt = Date.now();
};

export const armedSiteKeys = () => Array.from(armed.keys());
export const __resetArmed = () => {
  for (const { stop } of armed.values()) { try { stop(); } catch (_) {} }
  armed.clear();
  // Drop the reaper too, otherwise the interval outlives the test process.
  if (reaperTimer) {
    clearInterval(reaperTimer);
    reaperTimer = null;
  }
};
