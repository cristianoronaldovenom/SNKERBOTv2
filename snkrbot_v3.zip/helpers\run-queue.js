// Concurrency limiter with RAII-style release tokens and per-task single-flight.
//
// Why this exists:
//   1. Pro bots throttle simultaneous Chrome launches because each instance is
//      ~250-500MB. On Windows 11, spawning 20 in parallel after a bulk-clone
//      crashes the box and tanks success rate.
//   2. Each task has its own `profiles/task-<id>` user-data-dir for cookie /
//      Cloudflare-clearance persistence. If two attempts of the SAME task ever
//      run simultaneously they corrupt each other's profile lock files. So we
//      enforce strict single-flight per task on top of the global slot limit.
import db from '../db/index.js';
import logger from './logger.js';
import { recommendedRunConcurrency, recommendedCheckoutConcurrency, cpuSnapshot, shouldThrottleCpu } from './cpu-performance.js';

const DEFAULT_ARMED_TASKS = 1000;
const DEFAULT_CHECKOUT_SLOTS = 10;
const DEFAULT_CONFIGURED_CHECKOUT = 24;
const DEFAULT_ARMED_PER_HOST = 100;
const DEFAULT_PER_HOST = 100;
let maxConcurrent = DEFAULT_CHECKOUT_SLOTS;
let configuredMaxConcurrent = DEFAULT_CONFIGURED_CHECKOUT;
let configuredArmedTasks = DEFAULT_ARMED_TASKS;
let armedTaskCapacity = DEFAULT_ARMED_TASKS;
let armedTaskPerHostCapacity = DEFAULT_ARMED_PER_HOST;
let maxPerHost = DEFAULT_PER_HOST;
let limitsCacheExpiresAt = 0;
const LIMITS_CACHE_TTL_MS = 5000;
let active = 0;
const hostActive = new Map();   // host -> count of active tasks
const hostWaiters = new Map();  // host -> array of resolvers waiting for a per-host slot

// One selection rule for both queues: highest priority wins, but anything that has
// waited past the age threshold outranks priority entirely. Without that, a
// continuous stream of hot restocks starves stale background work forever — the
// exact inefficiency of a pure priority queue. Insertion order breaks ties, so the
// queue stays FIFO within a class.
const AGING_MS = 20_000;

const pickIndex = (queue) => {
  const now = Date.now();
  let best = 0;
  for (let i = 1; i < queue.length; i += 1) {
    const a = queue[i];
    const b = queue[best];
    const aAged = now - (a.enqueuedAt || 0) >= AGING_MS;
    const bAged = now - (b.enqueuedAt || 0) >= AGING_MS;
    if (aAged !== bAged) { if (aAged) best = i; continue; }
    // Within the same ageing class, older wins, then higher priority.
    if (!aAged && (a.priority || 0) > (b.priority || 0)) best = i;
  }
  return best;
};

const overCapacity = () => waiters.length >= WAITERS_MAX;
const waiters = [];           // global slot waiters: { resolve, priority, taskId, enqueuedAt }
const taskInflight = new Map(); // taskId -> queue of resolvers waiting for that taskId

const refreshLimit = async () => {
  const now = Date.now();
  if (limitsCacheExpiresAt > now) return;
  try {
    const [r, a, ah, h] = await Promise.all([
      db('settings').where({ key: 'max_concurrent_runs' }).first(),
      db('settings').where({ key: 'max_armed_tasks' }).first(),
      db('settings').where({ key: 'max_armed_tasks_per_host' }).first(),
      db('settings').where({ key: 'max_concurrent_per_host' }).first(),
    ]);
    const n = parseInt(r?.value, 10);
    configuredMaxConcurrent = (Number.isInteger(n) && n >= 1 && n <= 64) ? n : DEFAULT_CONFIGURED_CHECKOUT;
    const an = parseInt(a?.value, 10);
    configuredArmedTasks = (Number.isInteger(an) && an >= 1 && an <= 1000) ? an : DEFAULT_ARMED_TASKS;
    armedTaskCapacity = recommendedRunConcurrency({ configured: configuredArmedTasks });
    const aph = parseInt(ah?.value, 10);
    armedTaskPerHostCapacity = (Number.isInteger(aph) && aph >= 1 && aph <= 100) ? aph : DEFAULT_ARMED_PER_HOST;
    maxConcurrent = recommendedCheckoutConcurrency({ configured: configuredMaxConcurrent });
    const pn = parseInt(h?.value, 10);
    maxPerHost = (Number.isInteger(pn) && pn >= 1 && pn <= 100) ? pn : DEFAULT_PER_HOST;
  } catch (_) {
    configuredMaxConcurrent = DEFAULT_CONFIGURED_CHECKOUT;
    configuredArmedTasks = DEFAULT_ARMED_TASKS;
    armedTaskCapacity = recommendedRunConcurrency({ configured: DEFAULT_ARMED_TASKS });
    armedTaskPerHostCapacity = DEFAULT_ARMED_PER_HOST;
    maxConcurrent = recommendedCheckoutConcurrency({ configured: DEFAULT_CHECKOUT_SLOTS });
    maxPerHost = DEFAULT_PER_HOST;
  }
  limitsCacheExpiresAt = now + LIMITS_CACHE_TTL_MS;
};

const acquireGlobal = async (taskId, priority = 0) => {
  // High/max mode adapts to host load. A brief wait under sustained saturation
  // preserves throughput by avoiding CPU thermal/load thrash.
  if (shouldThrottleCpu() && active > 0) {
    await new Promise((resolve) => setTimeout(resolve, 150));
    maxConcurrent = recommendedCheckoutConcurrency({ configured: configuredMaxConcurrent });
  }
  if (active < maxConcurrent) { active += 1; return; }
  if (overCapacity()) {
    // Bounded queue: beyond this the wait is longer than any drop window, so fail
    // fast rather than letting waiters pile up unboundedly.
    logger.debug(`[RunQueue] Task ${taskId} rejected — ${waiters.length} already waiting`);
    throw new Error(`Checkout queue full (${waiters.length} waiting)`);
  }
  logger.debug(`[RunQueue] Task ${taskId} queued — ${active}/${maxConcurrent} slots full, ${waiters.length} ahead (priority=${priority})`);
  await new Promise((resolve) => waiters.push({ resolve, priority, taskId, enqueuedAt: Date.now() }));
  active += 1;
  logger.debug(`[RunQueue] Task ${taskId} dequeued — slot acquired (${active}/${maxConcurrent})`);
};

const releaseGlobal = () => {
  active = Math.max(0, active - 1);
  if (!waiters.length) return;
  const [next] = waiters.splice(pickIndex(waiters), 1);
  next.resolve();
};

const acquireHost = async (taskId, host, priority = 0) => {
  if (!host) return; // host is optional — ad-hoc callers without URL bypass per-host cap
  const cur = hostActive.get(host) || 0;
  if (cur < maxPerHost) {
    hostActive.set(host, cur + 1);
    return;
  }
  logger.debug(`[RunQueue] Task ${taskId} per-host throttled — ${cur}/${maxPerHost} active on ${host}`);
  if (!hostWaiters.has(host)) hostWaiters.set(host, []);
  await new Promise((resolve) => hostWaiters.get(host).push({ resolve, priority, taskId, enqueuedAt: Date.now() }));
  hostActive.set(host, (hostActive.get(host) || 0) + 1);
  logger.debug(`[RunQueue] Task ${taskId} per-host slot acquired on ${host} (${hostActive.get(host)}/${maxPerHost})`);
};

const releaseHost = (host) => {
  if (!host) return;
  const cur = hostActive.get(host) || 0;
  const next = Math.max(0, cur - 1);
  if (next === 0) hostActive.delete(host);
  else hostActive.set(host, next);
  const q = hostWaiters.get(host);
  if (q && q.length > 0) {
    const [wake] = q.splice(pickIndex(q), 1);
    if (q.length === 0) hostWaiters.delete(host);
    wake.resolve();
  }
};

const acquireTaskLock = async (taskId) => {
  if (!taskInflight.has(taskId)) {
    taskInflight.set(taskId, []);
    return;
  }
  logger.debug(`[RunQueue] Task ${taskId} already in-flight — waiting for previous attempt to finish`);
  await new Promise((resolve) => taskInflight.get(taskId).push(resolve));
};

const releaseTaskLock = (taskId) => {
  const q = taskInflight.get(taskId);
  if (!q) return;
  if (q.length > 0) q.shift()();
  else taskInflight.delete(taskId);
};

// Returns a release function. The release is idempotent — calling it twice is
// safe and a no-op the second time. Calling it without ever having acquired
// is also safe (the function simply does nothing).
//
// Pass `host` to also enforce a per-host active-checkout concurrency cap
// (default 100). The separate armed-monitor cap is enforced in monitor.js so
// hundreds of browserless monitors can stay live without opening hundreds of
// Chromium sessions.
// Acquisition order: per-host FIRST, then global.
//
// The old order took a global checkout slot and then waited for the per-host slot.
// So a task queued behind a saturated retailer already held a global slot, and a task
// for a DIFFERENT, free retailer arriving later could not use it — the global pool
// filled with tasks that were not runnable. Under a concentrated workload that
// collapses usable capacity toward zero for everybody else.
//
// Reversing it means a global slot is only taken when the host slot is already in
// hand, so every occupied global slot is immediately runnable. The unwind below
// releases in the opposite order to match.
export const acquireSlot = async (taskId, { host = null, priority = 0 } = {}) => {
  await refreshLimit();
  await acquireTaskLock(taskId);     // single-flight per task
  try {
    await acquireHost(taskId, host, priority); // per-host cap (cheap, usually immediate)
  } catch (err) {
    releaseTaskLock(taskId);
    throw err;
  }
  try {
    await acquireGlobal(taskId, priority);     // global concurrency cap
  } catch (err) {
    releaseHost(host);
    releaseTaskLock(taskId);
    throw err;
  }
  let released = false;
  return () => {
    if (released) return;
    released = true;
    releaseGlobal();
    releaseHost(host);
    releaseTaskLock(taskId);
  };
};

export const getArmedTaskCapacity = async () => {
  await refreshLimit();
  return armedTaskCapacity;
};

export const getArmedTaskHostCapacity = async () => {
  await refreshLimit();
  return armedTaskPerHostCapacity;
};

export const queueStatus = () => ({
  active, maxConcurrent, armedTaskCapacity, armedTaskPerHostCapacity, configuredCheckoutCapacity: configuredMaxConcurrent, maxPerHost,
  cpu: cpuSnapshot(),
  waiting: waiters.length,
  perHost: Object.fromEntries(hostActive),
  inflightTasks: Array.from(taskInflight.keys())
});

// Test seam: pin the caps without a database, and reset every bit of state so cases
// are independent. Also exposes the bounded-queue ceiling.
export const WAITERS_MAX = 1000;

export const setLimitsForTests = ({ maxConcurrent: mc, maxPerHost: mph } = {}) => {
  if (mc != null) maxConcurrent = mc;
  if (mph != null) maxPerHost = mph;
  limitsCacheExpiresAt = Date.now() + 1e9; // stop refreshLimit overwriting them
};

export const __resetForTests = () => {
  active = 0;
  waiters.length = 0;
  hostWaiters.clear();
  hostActive.clear();
  taskInflight.clear();
  limitsCacheExpiresAt = 0;
};
