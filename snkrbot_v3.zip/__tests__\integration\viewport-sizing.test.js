// Host-aware viewport sizing.
//
// The regression this guards: every profile drew from the FULL monitor catalog
// regardless of host RAM, so a 1 GB box could composite a 2560x1440 screen. Area
// is the right thing to trade against memory — it drives compositor and layout
// cost — and 1366x768 is an ordinary laptop the fingerprint already accepts.
import { describe, expect, test } from '@jest/globals';
import { deriveScreenMetrics, screenGeometry, sizeBiasForHost } from '../../helpers/fingerprint-coherence.js';

const GB = 1024 ** 3;
const area = (m) => m.screen.width * m.screen.height;

describe('sizeBiasForHost', () => {
  test('a big host is unbiased', () => {
    expect(sizeBiasForHost(8 * GB)).toBe(0);
    expect(sizeBiasForHost(64 * GB)).toBe(0);
  });

  test('smaller hosts bias progressively harder', () => {
    expect(sizeBiasForHost(3 * GB)).toBe(0.5);
    expect(sizeBiasForHost(2 * GB)).toBe(0.75);
    expect(sizeBiasForHost(1 * GB)).toBe(1);
  });

  test('an unknown size is unbiased rather than guessy', () => {
    expect(sizeBiasForHost(0)).toBe(0);
    expect(sizeBiasForHost(null)).toBe(0);
  });
});

describe('deriveScreenMetrics bias', () => {
  test('no bias can produce the largest panel', () => {
    const all = new Set();
    for (let seed = 0; seed < 40; seed++) all.add(area(deriveScreenMetrics('Windows', seed)));
    expect(all.size).toBeGreaterThan(1);
    expect(Math.max(...all)).toBeGreaterThanOrEqual(2560 * 1440);
  });

  test('full bias never exceeds the lightest panel', () => {
    for (let seed = 0; seed < 40; seed++) {
      const m = deriveScreenMetrics('Windows', seed, { sizeBias: 1 });
      expect(area(m)).toBeLessThanOrEqual(1366 * 768);
    }
  });

  test('a biased draw never exceeds the largest panel a bias allows', () => {
    // The index is modulo the shortened list, so the SAME seed can land on a
    // different panel. The guarantee is about the reachable band, not per-seed
    // monotonicity: bias 0.75 can only reach the lightest quarter of the catalog.
    for (let seed = 0; seed < 30; seed++) {
      expect(area(deriveScreenMetrics('Windows', seed, { sizeBias: 0.75 }))).toBeLessThanOrEqual(1920 * 1080);
    }
  });

  test('more bias never widens the reachable band', () => {
    const maxFor = (bias) => {
      let max = 0;
      for (let seed = 0; seed < 40; seed++) max = Math.max(max, area(deriveScreenMetrics('Windows', seed, { sizeBias: bias })));
      return max;
    };
    expect(maxFor(1)).toBeLessThanOrEqual(maxFor(0.5));
    expect(maxFor(0.5)).toBeLessThanOrEqual(maxFor(0));
  });

  test('the viewport still fits inside the screen under bias', () => {
    for (let seed = 0; seed < 30; seed++) {
      const m = deriveScreenMetrics('Windows', seed, { sizeBias: 1 });
      expect(m.viewport.width).toBeLessThanOrEqual(m.screen.width);
      expect(m.viewport.height).toBeLessThanOrEqual(m.screen.height);
    }
  });

  test('bias stays coherent end to end through screenGeometry', () => {
    for (let seed = 0; seed < 20; seed++) {
      const m = deriveScreenMetrics('Windows', seed, { sizeBias: 1 });
      const geo = screenGeometry({ platform: 'Windows', ...m });
      expect(geo.innerWidth).toBeLessThanOrEqual(geo.screenWidth);
      // outermost window still cannot exceed the physical panel
      expect(geo.outerWidth).toBeLessThanOrEqual(geo.screenWidth);
    }
  });

  test('an out-of-range bias is clamped, not extrapolated', () => {
    const m = deriveScreenMetrics('Windows', 3, { sizeBias: 5 });
    expect(area(m)).toBeLessThanOrEqual(1366 * 768);
    expect(deriveScreenMetrics('Windows', 3, { sizeBias: -5 }).screen.width).toBeGreaterThan(0);
  });

  test('macOS keeps its own catalog under bias', () => {
    const m = deriveScreenMetrics('macOS', 2, { sizeBias: 1 });
    expect(m.dpr).toBe(2); // retina pairs carry a fixed dpr
  });
});
