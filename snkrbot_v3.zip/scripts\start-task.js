import { pathToFileURL } from 'url';
import db from '../db/index.js';
import logger from '../helpers/logger.js';
import { storePageInTaskCache, removePageFromTaskCache } from '../helpers/task-cache.js';
import { launchBrowser, getNewPage } from '../helpers/cluster.js';
import { sendSuccessEmail } from '../helpers/email.js';
import { captureOrderSuccess } from '../helpers/order-capture.js';
import { waitForDropAndStock } from '../helpers/drop-watcher.js';
import { rotateIdentity, shouldRotateAfterFailure } from '../helpers/identity-rotator.js';
import { pickBackupProxy, shouldRotateProxyAfterFailure, isProxyTransportFailure, markProxyTransportFailure, markProxyTransportSuccess } from '../helpers/proxy-pool.js';
import { notify } from '../helpers/notifier.js';
import { warmInPlace } from '../helpers/session-warmer.js';
import { preflightTask, logPreflight } from '../helpers/preflight.js';
import { acquireSlot } from '../helpers/run-queue.js';
import { notifyProductSuccess, subscribeToSiblings, throwIfSiblingWon, SiblingWonError } from '../helpers/sibling-bus.js';
import { enableResourceBlocker } from '../helpers/resource-blocker.js';
import { detectDecline, isOosFailure, isDeclineFailure, isSessionFailure, getAlternatePaymentProfiles } from '../helpers/decline-detector.js';
import { injectCookies, harvestCookies, hasFreshCookies } from '../helpers/cookie-pool.js';
import { recordOutcome } from '../helpers/proxy-intelligence.js';
import { getBotLearnerRecommendation, recordBotLearnerOutcome } from '../helpers/bot-learner.js';
import { tryRequestCheckout, requestModeEnabled } from '../helpers/request-checkout/index.js';
import { StageTimer } from '../helpers/stage-timer.js';
import { adoptPrewarm, disposePrewarm } from '../helpers/prewarm-engine.js';
import { PC_SITE_ID, isWithinBusinessHours, businessHoursEnabled } from '../helpers/business-hours.js';
import { getSitePerformanceProfile } from '../helpers/site-performance.js';
import { resolveTaskProxy, sanitizeProxyMeta } from '../helpers/task-proxies.js';
import { broadcastToClients, broadcastAllClients } from '../helpers/monitor-store.js';
import { isPaymentLocked, recordPaymentOutcome } from '../helpers/payment-lockout.js';
import { checkoutAdmission } from '../helpers/admission.js';
import {
  acquireResidentialSession, activeResidentialSessions, maxResidentialSessions
} from '../helpers/residential-budget.js';
import { getMemorySnapshot } from '../helpers/memory-guard.js';

export const SITES = {
  1: 'footsites',
  2: 'shopify',
  3: 'demandware',
  4: 'nike',
  5: 'supremenewyork',
  6: 'pokemoncenter',
  7: 'topps',
  8: 'walmart',
  9: 'bestbuy',
  10: 'target',
  11: 'gamestop',
  12: 'amazon'
};

const sleep = (ms) => new Promise((r) => setTimeout(r, Math.max(0, ms)));
const randInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

const loadTaskWithRelations = async (task) => {
  const [shippingAddress, billingAddress, paymentProfile, checkoutProxy] = await Promise.all([
    task.shipping_address_id
      ? db('addresses').where({ id: task.shipping_address_id }).first()
      : Promise.resolve(null),
    task.billing_address_id
      ? db('addresses').where({ id: task.billing_address_id }).first()
      : Promise.resolve(null),
    task.payment_profile_id
      ? db('payment_profiles').where({ id: task.payment_profile_id }).first()
      : Promise.resolve(null),
    resolveTaskProxy(task, 'checkout').then((r) => r.proxy),
  ]);
  return { ...task, shippingAddress, billingAddress, paymentProfile, checkoutProxy, proxy: checkoutProxy };
};

const getScreenshotUrl = (taskId, stage) => {
  const base = process.env.PUBLIC_URL || '';
  return base ? `${base}/v1/screenshots/task-${taskId}-${stage}.png` : null;
};

const waitForDropTime = (task) => waitForDropAndStock({ task, sleep, randInt });

const recordRun = async (task, attemptNum, result, profileLabel, proxyHost) => {
  try {
    await db('task_runs').insert({
      task_id: task.id,
      attempt: attemptNum,
      status: result.ok ? 'success' : 'failed',
      stage_failed: result.ok ? null : (result.stage || null),
      order_number: result.orderNumber || null,
      duration_ms: result.durationMs,
      error_message: result.error || null,
      screenshot_url: !result.ok && result.stage ? getScreenshotUrl(task.id, result.stage) : null,
      profile_label: profileLabel || null,
      proxy_host: proxyHost || null,
      timings: result.timings ? JSON.stringify(result.timings) : null,
      finished_at: new Date()
    });
  } catch (err) {
    logger.warn(`[StartTask] Failed to record run for task ${task.id}: ${err.message}`);
  }
};

const runOnce = async (task, attemptNum, { overridePaymentProfileId, botLearnerArm } = {}) => {
  const taskId = task.id;
  const t0 = Date.now();
  const timer = new StageTimer(t0);
  // Time from the monitor confirming stock to this run starting (set by makeTick).
  const buildTimings = () => {
    const handoffMs = typeof task._instockAt === 'number' ? t0 - task._instockAt : null;
    return { ...timer.summary(), handoffMs };
  };
  let stage = null;
  let orderNumber = null;
  let browser;
  let release = () => {};
  let failureType = null;
  let siblingUnsub = () => {};
  let prewarmRelease = null;
  let sharedPrewarm = false;
  // Hoisted OUT of the try: the catch block reports proxyHost on the failure
  // result, and a `const` declared inside the try is not in scope there. Getting
  // this wrong threw `proxy is not defined` out of the catch, which swallowed the
  // classified failure result entirely — no retry, no run record, no proxy
  // intelligence update.
  let proxy = null;
  let checkoutProxy = null;
  // Residential session token. Released in `finally` next to the queue slot so a
  // throw anywhere after admission can never strand a gateway slot.
  let residentialRelease = null;

  try {
    // Cross-task signaling: if a sibling already won this product within the
    // last 5 minutes, abort immediately to save proxy/captcha/time budget.
    throwIfSiblingWon(task.url);
    // Subscribe so a sibling that wins mid-run can signal us to abort early.
    siblingUnsub = subscribeToSiblings(task.url, ({ winnerTaskId, orderNumber: orderNum }) => {
      logger.info(`[StartTask] Task ${taskId} received sibling-won signal — winner: task ${winnerTaskId} (order ${orderNum || 'unknown'}). Will abort at next guard checkpoint.`);
      // Set a flag the guards can check; we don't kill the browser here
      // because in-flight HTTP requests need to drain cleanly. Optional
      // chaining can't appear on the LEFT of an assignment, so we null-check
      // explicitly before tagging the browser instance.
      try { if (browser) browser.__siblingWon = { winnerTaskId, orderNumber: orderNum }; } catch (_) {}
    });
    const taskHost = (() => { try { return new URL(task.url).hostname; } catch (_) { return null; } })();
    release = await acquireSlot(taskId, { host: taskHost, priority: Number(task._priority || 0) });
    const enrichedTask = await loadTaskWithRelations(task);
    if (overridePaymentProfileId) {
      enrichedTask.paymentProfile = await db('payment_profiles').where({ id: overridePaymentProfileId }).first();
      enrichedTask.payment_profile_id = overridePaymentProfileId;
      logger.info(`[StartTask] Task ${taskId} using alternate payment profile ${overridePaymentProfileId}`);
    }
    ({ checkoutProxy, proxy } = enrichedTask);

    // ADMISSION GATE. Deliberately placed before the launch and before the
    // request-mode probe: everything below costs either RAM or residential
    // bandwidth, and neither is recoverable once spent.
    //
    // Contract: ADVISORY ONLY. This never throws and never aborts the attempt —
    // a busy host is a reason to be careful, not to drop a checkout during a
    // drop. Failures reading either snapshot fall through to "proceed".
    try {
      const memory = await getMemorySnapshot();
      const verdict = checkoutAdmission({
        memory,
        proxy,
        activeResidential: activeResidentialSessions('checkout'),
        maxResidential: maxResidentialSessions(),
        bootReserveBytes: 0
      });
      if (verdict.reasons.length > 0) {
        logger.warn(`[StartTask] Task ${taskId} admitted with pressure (${verdict.reasons.join(', ')}) — headroom ${verdict.headroomBytes == null ? 'n/a' : Math.round(verdict.headroomBytes / 1048576) + 'MB'}`);
      }
      if (verdict.isResidential) {
        // Always take a gateway slot. When the queue is full this blocks for a
        // bounded time and then admits anyway — we never drop the run here.
        // (If memory is the constraint instead, waiting buys nothing, but a
        // queued slot is still the correct accounting.)
        residentialRelease = await acquireResidentialSession('checkout');
      }
      if (verdict.lowRam) logger.info(`[StartTask] Task ${taskId} low-RAM host — tight renderer limit and reduced caches`);
    } catch (admissionErr) {
      logger.debug(`[StartTask] Admission check failed (non-fatal): ${admissionErr.message}`);
    }

    // Apply bot-learner recommendation when it was pre-computed by the caller.
    // The arm encodes both TLS profile and timing mode (e.g. 'chrome131-quick').
    // We only override quick_mode — the TLS profile override happens via the
    // profile_label stored with the run, which the learner seeds from on restart.
    if (botLearnerArm) {
      const armMode = botLearnerArm.split('-')[1];
      if (armMode === 'quick') enrichedTask.quick_mode = true;
      else if (armMode === 'normal') enrichedTask.quick_mode = false;
      logger.info(`[BotLearner] Task ${taskId} using arm "${botLearnerArm}" → quick_mode=${enrichedTask.quick_mode}`);
    }

    // REQUEST-MODE SMOKE PROBE (opt-in via `request_mode_enabled`, default OFF).
    // Read-only foundation for browserless checkout: before Chromium launches,
    // resolve the variant and confirm the Chrome-fingerprinted HTTP session
    // reaches the store cleanly. It NEVER mutates a cart or places an order, and
    // any result is purely informational — the normal browser flow always runs
    // next. Zero behavior change when the setting is off.
    try {
      if (await requestModeEnabled() && String(process.env.REQUEST_MODE_PROBE_HOTPATH || 'false').toLowerCase() === 'true') {
        const rc = await tryRequestCheckout({ task: enrichedTask, proxy, dryRun: true });
        if (rc.ok) {
          logger.info(`[StartTask] Task ${taskId} ⚡ request-mode probe OK (variant ${rc.variantId}, ${rc.durationMs}ms) — browserless path reachable`);
        } else {
          logger.info(`[StartTask] Task ${taskId} request-mode probe: ${rc.reason || rc.classified || rc.stage || 'n/a'} (browser flow unaffected)`);
        }
      }
    } catch (e) {
      logger.warn(`[StartTask] request-mode probe error (non-fatal): ${e.message}`);
    }

    // PREWARM ADOPT (park-then-adopt speed engine). If the monitor pre-positioned
    // a warmed browser for this task, adopt it and skip the cold launch + warm —
    // the biggest chunk of the monitor→checkout latency. Always safe: adoptPrewarm
    // returns null (an instant no-op) when nothing was parked, and it disposes any
    // stale/mismatched context BEFORE returning null so the cold launchBrowser can
    // never deadlock on the still-held per-task Chrome profile lock.
    const sitePerf = getSitePerformanceProfile(task.site_id);
    let page;
    let adopted = null;
    try {
      adopted = await adoptPrewarm(taskId, { proxyId: proxy?.id ?? null, url: task.url, siteId: task.site_id, quickMode: enrichedTask.quick_mode !== false });
    } catch (_) { adopted = null; }

    if (adopted && adopted.browser && adopted.page) {
      browser = adopted.browser;
      page = adopted.page;
      prewarmRelease = adopted.release || null;
      sharedPrewarm = adopted.sharedPrewarm === true;
      page.__checkoutFastUI = enrichedTask.quick_mode !== false;
      // Cold work already done while monitoring — record near-zero for these
      // stages so the speed dashboard reflects the win, then jump straight in.
      timer.mark('browser_launch');
      timer.mark('page_ready');
      timer.mark('prewarm_adopted');
      storePageInTaskCache({ taskId, page });
      timer.mark('blocker_ready');
      timer.mark('cookies_injected');
      timer.mark('warm_done');
      logger.info(`[StartTask] Task ${taskId} ⚡ adopted prewarmed browser — skipped cold launch + warm`);
    } else {
      browser = await launchBrowser({ proxy, taskId, siteId: task.site_id });
      timer.mark('browser_launch');
      page = await getNewPage({ browser, proxy, role: 'checkout', siteId: task.site_id, taskId });
      page.__checkoutFastUI = enrichedTask.quick_mode !== false;
      timer.mark('page_ready');
      storePageInTaskCache({ taskId, page });

      // Resource blocker — block images/fonts/media/trackers for speed.
      // Quick mode uses aggressive "checkout" blocking; normal mode blocks trackers only.
      const blockMode = enrichedTask.quick_mode ? 'checkout' : 'monitor';
      await enableResourceBlocker(page, { mode: blockMode, siteId: task.site_id });
      timer.mark('blocker_ready');

      // Cookie pool — inject warm cookies from other tasks targeting the same site.
      // Skips full Imperva/CF challenge if another task already solved it recently.
      const productUrl = new URL(task.url);
      const siteOrigin = `${productUrl.protocol}//${productUrl.hostname}`;
      const hadPoolCookies = await injectCookies(page, task.url);
      timer.mark('cookies_injected');

      // Session warm (homepage browse). Skip if we have fresh pooled cookies.
      if (!hadPoolCookies) {
        try {
          const homepage = `${siteOrigin}${sitePerf.warmPath}`;
          logger.info(`[StartTask] Task ${taskId} attempt ${attemptNum}: warming ${sitePerf.warmMode} path via ${homepage}`);
          const warmed = await warmInPlace(page, homepage);
          if (!warmed) logger.warn(`[StartTask] In-place warm did not produce session cookies — proceeding cautiously`);

          if (sitePerf.warmScroll && sitePerf.warmMode === 'full') {
            await page.evaluate(() => new Promise((r) => {
              let y = 0;
              const tick = setInterval(() => {
                window.scrollBy({ top: 80, behavior: 'smooth' });
                y += 80;
                if (y > 400) { clearInterval(tick); r(); }
              }, 160);
            })).catch(() => {});
          }

          const range = task.quick_mode ? sitePerf.quickWarmPauseMs : sitePerf.normalWarmPauseMs;
          const pause = randInt(range[0], range[1]);
          await sleep(pause);
          logger.info(`[StartTask] Pre-flight complete (${sitePerf.warmMode}) — proceeding to product`);
        } catch (preErr) {
          logger.warn(`[StartTask] In-place warm failed (continuing anyway): ${preErr.message}`);
        }
      } else {
        logger.info(`[StartTask] Task ${taskId} skipping warm — using ${hadPoolCookies ? 'pooled' : 'cached'} cookies`);
        await sleep(randInt(300, 700));
      }

      timer.mark('warm_done');
    }
    const siteName = SITES[task.site_id];
    if (!siteName) throw new Error(`Unknown site_id: ${task.site_id}`);

    const reportStage = async (stage, phase = 'running') => {
      const normalized = String(stage || 'unknown').replace(/([a-z])([A-Z])/g, '$1_$2').toLowerCase();
      const status = phase === 'completed' ? `stage_complete:${normalized}` : `stage:${normalized}`;
      await db('tasks').where({ id: taskId }).update({ last_status: status }).catch(() => {});
      const event = {
        type: 'workflow',
        taskId: Number(taskId),
        stage: normalized,
        phase,
        siteId: task.site_id,
        updatedAt: Date.now()
      };
      broadcastToClients(taskId, event);
      broadcastAllClients(event);
    };

    const { default: runSite } = await import(`../sites/${siteName}/index.js`);
    await reportStage('checkout', 'running');
    await runSite({ page, task: enrichedTask, reportStage });
    await reportStage('checkout', 'completed');
    timer.mark('adapter_done');

    // Harvest cookies for the pool BEFORE reading order number — share with
    // other tasks targeting the same site.
    await harvestCookies(page, task.url);

    orderNumber = await page.evaluate(() => {
      const el = document.querySelector('.order-number, [data-order-id], .summary-order-number');
      return el ? el.textContent.trim() : null;
    }).catch(() => null);

    await captureOrderSuccess({
      page, taskId,
      orderNumber,
      productUrl: task.url,
      durationMs: Date.now() - t0,
      profile: page._fingerprintProfile
    }).catch((err) => logger.warn(`[StartTask] Order capture failed: ${err.message}`));

    // Signal sibling tasks targeting the same product that we won.
    notifyProductSuccess({ productUrl: task.url, taskId, orderNumber });

    return { ok: true, durationMs: Date.now() - t0, stage: 'completed', orderNumber, arm: botLearnerArm, proxyHost: proxy?.host || null, timings: buildTimings() };
  } catch (err) {
    const m = err.message?.match(/at stage "([^"]+)"/);
    stage = m ? m[1] : null;

    // Sibling-won abort short-circuits all classification — never retry.
    if (err instanceof SiblingWonError || err.siblingWon) {
      logger.info(`[StartTask] Task ${taskId} aborting cleanly: ${err.message}`);
      return { ok: false, durationMs: Date.now() - t0, stage: 'sibling_won', error: err.message, failureType: 'sibling_won', proxyHost: null, timings: buildTimings() };
    }

    // An adapter can pre-classify a failure (e.g. 3DS → 'human_required',
    // missing critical field → 'checkout_fill_failed'). That explicit tag wins
    // over the message-based heuristics below.
    if (err.failureType) failureType = err.failureType;
    else if (isOosFailure(err.message)) failureType = 'oos';
    else if (isDeclineFailure(err.message)) failureType = 'decline';
    else if (isSessionFailure(err.message)) failureType = 'session_expired';

    // If error text didn't classify as decline/oos, try scraping the page
    // for actual decline/OOS error messages before the browser closes.
    if (!failureType && browser) {
      try {
        const pages = await browser.pages();
        const activePage = pages[pages.length - 1];
        if (activePage) {
          const detection = await detectDecline(activePage);
          if (detection) {
            failureType = detection.type === 'address_reject' ? 'decline' : detection.type;
            logger.info(`[StartTask] Page-level decline detection found: ${detection.type} — "${detection.message}"`);
          }
        }
      } catch (_) {}
    }

    return { ok: false, durationMs: Date.now() - t0, stage, error: err.message, failureType, arm: botLearnerArm, proxyHost: proxy?.host || null, timings: buildTimings() };
  } finally {
    try { siblingUnsub(); } catch (_) {}
    // Give the concurrency slot back FIRST. Everything below awaits, and a
    // rejection (or a hang) inside the teardown would otherwise strand the task's
    // global + per-host + single-flight slots until process restart, permanently
    // reducing capacity. `release` is idempotent.
    release();
    // Give the residential gateway slot back too. Idempotent token, same
    // discipline as the queue slot: a stranded token would permanently shrink
    // residential capacity until process restart.
    try { if (residentialRelease) residentialRelease(); } catch (_) {}
    // Release the strong Page reference before closing Chromium so completed runs
    // cannot accumulate closed Page objects in the in-process task cache.
    await removePageFromTaskCache({ taskId }).catch(() => {});
    if (sharedPrewarm) {
      if (prewarmRelease) await prewarmRelease().catch(() => {});
      else await page?.close?.().catch(() => {});
    } else if (browser) {
      await browser.close().catch(() => {});
    }
  }
};

const runTaskLifecycle = async (task) => {
  const taskId = task.id;
  // Hostname used for proxy-outcome recording below. Computed here (not only in
  // runOnce) so the recordOutcome call in this scope resolves — referencing the
  // runOnce-scoped copy threw a ReferenceError whenever a proxy was configured,
  // i.e. exactly the residential-proxy path PC/Walmart checkout depends on.
  const taskHost = (() => { try { return new URL(task.url).hostname; } catch (_) { return null; } })();
  logger.info(`Starting task ${taskId} — site_id: ${task.site_id}`);

  // Pokemon Center (site_id 6) runs 8am–6pm ET only. Block a *manual* start
  // outside the window. `task._instockAt` marks a monitor-triggered buy on a
  // live stock hit — those are allowed to complete even across the 6pm boundary
  // so a detected drop isn't dropped. Returns quietly (no throw) so a manual
  // start just no-ops with a clear status.
  if (task.site_id === PC_SITE_ID && !task._instockAt && (await businessHoursEnabled()) && !isWithinBusinessHours()) {
    const msg = 'Outside Pokemon Center hours (8am–6pm ET) — not started; monitoring auto-starts at 8am ET.';
    logger.info(`[StartTask] Task ${taskId} skipped — ${msg}`);
    await db('tasks').where({ id: taskId }).update({ last_status: 'outside_hours' }).catch(() => {});
    return { skipped: true, reason: 'outside_hours', message: msg };
  }

  // Preflight gate
  const pf = await preflightTask(task);
  logPreflight(taskId, pf);
  if (!pf.ok) {
    const msg = `Preflight failed: ${pf.issues.join('; ')}`;
    await notify({ taskId, message: msg, success: false, stage: 'preflight', productUrl: task.url });
    await db('tasks').where({ id: taskId }).update({
      last_run_at: new Date(), last_status: 'preflight_fail'
    });
    throw new Error(msg);
  }

  // Household cap enforcement — count successful orders already placed with
  // the same shipping address and block if over the limit. This prevents
  // multiple bot tasks from exceeding a site's per-household purchase limit
  // (e.g. "limit 2 per household" on Pokemon TCG drops).
  //
  // Uses a serializable transaction with FOR UPDATE row lock on the tasks
  // sharing this address, so concurrent starts for different task IDs that
  // share an address cannot both pass the check and both place orders.
  if (task.household_limit && task.shipping_address_id) {
    const blocked = await db.transaction(async (trx) => {
      // Lock all tasks with this shipping address to serialize concurrent cap checks
      await trx.raw(
        'SELECT id FROM tasks WHERE shipping_address_id = ? FOR UPDATE',
        [task.shipping_address_id]
      );
      const { count } = await trx('task_runs')
        .join('tasks', 'tasks.id', 'task_runs.task_id')
        .where({
          'tasks.shipping_address_id': task.shipping_address_id,
          'task_runs.status': 'success'
        })
        .count('task_runs.id as count')
        .first();
      return parseInt(count, 10) || 0;
    });
    if (blocked >= task.household_limit) {
      const msg = `Household cap reached: ${blocked}/${task.household_limit} successful orders for this address`;
      logger.warn(`[StartTask] Task ${taskId} blocked — ${msg}`);
      await notify({ taskId, message: msg, success: false, stage: 'household_cap', productUrl: task.url });
      await db('tasks').where({ id: taskId }).update({
        last_run_at: new Date(), last_status: 'household_cap',
        disabled_at: new Date(), disabled_reason: msg
      });
      throw new Error(msg);
    }
    logger.info(`[StartTask] Task ${taskId} household cap: ${blocked}/${task.household_limit} used`);
  }

  // Payment lockout. Checked AFTER household caps (a cap is a permanent stop,
  // the lock is a temporary one) and BEFORE any browser is launched, so an
  // armed task with a dead card cannot spend proxy bandwidth or captcha credits
  // on a checkout that is going to be declined at the last step. Only an
  // operator action clears it — see `POST /v1/tasks/:id/enable-payment`.
  if (isPaymentLocked(task)) {
    const msg = task.pay_disabled_reason || 'Payment locked — re-enable from the dashboard';
    logger.warn(`[StartTask] Task ${taskId} blocked — ${msg}`);
    await notify({ taskId, message: msg, success: false, stage: 'payment_locked', productUrl: task.url });
    await db('tasks').where({ id: taskId }).update({
      last_run_at: new Date(), last_status: 'payment_locked'
    });
    throw new Error(msg);
  }

  // Drop-time scheduling. A monitor-triggered stock hit is already at the
  // point of sale, so waiting on start_at again only adds latency and can miss
  // the remaining cart window. Cold/manual starts still honor the drop watcher.
  if (typeof task._instockAt === 'number') {
    logger.info(`[StartTask] Task ${taskId} hot-stock handoff — skipping drop-time wait`);
  } else {
    await waitForDropTime(task);
  }

  const profile = task.payment_profile_id
    ? await db('payment_profiles').where({ id: task.payment_profile_id }).first().then((p) => p?.label || null)
    : null;

  const maxRetries = Math.max(0, parseInt(task.max_retries ?? 2, 10));
  const MAX_RESTOCK_LOOPS = 3;
  const MAX_DECLINE_SWAPS = 2;
  const MAX_SESSION_RETRIES = 2;
  const MAX_PROXY_SWAPS = 3;
  let lastErr = null;
  let totalDuration = 0;
  let restockLoops = 0;
  let declineSwaps = 0;
  let sessionRetries = 0;
  let proxySwaps = 0;
  const triedProxyIds = new Set([task.checkout_proxy_id, task.proxy_id].filter(Boolean));
  let currentPaymentProfileId = task.payment_profile_id;
  const triedPaymentProfileIds = new Set([task.payment_profile_id].filter(Boolean));

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    if (attempt > 0) {
      const backoff = Math.min(15_000, 2_500 * 2 ** (attempt - 1)) + randInt(-500, 500);
      logger.info(`[StartTask] Task ${taskId} retry ${attempt}/${maxRetries} after ${backoff}ms backoff`);
      await sleep(backoff);
    }

    await db('tasks').where({ id: taskId }).update({ retry_count: attempt, last_run_at: new Date() });

    // Ask the bot learner which arm (TLS profile + timing mode) to use for
    // this site. On the very first run there's no data so it explores randomly.
    // After a few attempts it learns which combo evades detection best.
    let botLearnerArm = null;
    try {
      const rec = await getBotLearnerRecommendation(task.site_id);
      botLearnerArm = rec.arm;
      if (attempt === 0) {
        logger.info(`[BotLearner] Task ${taskId} site ${task.site_id}: using arm "${rec.arm}" (confidence=${rec.confidence}, totalPulls=${rec.totalPulls})`);
      }
    } catch (learnerErr) {
      logger.debug(`[BotLearner] Recommendation failed (non-fatal): ${learnerErr.message}`);
    }

    const result = await runOnce(task, attempt + 1, {
      overridePaymentProfileId: currentPaymentProfileId !== task.payment_profile_id ? currentPaymentProfileId : undefined,
      botLearnerArm
    });
    totalDuration += result.durationMs;
    const proxyHost = result.proxyHost || null;
    await recordRun(task, attempt + 1, result, profile, proxyHost);

    // Proxy intelligence is transport-only. A site-side 403/429/challenge is not
    // treated as evidence that the proxy is dead; connection failures are.
    const checkoutProxyId = Number(task.checkout_proxy_id || task.proxy_id || 0);
    if (checkoutProxyId && taskHost) {
      if (result.ok) {
        markProxyTransportSuccess(checkoutProxyId);
        recordOutcome(checkoutProxyId, taskHost, { success: true, latencyMs: result.durationMs });
      } else if (isProxyTransportFailure(result)) {
        markProxyTransportFailure(checkoutProxyId, result.error || result.failureType || 'transport failure');
        recordOutcome(checkoutProxyId, taskHost, { success: false, latencyMs: result.durationMs });
      }
    }

    // Bot learner: record this arm's outcome so the bandit updates its model.
    // Non-fatal — a learner failure must never kill a checkout attempt.
    if (botLearnerArm && task.site_id) {
      recordBotLearnerOutcome(task.site_id, botLearnerArm, result).catch(() => {});
    }

    if (result.ok) {
      // A placed order proves the card works: clear the decline streak and any
      // payment lock outright.
      await recordPaymentOutcome(db, taskId, task, 'success');
      await db('tasks').where({ id: taskId }).update({
        has_been_used: true,
        last_status: 'success',
        last_order_number: result.orderNumber || '',
        last_duration_ms: totalDuration,
        consecutive_failures: 0,
        // A successful order is terminal for this task; don't let the 24/7
        // reconciler immediately fire a duplicate checkout.
        monitor_24_7: false
      });

      await sendSuccessEmail({ to: task.notification_email_address, taskId, productUrl: task.url }).catch(() => {});
      await notify({
        taskId, success: true,
        message: `Checkout successful for ${task.url}`,
        productUrl: task.url, orderNumber: result.orderNumber,
        profileLabel: profile, retryCount: attempt, durationMs: totalDuration
      });
      logger.info(`Task ${taskId} completed successfully in ${totalDuration}ms (attempt ${attempt + 1})`);
      return;
    }

    lastErr = result;
    logger.warn(`[StartTask] Task ${taskId} attempt ${attempt + 1}/${maxRetries + 1} failed at "${result.stage || '?'}": ${result.error}`);
    if (/Preflight failed/i.test(result.error || '')) break;

    // --- HUMAN REQUIRED: 3DS / bank verification the bot can't solve ---
    // Retrying just re-hits the same challenge and spams alerts. The adapter has
    // already sent a loud "finish this manually" notification, so stop cleanly
    // WITHOUT counting it against the stop-loss failure streak.
    if (result.failureType === 'human_required') {
      logger.warn(`[StartTask] Task ${taskId} needs manual human action (3DS/verification) — stopping retries.`);
      await db('tasks').where({ id: taskId })
        .update({ last_status: 'needs_human', last_run_at: new Date() })
        .catch(() => {});
      return;
    }

    // --- RESTOCK LOOP: OOS mid-checkout → re-monitor instead of burning a retry ---
    // Pro bots loop back to the stock monitor when a product goes OOS during
    // checkout (e.g., someone else grabbed the last unit). This avoids wasting
    // retry attempts on a product that simply isn't available yet.
    if (result.failureType === 'oos' && restockLoops < MAX_RESTOCK_LOOPS) {
      restockLoops++;
      logger.info(`[StartTask] Task ${taskId} OOS during checkout — entering restock loop ${restockLoops}/${MAX_RESTOCK_LOOPS}`);
      await notify({
        taskId, success: false,
        message: `Item went OOS during checkout — waiting for restock (loop ${restockLoops}/${MAX_RESTOCK_LOOPS})`,
        stage: 'restock_wait', productUrl: task.url
      });
      await db('tasks').where({ id: taskId }).update({ last_status: 'restock_wait' });
      // Re-enter the drop watcher hot poll. This blocks until stock returns
      // or the grace window expires. We create a temporary task with start_at
      // set to "now" so the watcher enters hot-poll immediately.
      const restockTask = { ...task, start_at: new Date(Date.now() + 2000).toISOString() };
      await waitForDropTime(restockTask);
      attempt--; // don't count OOS as a retry burn
      continue;
    }

    // --- SESSION EXPIRED: cart/session timed out → retry without burning attempt ---
    // High-traffic drops sometimes invalidate the cart/session before checkout
    // finishes. This isn't a hard failure — a fresh browser session usually
    // recovers. Capped at MAX_SESSION_RETRIES to prevent infinite loops if
    // the session keeps getting invalidated (e.g. proxy banned, account flagged).
    if (result.failureType === 'session_expired' && sessionRetries < MAX_SESSION_RETRIES) {
      sessionRetries++;
      logger.info(`[StartTask] Task ${taskId} session/cart expired — retrying with fresh browser (retry ${sessionRetries}/${MAX_SESSION_RETRIES})`);
      await notify({
        taskId, success: false,
        message: `Cart/session expired — retrying with a fresh session (${sessionRetries}/${MAX_SESSION_RETRIES})`,
        stage: 'session_retry', productUrl: task.url
      });
      attempt--; // don't count session expiry as a retry burn
      continue;
    }
    if (result.failureType === 'session_expired') {
      logger.warn(`[StartTask] Task ${taskId} session expired ${sessionRetries}× — exhausted, falling through to normal retry`);
    }

    // --- DECLINE SWAP: payment declined → try alternate payment profile ---
    // Pro bots like Stellar rotate through backup payment methods when a card
    // is declined. We try up to MAX_DECLINE_SWAPS alternate profiles.
    if (result.failureType === 'decline' && declineSwaps < MAX_DECLINE_SWAPS && task.payment_profile_id) {
      declineSwaps++;
      const alternates = await getAlternatePaymentProfiles(currentPaymentProfileId, taskId);
      const untried = alternates.filter((p) => !triedPaymentProfileIds.has(p.id));
      if (untried.length > 0) {
        const nextProfile = untried[0];
        currentPaymentProfileId = nextProfile.id;
        triedPaymentProfileIds.add(nextProfile.id);
        logger.info(`[StartTask] Task ${taskId} payment declined — swapping to profile "${nextProfile.label || nextProfile.id}" (swap ${declineSwaps}/${MAX_DECLINE_SWAPS})`);
        await notify({
          taskId, success: false,
          message: `Payment declined — trying backup card "${nextProfile.label || 'Profile ' + nextProfile.id}"`,
          stage: 'decline_swap', productUrl: task.url
        });
        attempt--; // don't count decline as a retry burn
        continue;
      }
      logger.warn(`[StartTask] Task ${taskId} payment declined but no untried alternate profiles available`);
    }

    // --- PROXY FAILOVER: transport failure only ---
    // Dead/unreachable proxies should not consume the same retry budget.
    // Site-side policy responses remain on the normal retry/classification path.
    const checkoutProxySelection = await resolveTaskProxy(task, 'checkout');
    const checkoutProxyCanFailover = checkoutProxySelection.source === 'assigned' || checkoutProxySelection.source === 'legacy';
    const activeCheckoutProxyId = Number(task.checkout_proxy_id || task.proxy_id || 0);
    if (activeCheckoutProxyId && checkoutProxyCanFailover && proxySwaps < MAX_PROXY_SWAPS && shouldRotateProxyAfterFailure({ task, lastResult: result })) {
      const next = await pickBackupProxy({
        host: taskHost,
        excludeIds: triedProxyIds,
        forceRefresh: proxySwaps === 0,
        proxyType: checkoutProxySelection.proxy?.proxy_type || null,
      });
      if (next && next.id !== activeCheckoutProxyId) {
        proxySwaps++;
        triedProxyIds.add(next.id);
        const prevId = activeCheckoutProxyId;
        task.checkout_proxy_id = next.id;
        task.checkout_proxy_mode = 'assigned';
        if (!task.checkout_proxy_id && task.proxy_id) task.proxy_id = next.id;
        logger.info(`[StartTask] Task ${taskId} checkout proxy ${prevId ?? 'none'} had a transport failure — failing over to backup proxy ${next.id} (${next.host}) [swap ${proxySwaps}/${MAX_PROXY_SWAPS}]`);
        await notify({
          taskId, success: false,
          message: `Checkout proxy connection failed — switched to backup proxy ${next.host} (${proxySwaps}/${MAX_PROXY_SWAPS})`,
          stage: 'checkout_proxy_swap', productUrl: task.url
        });
        attempt--;
        continue;
      }
      if (!next) logger.warn(`[StartTask] Task ${taskId} checkout proxy transport failed but no backup proxies are currently available`);
    }

    // Identity rotation for detection failures
    if (attempt + 1 <= maxRetries && shouldRotateAfterFailure({ task, lastResult: result })) {
      logger.info(`[StartTask] Task ${taskId} rotating identity before retry ${attempt + 2} (failure stage: ${result.stage || '?'})`);
      await rotateIdentity(taskId);
    }
  }

  // Classify the terminal outcome for the payment lockout counter. A 'decline'
  // here means the decline exhausted every swap and every retry, i.e. the
  // funding source is what failed — that is the only thing worth counting.
  // Everything else (OOS, proxy death, session expiry) is neutral and leaves
  // the streak untouched.
  const terminalDecline = Boolean(lastErr && lastErr.failureType === 'decline');
  await recordPaymentOutcome(db, taskId, task, terminalDecline ? 'decline' : 'neutral');

  // All attempts exhausted. Atomic increment-and-check via a single SQL
  // statement so two concurrent runners can't both observe stale counts and
  // each fail to trip the breaker. RETURNING gives us the post-update row.
  const updated = await db.raw(`
    UPDATE tasks
       SET consecutive_failures = consecutive_failures + 1,
           last_status = 'failed',
           last_duration_ms = ?,
           has_been_used = CASE
             WHEN max_failures IS NOT NULL AND consecutive_failures + 1 >= max_failures THEN true
             ELSE has_been_used
           END,
           disabled_at = CASE
             WHEN max_failures IS NOT NULL AND consecutive_failures + 1 >= max_failures THEN NOW()
             ELSE disabled_at
           END,
           disabled_reason = CASE
             WHEN max_failures IS NOT NULL AND consecutive_failures + 1 >= max_failures
               THEN 'Stop-loss tripped: ' || (consecutive_failures + 1) || '/' || max_failures || ' consecutive failures'
             ELSE disabled_reason
           END
     WHERE id = ?
     RETURNING consecutive_failures, max_failures, disabled_at, disabled_reason
  `, [totalDuration, taskId]);
  const row = updated.rows?.[0];
  if (row?.disabled_at && row?.disabled_reason) {
    logger.error(`[StopLoss] Task ${taskId} auto-disabled — ${row.disabled_reason}`);
    await notify({
      taskId, success: false,
      message: `🛑 Stop-loss tripped (${row.consecutive_failures}/${row.max_failures}). Task auto-disabled.`,
      stage: 'stop_loss', productUrl: task.url
    }).catch(() => {});
  }
  await notify({
    taskId, success: false,
    message: lastErr?.error || 'Unknown error',
    stage: lastErr?.stage, productUrl: task.url,
    screenshotUrl: lastErr?.stage ? getScreenshotUrl(taskId, lastErr.stage) : null,
    profileLabel: profile, retryCount: maxRetries, durationMs: totalDuration
  });
  logger.error(`Task ${taskId} failed after ${maxRetries + 1} attempts in ${totalDuration}ms`);
};

// Public entry point. A purchase task is single-flight: repeated Start clicks,
// overlapping scheduler/manual starts, or duplicate monitor triggers should share
// the same in-flight promise rather than queueing a second full checkout behind the
// first one (which could otherwise place a duplicate order after the first succeeds).
const activeTaskRuns = new Map();

const startTask = (task) => {
  const taskId = task?.id;
  if (taskId != null && activeTaskRuns.has(taskId)) {
    logger.info(`[StartTask] Task ${taskId} already running — joining existing workflow`);
    return activeTaskRuns.get(taskId);
  }

  const runPromise = (async () => {
    try {
      return await runTaskLifecycle(task);
    } finally {
      await disposePrewarm(task?.id).catch(() => {});
    }
  })();

  if (taskId != null) {
    activeTaskRuns.set(taskId, runPromise);
    runPromise.finally(() => activeTaskRuns.delete(taskId)).catch(() => {});
  }
  return runPromise;
};

export const isTaskRunning = (taskId) => activeTaskRuns.has(taskId);
export const getActiveTaskRuns = () => Array.from(activeTaskRuns.keys());

export default startTask;

// Only run the CLI task-runner when this file is executed directly
// (`node scripts/start-task.js <id>`) — NOT when imported by app/route code.
// Without this guard, importing the module while any process arg is present
// (e.g. under the jest runner) spuriously fires a DB lookup + process.exit.
const isMainModule = process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href;

if (isMainModule && process.argv[2]) {
  const taskId = parseInt(process.argv[2]);
  db('tasks').where({ id: taskId }).first()
    .then((task) => {
      if (!task) { logger.error(`Task ${taskId} not found`); process.exit(1); }
      return startTask(task);
    })
    .then(() => process.exit(0))
    .catch((err) => { logger.error(err.message); process.exit(1); });
}
