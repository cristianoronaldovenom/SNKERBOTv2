import { describe, expect, test } from '@jest/globals';
import { recommendedPrewarmCap } from '../../helpers/memory-guard.js';

describe('memory optimization', () => {
  // The configured `prewarm_max_parked` is a ceiling on any host. This used to
  // fail in `max` mode, which raised a configured 3 to 4.
  test.each([1, 2, 3, 5, 10])('configured prewarm cap %i is never exceeded', async (configured) => {
    const cap = await recommendedPrewarmCap(configured);
    expect(cap).toBeGreaterThanOrEqual(0);
    expect(cap).toBeLessThanOrEqual(configured);
  });

  test('a disabled prewarm cap stays disabled', async () => {
    expect(await recommendedPrewarmCap(0)).toBe(0);
  });

  test('the cap is clamped to the documented 0-10 setting range', async () => {
    expect(await recommendedPrewarmCap(99)).toBeLessThanOrEqual(10);
  });
});

