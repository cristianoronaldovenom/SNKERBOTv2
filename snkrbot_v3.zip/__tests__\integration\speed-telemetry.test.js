import { jest } from '@jest/globals';

const { StageTimer, aggregateStageTimings } = await import('../../helpers/stage-timer.js');

describe('StageTimer — pipeline timing instrumentation', () => {
  test('records cumulative atMs and per-stage deltaMs with injected time', () => {
    const timer = new StageTimer(1000);
    timer.mark('browser_launch', 1300); // 300ms cold start
    timer.mark('page_ready', 1350);     // +50ms
    timer.mark('warm_done', 2350);      // +1000ms warm
    const { totalMs, stages } = timer.summary(2400);

    expect(stages.map((s) => s.name)).toEqual(['browser_launch', 'page_ready', 'warm_done']);
    expect(stages[0]).toMatchObject({ atMs: 300, deltaMs: 300 });
    expect(stages[1]).toMatchObject({ atMs: 350, deltaMs: 50 });
    expect(stages[2]).toMatchObject({ atMs: 1350, deltaMs: 1000 });
    expect(totalMs).toBe(1400);
  });

  test('preserves mark order and is independent across instances', () => {
    const a = new StageTimer(0);
    a.mark('x', 10);
    const b = new StageTimer(100);
    b.mark('y', 250);
    expect(a.summary(20).stages).toHaveLength(1);
    expect(b.summary(300).stages[0]).toMatchObject({ name: 'y', deltaMs: 150 });
  });

  test('summary returns a copy — later marks do not mutate an earlier snapshot', () => {
    const timer = new StageTimer(0);
    timer.mark('a', 100);
    const snap = timer.summary(100);
    timer.mark('b', 200);
    expect(snap.stages).toHaveLength(1);
  });
});

describe('aggregateStageTimings — per-site speed breakdown', () => {
  const rowObj = (siteId, totalMs, handoffMs, stages) => ({
    site_id: siteId,
    timings: { totalMs, handoffMs, stages },
  });

  test('averages totalMs, handoffMs and each stage across runs per site', () => {
    const rows = [
      rowObj(6, 1000, 200, [{ name: 'browser_launch', deltaMs: 300 }, { name: 'warm_done', deltaMs: 700 }]),
      rowObj(6, 2000, 400, [{ name: 'browser_launch', deltaMs: 500 }, { name: 'warm_done', deltaMs: 900 }]),
    ];
    const [pc] = aggregateStageTimings(rows);
    expect(pc.siteId).toBe(6);
    expect(pc.runs).toBe(2);
    expect(pc.avgTotalMs).toBe(1500);
    expect(pc.avgHandoffMs).toBe(300);
    const launch = pc.stages.find((s) => s.name === 'browser_launch');
    expect(launch).toMatchObject({ avgMs: 400, samples: 2 });
  });

  test('parses timings that arrive as a JSON string (jsonb round-trip)', () => {
    const rows = [{ site_id: 8, timings: JSON.stringify({ totalMs: 800, handoffMs: 100, stages: [{ name: 'page_ready', deltaMs: 80 }] }) }];
    const [walmart] = aggregateStageTimings(rows);
    expect(walmart.siteId).toBe(8);
    expect(walmart.avgTotalMs).toBe(800);
    expect(walmart.stages[0]).toMatchObject({ name: 'page_ready', avgMs: 80, samples: 1 });
  });

  test('separates sites and skips rows with missing/invalid timings', () => {
    const rows = [
      rowObj(6, 1000, null, [{ name: 'warm_done', deltaMs: 500 }]),
      rowObj(8, 2000, null, [{ name: 'warm_done', deltaMs: 600 }]),
      { site_id: 6, timings: null },
      { site_id: 6, timings: 'not-json' },
      { site_id: 6, timings: { totalMs: 5, stages: 'nope' } },
    ];
    const out = aggregateStageTimings(rows);
    expect(out).toHaveLength(2);
    expect(out.find((s) => s.siteId === 6).runs).toBe(1);
    expect(out.find((s) => s.siteId === 8).runs).toBe(1);
  });

  test('avgHandoffMs is null when no run recorded a handoff', () => {
    const rows = [rowObj(6, 1000, null, [{ name: 'warm_done', deltaMs: 500 }])];
    expect(aggregateStageTimings(rows)[0].avgHandoffMs).toBeNull();
  });

  test('ignores non-finite numbers (NaN/Infinity) instead of poisoning averages', () => {
    const rows = [
      { site_id: 6, timings: { totalMs: NaN, handoffMs: Infinity, stages: [{ name: 'warm_done', deltaMs: NaN }, { name: 'page_ready', deltaMs: 80 }] } },
      rowObj(6, 1000, 200, [{ name: 'page_ready', deltaMs: 120 }]),
    ];
    const [pc] = aggregateStageTimings(rows);
    expect(pc.runs).toBe(2);
    expect(pc.avgTotalMs).toBe(500);       // (0 + 1000) / 2 — NaN row contributes 0 to sum
    expect(pc.avgHandoffMs).toBe(200);     // only the finite handoff counted
    expect(pc.stages.find((s) => s.name === 'warm_done')).toBeUndefined(); // NaN delta skipped
    expect(pc.stages.find((s) => s.name === 'page_ready')).toMatchObject({ avgMs: 100, samples: 2 });
  });

  test('empty input yields an empty array', () => {
    expect(aggregateStageTimings([])).toEqual([]);
  });
});
