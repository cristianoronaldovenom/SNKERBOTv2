// F5 Shape (BIG-IP ASM / Advanced WAF) — detection and remediation ladder.
//
// Like Kasada, Shape was previously only *classified*: stock-monitor returned
// 'f5-shape' for a TSPD cookie and then fell into the generic bot-block branch,
// which wiped cookies and retried. That is actively wrong for Shape — wiping a
// TSPD session is the one thing guaranteed to make it worse, because TSPD is
// exactly what Shape wants to accumulate across requests.
//
// Shape's tells:
//   * `TSPD_101*` cookies — the clearance token. KEEP these.
//   * `TS01*`/`TS*` cookies — the older ASM cookie pair. Also keep.
//   * a body with the `ct_257` / `_bm` / `TSPD` obfuscated sensor bootstrap.
//
// The remediation ladder is ordered by cost, and deliberately starts with "do
// nothing but keep the cookies", because the most common Shape failure mode in
// this codebase was self-inflicted:
//
//   keep   — TSPD present and the page classified: replay with it.
//   rearm  — TSPD present but stale/rejected: re-request to get a fresh one.
//   browser— no cookie could be earned: only the sensor JS can mint one.

import logger from './logger.js';
import { tlsRequest } from './tls-client.js';

const TSPD_RE = /(?:^|;\s*)TSPD_101(?:_[A-Za-z]+)?=([^;]+)/i;

// Shape challenges are issued as 403/501 with a small bootstrap document, or as
// a 200 carrying the sensor loader while the real content is withheld.
export const isShapeChallenge = ({ status = 0, body = '', headers = {} } = {}) => {
  const headerStr = Object.keys(headers || {}).join('\n').toLowerCase();
  const setCookie = String((headers || {})['set-cookie'] || '').toLowerCase();
  if (/tspd_101/.test(setCookie)) return true;
  if (/tspd|_bm/.test(headerStr)) return true;
  const head = String(body || '').slice(0, 5000);
  if (/TSPD_101/.test(head) || /ct_257/.test(head)) return true;
  if (status === 501 && /\bTS[a-f0-9]{8}\b/i.test(head)) return true;
  if (status !== 403 && status !== 501) return false;
  return /X-Application-Context|BIG-IP|f5|shape/i.test(headerStr) || /_bm\b/.test(head);
};

// Pull every clearance cookie Shape cares about out of a Set-Cookie blob.
// Returns 'name=value; name=value' for splicing into a Cookie header.
export const shapeCookies = (setCookie = '') => {
  const raw = Array.isArray(setCookie) ? setCookie.join('; ') : String(setCookie || '');
  // Split on BOTH separators: a real response uses commas between cookie pairs,
  // and a comma inside an Expires date would break a naive split, so attr lines
  // are filtered by only accepting the name=value head of each pair.
  const out = [];
  const pairs = raw.split(/,(?=\s*[A-Za-z_][\w.-]*=)|;|,(?=\s*[A-Za-z_][\w.-]*=)/);
  for (const pair of pairs) {
    const m = String(pair).trim().match(/^(TSPD_101(?:_[A-Za-z]+)?|TS[0-9a-f]{4,})=([^;,\s]+)/i);
    if (m) out.push(`${m[1]}=${m[2]}`);
  }
  return out.join('; ');
};

export const hasShapeCookie = (cookieHeader = '') => TSPD_RE.test(String(cookieHeader || ''));

// ── Remediation ladder ───────────────────────────────────────────────────────
//
// Returns { action, cookies?, reason, needBrowser }.
//   action 'keep'  — replay as-is; the clearance token is still good.
//   action 'rearm' — cookies were just issued, adopt them and retry.
//   action 'wait'  — no cookie yet but the page looks like a bare challenge;
//                    back off and let the next poll try with whatever we kept.
//   action 'browser' — earned nothing; only the sensor JS can mint a token.
const ACTION = Object.freeze({ KEEP: 'keep', REARM: 'rearm', WAIT: 'wait', BROWSER: 'browser' });

export const solveShape = async ({ pageUrl, proxy = null, ua = null, status = 0, body = '', headers = {}, cookieHeader = '' } = {}) => {
  const issued = shapeCookies((headers || {})['set-cookie']);
  // Cookies were handed to us on this very response: adopt them, they are fresh.
  if (issued) {
    logger.info(`[Shape] Adopted ${issued.split(';').length} clearance cookie(s) for ${pageUrl}`);
    return { action: ACTION.REARM, cookies: issued, reason: 'cookies_issued', needBrowser: false };
  }

  // We already hold a TSPD token. It is usually the problem, so the FIRST thing
  // to do is nothing — the old generic path wiped it and made things worse.
  if (hasShapeCookie(cookieHeader)) {
    return { action: ACTION.KEEP, reason: 'tspd_present', needBrowser: false };
  }

  if (!pageUrl) return { action: ACTION.WAIT, reason: 'no_url', needBrowser: false };

  // No token at all: one cheap re-request may earn one.
  try {
    const res = await tlsRequest({
      url: pageUrl,
      headers: {
        Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        ...(cookieHeader ? { Cookie: cookieHeader } : {}),
        ...(ua ? { 'User-Agent': ua } : {})
      },
      proxy: proxy ? `${proxy.host}:${proxy.port}` : null,
      timeoutMs: 12_000
    });
    if (res?.ok) {
      const fresh = shapeCookies((res.headers || {})['set-cookie']);
      if (fresh) {
        logger.info(`[Shape] Rearmed clearance cookies for ${pageUrl} via re-request`);
        return { action: ACTION.REARM, cookies: fresh, reason: 'rear_armed', needBrowser: false };
      }
      // A 200 with real content after a 403 means the token was not needed.
      if (res.status === 200) return { action: ACTION.KEEP, reason: 'recovered', needBrowser: false };
    }
  } catch (err) {
    logger.warn(`[Shape] Re-request failed for ${pageUrl}: ${err.message}`);
  }

  logger.info(`[Shape] No clearance cookie obtainable for ${pageUrl} (status ${status}) — browser solve required`);
  return { action: ACTION.BROWSER, reason: 'browser_required', needBrowser: true };
};

export const SHAPE_ACTIONS = ACTION;
