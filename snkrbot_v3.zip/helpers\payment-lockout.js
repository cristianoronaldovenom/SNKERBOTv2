// Payment lockout: park a task after N consecutive declines.
//
// Why a dedicated counter instead of reusing the stop-loss columns:
//   * stop-loss counts EVERY failed run (OOS, proxy death, preflight), so a
//     dead card and a flaky proxy are indistinguishable in consecutive_failures;
//   * stop-loss is cleared by any single success and by the max_failures config,
//     while a payment lock must survive an operator restarting the monitor;
//   * the lock has to be visible and clearable as its own thing on the dashboard.
//
// Everything below is pure (no DB handle) so the threshold/clear semantics can
// be pinned by a unit test. `recordPaymentDecline` takes the row as data and
// returns what to write, which keeps the SQL to one statement in the caller.
import logger from './logger.js';

// 5 declines. One decline is usually a soft issuer hiccup (wrong CVC after an
// address change, a 3DS bounce) and the adapter already retries/rotates cards;
// five in a row on the same task means the funding source is really broken.
export const PAYMENT_LOCKOUT_THRESHOLD = 5;

// Treat a task's payment as locked. `pay_failed` is bumped on every exhausted
// decline and reset by any successful order.
export const isPaymentLocked = (task) => Boolean(task?.pay_disabled_at);

export const paymentLockReason = (count, threshold = PAYMENT_LOCKOUT_THRESHOLD) =>
  `Payment locked after ${count}/${threshold} consecutive declines — fix the card, then re-enable from the dashboard`;

// Compute the next payment-lock state for a completed task row.
//
// `outcome` is one of:
//   'success'          — order placed: clear count + lock
//   'decline'          — a decline that survived every backup card: count it
//   'neutral'          — anything else (OOS, proxy, session): leave it alone
// Returns { pay_fail_count, pay_disabled_at, pay_disabled_reason, locked, newlyLocked }.
export const nextPaymentState = (task, outcome, now = new Date()) => {
  const current = Number(task?.pay_fail_count) || 0;
  const alreadyLocked = Boolean(task?.pay_disabled_at);

  if (outcome === 'success') {
    return {
      pay_fail_count: 0,
      pay_disabled_at: null,
      pay_disabled_reason: null,
      locked: false,
      newlyLocked: false
    };
  }

  if (outcome !== 'decline') {
    return {
      pay_fail_count: current,
      pay_disabled_at: task?.pay_disabled_at ?? null,
      pay_disabled_reason: task?.pay_disabled_reason ?? null,
      locked: alreadyLocked,
      newlyLocked: false
    };
  }

  const next = current + 1;
  const trips = !alreadyLocked && next >= PAYMENT_LOCKOUT_THRESHOLD;
  const reason = trips
    ? paymentLockReason(next)
    : alreadyLocked ? task?.pay_disabled_reason ?? null : null;

  return {
    pay_fail_count: next,
    // Keep the original lock timestamp if it was already set — re-declining a
    // locked task shouldn't look like a fresh trip.
    pay_disabled_at: alreadyLocked ? task.pay_disabled_at : (trips ? now : null),
    pay_disabled_reason: reason,
    locked: alreadyLocked || trips,
    newlyLocked: trips
  };
};

// Persist the outcome of one finished run. Never throws: a bookkeeping failure
// must not turn a placed order into a failed task.
export const recordPaymentOutcome = async (db, taskId, task, outcome, now = new Date()) => {
  const next = nextPaymentState(task, outcome, now);
  // 'neutral' with an unlocked task would be a no-op write; skip the round trip
  // only when nothing at all changes.
  const unchanged = outcome === 'neutral'
    && next.pay_fail_count === (Number(task?.pay_fail_count) || 0)
    && next.pay_disabled_at == null && !next.locked;
  if (unchanged) return next;

  try {
    await db('tasks').where({ id: taskId }).update({
      pay_fail_count: next.pay_fail_count,
      pay_disabled_at: next.pay_disabled_at,
      pay_disabled_reason: next.pay_disabled_reason
    });
    if (next.newlyLocked) {
      logger.warn(`[PaymentLock] Task ${taskId} locked — ${next.pay_disabled_reason}`);
    }
  } catch (err) {
    logger.warn(`[PaymentLock] Could not persist payment state for task ${taskId}: ${err.message}`);
  }
  return next;
};

// Operator action: clear the lock and give the card a fresh allowance.
export const clearPaymentLock = async (db, taskId) => {
  await db('tasks').where({ id: taskId }).update({
    pay_fail_count: 0,
    pay_disabled_at: null,
    pay_disabled_reason: null
  });
  logger.info(`[PaymentLock] Task ${taskId} re-enabled by operator`);
};
