import db from '../../db/index.js';
import { getResidentialProxy, isResidentialGatewayConfigured } from '../../helpers/task-proxies.js';
import { residentialBudgetStatus } from '../../helpers/residential-budget.js';

export const findAll = async (req, res, next) => {
  try {
    const proxies = await db('proxies').where({ is_deleted: false }).select('*');
    if (proxies.length === 0) {
      return res.json({ success: true, message: 'Proxies not found', data: proxies });
    }
    return res.json({ success: true, message: 'Proxies successfully found', data: proxies });
  } catch (err) {
    next(err);
  }
};

export const findMeta = async (req, res, next) => {
  try {
    const monitor = getResidentialProxy('monitor');
    const checkout = getResidentialProxy('checkout');
    return res.json({
      success: true,
      message: 'Proxy configuration found',
      data: {
        residentialGateway: {
          commonConfigured: isResidentialGatewayConfigured('checkout') || isResidentialGatewayConfigured('monitor'),
          monitorConfigured: Boolean(monitor),
          checkoutConfigured: Boolean(checkout),
        },
        residentialBudget: residentialBudgetStatus(),
      }
    });
  } catch (err) {
    next(err);
  }
};

export const findOne = async (req, res, next) => {
  try {
    const proxy = await db('proxies')
      .where({ id: req.params.id, is_deleted: false })
      .first('*');
    if (!proxy) {
      return res.json({ success: true, message: 'Proxy not found', data: undefined });
    }
    return res.json({ success: true, message: 'Proxy successfully found', data: proxy });
  } catch (err) {
    next(err);
  }
};

export const create = async (req, res, next) => {
  try {
    const [proxy] = await db('proxies').insert(req.body).returning('*');
    return res.json({ success: true, message: 'Proxy successfully created', data: proxy });
  } catch (err) {
    next(err);
  }
};

export const update = async (req, res, next) => {
  try {
    const [proxy] = await db('proxies')
      .where({ id: req.params.id })
      .update({ ...req.body, updated_at: new Date() })
      .returning('*');
    return res.json({ success: true, message: 'Proxy successfully updated', data: proxy });
  } catch (err) {
    next(err);
  }
};

export const remove = async (req, res, next) => {
  try {
    await db('proxies').where({ id: req.params.id }).update({ is_deleted: true });
    return res.json({ success: true, message: 'Proxy successfully deleted', data: {} });
  } catch (err) {
    next(err);
  }
};
