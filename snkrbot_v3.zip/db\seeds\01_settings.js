export const seed = async (knex) => {
  await knex('settings').del();
  await knex('settings').insert([
    { key: 'webhook_url', value: '' },
    { key: 'captcha_api_key', value: '' },
    { key: 'discord_webhook_url', value: '' },
    // Prewarm / pre-position speed engine (park a warmed browser before the drop).
    // Empty = OFF. Set to 'true' to enable. prewarm_max_parked caps concurrent
    // parked Chrome instances (each ~300-500MB); defaults to 3 when unset.
    { key: 'prewarm_enabled', value: '' },
    { key: 'prewarm_max_parked', value: '' },
    { key: 'max_armed_tasks', value: '1000' },
    { key: 'max_armed_tasks_per_host', value: '100' },
    { key: 'max_concurrent_runs', value: '24' },
    { key: 'max_concurrent_per_host', value: '100' }
  ]);
};
