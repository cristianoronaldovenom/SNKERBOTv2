import { tryRequestFirstAddToCart } from '../../helpers/browser-request-atc.js';
import { navigateCartUnlessReady } from '../../helpers/site-checkout-fastpath.js';
import logger from '../../helpers/logger.js';
import { captureOrderSuccess } from '../../helpers/order-capture.js';
import { solveCaptcha } from '../../helpers/captcha.js';
import { humanType, humanTypeInFrames, humanClick, humanSelect } from '../../helpers/human-type.js';
import {
  formatPostal, stripPhone, dismissAutocomplete, verifyFieldValue,
  requireCardIframe, verifyCartHasItem, FillReport, assertCriticalFields
} from '../../helpers/autofill-utils.js';
import {
  retryWithBackoff, hasCaptchaApiKey, guardedGoto, preOrderGuard,
  postClickGuard, takeFailureScreenshot
} from '../../helpers/checkout-guards.js';

const NIKE_BASE = 'https://www.nike.com';
import { waitForAnySelector } from '../../helpers/site-runtime.js';
import { assertActionButtonIntent } from '../../helpers/checkout-controls.js';

const TIMEOUT = 15000;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const findFirst = async (page, selectorList, timeout = TIMEOUT) => {
  const selector = await waitForAnySelector(page, selectorList, { timeout });
  if (!selector) return null;
  const el = await page.$(selector).catch(() => null);
  return el ? { el, selector } : null;
};

const clickFirst = async (page, selectorList, { stage = '' } = {}) => {
  const found = await findFirst(page, selectorList, TIMEOUT);
  if (!found) throw new Error(`Could not find clickable element at stage "${stage}" — tried [${selectorList.join(', ')}]`);
  await humanClick(page, found.selector);
  return found.selector;
};

const fillField = async (page, selectorList, value, { type = 'text', label = '', report = null } = {}) => {
  const name = label || 'unnamed';
  if (!value) { if (report) report.record(name, true, 'skipped (empty)'); return false; }
  const found = await findFirst(page, selectorList, 8000);
  if (!found) { if (report) report.record(name, false, 'selector not found'); return false; }
  const formatted = type === 'postal' ? formatPostal(value) : type === 'phone' ? stripPhone(value) : String(value);
  for (let attempt = 0; attempt < 2; attempt++) {
    await found.el.click({ clickCount: 3 }).catch(() => {});
    await page.keyboard.press('Backspace').catch(() => {});
    await humanType(page, found.selector, formatted);
    await dismissAutocomplete(page);
    await page.keyboard.press('Tab').catch(() => {});
    const v = await verifyFieldValue(page, found.selector, formatted, type);
    if (v.ok) { if (report) report.record(name, true); return true; }
    logger.warn(`[Nike] ${name} did not stick on attempt ${attempt + 1} (got "${v.actual}", expected "${v.expected}"), retrying`);
  }
  if (report) report.record(name, false, 'verify failed after retry');
  return false;
};

const SELECTORS = {
  sizeButtons: [
    'button[data-testid="size-btn"]', 'li[data-testid="size-btn"] button',
    'button.size-btn', '.mt2-sm .css-xf3ahq'
  ],
  addToCart: [
    '[data-testid="add-to-cart-btn"]', 'button.add-to-cart-btn',
    'button[aria-label="Add to Bag"]', 'button[aria-label="Add to Cart"]'
  ],
  qtySelect: [
    'select[name="quantity"]', 'input[name="quantity"]',
    'select[data-testid="quantity"]'
  ],
  cartCheckout: [
    '[data-testid="checkout-btn"]', 'button.checkout-btn',
    'a[href*="/checkout"]', 'button[data-automation="checkout-button"]'
  ],
  guestCheckout: [
    'button[data-testid="guest-checkout-btn"]', 'a[data-testid="guest-checkout"]',
    'button.guest-checkout'
  ],
  email: [
    'input[name="email"]', 'input#email', 'input[type="email"]',
    'input[data-testid="email-input"]'
  ],
  firstName: [
    'input[name="firstName"]', 'input[data-testid="firstName"]',
    'input[autocomplete="given-name"]'
  ],
  lastName: [
    'input[name="lastName"]', 'input[data-testid="lastName"]',
    'input[autocomplete="family-name"]'
  ],
  address1: [
    'input[name="address1"]', 'input[data-testid="address1"]',
    'input[autocomplete="address-line1"]'
  ],
  address2: [
    'input[name="address2"]', 'input[data-testid="address2"]'
  ],
  city: [
    'input[name="city"]', 'input[data-testid="city"]',
    'input[autocomplete="address-level2"]'
  ],
  state: [
    'select[name="state"]', 'select[data-testid="state"]',
    'select[autocomplete="address-level1"]'
  ],
  postalCode: [
    'input[name="postalCode"]', 'input[data-testid="postalCode"]',
    'input[autocomplete="postal-code"]'
  ],
  phone: [
    'input[name="phoneNumber"]', 'input[data-testid="phoneNumber"]',
    'input[type="tel"]'
  ],
  continueToPayment: [
    'button[data-testid="save-address-btn"]', 'button.save-button',
    'button[type="submit"]'
  ],
  cardName: [
    'input[name="creditCardName"]', 'input[data-testid="creditCardName"]',
    'input[autocomplete="cc-name"]', 'input[name="nameOnCard"]',
    'input[name="cardholderName"]', 'input[placeholder*="name on card" i]'
  ],
  cardNumber: [
    'input[name="creditCardNumber"]', 'input[data-testid="creditCardNumber"]',
    'input[autocomplete="cc-number"]', 'input#creditCardNumber'
  ],
  expMonth: [
    'select[name="expirationMonth"]', 'select[data-testid="expirationMonth"]'
  ],
  expYear: [
    'select[name="expirationYear"]', 'select[data-testid="expirationYear"]'
  ],
  cvv: [
    'input[name="cvNumber"]', 'input[data-testid="cvNumber"]',
    'input[autocomplete="cc-csc"]'
  ],
  placeOrder: [
    'button[data-testid="place-order-btn"]', 'button.place-order',
    'button[type="submit"][aria-label*="Place Order"]'
  ],
  orderConfirmation: [
    '[data-testid="order-confirmation"]', '.order-confirmation',
    '.thank-you-page', 'h1[data-testid="order-confirmation-title"]'
  ]
};

const runNike = async ({ page, task }) => {
  const startedAt = Date.now();
  logger.info(`[Nike] Starting checkout for task ${task.id}: ${task.url}`);
  page.setDefaultNavigationTimeout(30000);

  await guardedGoto(page, task.url, { taskId: task.id, stage: 'pdp_load' });
  await waitForAnySelector(page, SELECTORS.addToCart, { timeout: 10000 });

  if (task.size) {
    logger.info(`[Nike] Selecting size "${task.size}"`);
    const sizeSelected = await page.evaluate((targetSize, selectors) => {
      for (const sel of selectors) {
        const buttons = Array.from(document.querySelectorAll(sel));
        for (const btn of buttons) {
          const text = (btn.textContent || btn.getAttribute('aria-label') || '').trim();
          if (text.toUpperCase() === targetSize.toUpperCase() && !btn.disabled) {
            btn.click();
            return true;
          }
        }
      }
      return false;
    }, task.size, SELECTORS.sizeButtons).catch(() => false);
    if (sizeSelected) { await waitForAnySelector(page, SELECTORS.addToCart, { timeout: 2500 }); logger.info(`[Nike] Size "${task.size}" selected`); }
    else logger.warn(`[Nike] Size "${task.size}" not found — proceeding with default`);
  }

  if (task.quantity && task.quantity > 1) {
    const qtyFound = await findFirst(page, SELECTORS.qtySelect, 5000);
    if (qtyFound) {
      const tag = await qtyFound.el.evaluate((el) => el.tagName.toLowerCase());
      if (tag === 'select') await page.select(qtyFound.selector, String(task.quantity)).catch(() => {});
      else { await qtyFound.el.click({ clickCount: 3 }).catch(() => {}); await humanType(page, qtyFound.selector, String(task.quantity)); }
      logger.info(`[Nike] Quantity set to ${task.quantity}`);
    }
  }

  await retryWithBackoff(async () => {
if (!(await tryRequestFirstAddToCart(page, SELECTORS.addToCart))) await clickFirst(page, SELECTORS.addToCart, { stage: 'add_to_cart' });
  }, { attempts: 3, baseMs: 1500, label: 'Nike ATC' });
  logger.info('[Nike] Added to cart');

  await navigateCartUnlessReady({ page, cartUrl: `${NIKE_BASE}/cart`, navigate: guardedGoto, taskId: task.id, stage: 'cart_load' });
  await waitForAnySelector(page, SELECTORS.cartCheckout, { timeout: 8000 });
  const cartState = await verifyCartHasItem(page, { timeout: 8000 });
  if (cartState.empty) {
    throw new Error('Cart is empty after ATC — item not added (likely OOS / size unavailable / session lost)');
  }
  logger.info(`[Nike] Cart verified: ${cartState.count} item(s)`);
  await clickFirst(page, SELECTORS.cartCheckout, { stage: 'cart_to_checkout' });
  await page.waitForNavigation({ waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
  await postClickGuard(page, { taskId: task.id, stage: 'cart_to_checkout' });
  await waitForAnySelector(page, [...SELECTORS.guestCheckout, ...SELECTORS.email, ...SELECTORS.cardNumber], { timeout: 10000 });

  const guest = await findFirst(page, SELECTORS.guestCheckout, 4000);
  if (guest) { await humanClick(page, guest.selector); await waitForAnySelector(page, SELECTORS.email, { timeout: 8000 }); await postClickGuard(page, { taskId: task.id, stage: 'guest_checkout' }); }

  const ship = task.shippingAddress;
  if (!ship) throw new Error('Shipping address missing at stage "fill_shipping"');
  const shipReport = new FillReport(task.id, 'Nike Shipping');
  await fillField(page, SELECTORS.email, task.notification_email_address || ship.email, { label: 'email', report: shipReport });
  await fillField(page, SELECTORS.firstName, ship.first_name, { label: 'firstName', report: shipReport });
  await fillField(page, SELECTORS.lastName, ship.last_name, { label: 'lastName', report: shipReport });
  await fillField(page, SELECTORS.address1, ship.address1, { label: 'address1', report: shipReport });
  await fillField(page, SELECTORS.address2, ship.address2, { label: 'address2', report: shipReport });
  await fillField(page, SELECTORS.city, ship.city, { label: 'city', report: shipReport });
  await fillField(page, SELECTORS.postalCode, formatPostal(ship.zip), { label: 'postalCode', report: shipReport });
  await fillField(page, SELECTORS.phone, stripPhone(ship.phone), { label: 'phone', report: shipReport });
  const stateSel = await findFirst(page, SELECTORS.state, 3000);
  if (stateSel) await humanSelect(page, stateSel.selector, ship.state).catch(() => {});
  shipReport.log();
  assertCriticalFields(shipReport, ['email', 'firstName', 'lastName', 'address1', 'city', 'postalCode', 'phone']);

  const contPay = await findFirst(page, SELECTORS.continueToPayment, 5000);
  if (contPay) { await humanClick(page, contPay.selector); await waitForAnySelector(page, [...SELECTORS.cardNumber, ...SELECTORS.placeOrder], { timeout: 12000 }); await postClickGuard(page, { taskId: task.id, stage: 'continue_payment' }); }

  const pay = task.paymentProfile;
  if (!pay) throw new Error('Payment profile missing at stage "fill_payment"');

  await requireCardIframe(page, { timeout: 15000 });

  const payReport = new FillReport(task.id, 'Nike Payment');
  const nameOk = await humanTypeInFrames(page, SELECTORS.cardName.join(', '), pay.card_holder_name, { tabAfter: true });
  payReport.record('cardName', nameOk, nameOk ? '' : 'not found in main or iframes');
  const cardFilled = await humanTypeInFrames(page, SELECTORS.cardNumber.join(', '), pay.card_number.replace(/\s/g, ''), { tabAfter: true });
  payReport.record('cardNumber', cardFilled);
  const expMo = await findFirst(page, SELECTORS.expMonth, 3000);
  if (expMo) await humanSelect(page, expMo.selector, String(parseInt(pay.expiration_month, 10))).catch(() => {});
  const expYr = await findFirst(page, SELECTORS.expYear, 3000);
  if (expYr) await humanSelect(page, expYr.selector, String(pay.expiration_year)).catch(() => {});
  await humanTypeInFrames(page, SELECTORS.cvv.join(', '), pay.cvv, { tabAfter: true });
  payReport.log();
  assertCriticalFields(payReport, ['cardNumber', 'cvv']);

  if (task.auto_solve_captchas) {
    const hasKey = await hasCaptchaApiKey();
    if (hasKey) {
      try {
        const captchaInfo = await page.evaluate(() => {
          const el = document.querySelector('[data-sitekey], .g-recaptcha, .h-captcha');
          if (!el) return null;
          return { siteKey: el.dataset.sitekey || el.dataset.hcaptchaSitekey || null };
        }).catch(() => null);
        if (captchaInfo && captchaInfo.siteKey) {
          logger.info('[Nike] Captcha detected — solving');
          const token = await solveCaptcha({ siteKey: captchaInfo.siteKey, pageUrl: page.url(), page });
          await page.evaluate((tok) => {
            const ta = document.querySelector('textarea[name="g-recaptcha-response"], textarea[name="h-captcha-response"]');
            if (ta) ta.value = tok;
          }, token).catch(() => {});
        }
      } catch (err) {
        logger.warn(`[Nike] Captcha solve failed: ${err.message}`);
      }
    }
  }

  await preOrderGuard(page, { taskId: task.id });
  await assertActionButtonIntent(page, SELECTORS.placeOrder, { stage: 'place order', allow: /place order|submit order|complete order/i });
  await clickFirst(page, SELECTORS.placeOrder, { stage: 'place_order' });

  const confirmed = await Promise.race([
    findFirst(page, SELECTORS.orderConfirmation, 60000),
    page.waitForFunction(() => /thank.you|order.*confirm|confirmation/i.test(window.location.pathname + ' ' + document.title), { timeout: 60000 }).then(() => ({ url: true })).catch(() => null)
  ]);
  if (!confirmed) {
    await takeFailureScreenshot(page, task.id, 'confirm_order_fail');
    throw new Error('Order confirmation not detected at stage "confirm_order"');
  }
  const orderNumber = await page.evaluate(() => {
    const el = document.querySelector('[data-testid="order-number"], .order-number, [class*="orderNumber" i]');
    return el ? el.textContent.trim() : null;
  }).catch(() => null);

  logger.info(`[Nike] ✅ Order placed for task ${task.id}! Order: ${orderNumber || 'N/A'}`);
  await captureOrderSuccess({ page, taskId: task.id, orderNumber, productUrl: task.url, durationMs: Date.now() - startedAt }).catch(() => {});
};

export default runNike;
