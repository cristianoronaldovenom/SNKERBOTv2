import db from '../../db/index.js';
import { testProxy, testAllProxies } from '../../helpers/proxy-health.js';

export const checkOne = async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    const proxy = await db('proxies').where({ id, is_deleted: false }).first();
    if (!proxy) return res.status(404).json({ success: false, message: 'Proxy not found', data: {} });
    const r = await testProxy(proxy);
    return res.json({ success: true, message: r.summary, data: r });
  } catch (err) { next(err); }
};

export const checkAll = async (_req, res, next) => {
  try {
    const proxies = await db('proxies').where({ is_deleted: false });
    if (proxies.length === 0) return res.json({ success: true, message: 'No proxies to test', data: [] });
    const results = await testAllProxies(proxies);
    return res.json({ success: true, message: `Tested ${results.length} proxies`, data: results });
  } catch (err) { next(err); }
};
