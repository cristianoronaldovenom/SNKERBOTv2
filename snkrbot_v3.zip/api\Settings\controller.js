import db from '../../db/index.js';
import { sendTestNotification } from '../../helpers/notifier.js';

export const testNotification = async (req, res, next) => {
  try {
    const channel = req.params.channel;
    if (!['discord', 'http'].includes(channel)) {
      return res.status(400).json({ success: false, message: 'channel must be discord or http', data: {} });
    }
    await sendTestNotification(channel);
    return res.json({ success: true, message: `Test ${channel} notification sent`, data: {} });
  } catch (err) {
    return res.status(400).json({ success: false, message: err.message, data: {} });
  }
};

export const findAll = async (req, res, next) => {
  try {
    const settings = await db('settings').select('*');
    if (settings.length === 0) {
      return res.json({ success: true, message: 'Settings not found', data: settings });
    }
    return res.json({ success: true, message: 'Settings successfully found', data: settings });
  } catch (err) {
    next(err);
  }
};

export const findOne = async (req, res, next) => {
  try {
    const setting = await db('settings').where({ key: req.params.key }).first('*');
    if (!setting) {
      return res.json({ success: true, message: 'Setting not found', data: undefined });
    }
    return res.json({ success: true, message: 'Setting successfully found', data: setting });
  } catch (err) {
    next(err);
  }
};

export const upsert = async (req, res, next) => {
  try {
    const { value } = req.body;
    const existing = await db('settings').where({ key: req.params.key }).first();
    let setting;
    if (existing) {
      [setting] = await db('settings')
        .where({ key: req.params.key })
        .update({ value, updated_at: new Date() })
        .returning('*');
    } else {
      [setting] = await db('settings')
        .insert({ key: req.params.key, value })
        .returning('*');
    }
    return res.json({ success: true, message: 'Setting successfully saved', data: setting });
  } catch (err) {
    next(err);
  }
};
