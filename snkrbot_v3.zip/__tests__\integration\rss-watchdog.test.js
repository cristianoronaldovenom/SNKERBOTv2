// RSS watchdog policy tests.
//
// Regression this guards: memory admission only ever ran BEFORE a launch, so an
// already-running parked browser could leak freely until the OOM killer took the
// host. The invariants that matter are ordering (parked ceilings are tighter than
// active ones), early action on growth before the budget is hit, and never
// killing a browser whose RSS simply could not be read.
import { describe, expect, test } from '@jest/globals';
import {
  VERDICT, assessBrowser, rssBudgetMb, rssWatchdogConfig
} from '../../helpers/rss-watchdog.js';

const GB = 1024 * 1024 * 1024;
const MB = 1024 * 1024;

describe('budgets', () => {
  test('a parked browser gets a tighter ceiling than an active one', () => {
    const opts = { hostLimitBytes: 4 * GB };
    expect(rssBudgetMb({ ...opts, parked: true })).toBeLessThan(rssBudgetMb({ ...opts, parked: false }));
  });

  test('a bigger host buys a bigger budget', () => {
    expect(rssBudgetMb({ hostLimitBytes: 8 * GB })).toBeGreaterThan(rssBudgetMb({ hostLimitBytes: 2 * GB }));
  });

  test('an unknown host falls back to the floor instead of zero', () => {
    expect(rssBudgetMb({})).toBe(rssWatchdogConfig().activeFloorMb);
    expect(rssBudgetMb({ parked: true })).toBe(rssWatchdogConfig().parkedFloorMb);
  });

  test('the ceiling is capped so one stuck tab cannot claim the host', () => {
    expect(rssBudgetMb({ hostLimitBytes: 512 * GB })).toBeLessThanOrEqual(rssWatchdogConfig().absoluteMaxMb);
  });
});

describe('verdicts', () => {
  const host = { hostLimitBytes: 4 * GB };

  test('an unreadable RSS keeps the browser', () => {
    const out = assessBrowser({ rssBytes: 0, ...host });
    expect(out.verdict).toBe(VERDICT.KEEP);
    expect(out.reasons).toContain('no_measurement');
  });

  test('a small, steady browser is kept', () => {
    expect(assessBrowser({ rssBytes: 80 * MB, ...host }).verdict).toBe(VERDICT.KEEP);
  });

  test('a parked browser over budget is evicted, an active one is recycled', () => {
    const over = rssBudgetMb({ ...host, parked: true }) * MB + 1;
    expect(assessBrowser({ rssBytes: over, ...host, parked: true }).verdict).toBe(VERDICT.EVICT);
    const actOver = rssBudgetMb({ ...host }) * MB + 1;
    expect(assessBrowser({ rssBytes: actOver, ...host }).verdict).toBe(VERDICT.RECYCLE);
  });

  test('the absolute ceiling evicts regardless of host size', () => {
    const out = assessBrowser({ rssBytes: rssWatchdogConfig().absoluteMaxMb * MB, hostLimitBytes: 64 * GB });
    expect(out.verdict).toBe(VERDICT.EVICT);
    expect(out.reasons).toContain('absolute_max');
  });

  test('growth acts before the budget is reached', () => {
    const budget = rssBudgetMb({ hostLimitBytes: 4 * GB });
    const rss = (budget * 0.7) * MB;
    // A leak that would breach the remaining headroom inside the ~2 min window.
    const headroom = budget - budget * 0.7;
    const out = assessBrowser({ rssBytes: rss, hostLimitBytes: 4 * GB, growthMbPerMin: headroom });
    expect(out.verdict).toBe(VERDICT.RECYCLE);
    expect(out.reasons.some((r) => r.startsWith('growth_'))).toBe(true);
  });

  test('a slow creep that will not breach soon is only noted', () => {
    const budget = rssBudgetMb({ hostLimitBytes: 4 * GB });
    const rss = (budget * 0.7) * MB;
    // A tenth of the headroom per minute: hours away, so keep the browser.
    const out = assessBrowser({ rssBytes: rss, hostLimitBytes: 4 * GB, growthMbPerMin: (budget * 0.03) });
    expect(out.verdict).toBe(VERDICT.KEEP);
  });

  test('a decaying or flat browser is not recycled for growth', () => {
    const flat = assessBrowser({ rssBytes: 60 * MB, ...host, growthMbPerMin: 0 });
    expect(flat.verdict).toBe(VERDICT.KEEP);
    const shrinking = assessBrowser({ rssBytes: 60 * MB, ...host, growthMbPerMin: -5 });
    expect(shrinking.verdict).toBe(VERDICT.KEEP);
  });

  test('the near-budget soft zone recycles without evicting', () => {
    const rss = rssBudgetMb({ hostLimitBytes: 8 * GB }) * 0.9 * MB;
    const out = assessBrowser({ rssBytes: rss, hostLimitBytes: 8 * GB });
    expect(out.verdict).toBe(VERDICT.RECYCLE);
    expect(out.reasons).toContain('near_budget');
  });

  test('a very old parked browser is recycled as hygiene even when small', () => {
    const out = assessBrowser({ rssBytes: 50 * MB, ...host, parked: true, ageMs: 25 * 60_000 });
    expect(out.verdict).toBe(VERDICT.RECYCLE);
    expect(out.reasons).toContain('aged_out');
  });

  test('page count is reported for a parked browser but does not evict', () => {
    const out = assessBrowser({ rssBytes: 50 * MB, ...host, parked: true, pageCount: 5 });
    expect(out.reasons).toContain('too_many_pages');
    expect(out.verdict).toBe(VERDICT.KEEP);
  });
});
