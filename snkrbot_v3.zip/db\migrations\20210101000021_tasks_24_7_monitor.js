export const up = (knex) =>
  knex.schema.alterTable('tasks', (table) => {
    table.boolean('monitor_24_7').notNullable().defaultTo(false);
  });

export const down = (knex) =>
  knex.schema.alterTable('tasks', (table) => {
    table.dropColumn('monitor_24_7');
  });
