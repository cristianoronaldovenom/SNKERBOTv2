import assert from 'node:assert/strict';
import { currentCheckoutSurface, hasSurfaceUrl } from '../helpers/site-checkout-fastpath.js';

assert.equal(hasSurfaceUrl('https://example.com/cart'), true);
assert.equal(hasSurfaceUrl('https://example.com/checkout'), true);
assert.equal(hasSurfaceUrl('https://example.com/p/product'), false);

const page = { url: () => 'https://example.com/cart' };
assert.equal(await currentCheckoutSurface(page), 'cart');
assert.equal(await currentCheckoutSurface({ url: () => 'https://example.com/checkout' }), 'checkout');
assert.equal(await currentCheckoutSurface({ url: () => 'https://example.com/p/foo' }), null);

console.log('site-checkout-fastpath tests passed');
