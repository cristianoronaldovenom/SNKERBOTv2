// Burst confirmation policy.
//
// The poll optimizations trade freshness for bandwidth: a 304 or a coalesced
// response is served from cache, so a change landing mid-poll-cycle is invisible
// until the next tick. That is fine for a quiet monitor and expensive during a
// restock, which lasts seconds.
//
// So a detected change is not trusted on its own. If a task flipped recently it is
// re-polled immediately on a short base, bypassing the economy backoff, until the
// burst is confirmed or the window expires. After that it settles back to normal —
// this never permanently raises the poll rate.
//
// Pure and I/O-free so the window arithmetic is assertable.

const BURST_WINDOW_MS = Math.max(5_000, Number(process.env.POLL_BURST_WINDOW_MS || 90_000));
const BURST_BASE_MS = Math.max(250, Number(process.env.POLL_BURST_BASE_MS || 1_000));

// taskId → { until, confirmations }
const bursts = new Map();
const MAX_BURSTS = 2000;

const now = () => Date.now();

// A change was seen: open (or extend) a burst window for this task.
export const noteChange = (taskId) => {
  if (taskId == null) return;
  const existing = bursts.get(taskId);
  bursts.set(taskId, {
    until: now() + BURST_WINDOW_MS,
    confirmations: (existing?.confirmations || 0) + 1
  });
  if (bursts.size > MAX_BURSTS) {
    const cutoff = now();
    for (const [k, v] of bursts) if (v.until <= cutoff) bursts.delete(k);
    while (bursts.size > MAX_BURSTS) {
      const first = bursts.keys().next().value;
      if (first === undefined) break;
      bursts.delete(first);
    }
  }
};

export const inBurst = (taskId) => {
  const entry = bursts.get(taskId);
  if (!entry) return false;
  if (entry.until <= now()) {
    bursts.delete(taskId);
    return false;
  }
  return true;
};

export const burstConfirmations = (taskId) => bursts.get(taskId)?.confirmations || 0;

// Delay for the next poll while bursting, or null when not bursting.
//
// Only ever SHORTENS relative to the caller's own base: a burst is an observation
// that the world is moving, so polling faster is exactly the point. Alternating
// fast/slow ticks keeps the cadence from looking like a metronome.
export const burstDelay = (taskId, { baseMs = null } = {}) => {
  if (!inBurst(taskId)) return null;
  const n = burstConfirmations(taskId);
  const jitter = Math.floor(Math.random() * 250);
  const delay = BURST_BASE_MS + jitter + (n % 2 === 0 ? 0 : 400);
  return baseMs ? Math.min(baseMs, delay) : delay;
};

export const clearBurst = (taskId) => bursts.delete(taskId);
export const __resetBursts = () => bursts.clear();
export const burstConfig = () => ({ windowMs: BURST_WINDOW_MS, baseMs: BURST_BASE_MS });
