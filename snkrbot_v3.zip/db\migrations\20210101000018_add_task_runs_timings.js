export const up = (knex) =>
  knex.schema.alterTable('task_runs', (t) => {
    t.jsonb('timings').nullable(); // per-stage speed telemetry (StageTimer summary)
  });

export const down = (knex) =>
  knex.schema.alterTable('task_runs', (t) => {
    t.dropColumn('timings');
  });
