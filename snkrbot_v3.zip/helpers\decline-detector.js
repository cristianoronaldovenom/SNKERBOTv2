import logger from './logger.js';
import db from '../db/index.js';

const DECLINE_PATTERNS = [
  /payment.*(?:declined|denied|refused|rejected|failed)/i,
  /card.*(?:declined|denied|refused|rejected|failed|invalid)/i,
  /transaction.*(?:declined|denied|could not be processed|failed)/i,
  /unable to (?:process|authorize|complete).*(?:payment|order|transaction)/i,
  /insufficient funds/i,
  /do not honor/i,
  /expired card/i,
  /invalid card/i,
  /card number.*(?:invalid|incorrect|wrong)/i,
  /cvv.*(?:invalid|incorrect|wrong|mismatch)/i,
  /security code.*(?:invalid|incorrect|wrong)/i,
  /billing address.*(?:does not match|mismatch|invalid)/i,
  /payment method.*(?:could not|unable|failed)/i,
  /authorization.*(?:failed|declined|error)/i,
  /please.*(?:try another|use a different|enter a valid).*(?:card|payment|method)/i,
  /your (?:bank|financial institution).*(?:declined|blocked)/i,
  /fraud.*(?:detected|suspected|prevention)/i,
  /risk.*(?:check|assessment).*failed/i,
  /avs.*(?:mismatch|failed|declined)/i,
  /cvv2.*(?:mismatch|failed|declined)/i,
  /3d secure.*(?:failed|declined|cancelled)/i,
  /payment.*(?:processor|gateway).*error/i
];

const OOS_PATTERNS = [
  /(?:item|product).*(?:out of stock|sold out|unavailable|no longer available)/i,
  /(?:sorry|unfortunately).*(?:out of stock|sold out|not available)/i,
  /(?:removed from|no longer in).*cart/i,
  /quantity.*(?:not available|exceeds|unavailable)/i,
  /(?:this item|this product).*(?:cannot be|can't be).*(?:shipped|purchased)/i,
  // Body text is concatenated with `alerts`, and the body always renders cart
  // chrome (e.g. `id="cart"`, `class="cart-error"`). The old `cart.*(?:is empty|…)`
  // therefore matched "cart…" on an unrelated `cart-error` container and reported
  // OOS on pages that were fine. Anchor the empty-cart cases instead.
  /(?:your|the) cart (?:is|appears to be) empty/i,
  /(?:cart|bag) (?:has been|was) (?:cleared|emptied)/i,
  /(?:there are|there's) no items in your (?:cart|bag)/i,
  /(?:inventory|stock).*(?:exhausted|depleted|zero)/i,
  /(?:size|variant).*(?:not available|unavailable|sold out)/i
];

const SESSION_PATTERNS = [
  /session.*(?:expired|timed out|invalid|ended)/i,
  /(?:please|kindly).*(?:sign in|log in|refresh).*(?:again|to continue)/i,
  /your.*(?:cart|session|order).*(?:has expired|timed out)/i,
  /checkout.*(?:expired|timed out|cancelled)/i,
  /(?:reservation|hold).*(?:on your|for your).*(?:item|cart).*expired/i
];

const ADDRESS_REJECT_PATTERNS = [
  /address.*(?:invalid|not recognized|cannot be verified|undeliverable)/i,
  /(?:please|we could not).*(?:verify|validate).*address/i,
  /(?:shipping|delivery).*(?:not available|unavailable).*(?:area|region|address)/i,
  /(?:enter|provide).*valid.*address/i,
  /po box.*not (?:accepted|allowed|supported)/i
];

export const detectDecline = async (page) => {
  try {
    const text = await page.evaluate(() => {
      const body = document.body?.innerText || '';
      const alerts = Array.from(document.querySelectorAll(
        '.error, .alert, .alert-danger, .alert-error, .notification-error, ' +
        '[role="alert"], .form-error, .field-error, .payment-error, ' +
        '.checkout-error, .order-error, .cart-error, .message-error, ' +
        '.flash-error, .notice-error, [data-error], .decline-message'
      )).map((el) => el.textContent).join(' ');
      return (body + ' ' + alerts).slice(0, 5000);
    }).catch(() => '');

    for (const pattern of DECLINE_PATTERNS) {
      if (pattern.test(text)) {
        const match = text.match(pattern)?.[0] || '';
        logger.warn(`[DeclineDetector] Payment decline detected: "${match}"`);
        return { type: 'decline', message: match, text };
      }
    }

    for (const pattern of OOS_PATTERNS) {
      if (pattern.test(text)) {
        const match = text.match(pattern)?.[0] || '';
        logger.warn(`[DeclineDetector] OOS during checkout: "${match}"`);
        return { type: 'oos', message: match, text };
      }
    }
    for (const pattern of ADDRESS_REJECT_PATTERNS) {
      if (pattern.test(text)) {
        const match = text.match(pattern)?.[0] || '';
        logger.warn(`[DeclineDetector] Address rejected: "${match}"`);
        return { type: 'address_reject', message: match, text };
      }
    }

    for (const pattern of SESSION_PATTERNS) {
      if (pattern.test(text)) {
        const match = text.match(pattern)?.[0] || '';
        logger.warn(`[DeclineDetector] Session/cart expired: "${match}"`);
        return { type: 'session_expired', message: match, text };
      }
    }

    return null;
  } catch (err) {
    logger.warn(`[DeclineDetector] Detection failed: ${err.message}`);
    return null;
  }
};

export const getAlternatePaymentProfiles = async (currentProfileId, taskId) => {
  try {
    const task = await db('tasks').where({ id: taskId }).first();
    const profiles = await db('payment_profiles')
      .where({ is_deleted: false })
      .whereNot({ id: currentProfileId })
      .orderByRaw('RANDOM()')
      .limit(3);

    return profiles;
  } catch (err) {
    logger.warn(`[DeclineDetector] Could not fetch alternate profiles: ${err.message}`);
    return [];
  }
};

export const isOosFailure = (errorMessage) => {
  if (!errorMessage) return false;
  const msg = errorMessage.toLowerCase();
  return (
    OOS_PATTERNS.some((p) => p.test(msg)) ||
    /out.of.stock|sold.out|oos|item.*unavailable|cart.*empty/i.test(msg)
  );
};

export const isDeclineFailure = (errorMessage) => {
  if (!errorMessage) return false;
  return DECLINE_PATTERNS.some((p) => p.test(errorMessage));
};

export const isSessionFailure = (errorMessage) => {
  if (!errorMessage) return false;
  return SESSION_PATTERNS.some((p) => p.test(errorMessage));
};
