import logger from './logger.js';

const pool = new Map();
const COOKIE_TTL_MS = 4 * 60 * 1000;

const hostKey = (url) => {
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch (_) {
    return null;
  }
};

// A cookie may come from a source that omits `domain`/`path` — notably the
// solver/runtime APIs, whose cookie objects often carry only name+value. Modern
// CDP `Network.setCookies` REJECTS a cookie with an empty domain and throws for
// the WHOLE set, so one anonymous cookie used to discard an entire warm jar.
// Fill both fields in from the page URL and drop anything unusable (no name, or
// no value that survived trimming).
export const normalizeCookiesForPage = (url, cookies) => {
  if (!Array.isArray(cookies) || cookies.length === 0) return [];
  let parsed;
  try { parsed = new URL(url); } catch (_) { return []; }
  const domain = parsed.hostname;
  const path = parsed.pathname && parsed.pathname !== '/' ? parsed.pathname : '/';
  const out = [];
  for (const c of cookies) {
    if (!c || typeof c.name !== 'string' || c.name === '') continue;
    const value = c.value == null ? '' : String(c.value);
    const cookie = { name: c.name, value, domain: c.domain || domain, path: c.path || path };
    // `expires` must be a finite epoch-seconds number or be omitted entirely;
    // a NaN/ISO-string would otherwise throw on injection.
    const expires = Number(c.expires);
    if (Number.isFinite(expires) && expires > 0) cookie.expires = expires;
    if (c.httpOnly) cookie.httpOnly = true;
    if (c.secure) cookie.secure = true;
    if (c.sameSite) cookie.sameSite = c.sameSite;
    out.push(cookie);
  }
  return out;
};

export const storeCookies = (url, cookies) => {
  const key = hostKey(url);
  if (!key || !cookies || cookies.length === 0) return;

  pool.set(key, {
    cookies,
    storedAt: Date.now(),
    count: cookies.length
  });
  logger.info(`[CookiePool] Stored ${cookies.length} cookies for ${key}`);
};

export const getCookies = (url) => {
  const key = hostKey(url);
  if (!key) return null;

  const entry = pool.get(key);
  if (!entry) return null;

  if (Date.now() - entry.storedAt > COOKIE_TTL_MS) {
    pool.delete(key);
    logger.info(`[CookiePool] Cookies expired for ${key} (${COOKIE_TTL_MS / 1000}s TTL)`);
    return null;
  }

  logger.info(`[CookiePool] Reusing ${entry.count} warm cookies for ${key} (age: ${Math.round((Date.now() - entry.storedAt) / 1000)}s)`);
  return entry.cookies;
};

export const hasFreshCookies = (url) => {
  return getCookies(url) !== null;
};

export const injectCookies = async (page, url) => {
  const cookies = getCookies(url);
  if (!cookies || cookies.length === 0) return false;

  const normalized = normalizeCookiesForPage(url, cookies);
  if (normalized.length === 0) return false;

  try {
    await page.setCookie(...normalized);
    logger.info(`[CookiePool] Injected ${normalized.length} warm cookies into page`);
    return true;
  } catch (err) {
    logger.warn(`[CookiePool] Failed to inject cookies: ${err.message}`);
    return false;
  }
};

export const harvestCookies = async (page, url) => {
  try {
    const cookies = await page.cookies();
    if (cookies.length > 0) {
      storeCookies(url, cookies);
    }
    return cookies;
  } catch (err) {
    logger.warn(`[CookiePool] Failed to harvest cookies: ${err.message}`);
    return [];
  }
};

export const poolStatus = () => {
  const entries = {};
  for (const [key, entry] of pool.entries()) {
    entries[key] = {
      count: entry.count,
      ageSeconds: Math.round((Date.now() - entry.storedAt) / 1000),
      expired: Date.now() - entry.storedAt > COOKIE_TTL_MS
    };
  }
  return entries;
};
