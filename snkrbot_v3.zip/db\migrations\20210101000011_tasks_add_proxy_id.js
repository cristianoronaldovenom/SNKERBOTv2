export const up = (knex) =>
  knex.schema.table('tasks', (t) => {
    t.integer('proxy_id').nullable().references('id').inTable('proxies').onDelete('SET NULL');
  });

export const down = (knex) =>
  knex.schema.table('tasks', (t) => {
    t.dropColumn('proxy_id');
  });
