#!/usr/bin/env bash
# Harness for deploy-lightsail.sh's decision logic. Sources only the functions
# and stubs the side-effecting commands, so the docker/swap/mode branches can be
# exercised on a machine without root, apt, or Docker.
set -uo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/deploy-lightsail.sh"
FAIL=0
pass() { printf '  ok  %s\n' "$1"; }
fail() { printf '  FAIL %s\n' "$1"; FAIL=1; }

# Extract the shell functions we want to test without running the script body.
# Pure bash on purpose: brace-counts instead of matching a closing-`}` line, so
# a heredoc payload containing braces at column 0 (the daemon.json body) cannot
# truncate the function. awk is also missing on some Windows/git-bash hosts.
#
# The braces are counted with an explicit char loop because
# ${line//[^}]/} is genuinely ambiguous about an empty replacement in bash.
count_char() {
  local s="$1" ch="$2" i n=0
  for (( i = 0; i < ${#s}; i++ )); do
    [[ "${s:i:1}" == "$ch" ]] && n=$(( n + 1 ))
  done
  printf '%s' "$n"
}

extract() {
  local fn="$1" line depth=0 started=1
  while IFS= read -r line; do
    if (( started )); then
      [[ "$line" == "${fn}() {"* ]] || continue
      started=0
    fi
    printf '%s\n' "$line"
    depth=$(( depth + $(count_char "$line" '{') - $(count_char "$line" '}') ))
    (( depth <= 0 )) && return 0
  done < "$SRC"
  return 0
}

# --- ensure_swap: only small hosts with little swap get a swapfile -----------
# /proc/meminfo is replaced by a temp file so the real threshold logic runs.
run_swap() {
  local mem_kb="$1" swap_kb="$2" out
  out="$(mktemp)"
  cat > "$out" <<EOF
set -uo pipefail
MEMINFO=\$(mktemp)
printf 'MemTotal: %s kB\nSwapTotal: %s kB\n' '$mem_kb' '$swap_kb' > "\$MEMINFO"
ACTIONS=\$(mktemp)
log() { printf '%s\n' "\$*" >> "\$ACTIONS"; }
fallocate() { echo "fallocate" >> "\$ACTIONS"; return 0; }
chmod() { :; }
mkswap() { echo "mkswap" >> "\$ACTIONS"; }
swapon() { echo "swapon" >> "\$ACTIONS"; }
sysctl() { echo "sysctl" >> "\$ACTIONS"; }
grep() { return 1; }
$(extract ensure_swap | sed 's#/proc/meminfo#"$MEMINFO"#g')
ensure_swap
cat "\$ACTIONS"
EOF
  bash "$out" 2>/dev/null
  rm -f "$out"
}

if run_swap 800000 0 | grep -q swapon; then
  pass 'adds swap on an 800MB host with no swap'
else
  fail 'adds swap on an 800MB host with no swap'
fi

if run_swap 8000000 0 | grep -q swapon; then
  fail 'skips swap on an 8GB host'
else
  pass 'skips swap on an 8GB host'
fi

if run_swap 1700000 2000000 | grep -q swapon; then
  fail 'skips swap when 2GB of swap already exists'
else
  pass 'skips swap when 2GB of swap already exists'
fi

if run_swap 1700000 0 | grep -q mkswap; then
  pass 'formats the swapfile on a 1.7GB host with no swap'
else
  fail 'formats the swapfile on a 1.7GB host with no swap'
fi

# --- DEPLOY_MODE validation --------------------------------------------------
for mode in docker systemd auto; do
  if DEPLOY_MODE="$mode" bash -c 'case "$DEPLOY_MODE" in docker|systemd|auto) exit 0;; *) exit 1;; esac'; then
    pass "accepts DEPLOY_MODE=$mode"
  else
    fail "accepts DEPLOY_MODE=$mode"
  fi
done
if DEPLOY_MODE=bogus bash -c 'case "$DEPLOY_MODE" in docker|systemd|auto) exit 0;; *) exit 1;; esac'; then
  fail 'rejects an unknown DEPLOY_MODE'
else
  pass 'rejects an unknown DEPLOY_MODE'
fi

# --- docker_usable reflects `docker info` ------------------------------------
eval "$(extract docker_usable)"
docker() { case "$1" in info) return "${STUB_INFO:-0}";; esac; return 0; }
STUB_INFO=0
if docker_usable; then pass 'docker_usable true when the daemon answers'; else fail 'docker_usable true when the daemon answers'; fi
STUB_INFO=1
if docker_usable; then fail 'docker_usable false when the daemon is down'; else pass 'docker_usable false when the daemon is down'; fi

# --- install_docker fails closed so the caller can fall back ----------------
eval "$(extract install_docker)"
command() { case "$1" in -v) return 0;; esac; builtin command "$@"; }
docker() {
  case "$1" in
    info) return 1 ;;
    compose) return 0 ;;
  esac
  return 0
}
apt-get() { return 1; }            # simulate an unreachable Docker repo
curl() { printf 'gpg\n'; return 0; }
gpg() { return 0; }
chmod() { return 0; }
install() { return 0; }
dpkg() { echo amd64; }
systemctl() { return 0; }
DOCKER_READY=0
if install_docker >/dev/null 2>&1; then
  fail 'install_docker returns non-zero when apt fails'
else
  pass 'install_docker fails closed when the install fails'
fi
if [[ "$DOCKER_READY" == '0' ]]; then
  pass 'DOCKER_READY stays 0 on failure (so the caller falls back)'
else
  fail 'DOCKER_READY stays 0 on failure (so the caller falls back)'
fi

if [[ "$FAIL" == '0' ]]; then
  echo 'PASS: deploy-lightsail docker/swap/mode logic'
else
  echo 'FAIL: deploy-lightsail logic'
  exit 1
fi
