import { Router } from 'express';
import * as controller from './controller.js';

const router = Router();

router.get('/pending', controller.listPending);
router.post('/solve/:id', controller.submitSolution);
router.get('/stats', controller.stats);

export default router;
