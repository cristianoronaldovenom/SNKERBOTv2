import { jest } from '@jest/globals';

jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));

jest.unstable_mockModule('../../helpers/stock-monitor.js', () => ({
  detectVendor: (html, headers = {}) => {
    const cookies = String(headers['set-cookie'] || '');
    const h = String(html || '').slice(0, 8000);
    if (/visid_incap|reese84/i.test(cookies + h) || /pardon our interruption/i.test(h)) return 'imperva';
    if (/cf-ray|__cf_bm|cf_clearance/i.test(cookies) || /cloudflare|just a moment/i.test(h)) return 'cloudflare';
    if (/_px3|px-captcha|perimeterx/i.test(cookies + h)) return 'perimeterx';
    if (/datadome|captcha-delivery/i.test(cookies + h)) return 'datadome';
    if (/_abck|ak_bmsc/i.test(cookies)) return 'akamai';
    if (/kasada|kpsdk/i.test(cookies + h)) return 'kasada';
    return 'unknown';
  }
}));

const {
  detectBotBlockOnPage,
  detectQueuePage,
  detectThreeDSecure,
  extractTurnstileInfo,
  injectTurnstileToken,
  __testing__
} = await import('../../helpers/checkout-guards.js');

// Test harness: mimics Puppeteer's page.evaluate by installing window/document
// as real globals during fn execution, then restoring originals.
const runInPageContext = (fakeWin, fakeDoc) => async (fn, ...args) => {
  const origWin = globalThis.window;
  const origDoc = globalThis.document;
  const origEvent = globalThis.Event;
  globalThis.window = fakeWin;
  globalThis.document = fakeDoc;
  globalThis.Event = function (type) { this.type = type; };
  try {
    return await fn(...args);
  } finally {
    globalThis.window = origWin;
    globalThis.document = origDoc;
    globalThis.Event = origEvent;
  }
};

const fakePage = ({ html = '', cookies = [], url = 'https://example.com/', win = {}, doc = null } = {}) => {
  const fakeWin = { location: { href: url }, __turnstileCapture: null, ...win };
  const fakeDoc = doc || {
    title: '',
    documentElement: { outerHTML: html },
    body: { innerText: html.replace(/<[^>]+>/g, '').slice(0, 2000), innerHTML: html },
    querySelector: () => null,
    querySelectorAll: () => []
  };
  return {
    content: async () => html,
    cookies: async () => cookies,
    url: () => url,
    evaluate: runInPageContext(fakeWin, fakeDoc)
  };
};

describe('checkout-guards: detectBotBlockOnPage', () => {
  test('detects Cloudflare "just a moment" challenge', async () => {
    const page = fakePage({ html: '<html><title>Just a moment...</title><body>Checking your browser before accessing</body></html>' });
    const r = await detectBotBlockOnPage(page);
    expect(r.blocked).toBe(true);
    expect(r.vendor).toBe('cloudflare');
  });

  test('detects Imperva "Pardon Our Interruption"', async () => {
    const page = fakePage({ html: '<html><body>Pardon Our Interruption — your request has triggered a security check</body></html>' });
    const r = await detectBotBlockOnPage(page);
    expect(r.blocked).toBe(true);
    expect(r.vendor).toBe('imperva');
  });

  test('detects PerimeterX press-and-hold challenge', async () => {
    const page = fakePage({ html: '<html><body>Please press &amp; hold to verify you are a human. Powered by perimeterx.net</body></html>' });
    const r = await detectBotBlockOnPage(page);
    expect(r.blocked).toBe(true);
    expect(r.vendor).toBe('perimeterx');
  });

  test('detects DataDome captcha-delivery iframe', async () => {
    const page = fakePage({ html: '<html><body>Please verify you are a human <iframe src="https://geo.captcha-delivery.com/captcha/"></iframe></body></html>' });
    const r = await detectBotBlockOnPage(page);
    expect(r.blocked).toBe(true);
    expect(r.vendor).toBe('datadome');
  });

  test('detects Kasada / kpsdk block', async () => {
    const page = fakePage({ html: '<html><body>Request blocked. kpsdk-cd: 12345</body></html>' });
    const r = await detectBotBlockOnPage(page);
    expect(r.blocked).toBe(true);
    expect(r.vendor).toBe('kasada');
  });

  test('detects FingerprintJS Pro signature', async () => {
    const page = fakePage({ html: '<html><body>Access denied. <script src="https://fpjs.io/v3"></script></body></html>' });
    const r = await detectBotBlockOnPage(page);
    expect(r.blocked).toBe(true);
  });

  test('detects Kasada from cookie evidence + denial wording', async () => {
    // Real Kasada blocks carry kpsdk-cd/-ct in cookies, not necessarily HTML.
    const page = fakePage({
      html: '<html><body>Access Denied</body></html>',
      cookies: [{ name: 'kpsdk-cd', value: 'AAABBBCCCDDD' }]
    });
    const r = await detectBotBlockOnPage(page);
    expect(r.blocked).toBe(true);
    expect(r.vendor).toBe('kasada');
  });

  test('does NOT flag a normal checkout page that merely runs FingerprintJS', async () => {
    // FingerprintJS/Kasada run on normal pages for fraud-scoring; a vendor signal
    // without denial wording must NOT trigger a (costly) block recovery.
    const page = fakePage({
      html: '<html><body><h1>Checkout</h1><p>Your card was declined. Please try another payment method.</p><script src="https://fpjs.io/v3"></script></body></html>'
    });
    const r = await detectBotBlockOnPage(page);
    expect(r.blocked).toBe(false);
  });

  test('passes through clean page', async () => {
    const page = fakePage({ html: '<html><body><h1>Welcome to our store</h1><div class="product">Sneaker $199</div></body></html>' });
    const r = await detectBotBlockOnPage(page);
    expect(r.blocked).toBe(false);
  });

  test('exports BLOCK_SIGNALS array with comprehensive coverage', () => {
    expect(__testing__.BLOCK_SIGNALS.length).toBeGreaterThanOrEqual(20);
    // Vendor coverage spans both the hard BLOCK_SIGNALS and the context-gated
    // SOFT_VENDOR_SIGNALS tier (Kasada / FingerprintJS live in the soft tier).
    const sources = [...__testing__.BLOCK_SIGNALS, ...__testing__.SOFT_VENDOR_SIGNALS].map((r) => r.source);
    expect(sources.some((s) => /just a moment/i.test(s))).toBe(true);
    expect(sources.some((s) => /perimeterx|px-captcha/i.test(s))).toBe(true);
    expect(sources.some((s) => /captcha-delivery/i.test(s))).toBe(true);
    expect(sources.some((s) => /kpsdk|kasada/i.test(s))).toBe(true);
    expect(sources.some((s) => /fpjs|fingerprintjs/i.test(s))).toBe(true);
  });
});

describe('checkout-guards: detectQueuePage', () => {
  test('detects Queue-it URL', async () => {
    const page = fakePage({
      url: 'https://nikequeue.queue-it.net/?c=nike',
      doc: { documentElement: { outerHTML: '' }, title: '', body: { innerText: '' } }
    });
    const r = await detectQueuePage(page);
    expect(r.queued).toBe(true);
    expect(r.type).toBe('queue-it');
  });

  test('detects Cloudflare Waiting Room', async () => {
    const page = fakePage({
      url: 'https://shop.example.com/',
      doc: {
        documentElement: { outerHTML: '<div class="cf-waiting-room">__cfwaitingroom</div>' },
        title: 'Waiting',
        body: { innerText: '' }
      }
    });
    const r = await detectQueuePage(page);
    expect(r.queued).toBe(true);
    expect(r.type).toBe('cloudflare-waiting-room');
  });

  test('detects generic queue text', async () => {
    const page = fakePage({
      url: 'https://shop.example.com/',
      doc: {
        documentElement: { outerHTML: '' },
        title: 'Waiting',
        body: { innerText: "You're in line. Your queue position is 1247. Please wait." }
      }
    });
    const r = await detectQueuePage(page);
    expect(r.queued).toBe(true);
    expect(r.type).toBe('generic-queue');
  });

  test('passes through clean page', async () => {
    const page = fakePage({ html: '<html><body>Product detail page</body></html>' });
    const r = await detectQueuePage(page);
    expect(r.queued).toBe(false);
  });
});

describe('checkout-guards: detectThreeDSecure', () => {
  test('detects 3DS by ACS iframe URL', async () => {
    const page = fakePage({
      doc: {
        querySelectorAll: (sel) => sel === 'iframe' ? [{ src: 'https://acs.cardinalcommerce.com/V2/Start' }] : [],
        body: { innerText: '' }
      }
    });
    const r = await detectThreeDSecure(page);
    expect(r).toBeTruthy();
    expect(r.url).toContain('cardinalcommerce');
  });

  test('detects 3DS by inline text', async () => {
    const page = fakePage({
      doc: {
        querySelectorAll: () => [],
        body: { innerText: 'Please complete Verified by Visa to continue' }
      }
    });
    const r = await detectThreeDSecure(page);
    expect(r).toBeTruthy();
    expect(r.url).toBe('inline');
  });

  test('returns null on clean checkout', async () => {
    const page = fakePage({
      doc: {
        querySelectorAll: () => [],
        body: { innerText: 'Order summary: $199' }
      }
    });
    const r = await detectThreeDSecure(page);
    expect(r).toBe(null);
  });
});

describe('checkout-guards: extractTurnstileInfo', () => {
  test('extracts sitekey from data-attr widget', async () => {
    const widget = { getAttribute: (a) => a === 'data-sitekey' ? '0x4AAA1234567890ABCDEF' : null };
    const page = fakePage({
      doc: {
        querySelector: (sel) => /cf-turnstile.*data-sitekey|data-sitekey.*cf-turnstile|data-sitekey.*turnstile/i.test(sel) ? widget : null,
        querySelectorAll: () => []
      }
    });
    const info = await extractTurnstileInfo(page);
    expect(info).toBeTruthy();
    expect(info.siteKey).toBe('0x4AAA1234567890ABCDEF');
    expect(info.source).toBe('data-attr');
  });

  test('extracts sitekey from render-hook capture', async () => {
    const captured = { sitekey: '0xRENDER_HOOK_KEY', callback: () => {}, action: 'login' };
    const page = fakePage({
      win: { __turnstileCapture: captured },
      doc: { querySelector: () => null, querySelectorAll: () => [] }
    });
    const info = await extractTurnstileInfo(page);
    expect(info.siteKey).toBe('0xRENDER_HOOK_KEY');
    expect(info.source).toBe('render-hook');
    expect(info.action).toBe('login');
  });

  test('extracts sitekey from iframe URL', async () => {
    const page = fakePage({
      doc: {
        querySelector: () => null,
        querySelectorAll: (sel) => sel.includes('iframe') ? [{ src: 'https://challenges.cloudflare.com/cdn-cgi/challenge-platform/turnstile/if/?k=0x4AAA_IFRAME_KEY&type=managed' }] : []
      }
    });
    const info = await extractTurnstileInfo(page);
    expect(info.siteKey).toBe('0x4AAA_IFRAME_KEY');
    expect(info.source).toBe('iframe-url');
  });

  test('extracts sitekey from inline script', async () => {
    const page = fakePage({
      doc: {
        querySelector: () => null,
        querySelectorAll: (sel) => sel.includes('script') ? [{ textContent: 'turnstile.render("#cap", { sitekey: "0xINLINE_SCRIPT_KEY", callback: cb });' }] : []
      }
    });
    const info = await extractTurnstileInfo(page);
    expect(info.siteKey).toBe('0xINLINE_SCRIPT_KEY');
    expect(info.source).toBe('inline-script');
  });

  test('returns null when no Turnstile present', async () => {
    const page = fakePage({
      doc: { querySelector: () => null, querySelectorAll: () => [] }
    });
    const info = await extractTurnstileInfo(page);
    expect(info).toBe(null);
  });
});

describe('checkout-guards: injectTurnstileToken', () => {
  test('fills hidden input + dispatches events + calls captured callback', async () => {
    const calls = { inputsSet: 0, eventsDispatched: 0, callbackCalled: false };
    const inputs = [
      {
        _v: '',
        get value() { return this._v; },
        set value(v) { this._v = v; calls.inputsSet++; },
        dispatchEvent: () => { calls.eventsDispatched++; }
      }
    ];
    const captured = { sitekey: 'k', callback: (tok) => { if (tok === 'TOKEN_123') calls.callbackCalled = true; } };
    const page = fakePage({
      win: { __turnstileCapture: captured, turnstile: null },
      doc: { querySelectorAll: () => inputs }
    });
    await injectTurnstileToken(page, 'TOKEN_123', { callback: null });
    expect(calls.inputsSet).toBe(1);
    expect(calls.eventsDispatched).toBe(2);
    expect(calls.callbackCalled).toBe(true);
    expect(inputs[0]._v).toBe('TOKEN_123');
  });

  test('calls named global callback when present', async () => {
    let received = null;
    const win = { __turnstileCapture: null, myCustomCb: (tok) => { received = tok; } };
    const page = fakePage({
      win,
      doc: { querySelectorAll: () => [] }
    });
    await injectTurnstileToken(page, 'TOK_ABC', { callback: 'myCustomCb' });
    expect(received).toBe('TOK_ABC');
  });

  test('swallows errors silently', async () => {
    const page = { evaluate: async () => { throw new Error('CDP detached'); } };
    await expect(injectTurnstileToken(page, 'X', {})).resolves.toBeUndefined();
  });
});
