import http from 'node:http';
import https from 'node:https';
import os from 'node:os';

const toInt = (value, fallback) => {
  const n = Number.parseInt(value, 10);
  return Number.isFinite(n) && n > 0 ? n : fallback;
};

const coreCount = Math.max(1, Number(os.cpus?.().length || os.cpus().length || 1));
const defaultMaxSockets = Math.max(64, Math.min(256, coreCount * 32));
const maxSockets = Math.min(256, toInt(process.env.HTTP_MAX_SOCKETS, defaultMaxSockets));
const maxFreeSockets = Math.min(maxSockets, toInt(process.env.HTTP_MAX_FREE_SOCKETS, Math.max(16, Math.floor(maxSockets / 4))));
const timeout = toInt(process.env.HTTP_SOCKET_TIMEOUT_MS, 30_000);

export const directHttpAgent = new http.Agent({
  keepAlive: true,
  maxSockets,
  maxFreeSockets,
  timeout,
  keepAliveMsecs: 1000,
  maxTotalSockets: maxSockets,
  scheduling: 'lifo',
});

export const directHttpsAgent = new https.Agent({
  keepAlive: true,
  maxSockets,
  maxFreeSockets,
  timeout,
  keepAliveMsecs: 1000,
  maxTotalSockets: maxSockets,
  scheduling: 'lifo',
  maxCachedSessions: 256,
});

export const directGotAgents = {
  http: directHttpAgent,
  https: directHttpsAgent,
};

export const networkPerformanceSnapshot = () => ({
  maxSockets,
  maxFreeSockets,
  timeout,
});

export const socketTimeoutMs = timeout;

export const closeNetworkAgents = () => {
  directHttpAgent.destroy();
  directHttpsAgent.destroy();
};

export const networkAgentsApplied = () => ({
  maxSockets,
  maxFreeSockets,
  timeout,
});
