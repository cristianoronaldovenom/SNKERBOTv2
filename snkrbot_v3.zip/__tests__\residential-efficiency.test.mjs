import assert from 'node:assert/strict';

const cleanPolls = Math.max(1, Number.parseInt(process.env.RESIDENTIAL_MONITOR_CLEAN_POLLS || '1', 10));
const cacheMs = Math.max(300, Number.parseInt(process.env.RESIDENTIAL_MONITOR_RESULT_CACHE_MS || '1500', 10));

assert.equal(cleanPolls, 1, 'default residential clean-poll threshold should be 1');
assert.equal(cacheMs, 1500, 'default residential result cache window should be 1500ms');
assert.ok(cacheMs < 5000, 'residential cache window must remain short');
console.log('residential efficiency config: ok');
