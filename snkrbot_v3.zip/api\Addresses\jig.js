import db from '../../db/index.js';
import { jigAddress } from '../../helpers/address-jigger.js';

export const jig = async (req, res, next) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ success: false, message: 'invalid address id', data: {} });
    const rawCount = parseInt(req.query.count || req.body.count || 5, 10);
    if (!Number.isInteger(rawCount) || rawCount < 1 || rawCount > 20) {
      return res.status(400).json({ success: false, message: 'count must be an integer between 1 and 20', data: {} });
    }
    const count = rawCount;
    const base = await db('addresses').where({ id, is_deleted: false }).first();
    if (!base) return res.status(404).json({ success: false, message: 'Address not found', data: {} });

    const variants = jigAddress(base, count);
    const inserted = [];
    for (const v of variants) {
      const [row] = await db('addresses').insert(v).returning('*');
      inserted.push(row);
    }
    return res.json({
      success: true,
      message: `Created ${inserted.length} jigged address variants from #${id}`,
      data: inserted
    });
  } catch (err) { next(err); }
};
