// Run the Go test suites (tls-sidecar and the vendored Akamai BMP sensor).
//
// Why this exists: there are real Go tests (sidecar pool/decode, sdk helpers) but `npm
// test` is the only command anyone types, so they were never executed and had quietly
// gone stale -- the Akamai sdk was missing eleven symbols the bm packages call, and
// nothing noticed because no one ran `go test`.
//
// Skips cleanly when a Go toolchain is absent, so the Node-only workflow is unaffected.
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

const findGo = () => {
  if (process.env.GO_BIN) return process.env.GO_BIN;
  const managed = path.join(root, '.local', 'runtimes');
  if (fs.existsSync(managed)) {
    for (const dir of fs.readdirSync(managed)) {
      if (!dir.startsWith('go-')) continue;
      for (const exe of ['go.exe', 'go']) {
        const candidate = path.join(managed, dir, 'go', 'bin', exe);
        if (fs.existsSync(candidate)) return candidate;
      }
    }
  }
  return 'go';
};

const run = (cwd, args) => new Promise((resolve) => {
  const child = spawn(findGo(), args, {
    cwd,
    stdio: 'inherit',
    env: { ...process.env, CGO_ENABLED: '0', GOFLAGS: '' }
  });
  child.on('error', () => resolve({ code: 127 }));
  child.on('exit', (code) => resolve({ code: code ?? 1 }));
});

const SUITES = [
  ['tls-sidecar', 'sidecar transport'],
  [path.join('vendor', 'akamai-bmp'), 'akamai sensor sdk']
];

let failed = 0;
for (const [rel, label] of SUITES) {
  const cwd = path.join(root, rel);
  if (!fs.existsSync(cwd)) {
    console.log(`SKIP ${label} — ${rel} missing`);
    continue;
  }
  console.log(`\n--- go test ${label} (${rel}) ---`);
  const { code } = await run(cwd, ['test', './...']);
  if (code === 127) {
    console.log('SKIP go tests — no Go toolchain found');
    process.exit(0);
  }
  if (code !== 0) {
    console.error(`FAIL ${label} exited ${code}`);
    failed++;
  }
}

if (failed) process.exit(1);
console.log('\nPASS: go test suites');
