import { Router } from 'express';
import db from '../../db/index.js';
import { aggregateStageTimings } from '../../helpers/stage-timer.js';

const router = Router();

let statsCache = { value: null, expiresAt: 0 };
const STATS_CACHE_TTL_MS = 2000;

// GET /v1/runs?task_id=&status=&limit=&offset=
router.get('/', async (req, res, next) => {
  try {
    const limit = Math.min(500, Math.max(1, parseInt(req.query.limit, 10) || 100));
    const offset = Math.max(0, parseInt(req.query.offset, 10) || 0);
    const q = db('task_runs').orderBy('started_at', 'desc').limit(limit).offset(offset);
    if (req.query.task_id) q.where({ task_id: parseInt(req.query.task_id, 10) });
    if (req.query.status)  q.where({ status: String(req.query.status) });
    const rows = await q;
    const totalQ = db('task_runs').count({ c: '*' }).first();
    if (req.query.task_id) totalQ.where({ task_id: parseInt(req.query.task_id, 10) });
    if (req.query.status)  totalQ.where({ status: String(req.query.status) });
    const total = await totalQ.then((r) => Number(r?.c || 0));
    res.json({ success: true, message: `Found ${rows.length} run(s)`, data: { rows, total, limit, offset } });
  } catch (err) { next(err); }
});

// GET /v1/runs/stats — aggregate success rate / avg duration per site
router.get('/stats', async (_req, res, next) => {
  try {
    if (statsCache.value && statsCache.expiresAt > Date.now()) {
      return res.json({ success: true, message: 'Run stats', data: statsCache.value, cached: true });
    }
    const rows = await db('task_runs')
      .leftJoin('tasks', 'tasks.id', 'task_runs.task_id')
      .select('tasks.site_id')
      .count({ total: '*' })
      .sum({ wins: db.raw(`CASE WHEN task_runs.status='success' THEN 1 ELSE 0 END`) })
      .avg({ avg_ms: 'task_runs.duration_ms' })
      .groupBy('tasks.site_id');
    const stats = rows.map((r) => ({
      site_id: r.site_id,
      total: Number(r.total || 0),
      wins: Number(r.wins || 0),
      successRate: r.total ? Math.round((Number(r.wins) / Number(r.total)) * 100) : 0,
      avgMs: r.avg_ms ? Math.round(Number(r.avg_ms)) : 0
    }));
    statsCache = { value: stats, expiresAt: Date.now() + STATS_CACHE_TTL_MS };
    res.json({ success: true, message: 'Run stats', data: stats, cached: false });
  } catch (err) { next(err); }
});

// GET /v1/runs/speed — per-site average stage timings (speed telemetry)
router.get('/speed', async (req, res, next) => {
  try {
    const limit = Math.min(2000, Math.max(1, parseInt(req.query.limit, 10) || 500));
    const q = db('task_runs')
      .leftJoin('tasks', 'tasks.id', 'task_runs.task_id')
      .select('task_runs.timings', 'tasks.site_id')
      .whereNotNull('task_runs.timings')
      .orderBy('task_runs.started_at', 'desc')
      .limit(limit);
    if (req.query.site_id !== undefined) {
      const siteId = parseInt(req.query.site_id, 10);
      if (!Number.isInteger(siteId)) {
        return res.status(400).json({ success: false, message: 'site_id must be an integer', data: [] });
      }
      q.where({ 'tasks.site_id': siteId });
    }
    const rows = await q;
    res.json({ success: true, message: 'Speed telemetry', data: aggregateStageTimings(rows) });
  } catch (err) { next(err); }
});

// GET /v1/runs/export.csv — download all runs as CSV
router.get('/export.csv', async (_req, res, next) => {
  try {
    const rows = await db('task_runs').orderBy('started_at', 'desc');
    const cols = ['id', 'task_id', 'attempt', 'status', 'stage_failed', 'order_number', 'duration_ms', 'profile_label', 'proxy_host', 'started_at', 'finished_at', 'error_message'];
    const esc = (v) => {
      if (v == null) return '';
      const s = String(v).replace(/"/g, '""');
      return /[",\n\r]/.test(s) ? `"${s}"` : s;
    };
    const lines = [cols.join(',')];
    for (const r of rows) lines.push(cols.map((c) => esc(r[c])).join(','));
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="sneakerbot-runs-${new Date().toISOString().slice(0, 10)}.csv"`);
    res.send(lines.join('\n'));
  } catch (err) { next(err); }
});

router.delete('/', async (_req, res, next) => {
  try {
    const n = await db('task_runs').del();
    res.json({ success: true, message: `Deleted ${n} run(s)`, data: { deleted: n } });
  } catch (err) { next(err); }
});

export default router;
