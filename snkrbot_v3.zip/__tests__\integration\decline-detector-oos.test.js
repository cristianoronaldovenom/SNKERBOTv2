// OOS detection precision. The detected text is the page body CONCATENATED with
// matching alert containers, so cart chrome (`id="cart"`, `class="cart-error"`)
// is always present. The old `cart.*(?:is empty|…)` therefore reported OOS on
// healthy pages.
import { jest } from '@jest/globals';

jest.unstable_mockModule('../../helpers/logger.js', () => ({
  default: { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} }
}));
jest.unstable_mockModule('../../db/index.js', () => ({ default: () => ({}) }));

const { detectDecline } = await import('../../helpers/decline-detector.js');

const pageWith = (bodyText, alerts = '') => ({
  evaluate: async (fn) => {
    // Reproduce the real evaluation: body innerText + joined alert text.
    global.document = {
      body: { innerText: bodyText },
      querySelectorAll: () => [{ textContent: alerts }],
    };
    return (bodyText + ' ' + alerts).slice(0, 5000);
  }
});

test('cart chrome alone does not look like an empty cart', async () => {
  const result = await detectDecline(pageWith('Your order is confirmed. Continue shopping.'));
  expect(result).toBeNull();
});

test('an explicit empty-cart sentence is OOS', async () => {
  expect((await detectDecline(pageWith('Your cart is empty'))).type).toBe('oos');
});

test('a cleared-cart notice is OOS', async () => {
  expect((await detectDecline(pageWith('The cart has been cleared'))).type).toBe('oos');
});

test('a no-items message is OOS', async () => {
  expect((await detectDecline(pageWith("There are no items in your cart"))).type).toBe('oos');
});

test('a payment decline still wins over cart wording', async () => {
  const r = await detectDecline(pageWith('Your card was declined. Your cart is empty'));
  expect(r.type).toBe('decline');
});
