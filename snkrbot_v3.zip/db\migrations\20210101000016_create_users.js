export const up = async (knex) => {
  await knex.schema.createTable('users', (t) => {
    t.increments('id').primary();
    t.string('email', 255).notNullable().unique();
    t.string('username', 100).notNullable().unique();
    t.string('password_hash', 255).notNullable();
    t.enu('role', ['owner', 'user']).notNullable().defaultTo('user');
    t.timestamps(true, true);
  });

  await knex.schema.createTable('pending_registrations', (t) => {
    t.increments('id').primary();
    t.string('email', 255).notNullable();
    t.string('username', 100).notNullable();
    t.string('password_hash', 255).notNullable();
    t.string('token', 128).notNullable().unique();
    t.timestamps(true, true);
  });
};

export const down = async (knex) => {
  await knex.schema.dropTableIfExists('pending_registrations');
  await knex.schema.dropTableIfExists('users');
};
