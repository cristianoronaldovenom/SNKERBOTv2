import db from '../../db/index.js';

export const findAll = async (req, res, next) => {
  try {
    const logs = await db('logs').select('*').orderBy('created_at', 'desc');
    if (logs.length === 0) {
      return res.json({ success: true, message: 'Logs not found', data: logs });
    }
    return res.json({ success: true, message: 'Logs successfully found', data: logs });
  } catch (err) {
    next(err);
  }
};

export const findOne = async (req, res, next) => {
  try {
    const log = await db('logs').where({ id: req.params.id }).first('*');
    if (!log) {
      return res.json({ success: true, message: 'Log not found', data: undefined });
    }
    return res.json({ success: true, message: 'Log successfully found', data: log });
  } catch (err) {
    next(err);
  }
};

export const findByTask = async (req, res, next) => {
  try {
    const logs = await db('logs')
      .where({ task_id: req.params.taskId })
      .select('*')
      .orderBy('created_at', 'desc');
    if (logs.length === 0) {
      return res.json({ success: true, message: 'Logs not found', data: logs });
    }
    return res.json({ success: true, message: 'Logs successfully found', data: logs });
  } catch (err) {
    next(err);
  }
};

export const remove = async (req, res, next) => {
  try {
    await db('logs').where({ id: req.params.id }).del();
    return res.json({ success: true, message: 'Log successfully deleted', data: {} });
  } catch (err) {
    next(err);
  }
};
