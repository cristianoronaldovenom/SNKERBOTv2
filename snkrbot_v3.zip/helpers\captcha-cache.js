import logger from './logger.js';

// reCAPTCHA v2 / hCaptcha tokens are valid for ~120 seconds. Cache for 110s
// so a token solved during monitor/checkout can be reused at the next stage
// without re-spending a 2Captcha credit.
const TTL_MS = 110_000;
const cache = new Map();

const keyOf = (type, siteKey, pageUrl) => {
  let host = pageUrl;
  try { host = new URL(pageUrl).hostname; } catch (_) {}
  return `${type}::${siteKey}::${host}`;
};

export const getCachedToken = (type, siteKey, pageUrl) => {
  const k = keyOf(type, siteKey, pageUrl);
  const entry = cache.get(k);
  if (!entry) return null;
  // A cache hit is handed to page.evaluate() and injected straight into the
  // hidden response field. An empty/undefined value silently produces a blank
  // token that the site rejects, so treat it as a miss.
  if (typeof entry.token !== 'string' || entry.token.length < 20) {
    cache.delete(k);
    return null;
  }
  if (Date.now() - entry.solvedAt > TTL_MS) {
    cache.delete(k);
    return null;
  }
  const ageS = Math.round((Date.now() - entry.solvedAt) / 1000);
  logger.info(`[CaptchaCache] HIT ${type} (age ${ageS}s) — reusing token, no 2Captcha spend`);
  return entry.token;
};

export const cacheToken = (type, siteKey, pageUrl, token) => {
  if (typeof token !== 'string' || token.length < 20) return false;
  const k = keyOf(type, siteKey, pageUrl);
  cache.set(k, { token, solvedAt: Date.now() });
  logger.info(`[CaptchaCache] STORED ${type} token (TTL ${Math.round(TTL_MS / 1000)}s)`);
  return true;
};

export const clearExpired = () => {
  const now = Date.now();
  for (const [k, v] of cache.entries()) {
    if (now - v.solvedAt > TTL_MS) cache.delete(k);
  }
};

setInterval(clearExpired, 60_000).unref();

// Test/maintenance helper — the module-level cache otherwise leaks between
// suites and a previously cached token looks like a successful store.
export const __resetCaptchaCacheForTests = () => cache.clear();
