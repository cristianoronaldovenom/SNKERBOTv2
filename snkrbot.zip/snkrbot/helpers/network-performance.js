import http from 'node:http';
import https from 'node:https';

const toInt = (value, fallback) => {
  const n = Number.parseInt(value, 10);
  return Number.isFinite(n) && n > 0 ? n : fallback;
};

const maxSockets = Math.min(256, toInt(process.env.HTTP_MAX_SOCKETS, 128));
const maxFreeSockets = Math.min(maxSockets, toInt(process.env.HTTP_MAX_FREE_SOCKETS, 32));
const timeout = toInt(process.env.HTTP_SOCKET_TIMEOUT_MS, 30_000);

export const directHttpAgent = new http.Agent({
  keepAlive: true,
  maxSockets,
  maxFreeSockets,
  timeout,
  keepAliveMsecs: 1000,
  maxTotalSockets: maxSockets,
  scheduling: 'lifo',
});

export const directHttpsAgent = new https.Agent({
  keepAlive: true,
  maxSockets,
  maxFreeSockets,
  timeout,
  keepAliveMsecs: 1000,
  maxTotalSockets: maxSockets,
  scheduling: 'lifo',
  maxCachedSessions: 256,
});

export const directGotAgents = {
  http: directHttpAgent,
  https: directHttpsAgent,
};

export const networkPerformanceSnapshot = () => ({
  maxSockets,
  maxFreeSockets,
  timeout,
});

export const closeNetworkAgents = () => {
  directHttpAgent.destroy();
  directHttpsAgent.destroy();
};
