import db from '../../db/index.js';
import logger from '../../helpers/logger.js';
import { checkStock, getAdaptiveDelay, getReliabilitySnapshot, clearEscalation } from '../../helpers/stock-monitor.js';
import { stopAutoRefresh } from '../../helpers/session-warmer.js';
import {
  setMonitor, clearMonitor, isMonitoring, getAllMonitors, getActiveMonitorCount, getActiveMonitorHostCount,
  addClient, removeClient, broadcastToClients, broadcastMonitorTick, getMonitor, addGlobalClient, removeGlobalClient, broadcastAllClients
} from '../../helpers/monitor-store.js';
import startTask from '../../scripts/start-task.js';
import { reserveCart } from '../../helpers/cart-reserver.js';
import { prepareRequestCheckout } from '../../helpers/request-checkout/index.js';
import { prewarmEnabled, park, disposePrewarm, sweepParkedByRss } from '../../helpers/prewarm-engine.js';
import { PC_SITE_ID, isWithinBusinessHours, businessHoursEnabled } from '../../helpers/business-hours.js';
import { resolveTaskProxy, sanitizeProxyMeta, getResidentialProxy } from '../../helpers/task-proxies.js';
import { canStartResidentialSession, remainingResidentialRatio } from '../../helpers/residential-budget.js';
import { getArmedTaskCapacity, getArmedTaskHostCapacity } from '../../helpers/run-queue.js';
import { nextPollDelay } from '../../helpers/poll-economy.js';
import { burstDelay, noteChange } from '../../helpers/poll-burst.js';
import { getMemorySnapshot } from '../../helpers/memory-guard.js';

const monitorStartsInFlight = new Map();
const armedReservationsByHost = new Map();
let armedReservations = 0;

// When each task's stock verdict last CHANGED. Poll economy uses quiet time in a
// tier decision, and "quiet" must mean "nothing happened", not "polled a lot".
const lastStockChangeAt = new Map();
const lastVerdictByTask = new Map();

// Host memory ceiling for the RSS sweep. Cached: the host does not resize during
// a session, and getMemorySnapshot is async so the poll path must not await it.
let cachedHostLimitBytes = 0;

// Feed poll economy the remaining share of the monitor allowance so idle
// monitors yield bytes instead of starving a later checkout. Null when unknown.
const residentialBudgetRatio = () => remainingResidentialRatio('monitor');

const hostLimitBytes = () => cachedHostLimitBytes;
const runWithConcurrency = async (items, limit, worker) => {
  const concurrency = Math.max(1, Math.min(limit, items.length || 1));
  let cursor = 0;
  const workers = Array.from({ length: concurrency }, async () => {
    while (true) {
      const index = cursor++;
      if (index >= items.length) return;
      await worker(items[index], index);
    }
  });
  await Promise.all(workers);
};


const persistMonitorStart = (taskId) =>
  db('active_monitors').insert({ task_id: taskId }).onConflict('task_id').merge().catch(() => {});

const persistMonitorStop = (taskId) =>
  db('active_monitors').where({ task_id: taskId }).del().catch(() => {});

const POLL_BASE_MS = 1000;
const POLL_JITTER_MS = 400;
const PC_DIRECT_MIN_POLL_MS = 2200;
const PC_ACCESS_BACKOFF_BASE_MS = 60_000;
const PC_ACCESS_BACKOFF_MAX_MS = 15 * 60_000;
const jitteredDelay = (baseMs = POLL_BASE_MS) => baseMs + Math.floor(Math.random() * POLL_JITTER_MS) - POLL_JITTER_MS / 2;
const pcAccessBackoff = (streak) => {
  const exp = Math.max(0, Math.min(4, streak - 1));
  const base = Math.min(PC_ACCESS_BACKOFF_BASE_MS * (2 ** exp), PC_ACCESS_BACKOFF_MAX_MS);
  return base + Math.floor(Math.random() * 5000);
};

// Read the user-configurable poll interval (setting key: monitor_poll_ms).
// Cached briefly because every monitor tick used to issue a DB query. The short
// TTL keeps dashboard setting changes effectively live while removing repeated
// DB work from the hot polling path.
let pollBaseCache = { value: POLL_BASE_MS, expiresAt: 0 };
const POLL_SETTING_TTL_MS = 5000;
const readPollBaseMs = async () => {
  const now = Date.now();
  if (pollBaseCache.expiresAt > now) return pollBaseCache.value;
  try {
    const row = await db('settings').where({ key: 'monitor_poll_ms' }).first();
    const v = parseInt(row?.value, 10);
    pollBaseCache.value = v >= 300 && v <= 10000 ? v : POLL_BASE_MS;
  } catch (_) {
    pollBaseCache.value = POLL_BASE_MS;
  }
  pollBaseCache.expiresAt = now + POLL_SETTING_TTL_MS;
  return pollBaseCache.value;
};

// Build the stock check options from a task row
const taskCheckOpts = (task, proxy, warmProxy = null) => ({
  proxy: proxy || null,
  warmProxy: warmProxy || null,
  taskId: task.id,          // required for proxy escalation tracking
  siteId: task.site_id || null,
  size: task.size || null,
  style: task.style || null,
});

// ─── Shared tick factory ───────────────────────────────────────────────────────
// Used by both startMonitor and restoreMonitors so both use the SAME logic:
// self-rescheduling setTimeout with adaptive backoff, proper cleanup on checkout.
const makeTick = (task, proxy, warmProxy, checkoutProxy, getTimerRef, setTimerRef, pollBaseMs = POLL_BASE_MS) => {
  const taskId = task.id;
  let activeProxy = proxy;
  const fallbackProxy = warmProxy || null;
  let residentialFallback = false;
  let pcAccessDeniedStreak = 0;
  const host = (() => { try { return new URL(task.url).hostname; } catch (_) { return ''; } })();

  const tick = async () => {
    if (!isMonitoring(taskId)) return null;

    // Pokemon Center only runs 8am–6pm ET. If a monitor drifts outside the window
    // (e.g. the scheduler sweep hasn't fired yet), self-pause instead of polling —
    // the scheduler will auto-restart it at 8am. Other sites are unaffected.
    if (task.site_id === PC_SITE_ID && (await businessHoursEnabled()) && !isWithinBusinessHours()) {
      logger.info(`[Monitor] Task ${taskId} — outside Pokemon Center hours (8am–6pm ET); pausing monitor`);
      clearMonitor(taskId);
      persistMonitorStop(taskId).catch(() => {});
      return null;
    }

    let result;
    try {
      result = await checkStock(task.url, taskCheckOpts(task, activeProxy, fallbackProxy));
    } catch (err) {
      logger.error(`[Monitor] checkStock threw for task ${taskId}: ${err.message}`);
      result = { inStock: false, blocked: false, error: err.message };
    }

    if (!isMonitoring(taskId)) return result; // Task may have been stopped during the async check

    if (result.blocked && !activeProxy) {
      pcAccessDeniedStreak += 1;
    } else if (!result.blocked) {
      pcAccessDeniedStreak = 0;
    }

    const pcAccessLimited = task.site_id === PC_SITE_ID && result.blocked && !activeProxy;
    let promotedToResidential = false;
    if (task.site_id === PC_SITE_ID && result.blocked && !activeProxy && !residentialFallback) {
      const residential = fallbackProxy || getResidentialProxy('monitor');
      if (residential && canStartResidentialSession('monitor')) {
        activeProxy = residential;
        residentialFallback = true;
        pcAccessDeniedStreak = 0;
        promotedToResidential = true;
        logger.warn(`[Monitor] Task ${taskId} — direct access denied; switching to configured residential monitoring gateway ${residential.host}:${residential.port}`);
        broadcastToClients(taskId, { status: 'residential_fallback', taskId, proxy: sanitizeProxyMeta(residential) });
      }
    }

    const nextRetryMs = pcAccessLimited
      ? pcAccessBackoff(pcAccessDeniedStreak)
      : null;

    // Track when this task's verdict last changed; quiet time drives the poll
    // tier. A first sighting counts as a change, so a new monitor starts fast.
    const previousVerdict = lastVerdictByTask.get(taskId);
    const verdict = result.blocked ? 'blocked' : (result.inStock ? 'in' : 'out');
    if (previousVerdict !== verdict) {
      lastStockChangeAt.set(taskId, Date.now());
      lastVerdictByTask.set(taskId, verdict);
      // Open a freshness burst so the next few polls confirm the change instead of
      // waiting out the economy backoff.
      noteChange(taskId);
    }

    setMonitor(taskId, {
      inStock: result.inStock,
      productName: result.productName,
      price: result.price,
      imageUrl: result.imageUrl,
      availableSizes: result.availableSizes,
      lastChecked: Date.now(),
      error: result.error,
      status: promotedToResidential ? 'residential_fallback' : (pcAccessLimited ? 'access_limited' : undefined),
      accessLimited: pcAccessLimited,
      residentialFallback: Boolean(activeProxy?.proxy_type === 'residential'),
      retryAt: nextRetryMs ? Date.now() + nextRetryMs : null,
      accessDeniedStreak: pcAccessLimited ? pcAccessDeniedStreak : 0,
    });

    const status = result.inStock ? 'instock' : (promotedToResidential ? 'residential_fallback' : (pcAccessLimited ? 'access_limited' : (result.blocked ? 'blocked' : 'outofstock')));
    broadcastMonitorTick(taskId, { status, taskId, ...result, lastChecked: Date.now() });

    if (promotedToResidential) {
      const timer = setTimeout(tick, 250);
      setTimerRef(timer);
      return result;
    }

    if (result.inStock) {
      logger.info(`[Monitor] Task ${taskId} — IN STOCK! Securing the spot...`);
      const instockAt = Date.now(); // for monitor→checkout handoff speed telemetry
      clearMonitor(taskId);
      persistMonitorStop(taskId).catch(() => {});
      broadcastToClients(taskId, { status: 'checkout_started', taskId });
      const freshTask = await db('tasks').where({ id: taskId }).first().catch(() => task);

      // REQUEST-FIRST HOT PATH: generic Shopify uses the live HTTP cart +
      // checkout-open bridge; other retailers retain the existing narrow HTTP
      // reservation path and their dedicated browser adapters.
      let reservation = null;
      try {
        if (Number(freshTask.site_id) === 2) {
          const prepared = await prepareRequestCheckout({ task: freshTask, proxy: checkoutProxy || activeProxy });
          if (prepared?.cartAdded && prepared.cookieHeader) {
            reservation = {
              ok: true,
              reserved: true,
              site: 'shopify',
              variantId: prepared.variantId,
              cartCookies: prepared.cookieHeader,
              checkoutUrl: prepared.checkoutUrl || null,
              checkoutReady: Boolean(prepared.checkoutUrl && prepared.stage === 'checkout_ready'),
            };
          }
        } else {
          reservation = await reserveCart({ task: freshTask, proxy: checkoutProxy || activeProxy });
        }
        if (reservation?.reserved) {
          broadcastToClients(taskId, {
            status: reservation.checkoutReady ? 'checkout_preopened' : 'cart_reserved',
            taskId,
            site: reservation.site,
          });
        }
      } catch (err) {
        logger.warn(`[Monitor] Request-first cart/checkout preparation errored for task ${taskId}: ${err.message}`);
      }

      const taskForCheckout = reservation?.reserved
        ? { ...freshTask, reservation, _instockAt: instockAt, _priority: 100 }
        : { ...freshTask, _instockAt: instockAt, _priority: 100 };
      startTask(taskForCheckout).catch((err) => {
        logger.error(`[Monitor] Checkout failed for task ${taskId}: ${err.message || err}`);
        broadcastToClients(taskId, { status: 'checkout_failed', taskId, error: err.message || String(err) });
      });
      return result; // Don't reschedule — monitor stops after triggering checkout
    }

    if (!isMonitoring(taskId)) return result;

    // Schedule the next poll. When the circuit breaker is OPEN/HALF_OPEN, respect
    // its cooldown so we don't hammer (and re-trip) a site that's hard-blocking —
    // otherwise fall back to adaptive backoff, then to jittered polling.
    let delay;
    if (pcAccessLimited) {
      // No residential proxy and Pokémon Center is currently denying the
      // monitor request: stay armed, but do not hammer the site. The task stays
      // active and automatically probes again with exponential backoff.
      delay = nextRetryMs;
      logger.warn(`[Monitor] Task ${taskId} — Pokémon Center access limited without fallback proxy; next probe in ${Math.ceil(delay / 1000)}s`);
    } else if (result.circuit === 'OPEN' || result.circuit === 'HALF_OPEN') {
      delay = Math.max(result.retryInMs || 0, jitteredDelay(pollBaseMs));
    } else {
      const backoff = getAdaptiveDelay(host);
      const base = (task.site_id === PC_SITE_ID && !activeProxy)
        ? Math.max(pollBaseMs, PC_DIRECT_MIN_POLL_MS)
        : pollBaseMs;
      // Economy policy only ever RAISES the interval (it never shortens a
      // caller's base), so this cannot miss a restock it would previously have
      // caught. Hot/instock and open drop windows stay at full speed.
      const economy = nextPollDelay({
        key: `${taskId}|${host}`,
        inStock: result.inStock,
        blockStreak: result.blocked ? 1 : 0,
        msSinceChange: Date.now() - (lastStockChangeAt.get(taskId) || Date.now()),
        budgetRemainingRatio: residentialBudgetRatio(),
        minMs: backoff > 0 ? backoff : base
      });
      // A confirmed change outranks the economy backoff: freshness matters for the
      // few seconds a restock lives, and the burst window closes on its own.
      const burst = burstDelay(taskId);
      delay = burst === null ? economy.delayMs : Math.min(economy.delayMs, burst);
    }
    const timer = setTimeout(tick, delay);
    setTimerRef(timer);

    // Parked prewarm browsers are the main leak surface, and nothing else
    // recycles them. Sweeping here piggybacks on the poll cadence, needs no extra
    // timer, and only touches pools with no checkout attached. Fire-and-forget so
    // a slow sweep never delays the next poll.
    sweepParkedByRss({ hostLimitBytes: hostLimitBytes() }).catch(() => {});
    return result;
  };

  return tick;
};

// ─── Internal: begin/stop a monitor for a task row ─────────────────────────────
// Shared by the HTTP start/stop handlers AND the Pokemon Center auto-scheduler so
// there is exactly one code path that wires up makeTick / prewarm / persistence.
const beginMonitorForTask = async (task) => {
  const taskId = task.id;
  if (isMonitoring(taskId)) return { already: true, result: getMonitor(taskId) };
  const inflight = monitorStartsInFlight.get(taskId);
  if (inflight) return inflight;

  const startPromise = (async () => {
    if (isMonitoring(taskId)) return { already: true, result: getMonitor(taskId) };

    const [armedLimit, armedPerHostLimit] = await Promise.all([
      getArmedTaskCapacity(),
      getArmedTaskHostCapacity(),
    ]);
    const activeMonitorCount = getActiveMonitorCount();
    if (activeMonitorCount + armedReservations >= armedLimit) {
      const err = new Error(`Armed monitor capacity reached (${activeMonitorCount + armedReservations}/${armedLimit})`);
      err.statusCode = 409;
      throw err;
    }
    let taskHost = null;
    try { taskHost = new URL(task.url).hostname; } catch (_) {}
    if (taskHost) {
      const activeOnHost = getActiveMonitorHostCount(taskHost);
      const reservedOnHost = armedReservationsByHost.get(taskHost) || 0;
      if (activeOnHost + reservedOnHost >= armedPerHostLimit) {
        const err = new Error(`Armed monitor host capacity reached for ${taskHost} (${activeOnHost + reservedOnHost}/${armedPerHostLimit})`);
        err.statusCode = 409;
        throw err;
      }
      armedReservationsByHost.set(taskHost, reservedOnHost + 1);
    }
    armedReservations += 1;

  const [proxySelection, checkoutSelection, pollBaseMs] = await Promise.all([
    resolveTaskProxy(task, 'monitor'),
    resolveTaskProxy(task, 'checkout'),
    readPollBaseMs(),
  ]);
  // Cache the host ceiling once per monitor start for the parked-browser RSS
  // sweep. Failure is fine: 0 means the watchdog falls back to its floors.
  getMemorySnapshot().then((m) => { cachedHostLimitBytes = m?.limitBytes || 0; }).catch(() => {});
  const proxy = proxySelection.proxy;
  const fallbackProxy = proxySelection.fallbackProxy || null;
  const checkoutProxy = checkoutSelection.proxy || null;
  if (proxy) logger.info(`[Monitor] Task ${taskId} using ${proxySelection.source} proxy ${proxy.host}:${proxy.port}`);
  logger.info(`[Monitor] Task ${taskId} poll interval: ${pollBaseMs}ms ±${POLL_JITTER_MS / 2}ms`);

  let nextTimer = null;
  const getTimerRef = () => nextTimer;
  const setTimerRef = (t) => { nextTimer = t; };

  const tick = makeTick(task, proxy, fallbackProxy, checkoutProxy, getTimerRef, setTimerRef, pollBaseMs);

  setMonitor(taskId, {
    active: true,
    proxy: sanitizeProxyMeta(proxy),
    proxySource: proxySelection.source,
    proxyFallback: sanitizeProxyMeta(fallbackProxy),
    checkoutProxy: sanitizeProxyMeta(checkoutProxy),
    taskId,
    url: task.url,
    siteId: task.site_id,
    size: task.size,
    startedAt: Date.now(),
    cleanup: () => {
      if (nextTimer) { clearTimeout(nextTimer); nextTimer = null; }
      try { stopAutoRefresh(task.url); } catch (_) {}
    },
  });

  await persistMonitorStart(taskId);
  logger.info(`[Monitor] Started monitoring task ${taskId} (site_id=${task.site_id}, size=${task.size || 'any'}): ${task.url}`);

  // Prewarm (default OFF): pre-position a warmed browser while we poll so the
  // instant stock hits, runOnce adopts it and skips the cold launch + warm.
  // Fire-and-forget — never blocks or breaks the monitor.
  if (await prewarmEnabled()) {
    park({ task, proxy: checkoutProxy || fallbackProxy || proxy }).catch((err) => logger.warn(`[Monitor] Prewarm park failed for task ${taskId}: ${err.message}`));
  }

  // Run the first poll immediately. tick() also schedules the next poll (or fires
  // checkout if already in stock), so there is exactly ONE check at startup — no
  // double-counting against the breaker.
  const result = await tick() || { inStock: false, blocked: false, error: 'Initial check failed' };
  return { already: false, result };
  })();
  monitorStartsInFlight.set(taskId, startPromise);
  try {
    return await startPromise;
  } finally {
    monitorStartsInFlight.delete(taskId);
    armedReservations = Math.max(0, armedReservations - 1);
    if (taskHost) {
      const cur = armedReservationsByHost.get(taskHost) || 0;
      if (cur <= 1) armedReservationsByHost.delete(taskHost);
      else armedReservationsByHost.set(taskHost, cur - 1);
    }
  }
};

export const endMonitorForTask = async (taskId) => {
  clearMonitor(taskId);
  await persistMonitorStop(taskId);
  await disposePrewarm(taskId).catch(() => {});
  clearEscalation(taskId);
};

// ─── Start monitor ─────────────────────────────────────────────────────────────
export const startMonitor = async (req, res, next) => {
  try {
    const taskId = parseInt(req.params.id);
    const task = await db('tasks').where({ id: taskId, is_deleted: false }).first();
    if (!task) return res.status(404).json({ success: false, message: 'Task not found', data: {} });

    // Pokemon Center runs 8am–6pm ET only. Block a manual monitor start outside
    // the window (the scheduler will auto-start it at 8am).
    if (task.site_id === PC_SITE_ID && (await businessHoursEnabled()) && !isWithinBusinessHours()) {
      return res.status(409).json({
        success: false,
        message: 'Pokemon Center runs 8am–6pm ET only — monitoring will auto-start at 8am ET.',
        data: { outsideBusinessHours: true }
      });
    }

    if (isMonitoring(taskId)) {
      await db('tasks').where({ id: taskId }).update({ monitor_24_7: true }).catch(() => {});
      return res.json({ success: true, message: 'Already monitoring (24/7 enabled)', data: getMonitor(taskId) });
    }

    // The dashboard's Monitor Stock action means "keep this monitor running".
    // Persist it so it survives app/container restarts.
    await db('tasks').where({ id: taskId }).update({ monitor_24_7: true }).catch(() => {});
    task.monitor_24_7 = true;
    const { result } = await beginMonitorForTask(task);

    return res.json({
      success: true,
      message: 'Monitoring started',
      data: { taskId, url: task.url, siteId: task.site_id, size: task.size, ...result },
    });
  } catch (err) {
    next(err);
  }
};

// ─── Stop monitor ──────────────────────────────────────────────────────────────
export const stopMonitor = async (req, res) => {
  const taskId = parseInt(req.params.id);
  // A dashboard Stop is an explicit opt-out from persistent monitoring.
  await db('tasks').where({ id: taskId }).update({ monitor_24_7: false }).catch(() => {});
  // Remember a manual stop of a Pokemon Center monitor so the business-hours
  // sweep doesn't auto-restart it within 60s (cleared at the next 8am open).
  if (getMonitor(taskId)?.siteId === PC_SITE_ID) markPcUserStopped(taskId);
  // endMonitorForTask tears down the timer, persistence, any parked prewarm
  // browser, and resets proxy escalation so a re-start begins cleanly.
  await endMonitorForTask(taskId);
  logger.info(`[Monitor] Stopped monitoring task ${taskId}`);
  return res.json({ success: true, message: 'Monitor stopped', data: {} });
};

// ─── Restore monitors after restart ───────────────────────────────────────────
// Uses the same makeTick factory (self-rescheduling setTimeout + adaptive backoff)
// instead of the old setInterval which ignored backoff and cleanup.
export const restoreMonitors = async () => {
  try {
    const saved = await db('active_monitors')
      .join('tasks', 'active_monitors.task_id', 'tasks.id')
      .where({ 'tasks.is_deleted': false })
      .select('tasks.*');

    if (saved.length === 0) return;

    logger.info(`[Monitor] Restoring ${saved.length} active monitor(s) after restart...`);

    const [pollBaseMs, prewarm] = await Promise.all([
      readPollBaseMs(),
      prewarmEnabled(),
    ]);

    const [armedLimit, armedPerHostLimit] = await Promise.all([
      getArmedTaskCapacity(),
      getArmedTaskHostCapacity(),
    ]);
    let restoredCount = Object.values(getAllMonitors() || {}).filter((m) => m?.active).length;
    const restoredByHost = new Map();
    for (const m of Object.values(getAllMonitors() || {})) {
      if (!m?.active || !m?.url) continue;
      try {
        const host = new URL(m.url).hostname;
        restoredByHost.set(host, (restoredByHost.get(host) || 0) + 1);
      } catch (_) {}
    }

    await runWithConcurrency(saved, 4, async (task, taskIndex) => {
      if (isMonitoring(task.id)) return;
      if (restoredCount >= armedLimit) {
        logger.warn(`[Monitor] Skipping restored task ${task.id} — armed capacity ${restoredCount}/${armedLimit}`);
        return;
      }
      let taskHost = null;
      try { taskHost = new URL(task.url).hostname; } catch (_) {}
      if (taskHost) {
        const hostCount = restoredByHost.get(taskHost) || 0;
        if (hostCount >= armedPerHostLimit) {
          logger.warn(`[Monitor] Skipping restored task ${task.id} — host capacity ${hostCount}/${armedPerHostLimit} on ${taskHost}`);
          return;
        }
        restoredByHost.set(taskHost, hostCount + 1);
      }
      restoredCount += 1;

      const [proxySelection, checkoutSelection] = await Promise.all([
        resolveTaskProxy(task, 'monitor'),
        resolveTaskProxy(task, 'checkout'),
      ]);
      const proxy = proxySelection.proxy;
      const fallbackProxy = proxySelection.fallbackProxy || null;
      const checkoutProxy = checkoutSelection.proxy || null;

      let nextTimer = null;
      const getTimerRef = () => nextTimer;
      const setTimerRef = (t) => { nextTimer = t; };

      const tick = makeTick(task, proxy, fallbackProxy, checkoutProxy, getTimerRef, setTimerRef, pollBaseMs);

      setMonitor(task.id, {
        active: true,
        proxy: sanitizeProxyMeta(proxy),
        proxySource: proxySelection.source,
        proxyFallback: sanitizeProxyMeta(fallbackProxy),
        checkoutProxy: sanitizeProxyMeta(checkoutProxy),
        taskId: task.id,
        url: task.url,
        siteId: task.site_id,
        size: task.size,
        startedAt: Date.now(),
        restored: true,
        cleanup: () => {
          if (nextTimer) { clearTimeout(nextTimer); nextTimer = null; }
          try { stopAutoRefresh(task.url); } catch (_) {}
        },
      });

      const staggerMs = taskIndex * 150;
      nextTimer = setTimeout(tick, staggerMs);

      if (prewarm) {
        park({ task, proxy: checkoutProxy || fallbackProxy || proxy }).catch((err) => logger.warn(`[Monitor] Prewarm park failed for task ${task.id}: ${err.message}`));
      }

      logger.info(`[Monitor] Restored monitor for task ${task.id} (site_id=${task.site_id}, proxy=${proxy?.host || 'direct'}, source=${proxySelection.source}, size=${task.size || 'any'}): ${task.url}`);
    });
  } catch (err) {
    logger.error(`[Monitor] Failed to restore monitors: ${err.message}`);
  }
};

// ─── SSE stream ───────────────────────────────────────────────────────────────
export const streamMonitor = async (req, res) => {
  const taskId = parseInt(req.params.id);

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders();

  addClient(taskId, res);

  const current = getMonitor(taskId);
  if (current) {
    const status = current.inStock ? 'instock' : (current.blocked ? 'blocked' : 'outofstock');
    res.write(`data: ${JSON.stringify({ status, taskId, ...current })}\n\n`);
  } else {
    res.write(`data: ${JSON.stringify({ status: 'idle', taskId })}\n\n`);
  }

  const heartbeat = setInterval(() => {
    try { res.write(': ping\n\n'); } catch (_) {}
  }, 15000);

  req.on('close', () => {
    clearInterval(heartbeat);
    removeClient(taskId, res);
  });
};

export const streamAllMonitors = async (_req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders();

  addGlobalClient(res);
  const current = Object.values(getAllMonitors() || {}).map((m) => ({
    taskId: Number(m?.taskId ?? 0),
    type: 'monitor',
    ...m,
  }));
  res.write(`data: ${JSON.stringify({ type: 'snapshot', monitors: current })}\n\n`);

  const heartbeat = setInterval(() => { try { res.write(': ping\n\n'); } catch (_) {} }, 15000);
  _req.on('close', () => { clearInterval(heartbeat); removeGlobalClient(res); });
};

// ─── Status endpoints ──────────────────────────────────────────────────────────
export const getMonitorStatus = (req, res) => {
  const taskId = parseInt(req.params.id);
  const monitor = getMonitor(taskId);
  if (!monitor) {
    return res.json({ success: true, message: 'Not monitoring', data: { active: false } });
  }
  return res.json({ success: true, message: 'Monitor status', data: monitor });
};

export const getAllMonitorStatuses = (_req, res) => {
  const raw = getAllMonitors() || {};
  const normalized = Object.fromEntries(Object.entries(raw).map(([taskId, monitor]) => {
    const m = monitor || {};
    return [taskId, {
      taskId: Number(taskId),
      siteId: m.siteId ?? null,
      status: m.status ?? m.state ?? 'checking',
      message: m.message ?? m.lastMessage ?? '',
      lastCheckedAt: m.lastCheckedAt ?? m.updatedAt ?? null,
      stage: m.stage ?? null,
      updatedAt: m.updatedAt ?? null,
      active: m.active !== false,
    }];
  }));
  return res.json({ success: true, message: 'All monitors', data: normalized });
};

export const getReliability = (_req, res) => {
  return res.json({ success: true, message: 'Reliability snapshot', data: getReliabilitySnapshot() });
};

// ─── Persistent 24/7 monitor scheduler ────────────────────────────────────────
// Reconciles dashboard-enabled monitors every minute. The DB flag is the source
// of truth, so enabled tasks resume after process/container restarts.
let persistentMonitorTimer = null;
let persistentSweepInProgress = false;
const PERSISTENT_NO_RESTART_STATUSES = new Set(['success', 'needs_human', 'household_cap', 'payment_locked']);

export const runPersistentMonitorSweep = async () => {
  if (persistentSweepInProgress) return;
  persistentSweepInProgress = true;
  try {
    const tasks = await db('tasks')
      .where({ is_deleted: false, monitor_24_7: true })
      .whereNull('disabled_at')
      .select('*');

    const eligible = tasks.filter((task) =>
      !PERSISTENT_NO_RESTART_STATUSES.has(task.last_status) && !isMonitoring(task.id)
    );
    await runWithConcurrency(eligible, 3, async (task) => {
      await beginMonitorForTask(task).catch((err) =>
        logger.warn(`[24/7] Auto-start failed for task ${task.id}: ${err.message}`)
      );
    });
  } catch (err) {
    logger.error(`[24/7] Persistent monitor sweep failed: ${err.message}`);
  } finally {
    persistentSweepInProgress = false;
  }
};

export const startPersistentMonitorScheduler = () => {
  if (persistentMonitorTimer) return;
  runPersistentMonitorSweep().catch((err) =>
    logger.error(`[24/7] Initial persistent-monitor sweep failed: ${err.message}`)
  );
  persistentMonitorTimer = setInterval(
    () => runPersistentMonitorSweep().catch((err) =>
      logger.error(`[24/7] Persistent-monitor sweep failed: ${err.message}`)
    ),
    60_000
  );
  logger.info('[24/7] Persistent monitor scheduler running (60s reconciliation)');
};

export const stopPersistentMonitorScheduler = () => {
  if (persistentMonitorTimer) {
    clearInterval(persistentMonitorTimer);
    persistentMonitorTimer = null;
  }
};

// ─── Pokemon Center business-hours scheduler ───────────────────────────────────
// Auto-starts monitoring for every eligible Pokemon Center (site_id 6) task at 8am
// ET and auto-stops it at 6pm ET, every day. A 60s sweep compares the desired
// state (open/closed) against reality and reconciles, so it self-heals across
// restarts, DST changes, and mid-day task edits.
let pcSchedulerTimer = null;
let lastPcOpen = null;
let pcSweepInProgress = false;

// Terminal statuses that must NOT be auto-restarted by the sweep. Resurrecting a
// won task would re-fire checkout on a still-in-stock product (duplicate order);
// re-monitoring a needs_human (3DS) task would loop it into the same wall the
// runner deliberately refuses to retry. household_cap tasks are already capped.
const PC_NO_RESTART_STATUSES = new Set(['success', 'needs_human', 'household_cap', 'payment_locked']);

// Task IDs the user manually stopped during the window. The sweep skips these so
// a manual stop isn't reverted within 60s. Cleared on the 8am OPEN transition so
// each new business day starts fresh.
const pcUserStopped = new Set();
export const markPcUserStopped = (taskId) => pcUserStopped.add(taskId);

export const runPcBusinessHoursSweep = async () => {
  if (pcSweepInProgress) return;          // re-entrancy guard: a slow sweep must not overlap the next tick
  pcSweepInProgress = true;
  try {
    if (!(await businessHoursEnabled())) return;

    const open = isWithinBusinessHours();

    // 8am OPEN transition → clear manual-stop memory so the new day starts clean.
    if (open && lastPcOpen !== true) pcUserStopped.clear();

    let tasks = [];
    try {
      tasks = await db('tasks')
        .where({ site_id: PC_SITE_ID, is_deleted: false })
        .whereNull('disabled_at');
    } catch (err) {
      logger.error(`[PCSched] Failed to load Pokemon Center tasks: ${err.message}`);
      return;
    }

    if (open) {
      const eligible = tasks.filter((task) =>
        !isMonitoring(task.id) &&
        !pcUserStopped.has(task.id) &&
        !PC_NO_RESTART_STATUSES.has(task.last_status)
      );
      await runWithConcurrency(eligible, 3, async (task) => {
        await beginMonitorForTask(task).catch((err) =>
          logger.warn(`[PCSched] Auto-start failed for task ${task.id}: ${err.message}`));
      });
    } else {
      const activeTasks = tasks.filter((task) => isMonitoring(task.id));
      await runWithConcurrency(activeTasks, 4, async (task) => {
        await endMonitorForTask(task.id).catch(() => {});
      });
    }

    if (lastPcOpen !== open) {
      logger.info(`[PCSched] Pokemon Center window ${open ? 'OPEN — auto-started monitors' : 'CLOSED — auto-stopped monitors'} (8am–6pm ET, ${tasks.length} task(s))`);
      lastPcOpen = open;
    }
  } finally {
    pcSweepInProgress = false;
  }
};

export const startPcBusinessHoursScheduler = () => {
  if (pcSchedulerTimer) return;
  runPcBusinessHoursSweep().catch((err) => logger.error(`[PCSched] Initial sweep failed: ${err.message}`));
  pcSchedulerTimer = setInterval(
    () => runPcBusinessHoursSweep().catch((err) => logger.error(`[PCSched] Sweep failed: ${err.message}`)),
    60_000
  );
  logger.info('[PCSched] Pokemon Center auto start/stop scheduler running (8am–6pm ET, 60s sweep)');
};

export const stopPcBusinessHoursScheduler = () => {
  if (pcSchedulerTimer) { clearInterval(pcSchedulerTimer); pcSchedulerTimer = null; }
};
